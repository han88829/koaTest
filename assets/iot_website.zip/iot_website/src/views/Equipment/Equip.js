/*
 * @Author: lai.haibo 
 * @Date: 2017-03-24 09:26:23 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-15 15:03:49
 */

import React, { Component } from 'react';
import { Layout, Menu, Icon, message } from 'antd';
import { Link } from 'react-router';
const { Header, Sider, Content } = Layout;
const MenuItemGroup = Menu.ItemGroup;

const routes = {
  equip: [{
    name: '设备管理',
    path: '/equip/manage',
    key: '1'
  }, {
    name: '设备统计',
    path: '/equip/stati',
    key: '2'
  }, {
    name: '设备预警',
    path: '/equip/warning',
    key: '3'
  },
  {
    name: '设备维护',
    path: '/equip/preserve',
    key: '4'
  }
  ],
  typemanage: [{
    name: '类型管理',
    path: '/equip/type/manage',
    key: '5'
  }, {
    name: '品牌管理',
    path: '/equip/brand/manage',
    key: '6'
  }]
}

class Equip extends Component {
  state = {
    collapsed: false,
    seconds: {
      background: '#eaedf1'
    },
    route: routes.equip,
    routeName: '设备管理',
    routeKey: '1',
    data: [true, true, true, true, true, true,],
    display: ''
  };
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
      seconds: {
        background: '#eaedf1',
        display: this.state.collapsed ? 'block' : 'none'
      }
    });
  };
  componentWillMount() {
    if (this.props.children) {
      let path = this.props.children.props.route.path;
      if (path === '/equip/manage') {
        this.setState({
          route: routes.equip,
          routeName: '设备管理',
          routeKey: '1'
        })
      } else if (path === '/equip/type/manage') {
        this.setState({
          route: routes.typemanage,
          routeName: '设置',
          routeKey: '6'
        })
      }
    }
    window.rpc.menu.getInfo().then((res) => {
      let display = res[3].default ? '' : 'none';
      let data = [];
      data.push(res[3].data[0].data[0].default, res[3].data[0].data[1].default, res[3].data[0].data[2].default, res[3].data[0].data[3].default, res[3].data[1].data[0].default, res[3].data[1].data[1].default, )
      this.setState((prevState) => ({ data, display }));
    })
  };
  componentWillReceiveProps(nextProps) {
    let path = nextProps.children.props.route.path;
    if (path === '/equip/type/manage') {
      this.setState({
        route: routes.typemanage,
        routeName: '设置',
        routeKey: '6'
      });
    } else if (path === '/equip/manage(/:type)') {
      this.setState({
        route: routes.equip,
        routeName: '设备管理',
        routeKey: '1'
      });
    }
    let routerkeys = Object.keys(routes);
    let route = [...routes[routerkeys[0]], ...routes[routerkeys[1]]];
    let routeKey = route.filter(x => x.path === path)[0] ? route.filter(x => x.path === path)[0].key : '10000';
    this.setState({
      routeKey
    });
  };
  render() {
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let dtypes = [{ name: '/' }];
      for (let value of result) {
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes', JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.area.getArray(0, 0).then((result) => {
      let locations = [{ name: '/' }];
      for (let value of result) {
        locations[value.id] = value;
      }
      sessionStorage.setItem('locations', JSON.stringify(locations));
    }, (err) => {
      console.warn(err);
      if (err.message == "timeout") {
        message.info("时间延时")
      }
    })
    return (
      <Layout className="Equip">
        <Sider
          trigger={null}
          collapsible
          collapsed={this.state.collapsed}
          style={this.state.seconds}
          width={180}
        >
          <div className="logo" style={{ background: '#eaedf1', height: '70px', lineHeight: '70px', paddingLeft: '24px' }}>{this.state.routeName}</div>
          <Menu theme="light" mode="inline" defaultSelectedKeys={[this.state.routeKey]} selectedKeys={[this.state.routeKey]} style={{ background: '#eaedf1' }}>
            {this.state.route.map(route =>
              (<Menu.Item
                key={route.key}
                disabled={!this.state.data[parseInt(route.key) - 1]} key={route.key}
                style={{ display: this.state.data[parseInt(route.key) - 1] ? '' : 'none', height: '40px' }}
              >
                <Link to={route.path} style={{ color: "#666" }} onClick={() => { sessionStorage.removeItem('equipment') }}>
                  {route.name}
                </Link>
              </Menu.Item>))}
          </Menu>
        </Sider>
        <Layout style={{ padding: '0', position: 'static!important' }}>
          <div className="toggle" style={{ height: '32px', width: '18px', background: this.state.collapsed ? '#eaedf1' : '#fff', textAlign: 'center', position: 'absolute', top: '50vh', marginLeft: this.state.collapsed ? 0 : '-18px' }}>
            <Icon
              className="trigger-right"
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
              onClick={this.toggle}
            />
          </div>
          <Content style={{ display: this.state.display, padding: '20px 16px 0 15px', margin: 0, background: '#fff', minHeight: 280 }}>
            {this.props.children}
          </Content>
          <Content key='2' style={{ display: this.state.display === 'none' ? '' : 'none', padding: 24, margin: 0, textAlign: "center", marginTop: '10%', background: '#fff', fontSize: '2rem', minHeight: 280 }}>
            权限不足！
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Equip;