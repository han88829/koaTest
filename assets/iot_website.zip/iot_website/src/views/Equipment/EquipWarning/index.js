import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, TreeSelect } from 'antd';
import './equipWarning.css';
import listStore from '../listStore';
import moment from 'moment';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

message.config({
  top: 216,
  duration: 2
})

//结构出参量表
const { warningType, resultsType } = listStore;
class appState {
  constructor() {
    extendObservable(this, {
      timer: 0,
      tableData: [],
      add() {
        this.tableData.push({ key: 4, id: 4, sign: '$', name: 'John Brown', dtype: '烟感', warningDate: '2016-09-26 08:50:08', installDate: '2015-09-26 08:50:08', address: 'New York No. 1 Lake Park', condition: '正常', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is John Brown, I am 32 years old, living in New York No. 1 Lake Park.' })
      }
    })
  }
}
class AdvancedSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      types: [],
      data: [],
      builldNames: []
    }
  }
  componentWillMount = () => {
     window.rpc.owner.getId().then(data => {
    //     data=parseInt(data||10)
      window.rpc.area.getArrayBriefByContainer({ownerId: 1, type: 50 },0,0).then(res => {
        let builldNames = res.map(x => ({ ...x }));
        this.setState({ builldNames });
      }, err => {
        console.warn(err)
      })
     }, err => {
       console.warn(err)
     })
    function pushChildren(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp)
      }
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = pushChildren(tableDate);
      this.setState({ data: tableDate });
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const setupTime = fieldsValue['setupTime']||null;
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        const lastPatrolDate = fieldsValue['lastPatrolDate'];
        const rstate = fieldsValue['rstate'];
        const location = fieldsValue['location'];
        let values = {};
        if (name) {
          values = { ...values, name }
        }
        if (lastPatrolDate) {
          values = { ...values, state: fieldsValue['lastPatrolDate'].map(x => parseInt(x, 10)) }
        }
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => parseInt(x, 10)) }
        }
        if (rstate) {
          values = { ...values, rstate: fieldsValue['rstate'].map(x => parseInt(x, 10)) }
        }
        if(setupTime){
             if (setupTime[0]) {
           ////console.log(setupTime);
           values = { ...values, createTime: [new Date(setupTime[0].format('YYY-MM-DD')), new Date(setupTime[1].format('YYY-MM-DD'))] }
         }
        }
        
        if (location) {
          values = { ...values,floor: fieldsValue['location'].map(x => parseInt(x, 10)) };
        }

        window.rpc.device.alarm.getCountByContainer(values).then(res => {
          number = res;
        },err=>{
          console.warn(err)
        })
 
      window.rpc.device.alarm.getCountByContainer(values).then(res => {
          number = res;
     },err=>{
          console.warn(err)
     })
     window.rpc.alias.getValueByName('device.patrol.state').then(res => {
        window.rpc.alias.getValueByName('device.alarm.state').then((info) => {
          window.rpc.device.alarm.getArrayBriefByContainer(values, 0, 0).then(data => {
               //console.log(data);
               let devices =data.map((x) => ({ ...x, dtype: x.typeName, state: res[x.state]||'', location: x.location, key: x.id, rstate: warningType[x.rstate]||'', setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
               this.props.appState.tableData = devices;
          },(err) => {
            console.warn(err);
          })
        },(err) => {
          console.warn(err);
        })
      }, (err) => {
        console.warn(err);
     })
    });
    
    } catch (e) {
      console.warn(e);
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let fildes = this.state.builldNames||[];//JSON.parse(sessionStorage.getItem('locations')) || [];
    let dtypeChildren = [];
    let fildeChildren = [];
    let waringstateChildren = [];
    let destateChildren = [];
    //整组拉所有数据 //console.log(dtypes);
    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of fildes) {
      if (value && value.id && value.type === 50) {
        fildeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < warningType.length; i++) {
      waringstateChildren.push(<Option key={`${i}`}>{warningType[i]}</Option>)
    }
    for (let i = 1; i < resultsType.length; i++) {
      destateChildren.push(<Option key={`${i}`}>{resultsType[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row style={{ margin: '15px 0 15px', height: '32px', lineHight: '32px' }}>
          <Col span={14} >
            <Row>
              <Col span={6} key={1}>
                <FormItem label={`设备名称`}>
                  {getFieldDecorator(`name`)(
                    <Input style={{ width: 140, height: 30 }} placeholder="请输入名称" />
                  )}
                </FormItem>
              </Col>
              <Col span={6} key={2}>
                <FormItem label={`设备类型`}>
                  {getFieldDecorator(`dtype`)(
                    <TreeSelect
                      style={{ width: 140 }}
                      dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                      treeData={this.state.data.filter(x => x.layer === 1)}
                      placeholder="请选择类型"
                      multiple
                    />
                  )}
                </FormItem>
              </Col>
              <Col span={6} key={3}>
                <FormItem label={`预警类型`}>
                  {getFieldDecorator(`rstate`)(
                    <Select multiple style={{ width: 140 }} placeholder="请选择">
                      {waringstateChildren}
                    </Select>
                  )}
                </FormItem>
              </Col>
              <Col span={6} key={4}>
                <FormItem label={`处理结果`}>
                  {getFieldDecorator(`lastPatrolDate`)(
                    <Select multiple style={{ width: 140 }} placeholder="请选择">
                      {destateChildren}
                    </Select>
                  )}
                </FormItem>
              </Col>
            </Row>
          </Col>
          <Col span={10}>
            <Row>
              <Col span={9} key={5}>
                <FormItem label={`所属建筑`}>
                  {getFieldDecorator(`location`)(
                    <Select multiple style={{ width: 150 }} placeholder="请选择">
                      {fildeChildren}
                    </Select>
                  )}
                </FormItem>
              </Col>
              <Col span={11} key={6}>
                <FormItem label={`时间`}>
                  {getFieldDecorator(`setupTime`)(
                    <RangePicker style={{ width: 220 }} />
                  )}
                </FormItem>
              </Col>
              <Col span={4} key={7} className="search-btn" >
                <FormItem style={{ float: 'right', marginRight: '10px' }}>
                  <Button
                    type="primary"
                    onClick={this.handleSearch}
                    style={{ height: '32px', width: '80px', padding: 0, margin: 0, fontSize: '0.75rem' }}
                  >
                    搜索
              </Button>
              </FormItem>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>
    );
  }
}
const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

let number = 0;
const EquipWarningC = observer(class appState extends React.Component {
  componentDidMount() {
    let type = this.props.params;
    let obj = {};
    switch (type.type) {
      case '1':
        obj = { rstate: 1 }
        break;
      case '2':
        obj = { rstate: 2 }
        break;
      case '3':
        obj = { rstate: 3 }
        break;
      default:
        obj = {}
        break;
    }
    window.rpc.device.alarm.getCountByContainer(obj).then(res => {
      number = res;
    })
    window.rpc.alias.getValueByName('device.patrol.state').then(res => {////处理结果
      return window.rpc.device.alarm.getArrayBriefByContainer(obj, 0, 0).then(data => {
        return { res, data }
      })
    }).then((date) => {
      return window.rpc.alias.getValueByName('device.alarm.state').then((info) => { return { ...date, info } })
    }
      ).then((result) => {
        let devices = result.data.filter(x => x).map((x) => ({ ...x, dtype: x.typeName, state: result.res[x.state], location: x.location, key: x.id, rstate: warningType[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
        this.props.appState.tableData = devices;
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) };
    this.setState({ Selected });
  }

  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id != null) {
      browserHistory.push(`/equip/device/info/${this.state.Selected.Id}`);
    } else {
      message.info('请选择设备！');
    }
  }
  //是否删除
  remove = () => {
    if (this.state.Selected.Id != null) {
      window.rpc.device.removeById(this.state.Selected.Id).then((res) => {
        let types = res.map(x => ({ ...x, dtype: x.typeName, key: x.id, rstate: warningType[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
        this.setState({ types });
        this.props.appState.tableData = types;
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    } else {
      message.info('请选择设备！');
    }
  }
  onDelete = (index) => {
    window.rpc.device.removeById(this.state.Selected.Id).then((res) => {
      let types = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark }));
      this.setState({ types });
      this.props.appState.tableData = types;
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })

  }
  cancel() {
    message.error('已取消');
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  add() {
    this.props.appState.tableData.push({ key: 4, id: 4, sign: '$', name: 'John Brown', dtype: '烟感', warningDate: '2016-09-26 08:50:08', installDate: '2015-09-26 08:50:08', address: 'New York No. 1 Lake Park', condition: '正常', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is John Brown, I am 32 years old, living in New York No. 1 Lake Park.' })
  }

  maintain() {
    message.success('保养成功');
  }

  check() {
    message.success('检测成功');
  }

  render() {
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      {
        title: '设备名称', dataIndex: 'deviceName', key: 'deviceName', render: (text, record) => (
          <span>
            <Link to={`/equip/device/${record.key}`} style={{ color: '#0099cc' }}>{text}</Link>
          </span>
        )
      },
      { title: '设备类型', dataIndex: 'deviceTypeName', key: 'deviceTypeName' },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record) => {
          let strs = text.split(",");
          if (strs[2]) {
            return (
              <span>
                <Link to={`/org/floor/${strs[0].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[0].split(':')[1]}</Link>--
                <Link to={`/org/area/cont/${strs[1].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[1].split(':')[1]}</Link>--
                <Link to={`/org/areat/info/${strs[2].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[2].split(':')[1]}</Link>
              </span>
            )
          } else if (strs[1]) {

            return (
              <span>
                <Link to={`/org/floor/${strs[0].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[0].split(':')[1]}</Link>--
                 <Link to={`/org/area/cont/${strs[1].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[1].split(':')[1]}</Link>
              </span>
            )
          } else if (strs[0]) {
            return (
              <span>
                <Link to={`/org/floor/${strs[0].split(':')[0]}`}>{strs[0].split(':')[1]}</Link>
              </span>
            )
          } else if (strs[0].length == 0) {
            <span>{"--"}</span>
          }

        }
      },
      { title: '预警时间', dataIndex: 'lastTime', key: 'lastTime' },
      { title: '预警类型', dataIndex: 'rstate', key: 'rstate' },
      { title: '处理结果', dataIndex: 'state', key: 'state' },
      { title: '处理人', dataIndex: 'userName', key: 'userName' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/equip/device/info/${record.key}`} style={{ color: '#0099cc' }}>查看详情</Link>
          </span>
        )
      },
    ];

    const data = [...this.props.appState.tableData];

    const pagination = {
      total: number,
      showTotal: total => `共 ${number} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
        const pageNum = (parseInt(current, 10) - 1) * 10
        window.rpc.alias.getValueByName('device.patrol.state').then(res => {
          return window.rpc.device.alarm.getArrayBriefByContainer(null, 0, pageNum).then(data => {
            return { res, data }
          })
        }).then((date) => {
          return window.rpc.alias.getValueByName('device.alarm.state').then((info) => { return { ...date, info } })
        }
          ).then((result) => {
            let devices = result.data.filter(x => x).map((x) => ({ ...x, dtype: x.typeName, state: result.info[x.state], location: x.location, key: x.id, rstate: warningType[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
            this.props.appState.tableData = devices;
          }, (err) => {
            console.warn(err);
          })
      },
    };
    return (
      <div className="EquipManage OrgManage" style={{ padding: 0 }}>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/equip/warning' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备预警</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#536679', padding: '0 15px', height: '32px', borderRadius: 0, color: '#fff' }} onClick={this.handleStaffOne}>预警详情</Button>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={data}
              pagination={pagination}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})

class EquipWarning extends Component {
  render() {
    return (
      <EquipWarningC appState={new appState()} params={this.props.params} />
    )
  }
}

export default EquipWarning;