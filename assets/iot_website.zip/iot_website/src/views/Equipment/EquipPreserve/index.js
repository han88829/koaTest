/*
 * @Author: szj
 * @Date: 2017-03-24 19:58:48 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-19 10:45:02
 */

import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, TreeSelect } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
var number = '';
let rStateChildren = [], rState = new Map();
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

let reg = /\,/ig;
let loca = '';
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selected: [],

    })
  }
}

class AdvancedSearchForm extends React.Component {
  state = {
    buildingType: [],
    locations: [],
    data: []
  }
  componentWillMount() {
    function pushChildren(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp)
      }
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = pushChildren(tableDate);
      this.setState({ buildingType: types, data: tableDate });
    })
    window.rpc.area.getArray(0, 0).then((result) => {
      let locations = [];
      for (let value of result) {
        locations[value.id] = value;
      }
      this.setState({
        locations
      })
    }, (err) => {
      console.warn(err);
    })

  }
  componentDidMount() {
    window.rpc.alias.getValueByName('device.rstate').then((res) => {
      for (let value in res) {
        rStateChildren.push(<Option key={`${value}`}>{res[value]}</Option>)
        rState[value] = res[value];
        rState[res[value]] = value;
      }
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['dstate'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        //设备类型
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => parseInt(x, 10)) }
        }
        //运行状态
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        //所属建筑
        if (location) {
          values = { ...values, location: fieldsValue['location'].map(x => x) }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
          window.rpc.device.getArrayBriefByCondContainer({}, values, 0, 0).then((result) => {
            message.info(`共搜索到${result.length}条数据`);
            let loca = '';
            let devi = result.map((x) => ({ ...x, dtype: x.typeName, location: x.location || '', key: x.id, rstate: rstate[x.rstate] || '未知', setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }));
            number = devi.length;
            this.props.appState.tableData = devi;
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    let locations = this.state.locations;
    let dtypeChildren = [];
    let locationChildren = [];

    for (let value of locations) {
      if (value && value.id && value.type === 50) {
        locationChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    let dtypes = this.state.buildingType;

    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row className="PreserveSearch" style={{ padding: '15px 0 15px' }}>
          <Col span={4} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 180 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`类型`}>
              {getFieldDecorator(`dtype`)(
                <TreeSelect
                  style={{ width: 170 }}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.data.filter(x => x.layer === 1)}
                  placeholder="请选择类型"
                  multiple
                />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`状态`}>
              {getFieldDecorator(`dstate`)(
                <Select multiple style={{ width: 180 }} placeholder="请选择">
                  {rStateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`安装位置`}>
              {getFieldDecorator(`location`)(
                <Select multiple style={{ width: 160 }} placeholder="请选择">
                  {locationChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`安装时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{ width: 280 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6} className='search-btn'>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                style={{ height: '32px', width: '80px', padding: 0, margin: 0, fontSize: '0.75em' }}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

const EquipPreserveC = observer(class appState extends React.Component {

  constructor() {
    super();
    this.state = {
      display: "none",
      Selected: [],
      pagenum: "",
      nature: null,
      PreserveType: []
    }
  }
  componentWillMount() {
    window.rpc.cache.alias.getValueByName('task.type').then((res) => {
      let arr = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arr.push(values);
      }
      let PreserveType = arr;
      this.setState({
        PreserveType
      })
    }, (err) => {
      console.warn(err);
    });
  }
  componentDidMount() {
    let type = this.props.params;
    let obj = {};
    switch (type) {
      case 1:
        obj = { rstate: 1 }
        break;
      case 2:
        obj = { rstate: 2 }
        break;
      case 3:
        obj = { rstate: 3 }
        break;
      default:
        obj = {}
        break;
    }
    window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
      window.rpc.device.getArrayBriefByCondContainer({}, obj, 0, 0).then((result) => {
        let loca = '';
        let devices = result.filter(x => x.rstate !== 1).map((x) => ({ ...x, dtype: x.typeName, location: x.location || '', key: x.id, rstate: rstate[x.rstate] || '未知', setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }));
        this.props.appState.tableData = devices;
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      });
    }, (err) => {
      console.warn(err);
    });

  }


  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    this.setState({ Selected });
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }
  //维护更改选择变化
  handleChange = (value) => {
    this.setState({ nature: value });
  }
  natureClick = (index, selectId) => {
    this.setState({ nature: index });
    let Selected = [];
    Selected.push(selectId);
    this.setState({ Selected });
    //存入单个数据
    let dObj = { resId: Selected }
    sessionStorage.setItem('EquipPreserve', JSON.stringify(dObj));
    browserHistory.push(`/equip/preserve/create/${index}`);
  }
  handelClick = (e) => {
    if (this.state.Selected.length !== 0 && this.state.nature) {
      let EquipSelected = this.state.Selected;
      let dObj = { resId: EquipSelected }
      sessionStorage.setItem('EquipPreserve', JSON.stringify(dObj));

      browserHistory.push(`/equip/preserve/create/${this.state.nature}`);
    }

  }
  render() {
    let PreserveTypes = this.state.PreserveType;
    let preTypeLists = [];

    for (let i = 1; i < PreserveTypes.length + 1; i++) {
      if (PreserveTypes[i] ===  "维护") {
        console.log(PreserveTypes[i])
        preTypeLists.push(<Option key={`${i}`}>{PreserveTypes[i]}</Option>)
      } else if (PreserveTypes[i] ===  "更换") {
        console.log(PreserveTypes[i])
        preTypeLists.push(<Option key={`${i}`}>{PreserveTypes[i]}</Option>)
      } else{
        preTypeLists.push(<Option key={`${i}`} disabled >{PreserveTypes[i]}</Option>)
      }
    }

    const rowSelection = {
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
        this.setState.Selected = selected;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.Selected = selected;
      },
    };
    const columns = [
      {
        title: '序号', dataIndex: 'id', key: 'id', render: (text, record) => (
          <span>
            <Link to={`/equipment/device/${record.key}`} style={{ color: '#0099cc' }}>{text}</Link>
          </span>
        ),
      },
      {
        title: '名称', dataIndex: 'name', key: 'name', render: (text, record) => (
          <span>
            <Link to={`/equipment/device/${record.key}`} style={{ color: '#0099cc' }}>{text}</Link>
          </span>
        ),
      },

      { title: '类型', dataIndex: 'dtype', key: 'dtype' },
      { title: '安装日期', dataIndex: 'setupTime', key: 'setupTime' },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record, index) => {
          let strs = `${text}`.split(",");
          if (strs[2]) {
            return (
              <span>
                <Link to={`/org/floor/${strs[0].split(':')[0]}`}>{strs[0].split(':')[1]}</Link>--
               <Link to={`/org/area/cont/${strs[1].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[1].split(':')[1]}</Link>--
               <Link to={`/org/areat/info/${strs[2].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[2].split(':')[1]}</Link>
              </span>
            )
          } else if (strs[1]) {

            return (
              <span>
                <Link to={`/org/floor/${strs[0].split(':')[0]}`}>{strs[0].split(':')[1]}</Link>--
                 <Link to={`/org/area/cont/${strs[1].split(':')[0]}`} style={{ color: '#0099cc' }}>{strs[1].split(':')[1]}</Link>
              </span>
            )
          } else if (strs[0]) {
            return (
              <span>
                <Link to={`/org/floor/${strs[0].split(':')[0]}`}>{strs[0].split(':')[1]}</Link>

              </span>
            )
          } else if (strs[0].length == 0) {
            <span>{"--"}</span>
          }
        }
      },
      { title: '状态', dataIndex: 'rstate', key: 'rstate' },
      { title: '最后巡查日期', dataIndex: 'lastTime', key: 'lastTime' },
      { title: '巡查人', dataIndex: 'userName', key: 'userName' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record, index) => (
          <span>
            <Link to='' onClick={() => this.natureClick(3, record.key)} style={{ color: '#999' }}>维护</Link>
            <span className="ant-divider" />
            <Link to={``} onClick={() => this.natureClick(4, record.key)} style={{ color: '#999' }}>更换</Link>
            <span className="ant-divider" />
            <Link to={`/equip/device/${record.key}`} style={{ color: '#0099cc' }}>查看</Link>
          </span>
        )
      },
    ];
    const data = [...this.props.appState.tableData];
    const pagination = {
      total: number,
      showTotal: total => `共 ${number} 条`,
      pageSize: 10,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (page, pageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * 10;
        this.setState({
          pagenum
        })
        window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
          return window.rpc.device.getArrayBriefByCondContainer(null, null, pagenum, 10).then(device => { return { device, rstate } });
        }).then((data) => {
          let result = data.device
          let devices;
          devices = result.map(x => ({ ...x, dtype: x.typeName, patrolId: x.userName, location: x.location, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
          this.props.appState.tableData = devices;
          this.setState({
            data: this.props.appState.tableData
          })
        }, (err) => {
          console.warn(err);
        })
      },
    };

    return (
      <div className="EquipPreserveManage" >
        <div style={{ overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75em', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/equip/preserve' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备维护</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, fontSize: '0.875em' }} ><Link to={``} onClick={this.handelClick} >批量操作</Link></Button>
          </div>
          <div style={{ float: 'left', width: 100, height: 32, marginRight: 4 }} className='select-small'>
            <Select style={{ width: 100, background: '#d9dee4', height: 32, fontSize: '0.875em', color: '#373d41' }} placeholder="更多操作" onChange={this.handleChange}>
              {preTypeLists}
            </Select>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />

        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={data}
              rowSelection={rowSelection}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})
class EquipPreserve extends Component {
  render() {
    return (
      <EquipPreserveC appState={new appState()} params={this.props.params} />
    )
  }
}

export default EquipPreserve;