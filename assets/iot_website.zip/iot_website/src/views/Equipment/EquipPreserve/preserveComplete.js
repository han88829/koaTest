/*
 * @Author: szj
 * @Date: 2017-03-24 19:58:48 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-01 16:30:43
 */
import React, { Component } from 'react';
import { Button,Steps,Card,Alert} from 'antd';
import { Link } from 'react-router';
import $ from 'jquery';
import './Steps.css';


const Step = Steps.Step;
//const { TabPane } = Tabs;

class  EquipPreserveComplete extends Component {
 componentWillMount(){
     
    let textMessage1="你所提交的信息已经未审核通过，请及时跟进申请状况。";
     // let linksLists = [];
      let Id=this.props.params.id;
      console.log(Id);
      // let linksLists = function(Id){
      //   if(Id!==0){
      //     console.log(Id);
      //     return(<Alert message="成功了" description={textMessage} style={{height:'100px'}} type="success" showIcon/>);
      //   }else{
      //      return(<Alert message="出错了" description={textMessage1} style={{height:'100px'}} type="error" showIcon/>);
      //   }
      //      //return(<div key={`${inps.id}`} id={inps.id}><Row><Col span={2}><span>{inps.name}:</span></Col><Col span={12}><FormItem><Input style={{width:80}} id={`leftValue${inps.id}`} /><span  style={{marginLeft:5}}>{inps.unit}</span></FormItem></Col></Row></div>);
      //   };
        // console.log(linksLists.length);
        if(!Id){
             //$("#reaultPreserveAlarm").html(`<Alert message="出错了" description=${textMessage1} style={{height:'100px'}} type="error" showIcon/>`); 
             //$("#reaultPreserveAlarm").html(`<div>123</div>`);
      }
  }
  render() {
    let arr=[
      {message:"已成功",type:"success"},
      {message:"请注意",type:"Warning"},
      {message:"出错了",type:"error"}
    ];
   let textMessage="你已经成功发布设备维护任务，请及时跟进维护情况。";
    let textMessage1="你所发布的设备维护信息未审核通过，请及时跟进申请状况。";
     // let linksLists = [];
      let Id=parseInt(this.props.params.id,10);
      console.log(Id);
      // let linksLists = function(Id){
      //   if(Id!==0){
      //     console.log(Id);
      //     return(<Alert message="成功了" description={textMessage} style={{height:'100px'}} type="success" showIcon/>);
      //   }else{
      //      return(<Alert message="出错了" description={textMessage1} style={{height:'100px'}} type="error" showIcon/>);
      //   }
      //      //return(<div key={`${inps.id}`} id={inps.id}><Row><Col span={2}><span>{inps.name}:</span></Col><Col span={12}><FormItem><Input style={{width:80}} id={`leftValue${inps.id}`} /><span  style={{marginLeft:5}}>{inps.unit}</span></FormItem></Col></Row></div>);
      //   };
      //   console.log(linksLists.length);    
       
   

    return (
      <div className="EquipPreserveComplete"  style={{ padding:'0 22px'}}>
          <Card style={{height:450}} className="PreserveCard">
               <div style={{padding:'0 0 15px'}}>
                   <p style={{fontSize:'18px',fontFamily:'苹方',fontWeight:'600'}}>维护设置</p> 
               </div>   
               <div >
                 <Steps current={3}>
                   <Step title="选择设备" description="" />
                   <Step title="基础信息" description="" />
                   <Step title="选择人员" description="" />
                   <Step title="完成" description="" />
                 </Steps>
               </div>
                <div style={{marginTop:'60px'}} id="reaultPreserveAlarm">
                  <Alert  type={`${Id?arr[0].type:arr[2].type}`}   message={`${Id?arr[0].message:arr[2].message}`} description={Id?textMessage:textMessage1} style={{height:'100px'}}  showIcon/>
               </div>
         
          </Card> 
          <div style={{position:'absolute',marginTop:30,left:'60%',marginLeft:'-50px'}}>
    
             <div>
                <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#0099cc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to={`/equip/preserve`}>完成</Link></span>
               {/*<Button style={{marginLeft:10}} type="primary"><Link to={`/equip/preserve`}>完成</Link></Button>*/}
             </div>
         </div>
      </div>
    );
  }
}

export default EquipPreserveComplete;