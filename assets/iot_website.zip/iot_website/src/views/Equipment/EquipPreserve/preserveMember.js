/*
 * @Author: szj
 * @Date: 2017-03-24 19:58:48 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:20:41
 */
import React, { Component } from 'react';
import { Button,Steps,Card,Table,Row,Select,Col,Modal,message} from 'antd';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import moment from 'moment';
import './Steps.css';

const Step = Steps.Step;
const {Option}=Select;
//const { TabPane } = Tabs;
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      mData:[],
      selectId: [],
      selectIdOne: null
    })
  }
}


const PopoverPreserve= observer(class appState extends Component {
    constructor() {
    super();
    this.state = {
     data:[],
     selectId:[]
    }
   }
   componentWillMount() {
    window.rpc.user.getArray(0, 0).then((result) => {
      //let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      let users = result.map((x) => ({ ...x, gender:x.gender||'/', ownerId: x.ownerId, level: x.level || '/', groupId: x.groupId, key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      this.props.appState.tableData = users;
      this.setState({data:users});

    }, (err) => {
      console.warn(err);
    })

  }
  state = { visible: false }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
 handleOk=(e)=>{
   //console.log(e);
    this.setState({
      visible: false,
    });
   // console.log(this.state.Selected);
    this.props.appState.selectId = this.state.Selected;
    //console.log(this.state.Selected);
    //{id:[46, 45, 34, 31, 19, 15, 8, 7, 6, 5]},0,0
    window.rpc.user.getArrayByContainer({id:[...this.props.appState.selectId]},0,0).then((result) => {
      //console.log(result);
      //let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      let users = result.map((x) => ({ ...x, gender:x.gender||'/', ownerId: x.ownerId, level: x.level || '/', groupId: x.groupId, key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      this.props.appState.mData  = users;
     // this.setState({data:users});

    }, (err) => {
      console.warn(err);
    })

    //this.props.appState.mData = 
 }
 handleCancel=(e)=>{
   //console.log(e);
    this.setState({
      visible: false,
    });
 }
  onSelectChange = (selectedRowKeys) => {
    //console.log('selectedRowKeys changed: ', selectedRowKeys);
    const Selected=selectedRowKeys;
    console.log(Selected);
    this.setState({ Selected });
  }
  
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      //console.log('Received values of form: ', values);
    });
  }
  render(){
    const rowSelection = {
      //type: 'radio',
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
         this.setState.Selected=selected ;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.Selected=selected ;
      },
    };
    //   let { sortedInfo } = this.state;
    // sortedInfo = sortedInfo || {};
    //filteredInfo = filteredInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      //sorter: (a, b) => a.id - b.id,
      //sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
      //sorter: (a, b) => a.number - b.number,
      //sortOrder: sortedInfo.columnKey === 'number' && sortedInfo.order,
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
            <Link to={`/memb/staff/detail/${record.key}`}>查看</Link>
        </span>
      )
    },
    ];

    //const data = this.state.data;
   // console.log( [...this.props.appState.tableData ]);
    // console.log([...this.props.appState.selectId]);

    const pagination = {
     // total: this.props.appState.tableData.length,
     total: this.state.data.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    return(
       <div >
        <Button type="primary" onClick={this.showModal}>新增人员</Button>
        <Modal title="所有人员" 
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          style={{minWidth:1000,minHeight:600,position: 'absolute',left:'50%',marginLeft: '-340px',padding:'0 22px'}}
          className="MemberModal"
        >
           <Row style={{ padding: '5px 0 0' }}>
              <Col span={24}>
                 <Table
                    bordered
                    columns={columns}
                    dataSource={this.state.data}
                    rowSelection={rowSelection}
                    pagination={ pagination}
                  />
               </Col>
            </Row>
          </Modal>    
       </div>
    )
  }
                   
})
const EquipPreserveMemberC = observer(class appState extends Component {
//class EquipPreserveMember extends Component {

 constructor() {
    super();
    this.state = {
      display: "none",
      removeSelected:[],
      pagenum: "",
      Value:null,
      Id:null
    }
   }
  componentWillMount(){
      var str = window.location.href;
      var index = str.lastIndexOf(`\/`);
      let Id = Number(str.substring(index + 1, str.length));
      console.log(Id);
      this.setState({Id});
  }
  componentDidMount() {
    
  }
  state = {
    visible: false,
  }


  onSelectChange = (selectedRowKeys) => {
    //console.log('selectedRowKeys changed: ', selectedRowKeys);
    const Selected=selectedRowKeys;
    console.log(Selected);
    this.setState({ removeSelected:Selected});
  }
  
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      //console.log('Received values of form: ', values);
    });
  }
  handleChange=(value)=>{
    console.log(`selected ${value}`); 
     this.setState({Value:value}) ;
  }
  removeClick=(value)=>{
 //remove
    console.log(`selected ${value}`); 
     this.setState({Value:value}) ;
  
  }

  handelClick=(e)=>{
    //let a=this.state.Selected;
     console.log(this.state.Value);
     console.log(this.state.removeSelected);
     //let data= [...this.props.appState.tableData ];
     let arrId=[...this.props.appState.selectId];
       console.log(arrId);
     //let Orgtypes = [{name: '/'}];
     if(this.state.Value===1&&arrId.length!==0){
       console.log(this.state.removeSelected);
       let removeId=this.state.removeSelected;
      //  arrId.map((x)=>({

      //  }))
       let newId=[];
       for(let i=0;i<arrId.length;i++){
			   for(let j=0;j<removeId.length;j++){
				    if(arrId[i]===removeId[j]){
                       
            }else{
              newId.push(arrId[i])
            }
		     }
       }
       console.log(newId);
       this.props.appState.selectId=newId;
       let arr1=[...this.props.appState.selectId];
       console.log(arr1);
        window.rpc.user.getArrayByContainer({id:arr1},0,0).then((result) => {
         let users = result.map((x) => ({ ...x, gender:x.gender||'/', ownerId: x.ownerId, level: x.level || '/', groupId: x.groupId, key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
         this.props.appState.mData  = users;
        // this.setState({data:users});

       }, (err) => {
         console.warn(err);
       })

    }
  }
 handelNextClick=()=>{
  // console.log([...this.props.appState.selectId]);
     let MemberId=[...this.props.appState.selectId];
     console.log({user:MemberId});
    
   if(MemberId.length!==0){
     let mObj={userId:MemberId};
     let obj = JSON.parse(sessionStorage.getItem('EquipPreserve'));
     //delete obj1.resId;
     console.log(obj)
   //let obj2 = eval('(' + (JSON.stringify(obj) + JSON.stringify(mObj)).replace(/}{/, ',') + ')');
     //console.log(obj2)
     //sessionStorage.setItem('EquipPreserve', JSON.stringify(obj2));
      let obj3 = {...obj,type:parseInt(obj.type ,10),userId:MemberId.map(x => parseInt(x,10)),beginTime: new Date(obj.beginTime.replace('T', ' ').replace('.000Z', '')),endTime: new Date(obj.endTime.replace('T', ' ').replace('.000Z', '')),resType:1,reportId:parseInt(obj.reportId,10),resId:obj.resId.map(x => parseInt(x,10))}
      console.log(obj3);
      window.rpc.task.create(obj3).then((res,err) => {
         console.log(res);//20
         if(res){
            sessionStorage.removeItem("EquipPreserve");
           browserHistory.push(`/equip/preserve/complete/${res}`);
         }else{
            browserHistory.push(`/equip/preserve/complete/0`);
         }
       }, (err) => {
         console.warn(err);
          function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
          browserHistory.push(`/equip/preserve/complete/0`);
       })
     browserHistory.push(`/equip/preserve/complete/:id`);
   }else{
     message.info("请选择人员");
   }
   //browserHistory
  
 }
  render() {
    //console.log([...this.props.appState.mData]);
    const data=[...this.props.appState.mData];
    const rowSelection = {
      //type: 'radio',
      onChange: this.onSelectChange,
      onSelect:(record, selected, selectedRows) => {
         this.setState.removeSelected=selected ;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.removeSelected=selected ;
      },
    };
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      //sorter: (a, b) => a.id - b.id,
      //sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
      //sorter: (a, b) => a.number - b.number,
      //sortOrder: sortedInfo.columnKey === 'number' && sortedInfo.order,
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
           <Link to={`/memb/staff/detail/${record.key}`}>查看</Link>
        </span>
      )
    },
    ];
     const pagination = {
     // total: this.props.appState.tableData.length,
      //total: this.state.data.length||0,
      total: [...this.props.appState.tableData].length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    return (
        <div className="EquipPreserMember" style={{ padding:'0 22px' }}>
            <Card  style={{minWidth:1000,minHeight:600}} className="PreserveCard" >
               <div style={{padding:'0 0 15px'}}>
                 <p style={{fontSize:'18px',fontFamily:'苹方',fontWeight:'600'}}>维护设置</p> 
               </div>   
               <div style={{padding:'0px'}} className='Steps' >
                 <Steps current={2}  size='default' >
                   <Step title="选择设备" description="" />
                   <Step title="基础信息" description="" />
                   <Step title="选择人员" description="" />
                   <Step title="完成" description="" />
                 </Steps>
               </div>
               <div style={{marginTop:15}}>
                 <div>
                    <Row style={{ padding: '5px 0 15px' }}>
                      <Col span={24}>
                         <PopoverPreserve  appState={this.props.appState}/>
                      </Col>
                   </Row>
                   <Row style={{ padding: '5px 0 15px' }}>
                      <Col span={24}>
                         <Button type="default" style={{ marginRight: '16px' }}><Link to={``} onClick={this.handelClick} >批量操作</Link></Button>
                         {/*<Button type="default" style={{ marginRight: '20px' }}><Link to={``} onClick={this.removeClick} >更多操作</Link></Button>*/}
                         {<Select  style={{width:100}} placeholder="更多操作" onChange={this.handleChange}>
                           <Option key={1}>删除</Option>
                         </Select>}
                      </Col>
                   </Row>
                   <Row style={{ padding: '5px 0 0' }}>
                     <Col span={24}>
                       <Table
                          bordered
                          columns={columns}
                          dataSource={data}
                          rowSelection={rowSelection}
                          pagination={pagination}
                        />
                     </Col>
                   </Row>
                 </div>  
               </div>
             </Card> 
              <div style={{position:'absolute',marginTop:'30px',left:'50%',marginLeft:'-50px'}}>
               <div>
                 <Button onClick={this.handelNextClick} type="primary" style={{height:30,textAlign:'center'}}>下一步</Button>
                 {/*<Button style={{marginLeft:10}}><Link to={`/equip/preserve/create/${this.state.Id}`}>返回修改</Link></Button>*/}
                  <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:80,height:32,borderRadius:0 }}><Link to={`/equip/preserve/create/${this.state.Id}`}>返回修改</Link></span>
               </div>
             </div> 
      </div>
    );
  }
})


class EquipPreserveMember extends Component {
  render() {
    return (
      <EquipPreserveMemberC appState={new appState()} />
    )
  }
}
export default EquipPreserveMember;