const listStore = {
  dStateList: ['/','未知', '合格', '不合格'],
  rStateList: ['/','正常', '异常', '离线'],
  networkModeList: ['/','网关', '4G', 'GSM'],
  patrolTypeList: ['/','巡查', '保养', '检测'],
  patrolStateList: ['/','巡查', '保养', '检测'],
  warningType: ['/','烟感','测温设备','灭火器'],
  resultsType: ['/','测试','已修复','已报警'],
  sexList: ['/','男','女'],
  taskStateList:['/','进行中', '超期', '已完成'],
  taskManList:['/','巡检员A', '巡检员B', '巡检员C','巡检员D'],
  taskTypeList:['/','巡检任务','抽检任务']
}

export default listStore;