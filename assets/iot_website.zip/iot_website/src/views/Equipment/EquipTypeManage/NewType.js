/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:25 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:27:45
 */
import React from 'react';
import { Input, Button, Form, TreeSelect, message, Row, Col, Table, Icon, Popconfirm, Checkbox } from 'antd';
import { Link } from 'react-router';
import './type.css';

const FormItem = Form.Item;


class EditableCell extends React.Component {
  state = {
    value: this.props.value,
    editable: false,
  }
  handleChange = (e) => {
    const value = e.target.value;
    this.setState({ value });
  }
  check = () => {
    this.setState({ editable: false });
    if (this.props.onChange) {
      this.props.onChange(this.state.value);
    }
  }
  edit = () => {
    this.setState({ editable: true });
  }
  render() {
    const { value, editable } = this.state;
    return (
      <div className="editable-cell">
        {
          editable ?
            <div className="editable-cell-input-wrapper">
              <Input
                value={value}
                onChange={this.handleChange}
                onPressEnter={this.check}
              />
              <Icon
                type="check"
                className="editable-cell-icon-check"
                onClick={this.check}
              />
            </div>
            :
            <div className="editable-cell-text-wrapper">
              {value || ' '}
              <Icon
                type="edit"
                className="editable-cell-icon"
                onClick={this.edit}
              />
            </div>
        }
      </div>
    );
  }
}


class EditableTable extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [{
      title: '名称',
      dataIndex: 'name',
      width: '30%',
      render: (text, record, index) => (
        <EditableCell
          value={text}
          onChange={this.onCellChange(index, 'name')}
        />
      ),
    }, {
      title: '单位',
      dataIndex: 'unit',
      render: (text, record, index) => (
        <EditableCell
          value={text}
          onChange={this.onCellChange(index, 'unit')}
        />
      ),
    }, {
      title: '区间值或单值',
      dataIndex: 'single',
      render: (text, record, index) => (
        <Checkbox onChange={this.onCellChange(index, 'single')}>单值打勾,区域值不勾</Checkbox>
      ),
    }, {
      title: '操作',
      dataIndex: 'operation',
      render: (text, record, index) => {
        return (
          this.state.dataSource.length > 0 ?
            (
              <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(index)}>
                <a href="#">删除</a>
              </Popconfirm>
            ) : null
        );
      },
    }];

    this.state = {
      dataSource: [],
      count: 2,
    };
  }
  onCellChange = (index, key) => {
    return (value) => {
      const dataSource = [...this.state.dataSource];
      dataSource[index][key] = value;
      this.setState({ dataSource });
      var newObj, sing = "";
      newObj = (JSON.parse(JSON.stringify(dataSource)) || {});
      for (var i = 0; i < newObj.length; i++) {
        if (newObj[i].single !== "1") {
          if (newObj[i].single.target.checked) {
            sing = 1;
          } else {
            sing = 0;
          }
        } else {
          sing = 0;
        }

        newObj[i].single = sing;
        delete newObj[i].key
      }
      setTimeout(() => {
        sessionStorage.setItem('datasource', JSON.stringify(newObj))
      }, 100)

    };
  }
  onDelete = (index) => {
    const dataSource = [...this.state.dataSource];
    dataSource.splice(index, 1);
    this.setState({ dataSource });
  }
  handleAdd = () => {
    const { count, dataSource } = this.state;
    const newData = {
      key: count,
      name: "请输入名字",
      unit: "请输入单位",
      single: "1",
    };
    this.setState({
      dataSource: [...dataSource, newData],
      count: count + 1,
    });

  }
  render() {
    const { dataSource } = this.state;
    const columns = this.columns;
    return (
      <div>
        <Button className="editable-add-btn" onClick={this.handleAdd}>添加</Button>
        <Table bordered dataSource={dataSource} columns={columns} />
      </div>
    );
  }
}
const NewTypes = Form.create()(React.createClass({
  getInitialState() {
    return {
      value: undefined,
      types: [],
      data: []
    };
  },
  componentWillMount() {
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      loop(tableDate)
      this.setState({ types, data: tableDate });
    }, (err) => {

    })
  },
  handleSubmit(e) {
    //alert(1)
    this.props.form.setFieldsValue({
      flags: JSON.parse(sessionStorage.getItem('datasource')) || []
    });
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let obj = { ...values, parentId: parseInt(values.parentId, 10) }
        window.rpc.device.types.create(obj).then(() => {
          message.info('创建成功！')
          setTimeout(function () {
            window.location.href = '/equip/type/manage';
          }, 1000)
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    message.info(`暂无权限!`);  }    } existError(err);
        })
      }
    });
  },
  onChange(value) {
    this.setState({ value });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 1 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    return (
      <div>
        <div style={{ fontSize: '0.75em', overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75em', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>类型新建</Link>
          </div>
        </div>
        <Row>
          <Col span={2}></Col>
          <Col span={22}>
            <Form onSubmit={this.handleSubmit} className="NewTypes" style={{ padding: 24 }}>
              <FormItem
                {...formItemLayout}
                label="上级类型"
              >
                {getFieldDecorator('parentId', {
                  valuePropName: 'checked',
                  initialValue: undefined,
                  rules: [{ required: true, message: 'Please input your username!' }]
                })(
                  <TreeSelect
                    style={{ width: 300 }}
                    value={this.state.value}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.data.filter(x => x.layer === 1)}
                    placeholder="Please select"
                    treeDefaultExpandAll
                    onChange={this.onChange}
                  />
                  )}
              </FormItem>
              <FormItem
                {...formItemLayout}
                label="名称"
              >
                {getFieldDecorator('name', {
                  rules: [{ required: true, message: 'Please input your username!' }],
                })(
                  <Input />
                  )}
              </FormItem>
              <FormItem
                {...formItemLayout}
                label="属性"
              >
                {getFieldDecorator('flags', {
                  rules: [{ required: true, message: 'Please input your username!' }],
                })(
                  <EditableTable />
                  )}
              </FormItem>
              <FormItem
                {...tailFormItemLayout}
              >
              </FormItem>
              <Row style={{ marginLeft: 76, marginTop: 400 }}>
                <Button type="primary" htmlType="submit"> 创建</Button>
                <Button type="success" style={{ marginLeft: 10 }}><Link to="/equip/type/manage">返回</Link></Button>
              </Row>
            </Form>
          </Col>

        </Row>
      </div>
    );
  },
}));


export default NewTypes;