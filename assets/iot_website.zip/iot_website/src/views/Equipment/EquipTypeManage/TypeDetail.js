import React, { Component } from 'react';
import { Link } from "react-router";
import { Row, Col, Form, Button } from 'antd';
import './type.css';

let parent;
class EquipTypeDetail extends Component {
  constructor() {
    super();
    this.state = {
      "parent": "",
      "name": "",
      "property": ""
    }
  }
  componentDidMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = Number(str.substring(index + 1, str.length));
    window.rpc.device.types.getInfoExById(str).then((res) => {
      let property = "";
      res.flags.forEach(function (value) {
        property += `${value.name}${value.unit}--`
      })
      if (res.parentId <= 0) {
        parent = '无';
        this.setState({
          "parent": parent,
          "name": res.name,
          "property": property
        })
      } else {
        window.rpc.device.types.getInfoById(res.parentId).then((result) => {
          parent = result.name;
          this.setState({
            "parent": parent,
            "name": res.name,
            "property": property
          })
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }

    }, (err) => {
      console.warn(err);
    })
  }
  render() {
    return (
      <div>
        <div style={{ fontSize: '0.75em', overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75em', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>类型详情</Link>
          </div>
        </div>
        <Form className="sorts">
          <div className="buildCard" style={{ fontsize: '0.75em', color: '#373e41' }}>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"> 归属：{this.state.parent}</div>
                <div className="Row-info-left"> 名称：{this.state.name}</div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75em', color: '#373e41' }}>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"> 属性：{this.state.property}</div>
              </div>
            </div>
          </div>
          <Row style={{ left: "10%" }}>
            <Col span={7} style={{ textAlign: 'left' }}>
              <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginTop: 140, marginRight: 10 }}><Link to="/equip/type/manage">返回</Link></Button>
            </Col>
          </Row>
        </Form>
      </div>
    )
  }
}

export default EquipTypeDetail;