import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Radio, Card, Form, message } from 'antd';
import echarts from 'echarts';
import moment from 'moment';
import './deivceWarnning.css'

const FormItem = Form.Item;
let nowday = new Date();
let beginTime = '';
let lastTime = moment(nowday).format('YYYY-MM-DD');
const { RangePicker } = DatePicker;

function datearr(res, constantData, dateArr) {
	let nDtate = [], dataYarr = [], tableDate = [], nameTable = [], arr = [], flag = 1, switcs = null;
	for (let i in res) {
		for (let j in constantData) {
			for (let z in res[i]) {
				if (z == j) arr.push({ name: i, value: res[i] })
				else arr.push({ name: j, value: { [j]: 0 } })
				tableDate.push({ name: constantData[i], constantData: [] })
			}
		}
	}
	for (let j in constantData) {
		nameTable.push(constantData[j])
		dateArr.forEach((x, i) => {
			dataYarr.push([x, constantData[j]]);
		})
	}
	if (arr.length > 0) {
		dataYarr.forEach((x, index) => {
			arr.forEach((y, i) => {
				if (y.name === x[0]) {
					for (let z in y.value) {
						if (constantData[z] === x[1]) {
							dataYarr[index].push(y.value[z])
							break;
						} else {
							dataYarr[index].push(0)
							break;
						}
					}
				} else {
					if (switcs !== index) {
						flag = 1;
						dataYarr[index].push(0);
					} else {
						flag = 0;
					}
					switcs = index;
				}
			})
		})
	} else {
		dataYarr.forEach((y, i) => {
			dataYarr[i].push(0);
		})
	}
	dataYarr.forEach((x, i) => {
		if (x.length > 3) {
			if (x[2] > 0) {
				x.splice(3, 1)
			} else {
				x.splice(2, 1)
			}
		}
		var type = x[1];
		x[1] = x[2];
		x[2] = type;
		nDtate.push(x[1])
	})
	return nDtate
}

class deviceState {
	constructor() {
	}
}

const TrendSearchFormUp = Form.create()(React.createClass({

	componentWillMount() {
		let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
		let month = date.getMonth() + 1;
		let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
		beginTime = moment(weekday).format('YYYY-MM-DD');
		this.changeTimeData(1);
	},
	changeTimeData(timeType) {
		/*图表一*/
		let timeDate = 'date';
		if (timeType === 2) {
			timeDate = 'month';
		} else if (timeType === 3) {
			timeDate = 'month';
		}

		window.rpc.alias.getValueByName('device.alarm.type').then(result => {
			return window.rpc.device.alarm.getTrendCountTypeByContainer({ createTime: [new Date(beginTime), new Date(lastTime)] }, timeDate).then(data => { return { result, data } })
		}).then(res => {
			const info = res.data;
			let arr = [];
			for (var i in res.result) {
				arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
			}
			let typeNameArr = arr.map(x => x.name);
			let timeArr = [];
			const reducs = (new Date(lastTime).getTime() - new Date(beginTime).getTime()) / 86400 / 1000;
			if (timeType === 1) {
				//周
				let dateTime = '';
				for (let i = 6; i >= 0; i--) {
					dateTime = new Date(nowday.getTime() - i * 24 * 3600 * 1000);
					timeArr.push(moment(dateTime).format('YYYY-MM-DD'));
				}
			} else if (timeType === 2) {
				//月
				let monthTime = nowday.getFullYear() + "-" + nowday.getMonth();
				timeArr.push(moment(monthTime).format('YYYY-MM'));
			} else if (timeType === 3) {
				let seaconTime = ''
				for (let i = -1; i <= 1; i++) {
					seaconTime = nowday.getFullYear() + "-" + (nowday.getMonth() + i);
					timeArr.push(moment(seaconTime).format('YYYY-MM'));

				}
			} else {

				for (let i = reducs; i >= 0; i--) {
					(function () {
						timeArr.push(`${new Date(lastTime).getFullYear()}-${(new Date(lastTime).getMonth() + 1).toString().length === 1 ? '0' + (new Date(lastTime).getMonth() + 1) : (new Date(lastTime).getMonth() + 1)}-${((new Date(lastTime).getDate() - i).toString().length === 1 ? '0' + (new Date(lastTime).getDate() - i) : (new Date(lastTime).getDate() - i))}`)
					})(i)
				}
			}

			//具体数据
			//const valueArr = arr.map(x => x.value);

			const valueArr = datearr(info, typeNameArr, timeArr);
			let num = 7;
			if (timeType === 2) {
				num = 1;
			} else if (timeType === 3) {
				num = 3;
			} else if (timeType === 5) {
				num = reducs + 1;
			}
			let data = [], num1 = 0;
			for (let i = 0; i < typeNameArr.length; i++) {
				for (let j = num1 * num; j < valueArr.length; j++) {
					data.push([i, (j - num1 * num), valueArr[j]]);
					if ((j + 1) % num === 0) {
						num1++; break;
					}
				}
			}
			let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
			let option = {
				tooltip: {
					position: 'top'
				},
				title: [],
				singleAxis: [],
				series: [],
				color: ['rgba(255,0,0,0.5)', 'rgba(5,127,63,0.5)', 'rgba(221,193,81,0.5)', 'rgba(102,102,102,0.5)']
			};
			echarts.util.each(typeNameArr, function (day, idx) {
				option.title.push({
					top: 10,
					left: 10,
					text: '报警趋势',
					x: 'left',
					textStyle: {
						fontFamily: '微软雅黑',
						color: "#666666",
						fontSize: '14px'
					}
				});
				option.title.push({
					textBaseline: 'top',
					top: (idx + 0.5) * 100 / 4 + '%',
					text: day,
					textStyle: {
						color: '#373d41',
						fontFamily: '苹方中等',
						fontSize: '0.75em'

					}
				});
				option.singleAxis.push({
					left: 100,
					type: 'category',
					boundaryGap: false,
					data: timeArr,
					top: (idx * 100 / 4 + 5) + '%',
					height: (100 / 4 - 10) + '%',
					axisLabel: {
						interval: 0
					}
				});
				option.series.push({
					singleAxisIndex: idx,
					coordinateSystem: 'singleAxis',
					type: 'scatter',
					data: [],
					symbolSize: function (dataItem) {
						return dataItem[1] * 0.5;
					}
				});
			});

			echarts.util.each(data, function (dataItem) {
				option.series[dataItem[0]].data.push([dataItem[1], dataItem[2]]);
			});
			myChartOne.setOption(option);

		},err=>{
			 function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
		})

		/*图表二*/
		window.rpc.alias.getValueByName('device.alarm.type').then(result => {
			return window.rpc.device.alarm.getCountFieldByContainer({ createTime: [new Date(beginTime), new Date(lastTime)] }, 'type').then(data => { return { result, data } })
		}).then(res => {
			const info = res.data;
			let arr = [];
			for (var i in res.result) {
				arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
			}
			this.props.deviceState.patrolData = arr
			this.setState({
				data: arr
			})
			const deviceAlarm = arr.map(x => ([x.createTime, x.value, x.name]))
			const pieAlarm = arr.map(x => ({ value: x.value, name: x.name }))
			let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));

			myChartTwo.setOption({
				title: {
					top: 10,
					left: 10,
					text: '报警占比',
					x: 'left',
					textStyle: {
						font: '14px 微软雅黑 Light',
						color: "#666666"
					}
				},
				legend: {
					orient: 'vertical',
					x: 'left',
					y: 'middle',
					data: arr.map(x => x.name)
				},
				tooltip: {
					trigger: 'item',
					formatter: "{a} <br/>{b} : {c} ({d}%)"
				},
				calculable: true,
				series: [
					{
						type: 'pie',
						radius: [20, 110],
						center: ['45%', '50%'],
						roseType: 'radius',
						label: {
							normal: {
								show: true
							},
							emphasis: {
								show: true
							}
						},
						lableLine: {
							normal: {
								show: false
							},
							emphasis: {
								show: true
							}
						},
						data: pieAlarm
					}
				],
				color: ['#d53b34', '#10eedc', '#a1d91b', '#fec100']
			});

		})
	},
	handleSearch(e) {
		e.preventDefault();
		try {
			this.props.form.validateFields((err, fieldsValue) => {
				const targetTime = fieldsValue['targetTime'];
				beginTime = targetTime[0].format('YYYY-MM-DD');
				lastTime = targetTime[1].format('YYYY-MM-DD');
				this.changeTimeData(5);
			});

		} catch (e) {
			console.warn(e);
		}
	},
	onChangeTop(e) {
		switch (e.target.value) {
			case 'week':
				let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
				let month = date.getMonth() + 1;
				let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
				beginTime = moment(weekday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(1);
				break;
			case 'month': {
				let monthday = nowday.getFullYear() + '-' + nowday.getMonth() + '-' + nowday.getDate();
				beginTime = moment(monthday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(2);
				break;
			}
			case 'seacon': {
				let seaconday = nowday.getFullYear() + '-' + (nowday.getMonth() - 2) + '-' + nowday.getDate();
				beginTime = moment(seaconday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(3);
				break;
			}
			default: {

			}
		}
	},
	render() {
		const { getFieldDecorator } = this.props.form;

		return (
			<Form layout="inssline" style={{ margin: '20px 0' }}>
				<Row>
					<Col style={{ float: "left", marginRight: 20 }} key={1}>
						<FormItem>
							{getFieldDecorator('chooseTime', {
								initialValue: 'week'
							})(
								<Radio.Group onChange={this.onChangeTop}>
									<Radio.Button value="week">周</Radio.Button>
									<Radio.Button value="month">月</Radio.Button>
									<Radio.Button value="seacon">季</Radio.Button>
								</Radio.Group>
								)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={2}>
						<FormItem label={`时间`}>
							{getFieldDecorator(`targetTime`)(
								<RangePicker
									showTime
									format="YYYY-MM-DD"
									placeholder={['开始日期', '结束日期']}
									style={{ width: 200 }} />
							)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={3}>
						<FormItem>
							<Button
								type="primary"
								onClick={this.handleSearch}
							>
								搜索
              </Button>
						</FormItem>
					</Col>
				</Row>
			</Form>
		);
	}
}));

const TrendSearchFormDown = Form.create()(React.createClass({
	componentWillMount() {
		let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
		let month = date.getMonth() + 1;
		let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
		beginTime = moment(weekday).format('YYYY-MM-DD');
		this.changeTimeData(1);
	},
	changeTimeData(timeType) {
		/*图表三*/
		let timeDate = 'date';
		if (timeType === 2) {
			timeDate = 'month';
		} else if (timeType === 3) {
			timeDate = 'month';
		}
		window.rpc.alias.getValueByName('device.patrol.type').then(result => {
			return window.rpc.device.patrol.getTrendCountTypeByContainer({ createTime: [new Date(beginTime), new Date(lastTime)] }, timeDate).then(data => { return { result, data } })
		}).then(res => {
			const info = res.data;
			let arr = [];
			for (var i in res.result) {
				arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
			}
			let typeNameArr = arr.map(x => x.name);
			let timeArr = [];
			const reducs = (new Date(lastTime).getTime() - new Date(beginTime).getTime()) / 86400 / 1000;
			if (timeType === 1) {
				//周
				let dateTime = '';
				for (let i = 6; i >= 0; i--) {
					dateTime = new Date(nowday.getTime() - i * 24 * 3600 * 1000);
					timeArr.push(moment(dateTime).format('YYYY-MM-DD'));
				}
			} else if (timeType === 2) {
				//月
				let monthTime = nowday.getFullYear() + "-" + nowday.getMonth();
				timeArr.push(moment(monthTime).format('YYYY-MM'));
			} else if (timeType === 3) {
				let seaconTime = ''
				for (let i = -1; i <= 1; i++) {
					seaconTime = nowday.getFullYear() + "-" + (nowday.getMonth() + i);
					timeArr.push(moment(seaconTime).format('YYYY-MM'));

				}
			} else {

				for (let i = reducs; i >= 0; i--) {
					(function () {
						timeArr.push(`${new Date(lastTime).getFullYear()}-${(new Date(lastTime).getMonth() + 1).toString().length === 1 ? '0' + (new Date(lastTime).getMonth() + 1) : (new Date(lastTime).getMonth() + 1)}-${((new Date(lastTime).getDate() - i).toString().length === 1 ? '0' + (new Date(lastTime).getDate() - i) : (new Date(lastTime).getDate() - i))}`)
					})(i)
				}
			}
			const valueArr = datearr(info, typeNameArr, timeArr);
			let num = 7;
			if (timeType === 2) {
				num = 1;
			} else if (timeType === 3) {
				num = 3;
			} else if (timeType === 5) {
				num = reducs + 1;
			}

			let data = [], num1 = 0, valueData = [];
			for (let i = 0; i < typeNameArr.length; i++) {
				for (let j = num1 * num; j < valueArr.length; j++) {
					data.push(valueArr[j]);
					if ((j + 1) % num === 0) {
						valueData.push({
							name: typeNameArr[i],
							type: 'bar',
							data: data,
							markPoint: {
								data: [
									{ type: 'max', name: '最大值' },
									{ type: 'min', name: '最小值' }
								]
							},
							markLine: {
								data: [
									{ type: 'average', name: '平均值' }
								]
							}
						})
						num1++;
						data = [];
						break;
					}
				}
			}
			let myChartThree = echarts.init(document.getElementById('DeviceTypeMountEcharts03'));
			myChartThree.setOption({
				title: {
					top: 10,
					left: 10,
					x: 'left',
					text: '维护趋势',
					textStyle: {
						font: '14px 微软雅黑 Light',
						color: "#666666"
					}
				},
				color: ['#d53b36', '#fec101', '#a1d91b'],
				tooltip: {
					trigger: 'axis'
				},
				legend: {
					data: typeNameArr
				},

				calculable: true,
				xAxis: [
					{
						type: 'category',
						data: timeArr,
					}
				],
				yAxis: [
					{
						type: 'value'
					}
				],
				series: valueData

			});

		})

		/*图表四*/
		window.rpc.alias.getValueByName('device.patrol.type').then(result => {
			return window.rpc.device.patrol.getCountFieldByContainer({ createTime: [new Date(beginTime), new Date(lastTime)] }, 'type').then(data => { return { result, data } })
		}).then(res => {
			const info = res.data;
			let arr = [];
			for (var i in res.result) {
				arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
			}
			this.props.deviceState.patrolData = arr
			this.setState({
				data: arr
			})
			const deviceAlarm = arr.map(x => ([x.createTime, x.value, x.name]))
			const text = arr.map(x => ({ text: x.name }))
			const textName = arr.map(x => x.name)
			const textValue = arr.map(x => x.value)
			let myChartFour = echarts.init(document.getElementById('DeviceTypeMountEcharts04'));
			myChartFour.setOption({
				title: {
					top: 10,
					left: 10,
					text: '维护占比',
					x: 'left',
					textStyle: {
						font: '14px 微软雅黑 Light',
						color: "#666666"
					}
				},
				tooltip: {
					trigger: 'axis'
				},
				radar: [
					{
						indicator: text,
						center: ['45%', '65%'],
						radius: 140
					},

				],
				name: {
					show: true,
					formatter: textName,
					textStyle: {
						font: '0.75em 苹方中等',
						color: "#373d41"
					}
				},
				series: [
					{
						type: 'radar',
						tooltip: {
							trigger: 'item'
						},
						itemStyle: { normal: { areaStyle: { type: 'default' } } },
						data: [
							{
								value: textValue,
								name: '维护占比'
							}
						]
					},

				],
				color: ['rgba(255,0,0,0.5)', '#fff', '#d4d4d4']
			})
		})
	},

	handleSearch(e) {
		e.preventDefault();
		try {
			this.props.form.validateFields((err, fieldsValue) => {
				const targetTime = fieldsValue['targetTime'];
				beginTime = targetTime[0].format('YYYY-MM-DD');
				lastTime = targetTime[1].format('YYYY-MM-DD');
				this.changeTimeData(5);
			});

		} catch (e) {
			console.warn(e);
		}
	},

	onChangeBottom(e) {
		switch (e.target.value) {
			case 'week':
				let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
				let month = date.getMonth() + 1;
				let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
				beginTime = moment(weekday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(1);
				break;
			case 'month': {
				let monthday = nowday.getFullYear() + '-' + nowday.getMonth() + '-' + nowday.getDate();
				beginTime = moment(monthday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(2);
				break;
			}
			case 'seacon': {
				let seaconday = nowday.getFullYear() + '-' + (nowday.getMonth() - 2) + '-' + nowday.getDate();
				beginTime = moment(seaconday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(3);
				break;
			}
			default: {

			}
		}
	},
	render() {
		const { getFieldDecorator } = this.props.form;

		return (
			<Form layout="inline" style={{ margin: '20px 0' }}>
				<Row>
					<Col style={{ float: "left", marginRight: 20 }} key={1}>
						<FormItem>
							{getFieldDecorator('chooseTime', {
								initialValue: 'week'
							})(
								<Radio.Group onChange={this.onChangeBottom}>
									<Radio.Button value="week">周</Radio.Button>
									<Radio.Button value="month">月</Radio.Button>
									<Radio.Button value="seacon">季</Radio.Button>
								</Radio.Group>
								)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={2}>
						<FormItem label={`时间`}>
							{getFieldDecorator(`targetTime`)(
								<RangePicker
									showTime
									format="YYYY-MM-DD"
									placeholder={['开始日期', '结束日期']}
									style={{ width: 200 }} />
							)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={3}>
						<FormItem>
							<Button
								type="primary"
								onClick={this.handleSearch}
							>
								搜索
              </Button>
						</FormItem>
					</Col>
				</Row>
			</Form>
		);
	}
}));

@observer
class DeviceTrendC extends Component {
	constructor() {
		super();
		this.state = {
			size: 'default'
		};
	}

	componentDidMount() {

	}


	render() {
		return (
			<div className="DeviceTrend" style={{ height: '85vh' }}>
				<TrendSearchFormUp deviceState={this.props.deviceState} />
				<Row gutter={16}>
					<Col span={14}>
						<Card>
							<div id="DeviceTypeMountEcharts01" style={{ height: '33vh', width: '100%' }}></div>
						</Card>
					</Col>
					<Col span={10}>
						<Card>
							<div id="DeviceTypeMountEcharts02" style={{ height: '33vh', width: '100%' }}></div>
						</Card>
					</Col>
				</Row>
				<TrendSearchFormDown deviceState={this.props.deviceState} />
				<Row gutter={16}>
					<Col span={14}>
						<Card>
							<div id="DeviceTypeMountEcharts03" style={{ height: '33vh', width: '100%' }}></div>
						</Card>
					</Col>
					<Col span={10}>
						<Card>
							<div id="DeviceTypeMountEcharts04" style={{ height: '33vh', width: '100%' }}></div>
						</Card>
					</Col>
				</Row>
			</div >
		);
	}
}

class DeviceTrend extends Component {
	render() {
		return (
			<DeviceTrendC deviceState={new deviceState()} />
		)
	}
}

export default DeviceTrend;