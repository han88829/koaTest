import React, { Component } from 'react';
import { Row, Col, Card, Table } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import echarts from 'echarts';

class typeMountState {
	constructor() {
		extendObservable(this, {
			tableData: []
		})
	}
}

const columns = [{
	title: '设备类型',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '设备数量',
	dataIndex: 'value',
	key: 'value',
}];

// 取出类型和locations
let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];

@observer
class DeviceTypeMountC extends Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			parentType: [],
			data: []
		};
	}

	onChangeDate(date, dateString) {
	}

	handleSizeChange = (e) => {
		this.setState({ size: e.target.value });
	}

	componentWillMount() {
		function pushChildren(data) {
			let arr = [...data];
			let layer = arr.map(x => x.layer).sort((a, b) => b - a)[0];
			let layerNow = arr.filter(x => x.layer === layer);
			let layerUp = arr.filter(x => x.layer !== layer);
			let parentDataA = layerUp.map(x => ({ ...x, key: x.id, value: x.value, name: x.name }));

			for (let i = 0; i < layerUp.length; i++) {
				for (let j = 0; j < layerNow.length; j++) {
					if (layerNow[j].parentId === layerUp[i].id) {
						if (layerUp[i].children) {
							layerUp[i].value += layerNow[j].value
							layerUp[i].children.push({ ...layerNow[j], key: `${layerNow[j].id}-${layer}` });
						} else {
							layerUp[i].value += layerNow[j].value
							layerUp[i].children = [{ ...layerNow[j], key: `${layerNow[j].id}-${layer}` }];
						}
					}
				}
			}
			if (layer === 2) {
				return layerUp;
			} else {
				pushChildren(layerUp);
			}
		}
		window.rpc.device.types.getArray(0, 0).then(result => {
			return window.rpc.device.getCountFieldByContainer({}, 'dtype').then(data => ({ result, data }))
		}).then((res) => {
			let tableDate = res.result.filter(x => x).map(x => ({ ...x, key: x.id, value: res.data[x.id] || 0 })).filter(x => x.id);
			pushChildren(tableDate)
			this.setState({
				data: tableDate
			})
			this.props.typeMountState.tableDate = tableDate;
			var dataAxis = this.state.data.filter(x => x.layer === 1 ).map(x => x.name);
			var data = this.state.data.filter(x => x.layer === 1).map(x => x.value);
			var dataShadow = [];
			let myChart = echarts.init(document.getElementById('DeviceTypeMountEcharts'));

			myChart.setOption({
				legend: {
					orient: 'vertical',
					left: '40',
					data: ['设备类型','设备数量']
				},
				xAxis: {
					data: dataAxis,
					axisLabel: {
						inside: true,
						textStyle: {
							color: '#fff'
						}
					},
					axisTick: {
						show: false
					},
					axisLine: {
						show: false
					},
					z: 10
				},
				yAxis: {
					axisLine: {
						show: false
					},
					axisTick: {
						show: false
					},
					axisLabel: {
						textStyle: {
							color: '#999'
						}
					}
				},
				dataZoom: [
					{
						type: 'inside'
					}
				],
				series: [
					{ // For shadow
						name:'设备类型',
						type: 'bar',
						itemStyle: {
							normal:{
								color: new echarts.graphic.LinearGradient(
									0, 0, 0, 1,
									[
										{ offset: 0, color: '#cbe876' },
										{ offset: 0.5, color: '#a3c95f' },
										{ offset: 1, color: '#b7e860' }
									]
								)
							}
						},
						barGap: '-100%',
						barCategoryGap: '40%',
						data: dataShadow,
						animation: false
					},
					{
						type: 'bar',
						itemStyle: {
							normal: {
								color: new echarts.graphic.LinearGradient(
									0, 0, 0, 1,
									[
										{ offset: 0, color: '#cbe876' },
										{ offset: 0.5, color: '#a3c95f' },
										{ offset: 1, color: '#b7e860' }
									]
								)
							},
							emphasis: {
								color: new echarts.graphic.LinearGradient(
									0, 0, 0, 1,
									[
										{ offset: 0, color: '#33cd03' },
										{ offset: 0.7, color: '#4bdf1d' },
										{ offset: 1, color: '#29ec32' }
									]
								)
							}
						},
						data: data
					}
				]
			});
			var zoomSize = 6;
			myChart.on('click', function (params) {
				myChart.dispatchAction({
					type: 'dataZoom',
					startValue: dataAxis[Math.max(params.dataIndex - zoomSize / 2, 0)],
					endValue: dataAxis[Math.min(params.dataIndex + zoomSize / 2, data.length - 1)]
				});
			});
		}, (err) => {
			console.warn(err);
			 function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
		});
	}

	render() {
		return (
			<div className="DeviceTypeMount" >
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{marginTop:16,marginBottom:10,fontSize:12,color:"#111",fontFamily:"PingFang-SC-Medium"}}>设备类型占比</p>
					<div id="DeviceTypeMountEcharts" style={{ height: '50vh', width: '100%',border:"1px solid #ccc"}}></div>
				</Row>
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{marginTop:16,marginBottom:10,fontSize:12,color:"#111",fontFamily:"PingFang-SC-Medium"}}>设备类型数量统计</p>
					<Table dataSource={this.state.data.filter(x => x.layer === 1)} bordered columns={columns} pagination={false} />
				</Row>
			</div>
		);
	}
}

class DeviceTypeMount extends Component {
	render() {
		return (
			<DeviceTypeMountC typeMountState={new typeMountState()} />
		)
	}
}

export default DeviceTypeMount;