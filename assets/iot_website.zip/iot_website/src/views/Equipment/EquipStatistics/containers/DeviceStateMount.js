import React, { Component } from 'react';
import { Row, Col, Card, Table } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import echarts from 'echarts';
import listStore from '../../listStore';

class stateMountState {
	constructor() {
		extendObservable(this, {
			tableData: []
		})
	}
}
// 结构出参量表
const { rStateList } = listStore;



const columns = [{
	title: '设备状态',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '设备数量',
	dataIndex: 'value',
	key: 'value',
}];

@observer
class DeviceStateMountC extends Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			data: []
		};
	}

	onChangeDate(date, dateString) {
	}

	handleSizeChange = (e) => {
		this.setState({ size: e.target.value });
	}

	componentDidMount() {
		window.rpc.device.getCountFieldByContainer({}, 'dstate').then((rest) => {
			let rState = [];
			for (let i = 1; i < rStateList.length; i++) {
				rState.push({ key: i, value: rest[i] || 0, name: rStateList[i] });
			}
			this.setState({
				data: rState
			})
			this.props.stateMountState.tableDate = rState;
			let myChart = echarts.init(document.getElementById('DeviceStateMountEcharts'));

			myChart.setOption({
				tooltip: {
					trigger: 'item',
					formatter: "{a} <br/>{b}: {c} ({d}%)"
				},
				legend: {
					orient: 'vertical',
					x: 'left',
					data: this.state.data.map(x => x.name)
				},
				series: [
					{
						name: '设备状态',
						type: 'pie',
						radius: ['50%', '70%'],
						avoidLabelOverlap: false,
						label: {
							normal: {
								show: false,
								position: 'center'
							},
							emphasis: {
								show: true,
								textStyle: {
									fontSize: '30',
									fontWeight: 'bold'
								}
							}
						},
						labelLine: {
							normal: {
								show: false
							}
						},
						data: [...rState]
					}
				]
			});
		}, (err) => {
			console.warn(err);
			 function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
		});

	}

	render() {
		return (
			<div className="DeviceStateMount">
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>设备状态占比</p>
					<div id="DeviceStateMountEcharts" style={{ height: '50vh', width: '100%',borderTop:"1px solid #ccc"}}></div>
				</Row>
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>设备状态占比</p>
					<Table dataSource={this.state.data} columns={columns} pagination={false} bordered/>
				</Row>
			</div>
		);
	}
}

class DeviceStateMount extends Component {
	render() {
		return (
			<DeviceStateMountC stateMountState={new stateMountState()} />
		)
	}
}

export default DeviceStateMount;