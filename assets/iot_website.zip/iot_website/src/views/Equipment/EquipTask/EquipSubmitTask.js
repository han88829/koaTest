/*
 * @Author: xmj 
 * @Date: 2017-03-04 09:34:43 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-03-17 15:53:53
 */

import React, { Component } from 'react';
import { Form, Input, Button, Row, Col, message,Radio } from 'antd';
import { Link} from 'react-router';

const RadioGroup = Radio.Group;

// import moment from 'moment';  
const FormItem = Form.Item;
//const Option = Select.Option;

// 结构出参量表
//const { networkModeList } = listStore;

const NewGroupMes = Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true
    };
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
         console.log('Received values of form: ', values);
      //   let {name, dstate} = values;
      //   let obj = {name,  dstate: parseInt(level, 10)};

      //   console.log(obj);
      //  // rpc.owner.create(info,fire)
      //   window.rpc.group.create(obj).then(() => {
      //     message.info('创建成功！')
      //     browserHistory.push('/member/group');
      //   }, (err) => {
      //     console.log(err);
      //   })
        
      }
    });
  },
  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },
  checkPassword(rule, value, callback) {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  },
  checkConfirm(rule, value, callback) {
    const form = this.props.form;
    if (value && this.state.passwordDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 3 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    return (
      <Form onSubmit={this.handleSubmit} style={{marginTop:-4,paddingTop:30}}>
       <Row style={{marginBottom:5}}>
        <Col span={2}>
            序号
            
          </Col>
           <Col span={9}>
            名称
            
          </Col>
           <Col span={9}>
           状态
          </Col>
        </Row>
        <Row style={{marginBottom:0}}>
        <Col span={2}>
           1
          </Col>
          <Col span={9}>
            <FormItem
              {...formItemLayout}
              hasFeedback
            >
              {getFieldDecorator('infos[1][name]', {
                rules: [{ required: true, message: '请输入名称!' }],
              })(
                <Input style={{height:30,width:250}} placeholder="请输入" rows={1}/>
              )}
            </FormItem>
          </Col>
           <Col span={9}>
            <FormItem
              {...formItemLayout}
            >, 
              {getFieldDecorator('infos[1][dstate]')(
               
                <RadioGroup style={{height:30,width:250}} rows={1}>
            <Radio value={1}>合格</Radio>
            <Radio value={2}>不合格</Radio>
            
          </RadioGroup>
                  )}
            </FormItem>
          </Col>
        </Row>
       
         <Row style={{marginBottom:0}}>
        <Col span={2}>
          2
          </Col>
          <Col span={9}>
            <FormItem
              {...formItemLayout}
              hasFeedback
            >
              {getFieldDecorator('infos[2][name]', {
                rules: [{ required: true, message: '请输入名称!' }],
              })(
                <Input style={{height:30,width:250}} placeholder="请输入" rows={1}/>
              )}
            </FormItem>
          </Col>
           <Col span={9}>
            <FormItem
              {...formItemLayout}
            >, 
              {getFieldDecorator('infos[2][dstate]')(
               
                <RadioGroup style={{height:30,width:250}} rows={1}>
                <Radio value={1}>合格</Radio>
                <Radio value={2}>不合格</Radio>
                
              </RadioGroup>
              )}
            </FormItem>
          </Col>
        </Row>
        
      

 <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />
          <Row style={{ margin: '10px 0', position: 'absolute', bottom: 30, right: 140 }}>
            <Col span={20}></Col>
            <Col span={4}>
              <Row style={{ margin:'0' }}>
                <Col span={6}></Col>
                <Col span={9}>
                  <FormItem {...tailFormItemLayout}>
                    <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontFamily: '微软雅黑', fontSize: '14px', borderRadius: '5px', position: 'absolute', right: 10 }}>提交</Button>
                  </FormItem>
                </Col>
                <Col span={9}>
                  <FormItem {...tailFormItemLayout}>
                    <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px' }}><Link to="/member/group">返回</Link></Button>
                  </FormItem>
                </Col>
              </Row>
            </Col>
          </Row>

      </Form>
    );
  },
}));




class NewGroup extends Component {
  render() {
    return (
      <div className="NewGroup">
        <NewGroupMes />
      </div>
    );
  }
}

export default NewGroup;