/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:53:31 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:53:31 
 */

import React from 'react';
import { Form, Input, Cascader, Select, Button, DatePicker, Row, Col } from 'antd';
import { Link } from 'react-router';
//import moment from 'moment';
const FormItem = Form.Item;
const Option = Select.Option;
const { RangePicker } = DatePicker;

const equipTypes = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const builds = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const EquipRandomTaskEdit = Form.create()(React.createClass({
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  },
 
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };

    const config = {
      rules: [{ type: 'array', required: true, message: '请选择时间!' }],
    };
    //const dateFormat = 'YYYY-MM-DD';

    return (
      <Form onSubmit={this.handleSubmit}>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务标题："
              hasFeedback
            >
              {getFieldDecorator('name', {
                initialValue:'第一次抽检',
                rules: [{ type:'string',required: true, message: '请输入任务标题!' }],
              })(
                <Input />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务说明："
              hasFeedback
            >
              {getFieldDecorator('task', {
                initialValue:'今天天气好',
                rules: [{ type:'string', required: true, message: '请输入任务说明!' }],
              })(
                <Input type="textarea" rows={3} />
              )}
            </FormItem>
          </Col>
        </Row>
         <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="审核方式选择："
              hasFeedback
            >
              {getFieldDecorator('auditMethon', {
                initialValue:'人工',
                rules: [
                  {type:'string', required: true, message: '请选择审核方式！' },
                ],
              })(
                <Select>
                  <Option value="1">系统</Option>
                  <Option value="2">人工</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="任务开始--截至时间："
            >
               {getFieldDecorator('TaskDate', config)(
                <RangePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['开始时间', '截至时间']}
                  /*onChange={onChange}*/
                  //defaultValue={[moment('2015-09-26 08:50:08'), moment('2015-09-26 08:50:08')]}
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检人选择："
              hasFeedback
            >
              {getFieldDecorator('Inspectors', {
                initialValue:'自动分配',
                rules: [
                  { type:'string', required: true, message: '请选择巡检人！' },
                ],
              })(
                <Select>
                  <Option value="1">自动分配</Option>
                  <Option value="2">巡检员1</Option>
                  <Option value="3">巡检员2</Option>  
                  <Option value="4">巡检员3</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检报表选择"
              hasFeedback
            >
              {getFieldDecorator('report', {
                initialValue:'总表',
                rules: [
                  { type:'string', required: true, message: '请选择报表方式！' },
                ],
              })(
                <Select>
                  <Option value="1">总表</Option>
                  <Option value="2">分表</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备类型选择："
            >
              {getFieldDecorator('equipType', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{ type: 'array', required: true, message: '请选择类型!' }],
              })(
                <Cascader options={equipTypes} />
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备建筑选择："
            >
              {getFieldDecorator('build', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{ type: 'array', required: true, message: '请选择建筑!' }],
              })(
                <Cascader options={builds} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem {...tailFormItemLayout}>
              <Button type="primary" htmlType="submit" size="large">确定修改</Button>
            </FormItem>
         </Col>
         <Col span={12}>
            <FormItem {...tailFormItemLayout}>
              <Button type="success"><Link to="/equipment/equiptask">返回</Link></Button>
            </FormItem>
         </Col>
        </Row>
      </Form>
    );
  },
}));

export default EquipRandomTaskEdit;