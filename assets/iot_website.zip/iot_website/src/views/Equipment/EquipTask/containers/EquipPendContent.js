/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:52:10 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:52:10 
 */

import React, { Component } from 'react';
import { Form, Select, Input, Button } from 'antd';
const FormItem = Form.Item;
const Option = Select.Option;

const App = Form.create()(React.createClass({
  handleSelectChange(value) {
    console.log(value);
     this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem
          label="Note"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
        >
          {getFieldDecorator('gender', {
            rules: [{ required: true, message: 'Please select your gender!' }],
            onChange: this.handleSelectChange,
          })(
            <Select placeholder="合格">
              <Option value="合格">合格</Option>
              <Option value="不合格">不合格</Option>
            </Select>
          )}
        </FormItem>
      </Form>
    );
  },
}));
function EquipPendContent(){
  return(
    <App/>
  )
}

export default EquipPendContent;
    