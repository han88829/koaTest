/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:52:27 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:52:27 
 */

import React from 'react';
import { Table,Button} from 'antd';
import {EquipPends,result} from './EquipPends.js';
var arr=["合格","合格","合格","合格"];
const columns = [{
  title: '设备名称',
  dataIndex: 'name',
  render: text => <a href="#">{text}</a>,
}, {
  title: 'Age',
  dataIndex: 'age',
}, {
  title: '状态',
  dataIndex: 'address',
}];

//表格数据
const data = [{
  key: '1',
  name: 'John Brown',
  age: 32,
  address: arr[0],
}, {
  key: '2',
  name: 'Jim Green',
  age: 42,
  address: arr[1],
}, {
  key: '3',
  name: 'Joe Black',
  age: 32,
  address: arr[2],
}, {
  key: '4',
  name: 'Disabled User',
  age: 99,
  address: arr[3],
}];


 function EquipTaskPendTr(){
   return(
     <div>
      <Table  columns={columns} dataSource={data} />
      <EquipPends/>
      <Button className="Tablesave">保存</Button>
      </div>
   )
 }
 
 let reviewedData = {"dataMes":data,"chooseResult":result};
 //console.log(reviewedData);
 export default EquipTaskPendTr;
