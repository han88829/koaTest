/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:31 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-22 10:27:27
 */
import React from 'react';
import { Form, Input, Tooltip, Icon, Select, Button, DatePicker, Row, Col, message, TreeSelect } from 'antd';
import { Link, browserHistory } from 'react-router';
import listStore from '../listStore';

import star from '../../../assets/images/equipment/设备名称.png';
import er from '../../../assets/images/equipment/设备二维码.png';
import time from '../../../assets/images/equipment/安装时间.png';
import state from '../../../assets/images/equipment/布设状态.png';
import models from '../../../assets/images/equipment/采集模块.png';
import create from '../../../assets/images/equipment/创立时间.png';
import unit from '../../../assets/images/equipment/单位.png';
import address from '../../../assets/images/equipment/地址.png';
import type from '../../../assets/images/equipment/检测类型.png';
import dtype from '../../../assets/images/equipment/设备型号.png';
import shang from '../../../assets/images/equipment/生产厂家.png';
import area from '../../../assets/images/equipment/所属区域.png';
import net from '../../../assets/images/equipment/网关地址.png';
import setLocation from '../../../assets/images/equipment/坐标.png';
import './newDevices.css';

const dateFormat = 'YYYY-MM-DD';
const FormItem = Form.Item;
const Option = Select.Option;
var model = [], dtypescon = [];
var brand = new Map(), product = new Map(), deviceType = new Map(), locationMap = new Map(), flag = 0, netWd = new Map(), local = "";
// 结构出参量表
//const { networkModeList } = listStore;
var provinceData = [];
const NewDevice = Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true,
      disabled: true,
      data: [],
      model: [],
      locations: [],
      setPingmiantu_visiable: false,
      pingmiantu_url: '',
      findData: [],
      newPointX: 0,
      newPointY: 0,
      extend: {},
      typeData: [],
       networkModeList:[]
    };
  },
  componentWillMount() {
    window.rpc.alias.getValueByName('device.networkmode').then(data=>{
        let arrWatch = ['/'];
        for (let key in data) {
          let values = `${data[key]}`
          arrWatch.push(values);
        }
        let  networkModeList= arrWatch;
        this.setState({
          networkModeList
        });
      },err=>{
        console.warn(err)
      })
    window.rpc.product.getArray(0, 0).then((res) => {
      res.forEach((x) => {
        product[x.id] = x.number;
        product[x.number] = x.id;
      })
    }, (err) => {
      console.warn(err);
    })
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
              locationMap[layerNow[i].id] = layerNow[i].name
              locationMap[layerNow[i].name] = layerNow[i].id
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
              locationMap[layerNow[i].id] = layerNow[i].name
              locationMap[layerNow[i].name] = layerNow[i].id
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }

    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = loop(tableDate);
      this.setState({ typeData: tableDate });
    })
    window.rpc.area.getArray(0, 0).then((res) => {
      let tableDate = [];
      res.forEach(function (x) {
        if (x.name != "") {
          tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
        }
      })
      loop(tableDate)
      res.filter(x => x.layer == 1).forEach((x) => {
        locationMap[x.id] = x.name
        locationMap[x.name] = x.id
      })
      this.setState({
        data: tableDate,
        findData: res
      })
    }, (err) => {
      console.warn(err);
    })
  },
  componentDidMount() {
    window.rpc.brand.getMapIdNameByContainer(null, 0, 0, console.log, console.error).then((res) => {
      for (var value in res) {
        provinceData.push(<Option key={`${value}`} data-key={value}>{res[value]}</Option>)
        brand[res[value]] = value;
      }
    }, (err) => {
      console.warn(err);
    })
    window.rpc.device.types.getArray(0, 0, console.log, console.error).then((res) => {
      res.forEach(function (value, index) {
        dtypescon.push(<Option key={value.id}>{value.name}</Option>)
        deviceType[value.name] = value.id;
        deviceType[value.id] = value.name;;
      })
    }, (err) => {
      console.warn(err);
    })
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        if (flag) {
          local = values.location;
        } else {
          local = locationMap[values.location];
        }
        let { name, setupTime, tag, expiryTime, networkAddr, networkId, networkMode, networkUrl, networkNode, location, brandId, productId, dtype } = values;
        let mappoint = values.mapX;
        let mapX = parseInt(mappoint.split(',')[0], 10);
        let mapY = parseInt(mappoint.split(',')[1], 10);
        let extend = this.state.extend;
        let obj = { name, tag, mapX, mapY, extend, setupTime: new Date(setupTime.format('YYYY-MM-DD')), expiryTime: new Date(expiryTime.format('YYYY-MM-DD')), networkAddr, networkMode: parseInt(values.networkMode, 10), networkNode, networkId, networkUrl, location: parseInt(local, 10), productId: product[productId], dtype: dtype, param: { brandId: brandId, unit: values.unit, scope: values.scope, survey: values.survey, module: values.module } };
        if (networkAddr) {
          obj = { ...obj, networkAddr };
        }
        if (networkId) {
          obj = { ...obj, networkId };
        }
        window.rpc.device.create(obj).then((res) => {
          message.info('创建成功！')
          browserHistory.push('/equip');
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }
    });
  },
  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },
  checkPassword(rule, value, callback) {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  },
  checkConfirm(rule, value, callback) {
    const form = this.props.form;
    if (value && this.state.passwordDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  },
  changeType(e) {
    window.rpc.product.getArrayIdNumberByContainer({ brandId: e }, 0, 0, console.log, console.error).then((info) => {
      model = [];
      for (let value of info) {
        if (value && value.id) {
          model.push(<Option key={`${value.number}`}>{value.number}</Option>)
        }
      }
      this.setState({
        model
      })
    }, (err) => {
      console.warn(err);
    })
    this.setState({
      disabled: false
    })
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 3 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };

    const config = {
      rules: [{ type: 'object', required: true, message: 'Please select time!' }],
    };

    function isNetworkModeEqualOne(value) {
      return value !== '1';
    }

    let dtypeChildren = [], locationChildren = [], productChildren = [], networkModeChildren = [];
    let  networkModeList=this.state.networkModeList||[];
    window.rpc.cache.device.types.getMapIdNameByContainer(null, 0, 0, result => {
      for (let id in result) {
        dtypeChildren.push(<Option key={`${id}`}>{result[id]}</Option>)
      }
    }, console.error);
    window.rpc.cache.area.getMapIdNameByContainer(null, 0, 0, result => {
      for (let id in result) {
        locationChildren.push(<Option key={`${id}`}>{result[id]}</Option>)
      }
    }, console.error);
    window.rpc.cache.product.getMapIdNameByContainer(null, 0, 0, result => {
      for (let id in result) {
        productChildren.push(<Option key={`${id}`}>{result[id]}</Option>)
      }
    }, console.error);

    for (let i = 1; i < networkModeList.length; i++) {
      networkModeChildren.push(<Option key={`${i}`}>{networkModeList[i]}</Option>)
      netWd[i] = networkModeList[i];
      netWd[networkModeList[i]] = i;
    }

    return (
      <div>
        <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/equip/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备管理</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="">新增设备</Link></Button>
          </div>
        </div>
        <Form className="EditDevice" style={{ marginTop: -4, paddingTop: 30, height: 700, overflow: 'auto' }} >
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>设备名称：</span>
              </div>
              <FormItem
                {...formItemLayout}
                style={{ float: 'left' }}
                hasFeedback
              >
                {getFieldDecorator('name', {
                  rules: [{ required: true, message: '请输入设备名称!' }],
                })(
                  <Input placeholder="请输入设备名称" style={{ width: 320 }} />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={time} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>过期时间：</span>
              </div>
              <FormItem
                style={{ float: 'left' }}
              >
                {getFieldDecorator('expiryTime', config)(
                  <DatePicker format={dateFormat} />
                )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={time} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>安装时间：</span>
              </div>
              <FormItem
                style={{ float: 'left' }}
              >
                {getFieldDecorator('setupTime', config)(
                  <DatePicker style={{ width: 180 }} format={dateFormat} />
                )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>品牌：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('brandId', {
                  rules: [{ required: true, message: '请选择品牌!' }],
                })(
                  <Select placeholder='请选择品牌' style={{ width: 180 }} onChange={this.changeType}>
                    {provinceData}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>安装位置：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('location', {
                  rules: [{ type: 'string', required: true, message: '请选择安装位置!' }],
                })(
                  <TreeSelect
                    style={{ width: 300 }}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.data.filter(x => x.layer == 1)}
                    placeholder="请选择安装位置"
                    treeDefaultExpandAll
                    onChange={(value) => {
                      flag = 1;
                      let me = parseInt(value, 10);
                      let sources = this.state.findData;
                      let meobj = sources.filter(x => x.id === me)[0];
                      if (meobj.mapUrl) {
                        this.setState({ pingmiantu_url: meobj.mapUrl });
                      } else {
                        let parentId = meobj.parentId;
                        let parentobj = sources.filter(x => x.id === parentId)[0];
                        this.setState({ pingmiantu_url: parentobj.mapUrl });
                      }
                    }}
                  />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={type} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>型号：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('productId', {
                  rules: [{ required: true, message: '请选择型号!' }],
                })(
                  <Select placeholder='请先选择品牌' disabled={this.state.disabled} style={{ width: 180 }} >
                    {model}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={dtype} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>设备类型：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('dtype', {
                  rules: [{ type: 'string', required: true, message: '请选择设备类型!' }],
                })(
                  <TreeSelect
                    style={{ width: 170 }}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.typeData.filter(x => x.layer === 1)}
                    placeholder="请选择类型"
                    treeDefaultExpandAll
                  />
                  )}
              </FormItem>
            </div>
    
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={net} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>联网模式：</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('networkMode', {
                  rules: [
                    { required: true, message: '请选择联网模式!' },
                  ],
                  onChange: this.handleNetWorkModel
                })(
                  <Select placeholder='请先选择联网模式' style={{ width: 180 }} >
                    {networkModeChildren}
                  </Select>
                  )}
              </FormItem>
            </div>
            {/*<div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>网关地址：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('networkAddr', {
                  rules: [{ message: '请输入网关地址!' }],
                })(
                  <Input disabled={isNetworkModeEqualOne(this.props.form.getFieldValue('networkMode'))} size="large" />
                  )}
              </FormItem>
            </div>*/}
          </div>
          {/*<div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>网关序号：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('networkId', {
                  rules: [{ message: '请输入网关序号!' }],
                })(
                  <Input disabled={isNetworkModeEqualOne(this.props.form.getFieldValue('networkMode'))} size="large" />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={models} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>采集模块：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('module', {
                  rules: [{ required: true, message: '请输入采集模块!' }],
                })(
                  <Input size="large" />
                  )}
              </FormItem>
            </div>
          </div>*/}
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={net} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>相对坐标：</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('mapX', {
                  rules: [
                    { required: true, message: '请输入设备坐标!' },
                  ]
                })(
                  <Input size="large" />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" style={{ height: 40, lineHeight: '40px', backgroundColor: '#fff' }}>
              <Button className="caiji_btn" style={{ display: 'inline-flex', alignItems: 'center' }} onClick={() => this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }))}><img src={setLocation} style={{ padding: '0 15px 0 12px' }} alt="" /><span>采集坐标</span></Button>
              <div className="shebei_pmt" style={{ display: this.state.setPingmiantu_visiable ? 'block' : 'none' }}>
                <div className="shebei_pmt_head">
                  <span>采集坐标</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }))}>X</span>
                </div>
                <div className="shebei_pmt_body">
                  <img src={this.state.pingmiantu_url} onMouseDown={(event) => {
                    event.persist();
                    let body = document.body;
                    let newPointX = event.clientX - event.target.offsetLeft - (body.clientWidth - event.target.offsetParent.offsetWidth) / 2;
                    let newPointY = event.clientY - event.target.offsetTop - (body.clientHeight - event.target.offsetParent.offsetHeight) / 2;
                    let zoom = event.target.height / event.target.naturalHeight;
                    let extend = { offsetHeight: event.target.offsetHeight, offsetWidth: event.target.offsetWidth, zoom };
                    this.setState({ newPointX, newPointY, extend });
                  }} alt="pingmiantu" />
                </div>
                <div className="shebei_pmt_footer">
                  <div>
                    <span>当前位置点如下：</span>
                    <Input value={`${this.state.newPointX}, ${this.state.newPointY}`} style={{ width: 150 }} />
                  </div>
                  <div>
                    <Button style={{ backgroundColor: '#00c2de', borderColor: '#00c2de', color: '#fff', marginRight: 8 }} onClick={() => {
                      this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }));
                      this.props.form.setFieldsValue({
                        mapX: `${this.state.newPointX},${this.state.newPointY}`,
                      });
                    }}>确定</Button>
                    <Button onClick={() => this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }))}>取消</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        
          <div className="Row-info">
          
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>NFC：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('tag', {
                  rules: [{ required: false, message: '请输入NFCID!' }],
                })(
                  <Input size="large" />
                  )}
              </FormItem>
            </div>
          </div>
          <div style={{ position: 'absolute', bottom: 60 }} className="search-btn">
            <FormItem >
              <Button htmlType="submit" onClick={this.handleSubmit} > 保存</Button>
              <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', marginLeft: 10, fontFamily: '微软雅黑', borderRadius: '5px', width: 60, height: 32, borderRadius: 0 }}><Link to="/equip/manage">返回</Link></div>
            </FormItem>
          </div>
        </Form>
      </div>
    );
  },
}));

export default NewDevice;