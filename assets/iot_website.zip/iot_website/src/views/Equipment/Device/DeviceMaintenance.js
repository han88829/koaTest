import React from 'react';
import { Form, Input, Select, Button, DatePicker, Row, Col} from 'antd';

import { Link } from 'react-router';
import './device.css'
const FormItem = Form.Item;
const Option = Select.Option;

//const { networkModeList } = listStore;

 const DeviceMaintenance = Form.create()(React.createClass({
  handleSubmit(e){
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
      }
    });
  },
  render(){
    const { getFieldDecorator } = this.props.form;
    return (
      <div className="Maintenance">
       <Form onSubmit={this.handleSubmit} >
         <Row>
            <Col span={2}></Col>
            <Col span={15}>
            <FormItem
              label="保养人"
              labelCol={{ span: 2 }}
              wrapperCol={{ span: 14}}
            >
              {getFieldDecorator('person', {
                rules: [{ required: true, message: '请输入保养人!' }],
              })(
               <Select defaultValue="lucy" style={{ width: 200 }} >
                 <Option value="jack">Jack</Option>
                 <Option value="lucy">Lucy</Option>
                 <Option value="disabled" disabled>Disabled</Option>
                 <Option value="yiminghe">Yiminghe</Option>
               </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={2}></Col>
          <Col span={15}>
            <FormItem
              label="更新时间"
              labelCol={{ span: 2 }}
              wrapperCol={{ span: 14}}
            >
              {getFieldDecorator('lastTime')(
                <DatePicker />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
         <Col span={2}></Col>
         <Col span={15}>
         <FormItem
           label="保养内容"
           labelCol={{ span: 2 }}
           wrapperCol={{ span: 14}}
         >
          {getFieldDecorator('instr', {
             rules: [{ required: true, message: '请输入保养内容' }],
          })(
             <Input  type="textarea" placeholder="请输入保养内容" />
          )}
        </FormItem>
        </Col>
        </Row>
        <FormItem
        >
          <Row style={{marginTop:200}}>
            <Col span={13}></Col>
            <Col span={6}>
              <Button type="primary" htmlType="submit">
                保存
              </Button>
              &nbsp;&nbsp;
              <Button type="success" style={{marginLeft:50}}><Link to="/equipment/equipmanage">返回</Link></Button>              
            </Col>
          </Row>
        </FormItem>
      </Form>
     </div>    
    )
  }
})); 

export default DeviceMaintenance;