import React from 'react';
import { Form} from 'antd';
//import { Link } from 'react-router';

//const FormItem = Form.Item;
//const Option = Select.Option;

//const { networkModeList } = listStore;

 const DeviceDetection = Form.create()(React.createClass({

  render(){
    return (
      <div className="Detection">检测</div>    
    )
  }
})); 

//export default DeviceMaintenance;
export default DeviceDetection;