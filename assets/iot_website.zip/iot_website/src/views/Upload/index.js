import React, { Component } from 'react';
import { Upload, message, Button, Icon } from 'antd';

import { UploaderBuilder, Uploader } from 'qiniu4js';

import { UploaderBuilder, Uploader } from 'qiniu4js';
 const Qiniu = require('qiniu-js/dist/qiniu');

import { UploaderBuilder, Uploader } from 'qiniu4js';

const Qiniu = require('qiniu-js/dist/qiniu');


class UploadC extends Component {
  componentDidMount() {
    //引入Plupload 、qiniu.js后
    console.log(window.Qiniu);
    console.log(window.rpc);
    setTimeout(function() {
      window.rpc.upload.images.getDefaultConfig().then((res)=>{
        console.info(res);
        let { domain, uptoken } = res;
        var uploader = window.Qiniu.uploader({
          runtimes: 'html5,flash,html4',    //上传模式,依次退化
          browse_button: 'pickfiles',       //上传选择的点选按钮，**必需**
          // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
          uptoken : uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
          // unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
          // save_key: true,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
          // domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
          domain: `http://omdwajej6.bkt.clouddn.com/`,
          get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
          // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
          max_file_size: '100mb',           //最大文件体积限制
          unique_names: true,
          multi_selection: false,
          // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
          max_retries: 3,                   //上传失败最大重试次数
          // dragdrop: true,                   //开启可拖曳上传
          // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
          chunk_size: '4mb',                //分块上传时，每片的体积
          auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
          init: {
              'FilesAdded': function(up, files) {
                  window.plupload.each(files, function(file) {
                  });
              },
              'BeforeUpload': function(up, file) {
              },
              'UploadProgress': function(up, file) {
              },
              'FileUploaded': function(up, file, info) {
                let domain = up.getOption('domain');
                let res = JSON.parse(info);
                let sourceLink = domain + res.key;
                console.log(sourceLink);
              },
              'Error': function(up, err, errTip) {
                      //上传出错时,处理相关的事情
              },
              'UploadComplete': function() {
                      //队列文件处理完毕后,处理相关的事情
              },
              'Key': function(up, file) {
                  var key = "";
                  // do something with key here
                  return key
              }
          }
        });
        uploader.init();


      }, (err) =>{

      })
    }, 1000);
  }
  render() {
    return (
      <div className="UploadC">
        <div>
          <Button id="pickfiles" type="primary" onClick={() => {console.log(1)}}>选择文件</Button>
        </div>
      </div>
    );
  }
}

export default UploadC;