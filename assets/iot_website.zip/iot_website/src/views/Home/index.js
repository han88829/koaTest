import React, { Component } from 'react';
import { Link } from 'react-router';
import { Layout, Menu, Icon, message } from 'antd';
import logo_pic from '../../assets/images/logined/logo.png';
import banner_pic from '../../assets/images/logined/banner.png';
import home_pic from '../../assets/images/logined/Home-16.png';
import './home.css'

// import './home.css';
// const { SubMenu } = Menu;
const { Header, Content } = Layout;
class Home extends Component {
  componentWillMount() {
    if(!sessionStorage.token){
      window.location.href = '/login';
    }
  }
  logout(e) {
    e.preventDefault();
    window.rpc.user.session.destroy().then((result) => {
      message.success('注销成功！');
      window.location.href = '/login';
    }, (err) => {
      console.warn(err)
    })
  }
  render() {
    return (
      <Layout className="Home">
        <Header className="header" style={{lineHeight: '220px', height: '220px', padding: 0 ,margin:0,background: 'url('+banner_pic+') no-repeat #333744'}}>
          {/*<div className="logo" />*/}
          <div className="banner" style={{ lineHeight: '160px', height: '160px', display: 'flex', justifyContent: 'space-between' }}>
            <div className="logo" style={{height:'84px', width:'580px', display: 'flex', justifyContent: 'center',margin: '0 0 0 94px'}}>
                <img src={logo_pic} style={{height: '120px',width: '120px',margin:'46px 0 0 15px' }} alt="logo" />
                <span style={{padding:'0 0 0 20px' ,color:'#FFF',fontWeight:'500',fontSize:'32px',fontFamily:'苹方中等'}}>消防安全综合管控平台</span>
            </div>
            <nav className="nav" style={{margin:'20px 100px 0 170',fontSize:'16px',lineHeight:'40px',height:'40px',padding:'10px 100px 0 0'}}>
              <a href="#" style={{ color:'#fff',lineHeight:'24px',margin:'0 5px',position:'relative'}}>
                <Icon type="user" style={{marginRight:'5px'}}/>
                     个人
                 <span style={{position:'absulute',top:'2px',left:'2px',background:'#c7b51f',zIndex:'9'}}></span>
              </a>
              <a href="#" style={{ color: '#fff',lineHeight:'24px' ,margin:'0 5px'}} ><Icon type="message" style={{marginRight:'5px'}}/>信息</a>              
              <Link to="/login" style={{ color: '#fff',lineHeight:'24px',margin:'0 5px'}} onClick={this.logout}><span><Icon type="poweroff" style={{marginRight:'3px'}}/>退出</span></Link>
            </nav>
          </div>
          <Menu
            theme="light"
            mode="horizontal"
           // defaultSelectedKeys={['4']}
            style={{ lineHeight: '60px', height: '60px',width:'1920px', display: 'flex', justifyContent: 'space-around',margin:'0 auto',background: '#333744',color:'#FFF',textAlign:'center',padding:'0 0',fontSize:'18px'}}
          >
            <Menu.Item key="7" style={{ width: '180px', height: '60px',background: '#333744',}}><Link to="/logined" style={{color:'#FFF'}}><span><img src={home_pic} style={{padding:'0 10px 0 0',verticalAlign:'middle' }} alt="home" />首页</span></Link></Menu.Item>
            <Menu.Item key="1" style={{ width: '180px', height: '60px' ,background: '#333744'}}><Link to="/org" style={{color:'#FFF'}} ><span>户籍管理</span></Link></Menu.Item>
            <Menu.Item key="2" style={{ width: '180px', height: '60px',background: '#333744'}}><Link to="/member" style={{color:'#FFF'}}><span>人员管理</span></Link></Menu.Item>
            <Menu.Item key="3" style={{ width: '180px' , height: '60px',background: '#333744'}}><Link to="/monitor" style={{color:'#FFF'}}><span>监控中心</span></Link></Menu.Item>
            <Menu.Item key="4" style={{ width: '180px' , height: '60px',background: '#333744'}}><Link to="/equipment" style={{color:'#FFF'}}><span>设施设备管理</span></Link></Menu.Item>
            <Menu.Item key="5" style={{ width: '180px' , height: '60px',background: '#333744' }}><Link to="/concen" style={{color:'#FFF'}}><span>警情集控中心</span></Link></Menu.Item>
            <Menu.Item key="6" style={{ width: '180px' , height: '60px',background: '#333744'}}>综合评估中心</Menu.Item>
          </Menu>
        </Header>
        <Content className="content" style={{ padding: '0' }}>
          {this.props.children}
        </Content>
        {/*
        <Footer style={{ textAlign: 'center' }}>
          消防物联管控平台 ©2016-2017 宁波蓝晟智品信息科技发展有限公司
        </Footer>
        */}
      </Layout>
    );
  }
}

export default Home;