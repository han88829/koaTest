/*
 * @Author: Han.beibei 
 * @Date: 2017-06-14 17:49:21 
<<<<<<< HEAD
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-22 15:37:05
=======
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-22 14:13:40
>>>>>>> eef2a91ecfd5e9431645d0e0ee7ab3cebef78255
 */

import React, { Component } from 'react';
import { Row, Col, Modal, message, Select, Input, Icon } from 'antd';
import { Link } from 'react-router';
import moment from 'moment';
import './Org.css';

import background from '../../assets/背景.png';
import xuncha from '../../assets/已巡查@2x.png';

const Option = Select.Option;

class Org extends Component {
  componentDidMount() {
    document.body.style.cssText = 'min-width:0px'
    let id = this.props.params.id;
    window.rpc.public.alias.getValueByName('fire.safetyLevel').then((safeName) => {
      window.rpc.public.alias.getValueByName('owner.state').then((stateName) => {
        window.rpc.public.owner.getInfoById(id).then((res) => {
          let org = { name: res.name, add: res.address, man: res.legalPerson, phone: res.legalPersonPhone, safe: safeName[res.safetyLevel], type: res.typeName, state: stateName[res.state] }
          let owner = res.log.map((x) => ({ ...x, state: x.state, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
          let num = this.state.num;
          let ownerNum = this.state.ownerNum;
          if (num >= owner.length) {
            for (let i = 0; i < owner.length; i++) {
              ownerNum[i] = owner[i]
            }
          } else {
            for (let i = 0; i < num; i++) {
              ownerNum[i] = owner[i]
            }
          }
          this.setState({ org, owner, ownerNum });
        }, (err) => {
          console.warn(err);
        })
      }), (err) => {
        console.warn(err);
      }
    }, (err) => {
      console.warn(err);
    })
  }

  state = {
    visible: false,
    org: {
      name: null,
      add: null,
      state: null,
      safe: null,
      type: null,
      man: null,
      phone: null,
    },
    num: 5,
    owner: [],
    ownerNum: [],
    remark: null,
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleOk = (e) => {
    // if (!this.state.state) {
    //   return message.error('请选择状态！');
    // }
    // if (!this.state.remark) {
    //   return message.error('请输入异常信息！');
    // }
    // window.rpc.position.setInfoById(this.props.params.id, { state: this.state.state, remark: this.state.remark }).then((res) => {
    //   if (res) {
    //     message.info("提交成功！")
    //     this.setState({
    //       visible: false,
    //       state: null,
    //       remark: null,
    //     });
    //   } else {
    //     message.info("提交失败！")
    //   }
    // }), (err) => {
    //   console.warn(err)
    // }
    this.setState({ visible: false, });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  handleChange = (value) => {
    this.setState({ state: parseInt(value, 10) });
  }

  render() {
    return (
      <div style={{ fontFamily: "宋体", overflowY: "auto", height: "100vh", width: "100vw", fontSize: "1.25rem", backgroundColor: "#cccccc" }}>

        <Row type="flex" justify="start" align='top' style={{ cursor: "pointer", height: "30%", background: `url(${background})` }}>
          <Col span={24} style={{ color: "white", backgroundColor: "none", fontSize: "1.5rem" }}>
            <div style={{ float: "left", width: "33.33%", textAlign: "left" }}>
              <Link to="/back">
                <Icon type="left" style={{ color: "white",fontSize: '1.75rem' }} />
              </Link>
            </div>
            <div style={{ float: "left", width: "33.33%", textAlign: "center" }}>
              信息展示
            </div>
            <div onClick={this.showModal} style={{ cursor: "pointer", width: "33.33%", textAlign: "right", paddingTop: 5, float: "right", fontSize: "20px" }}>
              匿名举报
            </div>
            <Modal
              title="Basic Modal"
              visible={this.state.visible}
              onOk={this.handleOk}
              onCancel={this.handleCancel}
              className="SOrg"
            >
              {/*<div style={{ paddingLeft: 20 }}>
                <div style={{ marginTop: 20 }}>
                  <span>单位名称 ：</span>
                  <Input disabled style={{ width: 200, marginLeft: 20 }} value={this.state.org.name} />
                </div>
                <div style={{ marginTop: 10 }}>
                  <span>单位地址 ：</span>
                  <Input disabled style={{ width: 200, marginLeft: 20 }} value={this.state.org.add} />
                </div>
                <div style={{ marginTop: 10 }}>
                  <span>户籍状态 ：</span>
                  <Select
                    showSearch
                    style={{ width: 200, marginLeft: 20 }}
                    placeholder="请选择状态！"
                    onChange={this.handleChange}
                  >
                    <Option value='1'>正常</Option>
                    <Option value='2'>异常</Option>
                  </Select>
                </div>
                <div style={{ marginTop: 10, lineHeight: "40px" }}>
                  <span>备注信息 ：</span>
                  <Input
                    style={{ width: 200, marginLeft: 20 }}
                    value={this.state.remark}
                    type="textarea"
                    rows={2}
                    onChange={(e) => {
                      this.setState({ remark: e.target.value });
                    }} />
                </div>
              </div>*/}
              <div style={{ textAlign: 'center', marginTop: 50, fontSize: '1.5rem' }}>
                暂未开通！
              </div>
            </Modal>
          </Col>
        </Row>

        {/*户籍信息*/}
        <Row type="flex" justify="start" align='middle' style={{ backgroundColor: "white", height:'3.75rem', paddingLeft: 10, marginTop: 10 }}>
          <Row >
            <Col span={24} style={{ color: "#363c61" }}>
              户籍信息<span></span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              户籍名称 : <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.org.name}</span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              户籍状态 : <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.org.state}</span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              安全等级 : <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.org.safe}</span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", borderBottom: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              位置 : <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.org.add}</span>
            </Col>
          </Row>
        </Row>

        {/*基本信息*/}
        <Row type="flex" justify="start" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10 }}>
          <Row >
            <Col span={24} style={{ color: "#363c61" }}>
              基本信息<span></span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              单位类型 : <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.org.type}</span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              责任人 : <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.org.man}</span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height:'3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              联系号码 : <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.org.phone}</span>
            </Col>
          </Row>
        </Row>

        {/*巡查*/}
        {this.state.ownerNum.map((x) => (
          <Row key={x.createTime} type="flex" justify="end" align='middle' style={{ cursor: "pointer", marginTop: 5, backgroundColor: "white", height: '4rem', width: '94%', marginLeft: "3%", paddingLeft: 10, borderLeft: '5px solid #00c1d1', borderBottomLeftRadius: "5px", borderTopLeftRadius: "5px" }}>
            <Col span={18} style={{ fontSize: "1.2rem" }}>
              <div style={{ color: "#363c61" }}>
                {x.state == 1 ? "已巡查" : "未巡查"}
              </div>
              <div style={{ color: "#8b8e92" }}>
                {x.createTime}
              </div>
            </Col>
            <Col span={6} style={{ fontSize: "1.2rem" }}>
              <img alt="" src={xuncha} style={{ display: x.state == 1 ? '' : "none", height: 20, marginTop: 15, width: 20, float: "left" }} />
              {/*<span style={{ fontSize: "1.8rem", color: "#cccccc", float: "right" }}>></span>*/}
            </Col>
          </Row>
        ))}

        <Row
          type="flex"
          justify="end"
          align='middle'
          style={{ cursor: "pointer", marginTop: 5, backgroundColor: "white", height: '1.75rem', width: '94%', marginLeft: "3%", paddingLeft: 10, }}
          onClick={() => {
            let num = this.state.num;
            num += 5;
            let owner = this.state.owner;
            let ownerNum = this.state.ownerNum;
            if (num > owner.length + 5) {
              message.info("已没有更多内容！")
              return
            }
            if (num >= owner.length) {
              for (let i = 0; i < owner.length; i++) {
                ownerNum[i] = owner[i]
              }
            } else {
              for (let i = 0; i < num; i++) {
                ownerNum[i] = owner[i]
              }
            }
            this.setState({ num, ownerNum });
          }}
        >
          <Col span={24} style={{ fontSize: "1.2rem", textAlign: "center" }}>
            查看更多
            <span style={{ fontSize: "1.2rem", color: "black", marginLeft: 10 }}>></span>
          </Col>
        </Row>

      </div>
    );
  }
}

export default Org;