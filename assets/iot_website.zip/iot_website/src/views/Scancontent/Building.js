/*
 * @Author: Han.beibei 
 * @Date: 2017-06-14 17:49:12 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-22 15:57:33
 */
/*
 * @Author: Han.beibei 
 * @Date: 2017-06-14 17:49:17 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-16 15:20:01
 */
import React, { Component } from 'react';
import {Row,Col,message,Icon} from 'antd';
import moment from 'moment';
import './Equipment.css';
import { Link } from 'react-router';
//import bgImg_pic from '../../assets/images/sconcontent/背景.png';
import return3x_pic from '../../assets/images/sconcontent/返回@3x.png';
import patrol3x_pic from '../../assets/images/sconcontent/已巡查@3x.png';
import jian3x_pic from '../../assets/images/sconcontent/箭头@2x.png';
let brand = new Map(), deviceType = new Map(), product = new Map(),  locationMap ='', brandMap = new Map();
class Building extends Component {
    state={
        id:null,
        device:{
        },
        patrolId:null,
        patrolData:[],
        preserveData:[]

    }
   componentWillMount(){
      document.body.style.cssText = 'min-width:0px';   
      let str = window.location.href;
      var index = str.lastIndexOf("\/");
      str = parseInt(str.substring(index + 1, str.length), 10);
      this.setState({id:str});
    if(window.rpc){
    if(window.rpc.area){
    window.rpc.public.area.getInfoById(str).then((result) => {
        this.setState({patrolId:result.patrolId});
      //window.rpc.area.types.getInfoById(result.type).then(loca=>{
        window.rpc.cache.public.alias.getValueByName('area.fireDanger').then(product=>{
        
         let time;
        if (result.setupTime == null) {
          time = moment(new Date()).format("YYYY年MM月DD日")
        } else {
          time = moment(result.setupTime).format("YYYY年MM月DD日")
        }
       
        setTimeout(() => {
          const device = { ...result, tag: result.tag, expiryTime: moment(result.expiryTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, type:result.typeName||'', fireDanger:product[result.fireDanger]||'',extend:result.extend.nature||'保密' };
          this.setState({ device });
          console.log(device.extend);
        }, 300)
     
      
      },err=>{
          console.warn(err);
      })
      
    }, (err) => {
      console.warn(err);
    })
}
 }

    //   window.rpc.position.log.getArrayByContainer({Id:patrolId},0,10).then(data=>{
    //      console.log(data);
    //   },err=>{
    //      console.warn(err);
    //   })
   }
    handleClick=()=>{
           console.log( this.state.id);
            message.info('暂未开通！')
    }
  
    render() {
        return (
            <div className="box">
                <Row className="bgImg"  style={{color:'#fff',width:'100%',height:200,position:'relative'}}  type="flex" justify="center">
                      
                  <div style={{float:'left',width:'10%',marginTop:'2.25rem',}}>
                     {/*<img src={return3x_pic} style={{width:'0.75rem',height:'1rem'}} alt=""/>*/}
                       <Link to="/back">
                           <Icon type="left" style={{ color: "white",fontSize:'1.5rem' }} />
                       </Link>
                  </div>
                  <div className="" style={{float:'left',width:'60%',marginTop:'1.75rem',textAlign:'center',fontSize:'1.25rem'}} >信息展示</div>
                   <div className="" style={{float:'right',width:'20%',marginTop:'2rem',textAlign: 'right',fontSize:'1.125rem'}} onClick={this.handleClick}>匿名提交</div>
                    
                    {/*<img src={bgImg_pic} style={{width: 'auto',height: '100%'}} alt=""/>*/}
                </Row>
                <div className="box">
                  <h5 style={{padding:'1rem 0 1rem 0'}}>建筑信息</h5>
                  <Row  className="row-line" type="flex" justify="center">
                    {/*<Col span={7} className="greyColorLeft">建筑名称</Col>
                    <Col span={17}>{this.state.device.name||''}</Col>*/}
                   <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                     建筑名称<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.name||''}</span>
                   </Col>
                  </Row>
                  <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">建筑类型</Col>
                      <Col span={17}>{this.state.device.type||''}</Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                        建筑类型<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.type||''}</span>
                      </Col>
                  </Row>
                  
                   <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">防火等级</Col>
                      <Col span={17}>
                        {this.state.device.fireLevel||''}
                        <span style={{display:this.state.device.fireLevel?'inline-block':'none'}}>级</span>
                      </Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                        防火等级
                        <span style={{ marginLeft:'1.75rem', color: "#363c61" }}>
                         {this.state.device.fireLevel||''}
                         <span style={{display:this.state.device.fireLevel?'inline-block':'none'}}>级</span>
                       </span>
                      </Col>
                  </Row>  
                  <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">日期</Col>
                      <Col span={17}>{this.state.device.setupTime||''}</Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                         日期 <span style={{ marginLeft: '3.75rem', color: "#363c61" }}>
                        {this.state.device.setupTime||''}
                         
                       </span>
                      </Col>
                  </Row>  
                   <h5 style={{padding:'1rem 0 1rem 0',borderTop: '1px solid #ddd'}}>基本信息</h5>
                  <Row  className="row-line" type="flex" justify="center">
                     <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                         使用性质 <span style={{ marginLeft: '1.75rem', color: "#363c61" }}>
                        {this.state.device.extend||''}
                         
                       </span>
                      </Col>
                  </Row>
                  <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7}  className="greyColorLeft">火灾危险性</Col>
                    <Col span={17}>{this.state.device.fireDanger||''}</Col>*/}
                     <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                         火灾危险性 <span style={{ marginLeft: '0.75rem', color: "#363c61" }}>
                       {this.state.device.fireDanger||''}
                         
                       </span>
                      </Col>
                  </Row> 
                </div>
               
            </div>
        );
    }
}

export default Building;