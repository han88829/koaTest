/*
 * @Author: Han.beibei 
 * @Date: 2017-06-14 17:49:21 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-22 14:12:35
 */
import React, { Component } from 'react';
import { Row, Col, Modal, Input, Select, message, Icon } from 'antd';
import { Link } from 'react-router';
import moment from 'moment';
import './Org.css';

import background from '../../assets/背景.png';
import dizhi from '../../assets/位置@2x.png';

const Option = Select.Option;

class Patro extends Component {
  componentDidMount() {
    document.body.style.cssText = 'min-width:0px'

    let id = this.props.params.id;
    window.rpc.public.position.getInfoById(id).then((res) => {
      let log = res.log.map((x) => ({ ...x, state: x.state, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
      let add = res.locationName.replace(/[0-9]/g, "").replace(/:/g, "").replace(/,/g, "");
      let logNum = this.state.logNum;
      let num = this.state.num;
      if (num >= log.length) {
        for (let i = 0; i < log.length; i++) {
          logNum[i] = log[i]
        }
      } else {
        for (let i = 0; i < num; i++) {
          logNum[i] = log[i]
        }
      }
      this.setState({ name: res.name, owner: res.ownerName, log, add, logNum });
    }), (err) => {
      console.warn(err)
    }
  }
  state = {
    visible: false,
    name: null,
    owner: null,
    ownerId: null,
    remark: null,
    state: null,
    num: 5,
    log: [],
    logNum: [],
    len: 0,
    add: null
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    // if (!this.state.state) {
    //   return message.error('请选择状态！');
    // }
    // if (!this.state.remark) {
    //   return message.error('请输入异常信息！');
    // }
    // window.rpc.position.setInfoById(this.props.params.id, { state: this.state.state, remark: this.state.remark }).then((res) => {
    //   if (res) {
    //     message.info("提交成功！")
    //     this.setState({
    //       visible: false,
    //       state: null,
    //       remark: null,
    //     });
    //   } else {
    //     message.info("提交失败！")
    //   }
    // }), (err) => {
    //   console.warn(err)
    // }
    this.setState({ visible: false, });
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  }
  handleChange = (value) => {
    this.setState({ state: parseInt(value, 10) });
  }
  render() {
    return (
      <div style={{ fontFamily: "宋体", overflowY: "auto", height: "100vh", width: "100vw", fontSize: "1.25rem", backgroundColor: "#cccccc" }}>

        <Row type="flex" justify="start" align='top' style={{ cursor: "pointer", height: "30%", background: `url(${background})` }}>
          <Col span={24} style={{ color: "white", backgroundColor: "none", fontSize: "1.5rem" }}>
            <div style={{ float: "left", width: "33.33%", textAlign: "left" }}>
              <Link to="/back">
                <Icon type="left" style={{ color: "white" }} />
              </Link>
            </div>
            <div style={{ float: "left", width: "33.33%", textAlign: "center" }}>
              信息展示
            </div>
            <div onClick={this.showModal} style={{ cursor: "pointer", width: "33.33%", textAlign: "right", paddingTop: 5, float: "right", fontSize: "1.2rem" }}>
              匿名举报
            </div>
            <Modal
              title="Basic Modal"
              visible={this.state.visible}
              onOk={this.handleOk}
              onCancel={this.handleCancel}
              className="SOrg"
            >
              {/*<div style={{ paddingLeft: 20 }}>
                <div style={{ marginTop: 20 }}>
                  <span>巡逻点名称 ：</span>
                  <Input disabled style={{ width: 150, marginLeft: 10 }} value={this.state.name} />
                </div>
                <div style={{ marginTop: 10 }}>
                  <span>单位 ：</span>
                  <Input disabled style={{ width: 150, marginLeft: 45 }} value={this.state.owner} />
                </div>
                <div style={{ marginTop: 10 }}>
                  <span>巡逻点状态 ：</span>
                  <Select
                    showSearch
                    style={{ width: 150, marginLeft: 8 }}
                    placeholder="请选择状态！"
                    onChange={this.handleChange}
                  >
                    <Option value='1'>正常</Option>
                    <Option value='2'>异常</Option>
                  </Select>
                </div>
                <div style={{ marginTop: 10, lineHeight: "40px" }}>
                  <span>备注信息 ：</span>
                  <Input
                    style={{ width: 150, marginLeft: 20 }}
                    value={this.state.remark}
                    type="textarea"
                    rows={2}
                    onChange={(e) => {
                      this.setState({ remark: e.target.value });
                    }} />
                </div>
              </div>*/}
              <div style={{ textAlign: 'center', marginTop: 50, fontSize: '1.5rem' }}>
                暂未开通！
              </div>
            </Modal>
          </Col>
        </Row>

        {/*基本信息*/}
        <Row type="flex" justify="start" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, marginTop: 10 }}>
          <Row >
            <Col span={24} style={{ color: "#363c61" }}>
              基本信息<span></span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              巡逻点名称 :  <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.name}</span>
            </Col>
          </Row>
        </Row>

        <Row type="flex" justify="end" align='middle' style={{ backgroundColor: "white", height: '3.75rem', paddingLeft: 10, }}>
          <Row type="flex" align='middle' style={{ borderTop: "1px solid #cccccc", width: "100%", height: "100%" }}>
            <Col span={24} style={{ fontSize: "1.2rem", color: "#8b8e92" }}>
              单位 ： <span style={{ marginLeft: 10, color: "#363c61" }}>{this.state.owner}</span>
            </Col>
          </Row>
        </Row>

        {/*签到*/}
        {this.state.logNum.map((x) => (
          <Row key={x.createTime} type="flex" justify="end" align='middle' style={{ cursor: "pointer", marginTop: 5, backgroundColor: "white", height: '4rem', width: '94%', marginLeft: "3%", paddingLeft: 10, borderLeft: '5px solid #00c1d1', borderBottomLeftRadius: "5px", borderTopLeftRadius: "5px" }}>
            <Col span={18} style={{ fontSize: "1.2rem" }}>
              <div style={{ color: "#363c61" }}>
                {x.createTime}
              </div>
              <div style={{ color: "#8b8e92" }}>
                <img alt="" src={dizhi} style={{ width: 10, height: 15, float: 'left', marginTop: 5 }} />
                <span style={{ fontSize: "1.2rem", marginLeft: 10 }}>{this.state.add}</span>
              </div>
            </Col>
            <Col span={6} style={{ fontSize: "1.2rem" }}>
              <div style={{ fontSize: "1.2rem", backgroundColor: x.state == 1 ? "#00c1d1" : "red", color: "white", width: "80%", textAlign: "center", borderRadius: "7px" }}>{x.state == 1 ? "正常" : "异常"}</div>
            </Col>
          </Row>
        ))}
        {/*固定数据*/}
        {/*<Row type="flex" justify="end" align='middle' style={{ cursor: "pointer", marginTop: 5, backgroundColor: "white", height: '3.9rem', width: '94%', marginLeft: "3%", paddingLeft: 10, borderLeft: '5px solid #00c1d1', borderBottomLeftRadius: "5px", borderTopLeftRadius: "5px" }}>
          <Col span={18} style={{ fontSize: "1rem" }}>
            <div style={{ color: "#363c61" }}>
              2016-2-5 5:00
            </div>
            <div style={{ color: "#8b8e92" }}>
              <img alt="" src={dizhi} style={{ width: 10, height: 15, float: 'left', marginTop: 5 }} />
              <span style={{ fontSize: "1rem", marginLeft: 10 }}>汇智大厦一楼</span>
            </div>
          </Col>
          <Col span={6} style={{ fontSize: "1rem" }}>
            <div style={{ fontSize: "1rem", backgroundColor: "#00c1d1", color: "white", width: "80%", textAlign: "center", borderRadius: "7px" }}>已签到</div>
          </Col>
        </Row>*/}

        <Row
          type="flex"
          justify="end"
          align='middle'
          style={{ cursor: "pointer", marginTop: 5, backgroundColor: "white", height: '1.75rem', width: '94%', marginLeft: "3%", paddingLeft: 10, }}
          onClick={() => {
            let num = this.state.num;
            num += 5;
            let log = this.state.log;
            let logNum = this.state.logNum;
            if (num > log.length + 5) {
              message.info("已没有更多内容！")
              return
            }
            if (num >= log.length) {
              for (let i = 0; i < log.length; i++) {
                logNum[i] = log[i]
              }
            } else {
              for (let i = 0; i < num; i++) {
                logNum[i] = log[i]
              }
            }
            this.setState({ num, logNum });
          }}
        >
          <Col span={24} style={{ fontSize: "1.2rem", textAlign: "center" }}>
            查看更多
            <span style={{ fontSize: "1.2rem", color: "black", marginLeft: 10 }}>></span>
          </Col>
        </Row>

      </div>
    );
  }
}

export default Patro;