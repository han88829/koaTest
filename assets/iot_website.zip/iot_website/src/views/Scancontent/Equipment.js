/*
 * @Author: Han.beibei 
 * @Date: 2017-06-14 17:49:17 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-22 16:01:06
 */
import React, { Component } from 'react';
import {Row,Col,message,Icon} from 'antd';
import moment from 'moment';
import './Equipment.css';
import { Link } from 'react-router';
//import bgImg_pic from '../../assets/images/sconcontent/背景.png';
import return3x_pic from '../../assets/images/sconcontent/返回@3x.png';
import patrol3x_pic from '../../assets/images/sconcontent/已巡查@3x.png';
import jian3x_pic from '../../assets/images/sconcontent/箭头@2x.png';
let brand = new Map(), deviceType = new Map(), product = new Map(),  locationMap ='', brandMap = new Map();
class Equipment extends Component {
    state={
        id:null,
        device:{
        },
        patrolId:null,
        patrolData:[],
        preserveData:[]

    }
   componentWillMount(){
      document.body.style.cssText = 'min-width:0px';   
      let str = window.location.href;
      var index = str.lastIndexOf("\/");
      str = parseInt(str.substring(index + 1, str.length), 10);
      this.setState({id:str});

    window.rpc.public.device.getInfoExById(str).then((result) => {
        this.setState({patrolId:result.patrolId});

         //window.rpc.brand.getInfoById(product.ownerId).then(brand=>{
         //    window.rpc.owner.getInfoById(result.ownerId).then(owner=>{
         let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      //console.log(locationMap);
      setTimeout(() => {
        const device = { ...result, tag: result.tag, expiryTime: moment(result.expiryTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, dtype:result.typeName||'',
         location:result.locationName.replace(/,/g,'-')||''.replace(',','-')||'', productId: result.productNumber||'',  };
        //  device.log.map(x=>({
        //    ...x,createTime:moment(x.createTime).format("YYYY年MM月DD日") 
        //  }));
         console.log(device);
        this.setState({ device });
        if(result.log[1]){
           // if(result.log.length)
           console.log(result.log[1]);
           let patrolData=result.log[1].map(x=>({
           ...x,createTime:moment(x.createTime).format("YYYY-MM-DD") 
        }));
        
        console.log(patrolData);
        this.setState({patrolData});
    }
          if(result.log[3]){
           // if(result.log.length)
           console.log(result.log[3]);
           let preserveData=result.log[3].map(x=>({
           ...x,createTime:moment(x.createTime).format("YYYY-MM-DD") 
        }));
        
        console.log(preserveData);
        this.setState({preserveData});
        }
        //let patrolList=device.log.filter(x=>x.state===1);
        console.log(device);
      }, 300)
  
       },err=>{
          console.warn(err);
      })
      // },err=>{
      //     console.warn(err);
      // })
      

   
    //   window.rpc.position.log.getArrayByContainer({Id:patrolId},0,10).then(data=>{
    //      console.log(data);
    //   },err=>{
    //      console.warn(err);
    //   })
   }
    handleClick=()=>{
           console.log( this.state.id);
            message.info('暂未开通！')
    }
    morePatrolClick=()=>{
          console.log( this.state.patrolId);
          message.info('没有更多数据了！')
    }
    render() {
        return (
            <div className="box">
               
                <Row className="bgImg"  style={{color:'#fff',width:'100%',height:200,position:'relative'}}  type="flex" justify="center">
                      
                  <div style={{float:'left',width:'10%',marginTop:'2.25rem',}}>
                     {/*<img src={return3x_pic} style={{width:'0.75rem',height:'1rem'}} alt=""/>*/}
                       <Link to="/back">
                           <Icon type="left" style={{ color: "white",fontSize: '1.5rem'  }} />
                       </Link>
                  </div>
                  <div className="" style={{float:'left',width:'60%',marginTop:'1.75rem',textAlign:'center',fontSize:'1.25rem'}} >信息展示</div>
                   <div className="" style={{float:'right',width:'20%',marginTop:'2rem',textAlign: 'right',fontSize:'1.125rem'}} onClick={this.handleClick}>匿名提交</div>
                    
                    {/*<img src={bgImg_pic} style={{width: 'auto',height: '100%'}} alt=""/>*/}
                </Row>
                <div className="box">
                  <h5 style={{padding:'1rem 0 1rem 0'}}>设备信息</h5>
                  <Row  className="row-line" type="flex" justify="center">
                    {/*<Col span={7} className="greyColorLeft">设备名称：</Col>
                    <Col span={17}>{this.state.device.name||''}</Col>*/}
                     <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                        设备名称<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.name||''}</span>
                      </Col>
                  </Row>
                  <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">设备类型：</Col>
                    <Col span={17}>{this.state.device.dtype||''}</Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                        设备类型<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.dtype||''}</span>
                      </Col>
                  </Row>
                  <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">安装时间：</Col>
                      <Col span={17}>{this.state.device.setupTime||''}</Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                       安装时间<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.setupTime||''}</span>
                      </Col>
                  </Row>  
                   <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">安装位置：</Col>
                      <Col span={17}>{this.state.device.location||''}</Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                       安装位置<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.location||''}</span>
                      </Col>
                  </Row>  
                   <h5 style={{padding:'1rem 0 1rem 0',borderTop: '1px solid #ddd'}}>基本信息</h5>
                  {/*<Row  className="row-line" type="flex" justify="center">
                    <Col span={7} className="greyColorLeft">所属系统：</Col>
                    <Col span={17}>{this.state.device.ownerId||''}</Col>
                  </Row>*/}
                  <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">生产厂家：</Col>
                    <Col span={17}>{this.state.device.makeName||''}</Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                       生产厂家<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.makeName||''}</span>
                      </Col>
                  </Row>
                  <Row  className="row-line" type="flex" justify="center">
                      {/*<Col span={7} className="greyColorLeft">设备型号：</Col>
                      <Col span={17}>{this.state.device.productId||''}</Col>*/}
                      <Col span={24} style={{ fontSize: "1rem", color: "#8b8e92" }}>
                        设备型号<span style={{ marginLeft: '1.75rem', color: "#363c61" }}>{this.state.device.productId||''}</span>
                      </Col>
                  </Row>   
                </div>
                <div className="patrolList">
                    <h3 className="subTitle"  style={{padding:'1rem 0 1.75rem 1.125rem',fontSize:'1.25rem'}}>
                        巡查记录
                        {/*<span className="more" onClick={this.morePatrolClick}>更多</span>*/}
                    </h3>
                     <div style={{display:this.state.patrolData.length?'none':'block',textAlign:'center', padding: '1.5rem 0 1rem'}}>       
                        <Icon type="frown-o" style={{fontSize: '1.25rem' , padding:'0 1rem'  }} />暂无巡查记录
                    </div>
                      {this.state.patrolData.map((point, index) => (
                         <div key={index+1} className="patrol-every">
                         <Row  className="row-line-patrol" type="flex" justify="start">
                          <Col span={17} className="">
                           <span style={{color:'#363c41'}}>已巡查</span>
                           <br/>
                           <span style={{color:'#8b8e92'}}>{point.createTime}</span>
                          </Col>
                          <Col span={7} style={{position:'relative',textAlign: 'left'}}>
                           <img src={patrol3x_pic} style={{width:'2rem',height:'2rem',position:'absolute',top:'1rem'}} alt=""/>
                           
                          </Col>
                         </Row>    
                        </div>
                       ))}
                      {/*<div className="patrol-every">
                         <Row  className="row-line-patrol" type="flex" justify="start">
                          <Col span={17} className="">
                           <span style={{color:'#363c41'}}>已巡查</span>
                           <br/>
                           <span style={{color:'#8b8e92'}}>2017-06-13</span>
                          </Col>
                         <Col span={7} style={{position:'relative',textAlign: 'left'}}>
                           <img src={patrol3x_pic} style={{width:'2rem',height:'2rem',position:'absolute',top:'1rem'}} alt=""/>
                           <img src={jian3x_pic} style={{width:'0.75rem',height:'1rem',position:'absolute',top:'1.625rem',marginLeft:'3rem'}} alt=""/>
                          </Col>
                         </Row>    
                     </div>
                     <div className="patrol-every">
                         <Row  className="row-line-patrol" type="flex" justify="start">
                          <Col span={17} className="">
                           <span style={{color:'#363c41'}}>已巡查</span>
                           <br/>
                           <span style={{color:'#8b8e92'}}>2017-06-13</span>
                          </Col>
                          <Col span={7} style={{position:'relative',textAlign: 'left'}}>
                           <img src={patrol3x_pic} style={{width:'2rem',height:'2rem',position:'absolute',top:'1rem'}} alt=""/>
                           <img src={jian3x_pic} style={{width:'0.75rem',height:'1rem',position:'absolute',top:'1.625rem',marginLeft:'3rem'}} alt=""/>
                          </Col>
                         </Row>    
                     </div>*/}
                  
                     
                </div>

                <div className="patrolList preserveList">
                    <h3 className="subTitle"  style={{padding:'1rem 0 1.75rem 1.125rem',fontSize:'1.25rem'}}>
                        维护记录
                        {/*<span className="more" onClick={this.morePatrolClick}>更多</span>*/}
                    </h3>
                    <div style={{display:this.state.preserveData.length?'none':'block',textAlign:'center', padding: '1.5rem 0 1rem'}}>       
                        <Icon type="frown-o" style={{fontSize: '1.25rem' ,padding:'0 1rem' }} />暂无维护记录
                    </div>
                    <div>
                    {this.state.preserveData.map((point, index) => (
                         <div key={index+1} className="patrol-every preserve-every">
                           <Row  className="row-line-patrol" type="flex" justify="start">
                          <Col span={17} className="">
                           <span style={{color:'#363c41'}}>{point.createTime||''}</span>
                           <br/>
                           <span style={{color:'#8b8e92'}}>巡查人ID：{point.id||''}</span>
                          </Col>
                          <Col span={7} style={{position:'relative',textAlign: 'left'}}>
                           {/*<img src={patrol3x_pic} style={{width:'2rem',height:'2rem',position:'absolute',top:'1rem'}} alt=""/>*/}
                           {/*<img src={jian3x_pic} style={{width:'0.75rem',height:'1rem',position:'absolute',top:'1.625rem',marginLeft:'3rem'}} alt=""/>*/}
                          </Col>
                         </Row>   
                        </div>
                       ))}
                     
                    </div>
                     
                </div>
            
            </div>
        );
    }
}

export default Equipment;