/*
 * @Author: lai.haibo 
 * @Date: 2017-03-24 09:26:32 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-15 15:14:40
 */

import React, { Component } from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router';
const { Header, Sider, Content } = Layout;
const MenuItemGroup = Menu.ItemGroup;

const routes = {
  manage: [{
    name: '报警管理',
    path: '/conct/manage',
    key: '1'
  }],
  stati: [{
    name: '报警统计',
    path: '/conct/statistics',
    key: '2'
  }],
  history: [{
    name: '报警处理',
    path: '/conct/history',
    key: '3'
  }],
  settings: [{
    name: '报警设定',
    path: '/conct/settings',
    key: '4'
  }],
}

class Conct extends Component {
  state = {
    collapsed: true,
    seconds: {
      background: '#eaedf1',
      display: 'none'
    },
    route: routes.manage,
    routeName: '报警管理',
    routeKey: '1',
    data: [true, true, true, true,],
    display: ''
  };
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
      seconds: {
        background: '#eaedf1',
        display: this.state.collapsed ? 'block' : 'none'
      }
    });
  };
  componentDidMount() {
    //查设备类型
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let dtypes = [{
        name: '/'
      }];
      for (let value of result) {
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes', JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })
    //获取户籍类型
    window.rpc.owner.types.getArray(0, 0).then((result) => {
      let Orgtypes = [{ name: '/' }];
      for (let value of result) {
        Orgtypes[value.id] = value;
      }
      sessionStorage.setItem('Orgtypes', JSON.stringify(Orgtypes));
    }, (err) => {
      console.warn(err);
    })
    //查安装位置
    window.rpc.area.getArray(0, 0).then((result) => {
      let locations = [{
        name: '/'
      }];
      for (let value of result) {
        locations[value.id] = value;
      }
      sessionStorage.setItem('locations', JSON.stringify(locations));
    }, (err) => {
      console.warn(err);
    })

    //查报警类型
    window.rpc.alias.getValueByName('device.alarm.type').then((result) => {

      let alarmTypes = [{
        name: '/'
      }];
      for (let value in result) {
        alarmTypes[value] = result[value];
      }
      sessionStorage.setItem('alarmTypes', JSON.stringify(alarmTypes));
    }, (err) => {
      console.warn(err);
    })
    // 查权限
    window.rpc.menu.getInfo().then((res) => {
      let display = res[5].default ? '' : 'none';
      let data = [];
      data.push(res[5].data[0].data[0].default, res[5].data[1].data[0].default, res[5].data[2].data[0].default, res[5].data[3].data[0].default, )
      this.setState((prevState) => ({ data, display }));
    })
  }
  componentWillMount() {
    if (this.props.children) {
      let path = this.props.children.props.route.path;
      if (path === '/conct/manage') {
        this.setState({
          route: routes.manage,
          routeName: '报警管理',
          routeKey: '1'
        })
      } else if (path === '/conct/statistics') {
        this.setState({
          route: routes.stati,
          routeName: '报警统计',
          routeKey: '2'
        })
      } else if (path === '/conct/history') {
        this.setState({
          route: routes.history,
          routeName: '报警处理',
          routeKey: '3'
        })
      } else if (path === '/conct/settings') {
        this.setState({
          route: routes.settings,
          routeName: '报警设定',
          routeKey: '4'
        })
      }
    }
  };
  componentWillReceiveProps(nextProps) {
    let path = nextProps.children.props.route.path;
    if (path === '/conct/manage') {
      this.setState({
        route: routes.manage,
        routeName: '报警管理',
        routeKey: '1'
      })
    } else if (path === '/conct/statistics') {
      this.setState({
        route: routes.stati,
        routeName: '报警统计',
        routeKey: '2'
      })
    } else if (path === '/conct/history') {
      this.setState({
        route: routes.history,
        routeName: '报警处理',
        routeKey: '3'
      })
    } else if (path === '/conct/settings') {
      this.setState({
        route: routes.settings,
        routeName: '报警设定',
        routeKey: '4'
      })
    }
    let routerkeys = Object.keys(routes);
    let route = [...routes[routerkeys[0]], ...routes[routerkeys[1]], ...routes[routerkeys[2]], ...routes[routerkeys[3]]];
    let routeKey = route.filter(x => x.path === path)[0] ? route.filter(x => x.path === path)[0].key : '10000';
    this.setState({
      routeKey
    });
  };
  render() {
    return (
      <Layout className="Conct">
        <Sider
          trigger={null}
          collapsible
          collapsed={this.state.collapsed}
          style={this.state.seconds}
          width={180}
        >
          <div className="logo" style={{ background: '#eaedf1', height: '70px', lineHeight: '70px', paddingLeft: '24px' }}>{this.state.routeName}</div>
          <Menu theme="light" mode="inline" defaultSelectedKeys={[this.state.routeKey]} selectedKeys={[this.state.routeKey]} style={{ background: '#eaedf1' }}>
            {this.state.route.map(route =>
              (<Menu.Item
                key={route.key}
                disabled={!this.state.data[parseInt(route.key) - 1]}
                style={{ display: this.state.data[parseInt(route.key) - 1] ? '' : 'none', height: '40px' }}
              >
                <Link to={route.path} style={{ color: "#666" }}>{route.name}
                </Link>
              </Menu.Item>))}
          </Menu>
        </Sider>
        <Layout style={{ padding: '0', position: 'static!important' }}>
          <div className="toggle" style={{ height: '32px', width: '18px', background: this.state.collapsed ? '#eaedf1' : '#fff', textAlign: 'center', position: 'absolute', top: '50vh', marginLeft: this.state.collapsed ? 0 : '-18px' }}>
            <Icon
              className="trigger-right"
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
              onClick={this.toggle}
            />
          </div>
          <Content style={{ display: this.state.display, padding: 24, margin: 0, background: '#fff', minHeight: 280 }}>
            {this.props.children}
          </Content>
          <Content key='2' style={{ display: this.state.display === 'none' ? '' : 'none', padding: 24, margin: 0, textAlign: "center", marginTop: '10%', background: '#fff', fontSize: '2rem', minHeight: 280 }}>
            权限不足！
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Conct;