import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Card, Form, Table, Radio } from 'antd';
import moment from 'moment';
import echarts from 'echarts';
import '../concentStatistics.css';

const FormItem = Form.Item;
const { RangePicker } = DatePicker;
let nowday = new Date();
let beginTime = '';
let lastTime = moment(nowday).format('YYYY-MM-DD');
let locations = JSON.parse(sessionStorage.getItem('locations')) || [];

const columns = [{
	title: '安装位置',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '设备数量',
	dataIndex: 'value',
	key: 'value',
}];
class deviceState {
	constructor() {
		extendObservable(this, {
			tableDate: [],

		})
	}
}

class AdvancedSearchForm extends React.Component {
	// state = {
	// 	beginTime: '',
	// 	lastTime: moment(nowday).format('YYYY-MM-DD'),
	// }

	componentWillMount() {

		let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
		let month = date.getMonth() + 1;
		let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
		beginTime = moment(weekday).format('YYYY-MM-DD');
		//this.setState({ beginTime: weekday });
		this.changeTimeData();
	}
	changeTimeData = () => {
		function pushChildren(data) {
			let arr = [...data];
			let layer = arr.map(x => x.layer).sort((a, b) => b - a)[0];
			let layerNow = arr.filter(x => x.layer === layer);
			let layerUp = arr.filter(x => x.layer !== layer);
			//此处为最外层数据
			//let parentDataA = layerUp.map(x => ({ ...x, key: x.id, value: x.value, name: x.name }));
			//console.log(parentDataA);
			//	this.props.typeMountState.parData = parentDataA;

			//let parentData =layerUp;

			for (let i = 0; i < layerUp.length; i++) {
				for (let j = 0; j < layerNow.length; j++) {
					if (layerNow[j].parentId === layerUp[i].id) {
						if (layerUp[i].children) {
							layerUp[i].value += layerNow[j].value;
							layerUp[i].children.push({ ...layerNow[j], key: `${layerNow[j].id}-${layer}` });
						} else {
							layerUp[i].value += layerNow[j].value;
							layerUp[i].children = [{ ...layerNow[j], key: `${layerNow[j].id}-${layer}` }];
						}
					}
				}
			}
			if (layer === 2) {
				return layerUp;
			} else {
				pushChildren(layerUp);
			}
			//this.setState.parentType=parentDataA;
		}

		window.rpc.device.alarm.getFieldCountByContainer({ createTime: [new Date(beginTime), new Date(lastTime)] }, 'location').then((res) => {
			let alarmTypesArr = [];
			let tableDate = locations.filter(x => x).map(x => ({ ...x, key: x.id, value: res[x.id] || 0 })).filter(x => x.id);
			console.log(tableDate.filter(x => x.layer === 2))
			pushChildren(tableDate);
			this.props.deviceState.tableDate = tableDate;
			tableDate.filter(x => x.layer === 1).forEach(value => {
				alarmTypesArr.push(value.name)
			})
			let myChart = echarts.init(document.getElementById('TaskResultEcharts'));
			myChart.setOption({
				color: ['#3398DB'],
				title: {
					text: '安装位置'
				},
				tooltip: {},
				legend: {
					data: ['数量']
				},
				xAxis: {
					data: alarmTypesArr,
				},
				yAxis: {},
				series: [{
					name: '数量',
					type: 'bar',
					//data: [...this.patrolData].filter(x => x.key !== 1)
					data: [...this.props.deviceState.tableDate]
				}]
			});
		}, (err) => {
			console.warn(err);
			 function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
		});
	}
	onChange = (e) => {
		//console.log(e.target.value);
		switch (e.target.value) {
			case 'week':
				let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
				let month = date.getMonth() + 1;
				let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
				beginTime = moment(weekday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData();
				break;
			case 'month': {
				let monthday = nowday.getFullYear() + '-' + nowday.getMonth() + '-' + nowday.getDate();
				beginTime = moment(monthday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				//this.setState({ beiginTime: monthday, lastTime: moment(nowday).format('YYYY-MM-DD') });
				this.changeTimeData();
				break;
			}
			case 'seacon': {
				let seaconday = nowday.getFullYear() + '-' + (nowday.getMonth() - 2) + '-' + nowday.getDate();
				beginTime = moment(seaconday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData();
				break;
			}
			default: {

			}
		}
	}
	handleSearch = (e) => {
		e.preventDefault();
		try {
			this.props.form.validateFields((err, fieldsValue) => {
				const targetTime = fieldsValue['targetTime'];
				beginTime = targetTime[0].format('YYYY-MM-DD');
				lastTime = targetTime[1].format('YYYY-MM-DD');
				this.changeTimeData();
			});

		} catch (e) {
			console.warn(e);
		}
	}

	render() {
		const { getFieldDecorator } = this.props.form;
		const dateFormat = 'YYYY/MM/DD';
		return (
			<Form layout="inline" style={{ margin: '15px 0 0' }}>
				<Row>
					<Col style={{ float: "left", marginRight: 20 }} key={1}>
						<FormItem>
							{getFieldDecorator('chooseTime', {
								initialValue: 'week'
							})(
								<Radio.Group onChange={this.onChange}>
									<Radio.Button value="week">周</Radio.Button>
									<Radio.Button value="month">月</Radio.Button>
									<Radio.Button value="seacon">季</Radio.Button>
								</Radio.Group>
								)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={2}>
						<FormItem label={`时间`}>
							{getFieldDecorator(`targetTime`)(
								<RangePicker
									showTime
									format="YYYY-MM-DD"
									placeholder={['开始日期', '结束日期']}
									style={{ width: 200 }} />
							)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={3}>
						<FormItem>
							<Button
								type="primary"
								onClick={this.handleSearch}
							>
								搜索
              </Button>
						</FormItem>
					</Col>
				</Row>
			</Form>
		);
	}
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

// @observer
const TaskResultC = observer(class TaskResultC extends Component {
	constructor() {
		super();

		this.state = {
			size: 'default',
			parentType: []
		};
	}

	onChangeDate(date, dateString) {
		console.log(date, dateString);
	}

	handleSizeChange = (e) => {
		this.setState({ size: e.target.value });
	}

	render() {
		return (
			<div className="TaskResult" style={{ padding: '13px 0 0' }}>
				<div className="contentDetail">
					<WrappedAdvancedSearchForm deviceState={this.props.deviceState} />
				</div>
				<Row style={{ padding: '30px 0' }}>
					<Col>
						安装位置：
				        </Col>
				</Row>
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<Col span={8}>
						<Card>
							<Table dataSource={[...this.props.deviceState.tableDate].filter(x => x.layer === 1)} columns={columns} pagination={false} />
						</Card>
					</Col>
					<Col span={16}>
						<Card>
							<div id="TaskResultEcharts" style={{ height: '45vh', width: '100%' }}></div>
						</Card>
					</Col>
				</Row>

			</div>
		);
	}
})

class TaskResult extends Component {
	render() {
		return (
			<TaskResultC deviceState={new deviceState()} />
		)
	}
}

export default TaskResult;