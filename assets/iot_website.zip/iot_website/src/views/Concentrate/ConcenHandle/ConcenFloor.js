/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: xmj
<<<<<<< HEAD
 * @Last Modified time: 2017-03-28 15:48:22
=======
 * @Last Modified time: 2017-03-28 13:02:57
>>>>>>> 84a9beca2f3f38cc1a9532537d5e40984652240a
 */
import React, { Component } from 'react';
import { Form, Button, Row, Col, message } from 'antd';
import concentFloor_pic from '../../../assets/images/concentrate/cjzongpingtu.png';
import './concenFloor.css';
import { Link } from 'react-router';
import moment from 'moment';
//let obj = document.getElementById("locationMark");
//obj.style.backgroundColor= "black";
const DemoBox = props => <p className={`height-${props.value}`}>{props.children}</p>;
const FormItem = Form.Item;

class ConcenFloor extends Component {
  constructor() {
    super();
    this.state = {
      id: null,
      device: [],
    };
  }
  componentDidMount() {
    const id = parseInt(this.props.params.id, 10);
    this.setState({ id });
    //建筑
    window.rpc.device.getInfoById(id).then((result) => {
      const device = { ...result, name: result.name, location: result.location, networkAddr: result.networkAddr, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString };
      this.setState({ device });
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  render() {
    return (

      <div className="ConcenEquipment" style={{ fontSize: 14, fontFamily: '苹方中等' }}>
        <Row type="flex" justify="center" align="middle" style={{ marginLeft: '5%' }}>
          <Col span={10} style={{ marginTop: 10 }}>
            <DemoBox value={50}>
              报警建筑物： {this.state.device.name}
            </DemoBox>
          </Col>
          <Col span={12} style={{ marginTop: 10 }}>
            <DemoBox value={50}>
              使用性质： {this.state.device.networkAddr}
            </DemoBox>
          </Col>
        </Row>
        <Row type="flex" justify="center" align="top" style={{ marginLeft: '5%' }}>
          <Col span={10} style={{ marginTop: 10 }}>
            <DemoBox value={50}>
              火灾危险性： {this.state.device.location}
            </DemoBox>
          </Col>
          <Col span={12} style={{ marginTop: 10 }}>
            <DemoBox value={50}>
              结构类型： {this.state.device.lastTime}
            </DemoBox>
          </Col>
        </Row>
        <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD', marginTop: 10 }} />
        <Row style={{ width: '100%', margin: '10% 0 ' }}>
          <Col span={18}>
            <div className="ConcenFloor" >
              <div className="locationMark" id="locationMark" style={{ position: 'absolute', left: '350px', top: '500px' }}></div>
              <img src={concentFloor_pic} alt="出警总平图" />
            </div>
          </Col>
        </Row>
        <br />
        <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
        <Row>
          <Col span={20}></Col>
          <Col span={4}>
            <Row style={{ margin: '0' }}>
              <Col span={6}></Col>
              <Col span={9}></Col>
              <Col span={9}>
                <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginTop: 20, marginRight: 30 }}><Link to={`/conct/handle/${this.state.id}`}>返回</Link></Button>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    );
  }
}


export default ConcenFloor;