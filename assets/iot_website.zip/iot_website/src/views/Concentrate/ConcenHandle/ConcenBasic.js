/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:02:55

 */

import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { Link } from 'react-router';
import { observer } from 'mobx-react';
import { Tabs, Icon, Row, Col, Button,  Card, message } from 'antd';
import moment from 'moment';

const { TabPane } = Tabs;

message.config({
  top: 216,
  duration: 2
})

class deviceState {
  constructor() {
    extendObservable(this, {
      runData: [{ key: 1, id: 1, state: '合格', createTime: '2016-09-26 08:50:08' }]
    })
  }
}

// @observer
const DeviceC = observer(class DeviceC extends Component {
  constructor() {
    super();
    this.state = {
      id:null,
      runData:[],
      area:[],
      owner:[],
      device: {
        name: '',
        location: '',
        setupTime: '',
        expiryTime: '',
        lastTime:'',
        armtype:'',
        dtype:'',
        rstate:'',
        patrolId:'',
        idQc: 123
      }
    };
  }
  componentWillMount() {
    //console.log(this.props)
    const id = parseInt(this.props.params.id, 10);
    this.setState({
      idQc: id,
      id:id
    })
    window.rpc.device.getInfoById(id).then((result) => {
      console.log(result);
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      window.rpc.area.getLocationName(result.location).then((res) => {
        const device = { ...result, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time ,location:res,};
        const runData = [{ key: result.id,rstate:'已处理',name:result.name,armtype:'火情',dtype:'消防栓',patrolId:'消防员002', lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time ,}];
        this.setState({ runData });
        console.log(runData)
        this.setState({ device });
      },(err) =>{
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  //户籍 建筑
  componentDidMount() {
    const id = parseInt(this.props.params.id, 10);
    //建筑
    window.rpc.area.getInfoById(id).then((result) => {
      const area = { ...result,name:result.name,layer:result.layer,galleryful:result.galleryful,face:result.face,hight:result.hight,number:result.number,createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString };
      console.log('户籍:'+area)
      this.setState({ area });
    }, (err) => {
    console.warn(err);
    })
    //户籍
    window.rpc.owner.getInfoById(id).then((result) => {
      const owner = { ...result,name:result.name,asset:result.asset,face:result.face,address:result.address,peopleScale:result.peopleScale,number:result.number,registerTime: moment(result.registerTime).format("YYYY年MM月DD日") || new Date().toLocaleString,lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, };
      console.log(owner)
      this.setState({ owner });
    }, (err) => {
    console.warn(err);
    })
  }
  onChangeDate(date, dateString) {
    //console.log(date, dateString);
  }

  render() {
    return (
      <div className="Device" style={{ margin: 0 , fontFamily:'苹方中等'}} >
        <Tabs defaultActiveKey="1" style={{ paddingLeft: '15px',marginTop: -4}} >
          <TabPane tab={<span><Icon type="info-circle-o" />基本信息</span>} key="1" style={{ padding: '5px' }}>
           <div style={{ marginTop: -4, paddingTop:5, height: 500, overflow: 'auto' ,}}>
             <Card bodyStyle={{ fontsize: 16, color: '#666666' }} bordered={false}>
              <Row style={{ padding: '0  0 5px', fontsize: '16px', }}>
                <Col span={10}>处理结果：已处理</Col>
                <Col span={12}>处理人：警卫处小王007</Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>报警时间： {this.state.device.lastTime}</Col>
                <Col span={12}>处理时间： {this.state.device.lastTime}</Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>报警类型：</Col>
                <Col span={12}>报警位置：{this.state.device.location}</Col>
              </Row>
            </Card>
            <br />
            <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />
            <br />
            <Card bodyStyle={{ fontsize: 16, color: '#666666' }} bordered={false}>
              <Row style={{ padding: '0  0 5px', fontsize: '16px', }}>
                <Col span={10}>设备名称： {this.state.device.name}</Col>
                <Col span={12}>报警类型： </Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>所属系统： </Col>
                <Col span={12}>所在建筑： 圆球咖啡</Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>生产厂家： </Col>
                <Col span={12}>安装时间： {this.state.device.setupTime}</Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>设备类型： 消火栓</Col>
                <Col span={12}>报警时间： {this.state.device.createTime}</Col>
              </Row>
              <Row style={{ padding: '5px 0 0' }}>
                <Col span={10}>安装位置： {this.state.device.location}</Col>
              </Row>
            </Card>
            </div>
            <br />
            <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
            <Row>
             <Col span={20}></Col>
              <Col span={4}>
               <Row style={{ margin: '0' }}>
                 <Col span={6}></Col>
                 <Col span={9}></Col>          
                 <Col span={9}>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px',marginTop:20,marginRight:30 }}><Link to={`/conct/handle/${this.state.id}`}>返回</Link></Button>
                 </Col>
              </Row>
             </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />户籍</span>} key="2" style={{ padding: '5px' }}>
           <div style={{ marginTop: -4, paddingTop:5, height: 500, overflow: 'auto' ,}}>
            <Card bodyStyle={{ fontsize: 16, color: '#666666' }} bordered={false}>
              <Row style={{ padding: '0  0 5px', fontsize: '16px', }}>
                <Col span={10}>户籍名称：{this.state.owner.name} </Col>
                <Col span={12}>户籍类型：</Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>户籍状态： </Col>
                <Col span={12}>资产：{this.state.owner.asset} </Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>面积(平方米)：{this.state.owner.face} </Col>
                <Col span={12}>详细地址：{this.state.owner.address} </Col>
              </Row>
              <br />
              <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
              <br />
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>人数规模：{this.state.owner.peopleScale} </Col>
                <Col span={12}>注册时间：{this.state.owner.registerTime} </Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>营业执照编号：{this.state.owner.number} </Col>
                <Col span={12}>最后更新时间：{this.state.owner.lastTime} </Col>
              </Row>
            </Card>
            </div>
            <br />
            <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
            <Row>
             <Col span={20}></Col>
              <Col span={4}>
               <Row style={{ margin: '0' }}>
                 <Col span={6}></Col>
                 <Col span={9}></Col>          
                 <Col span={9}>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px',marginTop:20,marginRight:30 }}><Link to={`/conct/handle/${this.state.id}`}>返回</Link></Button>
                 </Col>
              </Row>
             </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />建筑</span>} key="3" style={{ padding: '5px' }}>
           <div style={{ marginTop: -4, paddingTop:5, height: 500, overflow: 'auto' ,}}>
            <Card bordered={false}>
              <Row style={{ padding: '0  0 5px' }}>
                <Col span={10}>建筑名称：{this.state.area.name} </Col>
                <Col span={12}>建筑类型： </Col>
              </Row>
              <Row style={{ padding: '5px 0' }}>
                <Col span={10}>层次数： {this.state.area.layer}</Col>
                <Col span={12}>火灾危险性：</Col>
              </Row>
              <Row style={{ padding: '5px 0 0' }}>
                <Col span={10}>容纳人数：{this.state.area.galleryful} </Col>
                <Col span={12}>面积(平方米)： {this.state.area.face}</Col>
              </Row>
              <br />
              <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} /> 
              <br />
              <Row style={{ padding: '5px 0 0' }}>
                <Col span={10}>高度(米)：{this.state.area.hight} </Col>
                <Col span={10}>编号：{this.state.area.number} </Col>
              </Row>
              <Row style={{ padding: '5px 0 0' }}>
                <Col span={10}>建造日期：{this.state.area.createTime} </Col>
              </Row>
            </Card>
            </div>
            <br />
            <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
            <Row>
             <Col span={20}></Col>
              <Col span={4}>
               <Row style={{ margin: '0' }}>
                 <Col span={6}></Col>
                 <Col span={9}></Col>          
                 <Col span={9}>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px',marginTop:20,marginRight:30 }}><Link to={`/conct/handle/${this.state.id}`}>返回</Link></Button>
                 </Col>
              </Row>
             </Col>
            </Row>
          </TabPane>
        </Tabs>
      </div>
    )
  }
})

class ConcenBasic extends Component {
  render() {
    return (
      <DeviceC deviceState={new deviceState()} params={this.props.params} />
    )
  }
}

export default ConcenBasic;