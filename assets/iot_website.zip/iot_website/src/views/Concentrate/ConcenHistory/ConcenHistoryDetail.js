/*
 * @Author: Han.beibei 
 * @Date: 2017-03-08 10:03:44 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:05:09
 */

import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { Link, browserHistory } from 'react-router';
import { observer } from 'mobx-react';
import { Tabs, Icon, Row, Col, Button, Table, message } from 'antd';
import moment from 'moment';
import listStore from '../listStore';
import './ConcenHistory.css';
import chang from '../../../assets/images/account/chang.png';
import time from '../../../assets/images/account/time.png';
import timeOne from '../../../assets/images/account/timeOne.png';
import prdu from '../../../assets/images/account/prdu.png';
import danwei from '../../../assets/images/account/danwei.png';
//import createTime from '../../../assets/images/account/createTime.png';
import location from '../../../assets/images/account/location.png';
import nameOne from '../../../assets/images/account/name.png';

// 结构出参量表
const { armtypeList, ResultState, dStateList } = listStore;
const { TabPane } = Tabs;

message.config({
  top: 216,
  duration: 2
})
//取出户籍类型
let Orgtypes = JSON.parse(sessionStorage.getItem('Orgtypes')) || [];

// 二维码
/*class QrCode extends React.Component {
  state = {
    modal2Visible: false
  }
  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }
  render() {
    let ie = "http://qr.liantu.com/api.php?text=http%3a%2f%2fiot.lszpcn.com%2fdevice%2finfo%26id%3d" + this.props.id;
    return (
      <span>
        <Button type="primary" onClick={() => this.setModal2Visible(true)} style={{ borderColor: "#ccc", color: "#000", backgroundColor: "white" }}>点我查看二维码</Button>
        <Modal
          title="请扫以下二维码"
          wrapClassName="vertical-center-modal"
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          style={{ height: "400px" }}
        >
          <img src={ie} alt="" style={{ marginLeft: "80px" }} />
        </Modal>
      </span>
    );
  }
}*/
class deviceState {
  constructor() {
    extendObservable(this, {
      runData: [{ key: 1, id: 1, state: '合格', createTime: '2016-09-26 08:50:08' }],
      patrolData: [{ key: 1, id: 1, userId: 1, type: '巡查', state: '正常', createTime: '2015-09-26 08:50:08', reportId: 1, remark: 'My name is' }],
      maintainData: [{ key: 1, id: 1, userId: 1, type: '巡查', state: '正常', createTime: '2015-09-26 08:50:08', reportId: 1, remark: 'My name is' }],

      addRun: action(function () {
        // console.log(this.runData);
        this.runData.push({ key: 2, id: 2, state: '不合格', createTime: '2016-10-26 08:50:08' })
      })
    })
  }
}

// @observer
const DeviceC = observer(class DeviceC extends Component {
  constructor() {
    super();
    this.state = {
      runData: [],
      rData: [],
      area: [],
      owner: [],
      OrgsType: null,
      device: {
        name: '',
        location: '',
        setupTime: '',
        expiryTime: '',
        lastTime: '',
        armtype: '',
        dtype: '',
        rstate: '',
        patrolId: '',
        idQc: 123
      }
    };
  }
  componentWillMount() {
    //console.log(this.props)
    const id = parseInt(this.props.params.id, 10);
    this.setState({
      idQc: id
    })
    window.rpc.device.getInfoById(id).then((result) => {
      //console.log(result);
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      window.rpc.area.getLocationName(result.location).then((res) => {
        const device = { ...result, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, location: res, };
        this.setState({ device });
      }, (err) => {
        console.warn(err);
      })

    }, (err) => {
      console.warn(err);
    })
  }
  //户籍 建筑
  componentDidMount() {
    const id = parseInt(this.props.params.id, 10);
    //处理记录
    window.rpc.device.alarm.getInfoById(id).then((result) => {
      const runData = [{ ...result, key: result.id, id: result.id, state: ResultState[result.state], type: armtypeList[result.type], userId: '巡查员A', lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString }];
      this.setState({ runData });
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
    //建筑
    window.rpc.area.getInfoById(id).then((result) => {
      const area = { ...result, name: result.name, layer: result.layer, galleryful: result.galleryful, face: result.face, hight: result.hight, };
      this.setState({ area });
      //console.log(area)
    }, (err) => {
      console.warn(err);
    })
    //户籍
    window.rpc.owner.getInfoById(id).then((result) => {
      const owner = { ...result, type: Orgtypes[result.type]['name'], state: dStateList[result.state], name: result.name, asset: result.asset, face: result.face, address: result.address, peopleScale: result.peopleScale, registerTime: moment(result.registerTime).format("YYYY年MM月DD日") || new Date().toLocaleString, };

      this.setState({ owner });
    }, (err) => {
      console.warn(err);
    })
    //处理结果详情数据
    window.rpc.device.alarm.getInfoById(id).then((result) => {
      const rData = { ...result, type: armtypeList[result.type], createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString };

      this.setState({ rData });
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  onChangeDate(date, dateString) {
    //console.log(date, dateString);
  }

  render() {
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '报警时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '报警类型', dataIndex: 'type', key: 'type' },
      { title: '处理结果', dataIndex: 'state', key: 'state' },
      { title: '处理人', dataIndex: 'userId', key: 'userId' },
      { title: '处理时间', dataIndex: 'lastTime', key: 'lastTime' },
    ];
    return (
      <div style={{ height: '100%' }} className='Floor'>
        <Tabs style={{ padding: '0px', height: '100%', fontSize: '0.75rem' }} className='infoTabOne' >
          <TabPane className="firstTabInfo" tab={<span><Icon type="info-circle-o" />处理记录</span>} style={{ height: '100%', }} key="1">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/conct/history' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警处理</Link>
            </div>
            <Row >
              <Col span={24} className='ConcenHistory'>
                <Table
                  columns={columns}
                  dataSource={[...this.state.runData]}
                  pagination={false}
                />
              </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span style={{}}><Icon type="info-circle-o" />基础信息</span>} style={{ height: '100%', }} key="2">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/conct/history' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警处理</Link>
            </div>
            <div style={{ marginTop: -4, paddingTop: 5, height: '100%', maxHeight: 780, overflow: 'auto', }}>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75em', color: '#373e41', }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>设备基础信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={nameOne} alt="" style={{ marginRight: 20 }} />设备名称： {this.state.device.name} </div>
                    <div className="Row-info-right"><img src={location} alt="" style={{ marginRight: 20 }} />设备型号： </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />所属系统： </div>
                    <div className="Row-info-right"><img src={chang} alt="" style={{ marginRight: 20 }} />所在建筑：</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={time} alt="" style={{ marginRight: 20 }} />生产厂家： </div>
                    <div className="Row-info-right"><img src={location} alt="" style={{ marginRight: 20 }} />安装时间： {this.state.device.setupTime}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />设备类型： </div>
                    <div className="Row-info-right"><img src={timeOne} alt="" style={{ marginRight: 20 }} />报警时间： {this.state.rData.createTime}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={prdu} alt="" style={{ marginRight: 20 }} />报警类型：{this.state.rData.type}  </div>
                    <div className="Row-info-right"><img src={timeOne} alt="" style={{ marginRight: 20 }} />处理时间： {this.state.rData.lastTime}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />安装位置： </div>
                  </div>
                </div>
              </div>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75em', color: '#373e41', }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>设备其他信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={nameOne} alt="" style={{ marginRight: 20 }} />网关地址：  </div>
                    <div className="Row-info-right"><img src={prdu} alt="" style={{ marginRight: 20 }} />网关序号：</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />采集模块：  </div>
                    <div className="Row-info-right"><img src={location} alt="" style={{ marginRight: 20 }} />监控类型：</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={chang} alt="" style={{ marginRight: 20 }} />监测类型： </div>
                    <div className="Row-info-right"><img src={prdu} alt="" style={{ marginRight: 20 }} />单位：</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />监测范围： </div>
                    <div className="Row-info-right"><img src={location} alt="" style={{ marginRight: 20 }} />监测值：</div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <Row style={{ paddingTop: 20, background: '#fff' }}>
                <Button type="success" style={{ borderRadius: 0 }}><Link to="/conct/history">返回</Link></Button>
              </Row>
            </div>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />户籍建筑</span>} style={{ height: '100%', }} key="3">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/conct/history' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警处理</Link>
            </div>
            <div style={{ marginTop: -4, paddingTop: 5, height: '100%', maxHeight: 780, overflow: 'auto', }}>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75em', color: '#373e41', }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>户籍信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={nameOne} alt="" style={{ marginRight: 20 }} />户籍名称：{this.state.owner.name}</div>
                    <div className="Row-info-right"><img src={prdu} alt="" style={{ marginRight: 20 }} />户籍类型：{this.state.owner.type} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />户籍状态：{this.state.owner.state} </div>
                    <div className="Row-info-right"><img src={location} alt="" style={{ marginRight: 20 }} />资产：{this.state.owner.asset}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={chang} alt="" style={{ marginRight: 20 }} />面积(平方米)：{this.state.owner.face} </div>
                    <div className="Row-info-right"><img src={chang} alt="" style={{ marginRight: 20 }} />详细地址：{this.state.owner.address}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />人数规模：{this.state.owner.peopleScale}  </div>
                    <div className="Row-info-right"><img src={timeOne} alt="" style={{ marginRight: 20 }} />注册时间：{this.state.owner.registerTime}</div>
                  </div>
                </div>
              </div>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75em', color: '#373e41', }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>建筑信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={nameOne} alt="" style={{ marginRight: 20 }} />建筑名称：{this.state.area.name}  </div>
                    <div className="Row-info-right"><img src={nameOne} alt="" style={{ marginRight: 20 }} />建筑类型：{this.state.area.type}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />层次数： {this.state.area.layer}  </div>
                    <div className="Row-info-right"><img src={location} alt="" style={{ marginRight: 20 }} />火灾危险性：{this.state.area.fireLevel}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={chang} alt="" style={{ marginRight: 20 }} />容纳人数：{this.state.area.galleryful} </div>
                    <div className="Row-info-right"><img src={nameOne} alt="" style={{ marginRight: 20 }} />面积(平方米)： {this.state.area.face}</div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={danwei} alt="" style={{ marginRight: 20 }} />高度(米)：{this.state.area.hight} </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <Row style={{ paddingTop: 20, background: '#fff' }}>
                <Button type="success" style={{ borderRadius: 0 }} onClick={() => { browserHistory.push("/conct/history"); }}>返回</Button>
              </Row>
            </div>
          </TabPane>
        </Tabs>
      </div >
    )
  }
})

class ConcenHistoryDetail extends Component {
  render() {
    return (
      <DeviceC deviceState={new deviceState()} params={this.props.params} />
    )
  }
}

export default ConcenHistoryDetail;