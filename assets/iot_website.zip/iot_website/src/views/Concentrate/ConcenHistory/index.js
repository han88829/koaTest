/*
 * @Author: Han.beibei 
 * @Date: 2017-03-07 09:32:18 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:05:28
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message } from 'antd';
import moment from 'moment';
import listStore from '../listStore';
import './ConcenHistory.css';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
var number = '';
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 结构出参量表
const { armtypeList, ResultState } = listStore;

// 取出类型和locations
let types = JSON.parse(sessionStorage.getItem('dtypes')) || [];
let locations = JSON.parse(sessionStorage.getItem('locations')) || [];
// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        const type = fieldsValue['type'];
        const location = fieldsValue['location'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (type) {
          values = { ...values, type: fieldsValue['type'].map(x => parseInt(x, 10)) };
        }
        if (location) {
          values = { ...values, location: fieldsValue['location'].map(x => parseInt(x, 10)) };
        }
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => parseInt(x, 10)) };
        }
        if (rangeValue) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        window.rpc.device.alarm.getArrayBriefByContainer(values, 0, 0).then((result) => {
          console.log(values)
          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, dtype: types[x.deviceId]['name'], name: x.deviceName, location: x.location || '/', type: armtypeList[x.type], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          this.props.appState.tableData = users.reverse();
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let locations = JSON.parse(sessionStorage.getItem('locations')) || [];
    let dtypeChildren = [];
    let locationChildren = [];
    let armChildren = [];

    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of locations) {
      if (value && value.id && value.type === 50) {
        locationChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    for (let i = 1; i < armtypeList.length; i++) {
      armChildren.push(<Option key={`${i}`}>{armtypeList[i]}</Option>)
    }


    return (
      <Form layout="inline" style={{ margin: 0, fontFamily: '苹方中等' }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`报警设备`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 150 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`设备类型`}>
              {getFieldDecorator(`dtype`)(
                <Select multiple style={{ width: 150 }} placeholder="请选择">
                  {dtypeChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`报警类型`}>
              {getFieldDecorator(`type`)(
                <Select multiple style={{ width: 150 }} placeholder="请选择">
                  {armChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`安装位置`}>
              {getFieldDecorator(`location`)(
                <Select multiple style={{ width: 150 }} placeholder="请选择">
                  {locationChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`报警时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker style={{ width: 250 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
// @observer
const EquipManageC = observer(class EquipManageC extends Component {
  constructor() {
    super();
    this.state = {
      display: "none"
    }
  }
  componentDidMount() {
    window.rpc.device.alarm.getArrayBriefByContainer(null, 0, 0).then((result) => {
      let alarm = result.map(x => ({ ...x, name: x.deviceName, dtype: x.deviceTypeName, location: x.location || '/', type: armtypeList[x.type] || '/', key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = alarm;
    }, (err) => {
      console.warn(err);
    })

  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
  };
  handleChange = (pagination, filters, sorter) => {
    //console.log('Various parameters', pagination, filters, sorter);
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }
  handleSelect = () => {
    if (this.props.appState.selectId != null) {
      browserHistory.push(`/conct/historydetail/${this.props.appState.selectId}`);
    } else {
      message.info('请选择设备！');
    }
  }

  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
    }, { title: '报警设备', dataIndex: 'name', key: 'name' },
    { title: '报警类型', dataIndex: 'type', key: 'type' },
    { title: '设备类型', dataIndex: 'dtype', key: 'dtype' },
    {
      title: '安装位置', dataIndex: 'location', key: 'location',
      render: (text, record) => {
        let textArr = text.split(',');
        if (textArr[2]) {
          return (
            <span>
              <Link to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
              <Link to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>--
              <Link to={`/org/area/cont/${textArr[2].split(':')[0]}`}>{textArr[2].split(':')[1]}</Link>
            </span>
          )
        }
        if (textArr[1]) {
          return (
            <span>
              <Link to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
              <Link to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>
            </span>
          )
        }
        if (textArr[0]) {
          return (
            <span>
              <Link to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>
            </span>
          )
        }
      }
    },//{ title: '处理状态', dataIndex: 'rstate', key: 'rstate' },
    { title: '报警时间', dataIndex: 'createTime', key: 'createTime' },
    { title: '处理时间', dataIndex: 'lastTime', key: 'lastTime' },
    //{ title: '处理人', dataIndex: 'patrolId', key: 'patrolId' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/conct/historydetail/${record.key}`}>查看</Link>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];
    //console.log(data)
    const pagination = {
      total: number,
      showTotal: total => `共 ${number} 条`,
      pageSize: 10,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
    };

    //表格单选框设置
    const rowSelection = {
      type: 'radio',
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (
      <div className="ConcenHistory" >
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警处理</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4, marginTop: '-7px' }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleSelect} >设备详情</Button>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        {/*<Row style={{ padding: '5px 0 15px', marginTop: 20 }}>
          <Col span={24}>
            <Button type="primary" onClick={this.handleSelect}><Link to="">设备详情</Link></Button>
          </Col>
        </Row>*/}
        <Row style={{ marginTop: 20 }}>
          <Col span={24}>
            <Table
              //bordered
              style={{ color: '#999' }}
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class ConcenHistory extends Component {
  render() {
    return (
      <EquipManageC appState={new appState()} />
    )
  }
}

export default ConcenHistory;