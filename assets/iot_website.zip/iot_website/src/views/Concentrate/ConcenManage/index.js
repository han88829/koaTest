﻿/*
 * @Author: lai.haibo 
 * @Date: 2017-03-07 09:06:33 
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Modal } from 'antd';
import moment from 'moment';
import listStore from '../listStore';
import './concenManage.css';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
var number = '';
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 结构出参量表
const { rStateList, dStateList } = listStore;

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectArr: []
    })
  }
}

class AdvancedSearchForm extends React.Component {
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const deviceTypeId = fieldsValue['deviceTypeId'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['rstate'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (deviceTypeId) {
          values = { ...values, deviceTypeId: fieldsValue['deviceTypeId'].map(x => parseInt(x, 10)) }
        }
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        if (location) {
          values = { ...values, location: fieldsValue['location'].map(x => x) }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }

        window.rpc.device.alarm.getArrayBriefByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let devi = result.map((x) => ({ ...x, deviceTypeName: x.deviceTypeName, location: x.location, key: x.id, rstate: rStateList[x.rstate], dstate: dStateList[x.dstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
          let devices = devi.reverse();
          this.props.appState.tableData = devices;
        }, (err) => {
          console.warn(err);
          function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let locations = JSON.parse(sessionStorage.getItem('locations')) || [];
    let dtypeChildren = [];
    let locationChildren = [];
    let rStateChildren = [];

    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of locations) {
      if (value && value.id && value.type === 50) {
        locationChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    for (let i = 1; i < rStateList.length; i++) {
      rStateChildren.push(<Option key={`${i}`}>{rStateList[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: "12px 0" }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`设备名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 100 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`设备类型`}>
              {getFieldDecorator(`deviceTypeId`)(
                <Select multiple style={{ width: 100 }} placeholder="请选择">
                  {dtypeChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`运行状态`}>
              {getFieldDecorator(`dstate`)(
                <Select multiple style={{ width: 100 }} placeholder="请选择">
                  {rStateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`所属建筑`}>
              {getFieldDecorator(`location`)(
                <Select multiple style={{ width: 100 }} placeholder="请选择">
                  {locationChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`报警时间`}>
              {getFieldDecorator(`lastTime`)(
                <RangePicker style={{ width: 200 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

const ConcenManageC = observer(class ConcenManageC extends Component {
  state = {
    display: "none",
    ModalText: '请选择处理结果',
    visible: false,
  }
  showModal = (stateID, mark) => {
    console.log(this.props.tableData)
    if (mark) {
      if ([...this.props.appState.selectArr].length > 0) {
        this.setState({
          visible: true,
          selectedRowKeys: [...this.props.appState.selectArr]
        });
      } else {
        message.info("请选择要设置的项！")
      }
    } else {
      this.setState({
        visible: true,
        keyID: stateID
      });
    }
  }
  handleOk = () => {
    this.setState({
      visible: false,
    });
    if (this.state.selectedRowKeys.length > 0) {
      window.rpc.device.alarm.setStateByArrayId(this.state.selectedRowKeys, this.state.value).then(() => {
        message.info('批量设置成功！');
      }, (err) => {
        console.log(err);
        function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
    } else {
      window.rpc.device.alarm.setStateById(this.state.keyID, this.state.value).then(() => {
        message.info('设置成功！');
      }, (err) => {
        console.warn(err);
        function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
    }
  }
  handleCancel = () => {
    this.setState({
      visible: false,
    });
  }
  handleChange = (chooseValue) => {
    this.setState({
      value: chooseValue,
    });
  }
  state = {
    selectedRowKeys: [],  // Check here to configure the default column
    keyID: -1,
    value: 2,
  };
  componentDidMount() {
    if (sessionStorage.getItem('flag')) {
      this.setState({
        display: 'inline-block'
      })
    } else {
      this.setState({
        display: 'none'
      })
    }
    if (sessionStorage.getItem("equipment")) {
      let equipmentMap = (JSON.parse(sessionStorage.getItem("equipment")) || []).map((x) => ({ ...x, deviceTypeName: x.deviceTypeName, location: x.location, key: x.id, rstate: x.rstate, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = equipmentMap;
    } else {
      window.rpc.device.alarm.getArrayBriefByContainer(null, 0, 0).then((result) => {
        let devices = result.map(x => ({ ...x, deviceTypeName: x.deviceTypeName, location: x.location || '/', key: x.id, rstate: rStateList[x.rstate], dstate: dStateList[x.dstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
        this.props.appState.tableData = devices;
      }, (err) => {
        console.warn(err);
        function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
    }
    if (sessionStorage.getItem('number')) {
      number = parseInt(sessionStorage.getItem('number'), 10)
    } else {
      window.rpc.device.getCountByContainer(null, 0, 0).then((res) => {
        number = res;
      }, (err) => {
        console.warn(err);
      })
    }
  }
  handAll = () => {
    if (sessionStorage.getItem('number')) {
      number = parseInt(sessionStorage.getItem('number'), 10)
    } else {
      window.rpc.device.getCountByContainer({}, console.log).then((res) => {
        number = res;
      }, (err) => {
        console.warn(err);
      })
    }
    window.rpc.device.alarm.getArrayBriefByContainer(null, 0, 0).then((result) => {
      let devices = result.map(x => ({ ...x, deviceTypeName: x.deviceTypeName, location: x.location || '/', key: x.id, rstate: rStateList[x.rstate] || '/', dstate: dStateList[x.state] || '/', setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = devices;
      console.log(this.props.appState.tableData)
    }, (err) => {
      console.warn(err);
    })
  }

  handelClick(e) {
    // console.log('html' + e.target.innerText)
  }
  render() {
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      {
        title: '设备名称', dataIndex: 'deviceName', key: 'deviceName', render: (text, record) => (
          <span>
            <Link to={`/equipment/device/${record.key}`}>{text}</Link>
          </span>
        ),
      },
      { title: '设备类型', dataIndex: 'deviceTypeName', key: 'deviceTypeName' },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record) => {
          let textArr = text.split(',');
          if (textArr[2]) {
            return (
              <span>
                <Link to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>--
                <Link to={`/org/area/cont/${textArr[2].split(':')[0]}`}>{textArr[2].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[1]) {
            return (
              <span>
                <Link to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[0]) {
            return (
              <span>
                <Link to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>
              </span>
            )
          }
        }
      },
      { title: '运行状态', dataIndex: 'rstate', key: 'rstate' },
      { title: '设备状态', dataIndex: 'dstate', key: 'dstate' },
      { title: '报警时间', dataIndex: 'lastTime', key: 'lastTime' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/conct/historydetail/${record.key}`}>查看</Link>
            <span className="ant-divider" />
            <a href="#" onClick={(stateID) => this.showModal(record.key, 0)}>处警</a>
            <span className="ant-divider" />
            <Link to={`/conct/handle/${record.key}`}>辅助信息</Link>
          </span>
        )
      },
    ];

    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
      },
      onSelect: (record, selected, selectedRows) => {
        let selectArr = selectedRows.map(x => x.id);
        this.props.appState.selectArr = selectArr;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    const data = [...this.props.appState.tableData];
    const pagination = {
      total: data.length,
      showTotal: total => `共 ${total} 条`,
      pageSize: 10,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
    };

    return (
      <div className="ConcenManage">
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警管理</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button type="primary" onClick={(stateID) => this.showModal(-1, 1)} style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, borderColor: '#536679' }}>处警</Button>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              bordered
              rowSelection={rowSelection}
              columns={columns}
              dataSource={data}
              pagination={pagination}
            />
          </Col>
        </Row>
        <Modal title="处警"
          visible={this.state.visible}
          onOk={this.handleOk}
          confirmLoading={this.state.confirmLoading}
          onCancel={this.handleCancel}
          style={{ textAlign: "center" }}
          className="concentrateM"
          appState={this.props.appState}
        >
          <p>{this.state.ModalText}</p>
          <Select style={{ width: 120 }} defaultValue="2" onChange={this.handleChange} >
            <Option value="1">已处理</Option>
            <Option value="2">误报</Option>
          </Select>
        </Modal>
      </div>
    );
  }
})

class ConcenManage extends Component {
  render() {
    return (
      <ConcenManageC appState={new appState()} />
    )
  }
}

export default ConcenManage;
