/*
 * @Author: lai.haibo 
 * @Date: 2017-03-24 09:25:52 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-14 17:49:46
 */

import React, { Component } from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link, browserHistory } from 'react-router';
const { Header, Sider, Content } = Layout;
const MenuItemGroup = Menu.ItemGroup;

const routes = {
  org: [{
    name: '全部消息',
    path: '/mess/all',
    key: '1'
  }, {
    name: '未读消息',
    path: '/mess/un',
    key: '2'
  }, {
    name: '已读消息',
    path: '/mess/have',
    key: '3'
  }],
}

class Message extends Component {
  state = {
    collapsed: true,
    seconds: {
      background: '#eaedf1',
      display:'none'
    },
    route: routes.org,
    routeName: '消息中心',
    routeKey: '1'
  };
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
      seconds: {
        background: '#eaedf1',
        display: this.state.collapsed ? 'block' : 'none'
      }
    });
  };

  componentWillMount() {
    if (this.props.children) {
      let path = this.props.children.props.route.path;
      if (path === '/mess/all') {
        this.setState({
          route: routes.org,
          routeName: '全部消息',
          routeKey: '1'
        })
      }else if(path === '/mess/un'){
        this.setState({
          route: routes.org,
          routeName: '未读消息',
          routeKey: '2'
        })
      }else if(path === '/mess/have'){
        this.setState({
          route: routes.org,
          routeName: '已读消息',
          routeKey: '3'
        })
      }
    }
  };
  componentDidMount() {

  }
  componentWillReceiveProps(nextProps) {
    let path = nextProps.children.props.route.path;
    if (path === '/mess') {
      this.setState({
        route: routes.org,
        routeName: '消息中心',
        routeKey: '1'
      });
    }
    let routerkeys = Object.keys(routes);
    let route = [...routes[routerkeys[0]]];
    let routeKey = route.filter(x => x.path === path)[0] ? route.filter(x => x.path === path)[0].key : '10000';
    this.setState({
      routeKey
    });
  };

  render() {
    return (
      <Layout className="Orgx">
        <Sider
          trigger={null}
          collapsible
          collapsed={this.state.collapsed}
          style={this.state.seconds}
          width={180}
        >
          <div className="logo" style={{ background: '#eaedf1', height: '70px', lineHeight: '70px', paddingLeft: '24px' }}>{this.state.routeName}</div>
          <Menu theme="light" mode="inline" defaultSelectedKeys={[this.state.routeKey]} selectedKeys={[this.state.routeKey]} style={{ background: '#eaedf1' }}>
            {this.state.route.map(route => (<Menu.Item key={route.key} style={{ height: '40px' }}><Link to={route.path} style={{ color: "#666" }}>{route.name}</Link></Menu.Item>))}
          </Menu>
        </Sider>
        <Layout style={{ padding: '0',position: 'static!important' }}>
          <div className="toggle" style={{ height: '32px', width: '18px', background: this.state.collapsed ? '#eaedf1' : '#fff', textAlign: 'center', position: 'absolute', top: '50vh', marginLeft: this.state.collapsed ? 0 : '-18px' }}>
            <Icon
              className="trigger-right"
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
              onClick={this.toggle}
            />
          </div>
          <Content style={{ margin: '24px 16px', padding: '20px 16px  0 15px', margin: 0, overflow: 'auto', background: '#fff', minHeight: 280 }}>
            {this.props.children}
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Message;