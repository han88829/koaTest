/*
 * @Author: Han.beibei 
 * @Date: 2017-04-13 13:59:31 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-14 17:49:45
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import moment from 'moment';
import { observer } from 'mobx-react';
import { Select, Radio, Icon, Table, } from 'antd';
import './Message.css';
import listStore from '../Member/listStore';

const { messageList } = listStore ;
const Option = Select.Option;

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      selectValue: null,
    })
  }
}

const StaffC = observer(class StaffC extends Component {
  componentDidMount() {
    window.rpc.message.receive.getArrayByContainer({ state: 1024 }, 0, 0).then((result) => {
      this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
    }, (err) => {
      console.warn(err);
       console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }

  handleSizeChange = (e) => {
    //console.log(e.target.value);
    if (e.target.value == 1) {
      window.rpc.message.receive.getArrayByContainer({ state: 1024 }, 0, 0).then((result) => {
        this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
      }, (err) => {
        console.warn(err);
      })
    } else if (e.target.value == 2) {
      window.rpc.message.receive.getArrayByContainer({ state: 1024, type: 0 }, 0, 0).then((result) => {
        this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
      }, (err) => {
        console.warn(err);
      })
    } else if (e.target.value == 3) {
      window.rpc.message.receive.getArrayByContainer({ state: 1024, type: 1 }, 0, 0).then((result) => {
        this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
      }, (err) => {
        console.warn(err);
      })
    } else if (e.target.value == 4) {
      window.rpc.message.receive.getArrayByContainer({ state: 1024, type: 2 }, 0, 0).then((result) => {
        this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
      }, (err) => {
        console.warn(err);
      })
    } else if (e.target.value == 5) {
      window.rpc.message.receive.getArrayByContainer({ state: 1024, type: 3 }, 0, 0).then((result) => {
        this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
      }, (err) => {
        console.warn(err);
      })
    } else if (e.target.value == 6) {
      window.rpc.message.receive.getArrayByContainer({ state: 1024, type: 4 }, 0, 0).then((result) => {
        this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
      }, (err) => {
        console.warn(err);
      })
    } else if (e.target.value == 7) {
      window.rpc.message.receive.getArrayByContainer({ state: 1024, type: 5 }, 0, 0).then((result) => {
        this.props.appState.tableData = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }))
      }, (err) => {
        console.warn(err);
      })
    }
  }
  render() {
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id', },
      {
        title: '标题内容', dataIndex: 'name', key: 'name',
        render: (text, record) => {
          return (
            <Link>{text}</Link>
          )
        }
      },
      { title: '提交时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '类型', dataIndex: 'type', key: 'type' },
    ];

    const data = [...this.props.appState.tableData];
    //表格单选框设置
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        //console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (
      <div className="Allnews">
        <div style={{ width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ paddingLeft: 10, margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>已读消息</Link>
        </div>
        <div className="hr" style={{ marginTop: 15 }}></div>
        <div style={{ marginTop: 20 }}>
          {/*标题*/}
          <div className="Allradio">
            <Radio.Group onChange={this.handleSizeChange}>
              <Radio.Button value="1">全部类型消息</Radio.Button>
              <Radio.Button value="2">产品消息</Radio.Button>
              <Radio.Button value="3">安全消息</Radio.Button>
              <Radio.Button value="4">服务消息</Radio.Button>
              <Radio.Button value="5">活动消息</Radio.Button>
              <Radio.Button value="6">历史消息</Radio.Button>
              <Radio.Button value="7">故障消息</Radio.Button>
            </Radio.Group>
          </div>
          {/*内容*/}
          <div style={{ display: `${this.props.appState.tableData.length == 0 ? "block" : "none"}` }} >
            <div className="noNews">
              <Icon type="info-circle-o" style={{ fontSize: 30, color: "#66c7df", marginRight: 10 }} />
              您好！还没有任何消息哦！
            </div>
          </div>
          <div style={{ display: `${this.props.appState.tableData.length == 0 ? "none" : "block"}`, marginTop: 20 }} className="ConcenHistory">
            <Table
              style={{ color: '#999' }}
              columns={columns}
              dataSource={data}
              pagination={false}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </div>
        </div>
      </div>
    )
  }
})

class Haveread extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default Haveread;