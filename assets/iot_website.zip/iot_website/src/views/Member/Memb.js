/*
 * @Author: lai.haibo 
 * @Date: 2017-03-24 09:26:13 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-15 15:04:42
 */

import React, { Component } from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router';
const { Sider, Content } = Layout;

const routes = {
  staff: [{
    name: '人员信息',
    path: '/memb/staff',
    key: '1'
  }, {
    name: '人员统计',
    path: '/memb/staff/stat',
    key: '2'
  },
  {
    name: '人员权限',
    path: '/memb/staff/authority',
    key: '3'
  },
  ],
  group: [{
    name: '部门信息',
    path: '/memb/group',
    key: '4'
  }, {
    name: '部门结构',
    path: '/memb/permit',
    key: '5'
  }, {
    name: '部门权限',
    path: '/memb/frame',
    key: '6'
  }, {
    name: '部门人员',
    path: '/memb/group/memb',
    key: '7'
  }],
  prfrm: [{
    name: '绩效管理',
    path: '/memb/prfrm',
    key: '8'
  }],
  patrol: [{
    name: '巡逻设置',
    path: '/memb/patrol',
    key: '9'
  }, {
    name: '巡逻详情查看',
    path: '/memb/patrol/detail',
    key: '10'
  }, {
    name: '巡逻人管理',
    path: '/memb/patrol/man',
    key: '11'
  }, {
    name: '巡逻点管理',
    path: '/memb/patrol/point',
    key: '12'
  }, {
    name: '巡逻统计',
    path: '/memb/patrol/point/info',
    key: '13'
  }]
}

class Memb extends Component {
  state = {
    collapsed: false,
    seconds: {
      background: '#eaedf1'
    },
    route: routes.staff,
    routeName: '人员信息',
    routeKey: '1',
    data: [true, true, true, true, true, true, true, true,],
    display: ''
  };
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
      seconds: {
        background: '#eaedf1',
        display: this.state.collapsed ? 'block' : 'none'
      }
    });
  };
  componentWillMount() {
    if (this.props.children) {
      let path = this.props.children.props.route.path;
      if (path === '/memb/staff') {
        this.setState({
          route: routes.staff,
          routeName: '人员信息',
          routeKey: '1'
        })
      } else if (path === '/memb/group') {
        this.setState({
          route: routes.group,
          routeName: '部门信息',
          routeKey: '3'
        })
      } else if (path === '/memb/prfrm') {
        this.setState({
          route: routes.prfrm,
          routeName: '绩效管理',
          routeKey: '7'
        })
      } else if (path === '/memb/patrol') {
        this.setState({
          route: routes.patrol,
          routeName: '巡逻管理',
          routeKey: '8'
        })
      }
    }
  };
  componentWillReceiveProps(nextProps) {
    let path = nextProps.children.props.route.path;
    if (path === '/memb/staff') {
      this.setState({
        route: routes.staff,
        routeName: '人员信息',
        routeKey: '1'
      })
    } else if (path === '/memb/group') {
      this.setState({
        route: routes.group,
        routeName: '部门信息',
        routeKey: '3'
      })
    } else if (path === '/memb/prfrm') {
      this.setState({
        route: routes.prfrm,
        routeName: '绩效管理',
        routeKey: '7'
      })
    } else if (path === '/memb/patrol') {
      this.setState({
        route: routes.patrol,
        routeName: '巡逻管理',
        routeKey: '8'
      })
    }
    let routerkeys = Object.keys(routes);
    let route = [...routes[routerkeys[0]], ...routes[routerkeys[1]], ...routes[routerkeys[2]], ...routes[routerkeys[3]]];
    let routeKey = route.filter(x => x.path === path)[0] ? route.filter(x => x.path === path)[0].key : '10000';
    this.setState({
      routeKey
    });
    // 查权限
    window.rpc.menu.getInfo().then((res) => {
      let display = res[2].default ? '' : 'none';
      let data = [];
      data.push(res[2].data[0].data[0].default, res[2].data[0].data[1].default, res[2].data[0].data[2].default, res[2].data[1].data[0].default, res[2].data[1].data[1].default, res[2].data[1].data[2].default, res[2].data[1].data[3].default, res[2].data[2].data[0].default, )
      this.setState((prevState) => ({ data, display }));
    })
  };
  componentDidMount() {
    //查性别
    window.rpc.user.getArray(0, 0).then((result) => {
      let genders = [{
        name: '/'
      }];
      for (let value of result) {
        genders[value.id] = value;
      }
      sessionStorage.setItem('genders', JSON.stringify(genders));
    }, (err) => {
      console.warn(err);
    })
    //查等级
    window.rpc.user.getArray(0, 0).then((result) => {
      let levels = [{
        name: '/'
      }];
      for (let value of result) {
        levels[value.id] = value;
      }
      sessionStorage.setItem('levels', JSON.stringify(levels));
    }, (err) => {
      console.warn(err);
    })
    //查组织
    window.rpc.user.getArray(0, 0).then((result) => {
      let ownerIds = [{
        name: '/'
      }];
      for (let value of result) {
        ownerIds[value.id] = value;
      }
      sessionStorage.setItem('ownerIds', JSON.stringify(ownerIds));
    }, (err) => {
      console.warn(err);
    })
    //查用户组
    window.rpc.user.getArray(0, 0).then((result) => {
      let groupIds = [{
        name: '/'
      }];
      for (let value of result) {
        groupIds[value.id] = value;
      }
      sessionStorage.setItem('groupIds', JSON.stringify(groupIds));
    }, (err) => {
      console.warn(err);
    })

    //查组织
    window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      var groupownerNames = [{
        name: '/'
      }];
      for (let value of result) {
        groupownerNames[value.id] = value;
      }
      sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
    }, (err) => {
      console.warn(err);
    })
    //查等级
    window.rpc.cache.group.getArrayBriefByContainer(null, 0, 0).then((result) => {
      let grouplevels = [{
        name: '/'
      }];
      for (let value of result) {
        grouplevels[value.id] = value;
      }
      sessionStorage.setItem('grouplevels', JSON.stringify(grouplevels));
    }, (err) => {
      console.warn(err);
    })
    //查部门
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      var groupNames = [{
        name: '/'
      }];
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    })

  };
  render() {
    return (
      <Layout className="Memb">
        <Sider
          trigger={null}
          collapsible
          collapsed={this.state.collapsed}
          style={this.state.seconds}
          width={180}
        >
          <div className="logo" style={{ background: '#eaedf1', height: '70px', lineHeight: '70px', paddingLeft: '24px' }}>{this.state.routeName}</div>
          <Menu theme="light" mode="inline" defaultSelectedKeys={[this.state.routeKey]} selectedKeys={[this.state.routeKey]} style={{ background: '#eaedf1' }}>
            {this.state.route.map(route =>
              (<Menu.Item
                key={route.key}
                disabled={!this.state.data[parseInt(route.key) - 1]} key={route.key}
                style={{ display: this.state.data[parseInt(route.key) - 1] ? '' : 'none', height: '40px' }}
              >
                <Link to={route.path} style={{ color: "#666" }}>
                  {route.name}
                </Link>
              </Menu.Item>))}
          </Menu>
        </Sider>
        <Layout style={{ padding: '0', position: 'static!important' }}>
          <div className="toggle" style={{ height: '32px', width: '18px', background: this.state.collapsed ? '#eaedf1' : '#fff', textAlign: 'center', position: 'absolute', top: '50vh', marginLeft: this.state.collapsed ? 0 : '-18px' }}>
            <Icon
              className="trigger-right"
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
              onClick={this.toggle}
            />
          </div>
          <Content style={{ display: this.state.display, padding: 24, paddingBottom: 0, margin: 0, background: '#fff', minHeight: 280 }}>
            {this.props.children}
          </Content>
          <Content key='2' style={{ display: this.state.display === 'none' ? '' : 'none', padding: 24, margin: 0, textAlign: "center", marginTop: '10%', background: '#fff', fontSize: '2rem', minHeight: 280 }}>
            权限不足！
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Memb;