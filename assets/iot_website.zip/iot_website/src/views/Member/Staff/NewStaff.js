/*
 * @Author: Han.beibei 
 * @Date: 2017-03-04 15:29:37 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-22 13:47:55
 */

import React, { Component } from 'react';
import { Form, Input, Select, Button, Row, Col, message, AutoComplete } from 'antd';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import './staff.css'
import listStore from '../listStore';

import bumen from '../../../assets/images/account/bumne.png';
import dengji from '../../../assets/images/account/dengji.png';
import email from '../../../assets/images/account/email.png';
import gons from '../../../assets/images/account/gons.png';
import mima from '../../../assets/images/account/mima.png';
import shouji from '../../../assets/images/account/shouji.png';
import xingbie from '../../../assets/images/account/xingbie.png';
import yonghu from '../../../assets/images/account/yonhhu.png';

const { genderList, levelList } = listStore;
const FormItem = Form.Item;
const Option = Select.Option;
const OptionOne = AutoComplete.Option;

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      number: null,
      result: [],
      children: [],
    })
  }
}

const NewStaffMes = observer(Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true,
      display: 'none',
      number: null,
    };
  },
  componentDidMount() {
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let { name, number, username, password, email, mobile, level, groupId, ownerId, gender } = values;
        let obj = { name, number: parseInt(number, 10), username, password, email, mobile: parseInt(mobile, 10), level, groupId, ownerId, gender };
        if (number) {
          obj = { ...obj, number };
        }
        window.rpc.user.create(obj).then(() => {
          message.info('创建成功！')
          browserHistory.push('/memb/staff');
        }, (err) => {
          console.log(err);
        })

      }
    });
  },

  //验证手机号
  checkAccount(rule, value, callback) {
    var regex = /^0\d{2,3}-?\d{7,8}$|^((\+)?86|((\+)?86)?)0?1[3578]\d{9}$/;
    if (regex.test(value)) {
      callback();
    } else {
      callback('请输入正确的电话号码');
    }
  },

  //验证数字
  checkNumber(rule, value, callback) {
    var num = /^[0-9]*$/;
    if (num.test(value)) {
      callback();
    } else {
      callback('请输入数字');
    }
  },

  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },

  checkPassword(rule, value, callback) {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('两次输入的密码不一致!');
    } else {
      callback();
    }
  },

  checkConfirm(rule, value, callback) {
    const form = this.props.form;
    if (value && this.state.passwordDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  },

  handleChange(value) {
    let result;
    if (!value || value.indexOf('@') >= 0) {
      result = [];
    } else {
      result = ['gmail.com', '163.com', 'qq.com', 'foxmail.com', '126.com'].map(domain => `${value}@${domain}`);
    }
    const children = result.map((email) => {
      return <OptionOne key={email}>{email}</OptionOne>;
    });
    this.props.appState.children = children;
  },

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 9 },
    };

    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let levelsChildren = [];
    let groupIdsChildren = [];
    let ownerIdsChildren = [];
    let genderChildren = [];

    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }
    for (let i = 1; i < levelList.length; i++) {
      levelsChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdsChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdsChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    return (
      <div>
        <div style={{ float: 'left', height: '20px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ paddingLeft: 10, margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>新增人员</Link>
        </div> <br />
        <div className="hr" style={{ marginTop: 16 }}></div>
        <Form onSubmit={this.handleSubmit} className="newPeople" style={{ textAlign: 'left', marginTop: 20 }}>
          <div style={{ fontSize: 12 }}><span style={{ fontWeight: 'blod', fontSize: 14, color: 'black', margin: '0 10px' }}>信息编辑</span>请编辑你的个人信息用于登录</div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={yonghu} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="用户名："
                hasFeedback
              >
                {getFieldDecorator('username', {
                  rules: [{ required: true, message: '请输入用户名!' }],
                })(
                  <Input style={{ width: 190 }} />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={mima} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="登陆密码"
                hasFeedback
              >
                {getFieldDecorator('password', {
                  rules: [{
                    required: true, message: '请输入您的密码!',
                  }, {
                    validator: this.checkConfirm,
                  }],
                })(
                  <Input type="password" style={{ width: 190 }} />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={mima} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="密码确认"
                hasFeedback
              >
                {getFieldDecorator('confirm', {
                  rules: [{
                    required: true, message: '请输入您的密码!',
                  }, {
                    validator: this.checkPassword,
                  }],
                })(
                  <Input type="password" onBlur={this.handleConfirmBlur} style={{ width: 190 }} />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={gons} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="公司："
                hasFeedback
              >
                {getFieldDecorator('ownerId', {
                  rules: [{ required: true, message: '请选择公司!' }],
                })(
                  <Select style={{ width: 190 }}>
                    {ownerIdsChildren}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={bumen} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="部门："
                hasFeedback
              >
                {getFieldDecorator('groupId', {
                  rules: [{ required: true, message: '请选择部门!' }],
                })(
                  <Select style={{ width: 190 }}>
                    {groupIdsChildren}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={bumen} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="工号："
                hasFeedback
              >
                {getFieldDecorator('number', {
                  rules: [{ required: true, message: '请输入工号!' }, {
                    validator: this.checkNumber,
                  }],
                })(
                  <Input style={{ width: 190 }} />
                  )}
              </FormItem>
            </div>
          </div>
          <Row style={{ marginLeft: '42%' }}>
            <Col span={8}>

            </Col>
          </Row>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={dengji} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="等级："
                hasFeedback
              >
                {getFieldDecorator('level', {
                  rules: [{ required: true, message: '请选择等级!' }],
                })(
                  <Select style={{ width: 190 }}>
                    {levelsChildren}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div style={{ fontSize: 12, marginTop: 35 }}><span style={{ fontWeight: 'blod', fontSize: 14, color: 'black', margin: '0 10px' }}>基本信息</span>请输入真实的信息</div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={yonghu} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="姓名："
                hasFeedback
              >
                {getFieldDecorator('name', {
                  rules: [{ required: true, message: '请输入姓名!' }],
                })(
                  <Input style={{ width: 190 }} />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={xingbie} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="性别："
                hasFeedback
              >
                {getFieldDecorator('gender', {
                  rules: [{ required: true, message: '请选择性别！' }],
                })(
                  <Select style={{ width: 190 }}>
                    {genderChildren}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={shouji} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="电话："
                hasFeedback
              >
                {getFieldDecorator('mobile', {
                  rules: [{ required: true, message: '请输入电话号码!' }, {
                    validator: this.checkAccount,
                  }],
                })(
                  <Input style={{ width: 190 }} />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ width: "40%" }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={email} alt="" />
            </div>
            <div style={{ float: "left", width: "90%", marginLeft: 9 }}>
              <FormItem
                {...formItemLayout}
                label="邮箱："
                hasFeedback
              >
                {getFieldDecorator('email', {
                  rules: [{ type: 'email', required: true, message: '请输入邮箱!' }],
                })(
                  <AutoComplete
                    style={{ width: 190 }}
                    onChange={this.handleChange}
                  >
                    {this.props.appState.children}
                  </AutoComplete>
                  )}
              </FormItem>
            </div>
          </div>
          <div style={{ marginTop: 46 }} className="newPeopleB">
            <FormItem>
              <Button type="primary" onClick={this.handleSubmit} size="large" style={{ backgroundColor: '#00c1de', borderColor: "#00c1de", color: '#fff', fontSize: '12px', fontFamily: '苹方中等', borderRadius: 0 }}>创建</Button>
              <Button type="success" style={{ marginLeft: 20, backgroundColor: '#ccc', color: '#fff', fontSize: '12px', fontFamily: '苹方中等', borderRadius: 0 }} onClick={() => { browserHistory.push("/memb/staff"); }}>返回</Button>
            </FormItem>
          </div>
        </Form>
      </div>
    );
  },
})));

class NewStaff extends Component {
  render() {
    return (
      <div className="NewStaff">
        <NewStaffMes appState={new appState()} />
      </div>
    );
  }
}

export default NewStaff;