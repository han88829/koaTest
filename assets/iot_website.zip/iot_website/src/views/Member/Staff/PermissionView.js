import React, { Component } from 'react';
import { Table, Checkbox, Button, message, Row } from 'antd';
import { Link, browserHistory } from 'react-router';
import { extendObservable, toJS } from 'mobx';
import { observer } from 'mobx-react';
import '../Group/PermissionView.css';

class appState {
  constructor() {
    extendObservable(this, {
      data: [
        {
          key: '1',
          name: '单位管理',
          default: false,
          data: [
            {
              key: '1-1',
              name: '单位信息',
              default: false,
              data: [
                { key: '1-1-1', name: '单位信息', default: false, }
              ]
            },
            {
              key: '1-2',
              name: '单位统计',
              default: false,
              data: [
                { key: '1-2-1', name: '单位统计', default: false, }
              ]
            },
            {
              key: '1-3',
              default: false,
              name: '消防整改',
              data: [
                { key: '1-3-1', name: '消防整改', default: false, }
              ]
            },
            {
              key: '1-4',
              name: '设置',
              default: false,
              data: [
                { key: '1-4-1', name: '单位类型管理', default: false, }
              ]
            },
          ]
        },
        {
          key: '2',
          name: '建筑管理',
          default: false,
          data: [
            {
              key: '2-1',
              name: '建筑管理',
              default: false,
              data: [
                { key: '2-1-1', name: '建筑信息', default: false, }
              ]
            },
            {
              key: '2-2',
              name: '设置',
              default: false,
              data: [
                { key: '2-2-1', name: '建筑类型管理', default: false, }
              ]
            },
          ]
        },
        {
          key: '3',
          name: '人员管理',
          default: false,
          data: [
            {
              key: '3-1',
              name: '人员管理',
              default: false,
              data: [
                { key: '3-1-1', name: '人员信息', default: false, },
                { key: '3-1-2', name: '人员统计', default: false, },
                { key: '3-1-3', name: '人员权限', default: false, },
              ]
            },
            {
              key: '3-2',
              default: false,
              name: '部门管理',
              data: [
                { default: false, key: '3-2-1', name: '部门信息' },
                { default: false, key: '3-2-2', name: '部门结构' },
                { default: false, key: '3-2-3', name: '部门权限' },
                { default: false, key: '3-2-4', name: '部门人员' },
              ]
            },
            {
              key: '3-3',
              default: false,
              name: '绩效管理',
              data: [
                { default: false, key: '3-3-1', name: '绩效管理' }
              ]
            },
          ]
        },
        {
          key: '4',
          name: '设备管理',
          default: false,
          data: [
            {
              key: '4-1',
              name: '设备管理',
              default: false,
              data: [
                { default: false, key: '4-1-1', name: '设备管理' },
                { default: false, key: '4-1-2', name: '设备统计' },
                { default: false, key: '4-1-3', name: '设备预警' },
                { default: false, key: '4-1-4', name: '设备维护' },
              ]
            },
            {
              key: '4-2',
              name: '设置',
              default: false,
              data: [
                { default: false, key: '4-2-1', name: '类型管理' },
                { default: false, key: '4-2-2', name: '品牌管理' },
              ]
            },
          ]
        },
        {
          key: '5',
          name: '监控中心',
          default: false,
          data: [
            {
              key: '5-1',
              name: '监控管理',
              default: false,
              data: [
                { default: false, key: '5-1-1', name: '监控管理' },
              ]
            },
            {
              key: '5-2',
              name: '文件管理',
              default: false,
              data: [
                { default: false, key: '5-2-1', name: '视频管理' },
                { default: false, key: '5-2-2', name: '截图管理' },
              ]
            },
            {
              key: '5-3',
              name: '实时监控',
              default: false,
              data: [
                { default: false, key: '5-3-1', name: '实时监控' },
              ]
            },
          ]
        },
        {
          key: '6',
          name: '报警中心',
          default: false,
          data: [
            {
              key: '6-1',
              name: '报警管理',
              default: false,
              data: [
                { default: false, key: '6-1-1', name: '报警管理' },
              ]
            },
            {
              key: '6-2',
              default: false,
              name: '报警统计',
              data: [
                { default: false, key: '6-2-1', name: '报警统计' },
              ]
            },
            {
              key: '6-3',
              default: false,
              name: '报警处理',
              data: [
                { default: false, key: '6-3-1', name: '报警处理' },
              ]
            },
            {
              key: '6-4',
              name: '报警设定',
              default: false,
              data: [
                { default: false, key: '6-4-1', name: '报警设定' },
              ]
            },
          ]
        },
        {
          key: '7',
          name: '短信通知',
          default: false,
          data: [
            {
              key: '7-1',
              default: false,
              name: '联系人管理',
              data: [
                { default: false, key: '7-1-1', name: '联系人管理' },
              ]
            },
            {
              key: '7-2',
              default: false,
              name: '短信管理',
              data: [
                { default: false, key: '7-2-1', name: '短信管理' },
              ]
            },
            {
              key: '7-3',
              name: '短信模板',
              default: false,
              data: [
                { default: false, key: '7-3-1', name: '短信模板' },
              ]
            },
          ]
        },
        {
          key: '8',
          default: false,
          name: '安全检查',
          data: [
            {
              key: '8-1',
              name: '任务清单',
              default: false,
              data: [
                { default: false, key: '8-1-1', name: '设备检查任务' },
                { default: false, key: '8-1-2', name: '安全检查任务' },
              ]
            },
            {
              key: '8-2',
              default: false,
              name: '任务规则',
              data: [
                { default: false, key: ' 8-2-1', name: '设备检查任务规则' },
                { default: false, key: '8-2-2', name: '安全检查任务规则' },
              ]
            },
            {
              key: '8-3',
              name: '任务报表',
              default: false,
              data: [
                { default: false, key: '8-3-1', name: '任务报表' },
              ]
            },
          ]
        },
        {
          key: '9',
          name: '巡逻管理',
          default: false,
          data: [
            {
              key: '9-1',
              default: false,
              name: '巡逻设置',
              data: [
                { default: false, key: '9-1-1', name: '巡逻设置' },
              ]
            },
            {
              key: '9-2',
              name: '巡逻详情查看',
              default: false,
              data: [
                { default: false, key: '9-2-1', name: '巡逻详情查看' },
              ]
            },
            {
              key: '9-3',
              name: '巡逻人管理',
              default: false,
              data: [
                { default: false, key: '9-3-1', name: '巡逻人管理' },
              ]
            },
            {
              key: '9-4',
              name: '巡逻点管理',
              data: [
                { key: '9-4-1', name: '巡逻点管理' },
              ]
            },
            {
              key: '9-5',
              default: false,
              name: '巡逻统计',
              data: [
                { default: false, key: '9-5-1', name: '巡逻统计' },
              ]
            },
          ]
        },
      ]
    })
  }
}

const EquipPreserveMemberC = observer(class EquipPreserveMemberC extends Component {
  state = {
    data: toJS(this.props.appState.data),
    Gdata: []
  }
  componentWillMount() {
    let id = this.props.params.id;
    window.rpc.menu.user.getInfoById(id).then((res) => {
      if (res.length >= 9) {
        this.props.appState.data = res
        this.setState({ data: res });
      } else {
        window.rpc.menu.user.getInfoById(4).then((res) => {
          let data = res;
          for (let num = 0; num < data.length; num++) {
            data[num].default = false;
            for (let i = 0; i < data[num].data.length; i++) {
              data[num].data[i].default = false;
              let len = data[num].data[i].data.length;
              for (let j = 0; j < len; j++) {
                data[num].data[i].data[j].default = false;
              }
            }
          }
          this.setState({ data });
          this.props.appState.data = data;
        }), (err) => {
          console.error(err)
        }
      }
    }), (err) => {
      console.error(err)
    }
  }
  handleSubmit = () => {
    let data = toJS(this.props.appState.data)
    let id = this.props.params.id;
    window.rpc.menu.user.setInfoById(id, data).then((res) => {
      if (res) {
        message.info("修改成功！")
        browserHistory.push('/memb/staff/authority')
      } else {
        message.error('修改失败！')
      }
    }), (err) => {
      console.error(err)
    }
  }
  render() {
    const columns = [
      { title: '权限列表', dataIndex: 'name', key: 'name' },
      {
        title: '是否启用', dataIndex: '', key: 'x', render: (text, record) => {
          let arr = record.key.split('-');
          let data = toJS(this.props.appState.data);
          let num = parseInt(arr[0], 10) - 1;
          return (
            <Checkbox
              defaultChecked={this.props.appState.data[num].default}
              checked={this.state.data[num].default}
              onChange={(e) => {
                data[num].default = e.target.checked;
                for (let i = 0; i < data[num].data.length; i++) {
                  data[num].data[i].default = e.target.checked;
                  let len = data[num].data[i].data.length;
                  for (let j = 0; j < len; j++) {
                    data[num].data[i].data[j].default = e.target.checked;
                  }
                }
                this.props.appState.data = data;
                this.setState({ data });
              }}>
            </Checkbox>
          )
        }
      },
    ];
    const columnsT = [
      { title: '名称', dataIndex: 'name', key: 'name' },
      {
        title: '', dataIndex: '', key: 'x', render: (text, record) => {
          let arr = record.key.split('-');
          let data = toJS(this.props.appState.data);
          let num = parseInt(arr[0], 10) - 1;
          return (
            <Checkbox
              defaultChecked={this.state.data[num].data[parseInt(arr[1], 10) - 1].default}
              checked={this.state.data[num].data[parseInt(arr[1], 10) - 1].default}
              onChange={(e) => {
                this.props.appState.data[num].data[parseInt(arr[1], 10) - 1].default = e.target.checked;
                let len = data[num].data[parseInt(arr[1], 10) - 1].data.length;
                for (let j = 0; j < len; j++) {
                  data[num].data[parseInt(arr[1], 10) - 1].data[j].default = e.target.checked;
                }
                this.props.appState.data = data;
                this.setState({ data });
              }}>
            </Checkbox>
          )
        }
      },
    ];
    const columnsS = [
      { title: '名称', dataIndex: 'name', key: 'name' },
      {
        title: '', dataIndex: '', key: 'x', render: (text, record) => {
          let arr = record.key.split('-');
          let data = toJS(this.props.appState.data);
          let num = parseInt(arr[0], 10) - 1;
          return (
            <Checkbox
              checked={this.state.data[num].data[parseInt(arr[1], 10) - 1].data[parseInt(arr[2], 10) - 1].default}
              defaultChecked={this.state.data[num].data[parseInt(arr[1], 10) - 1].data[parseInt(arr[2], 10) - 1].default}
              onChange={(e) => {
                this.props.appState.data[num].data[parseInt(arr[1], 10) - 1].data[parseInt(arr[2], 10) - 1].default = e.target.checked;
                this.setState({ data });
              }}>
            </Checkbox>
          )
        }
      },
    ];
    const data = [...this.props.appState.data]
    return (
      <div>
        <Row>
          <div style={{ float: 'left', width: 66, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/frame' style={{ padding: '2px 2px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>
              人员权限
            </Link>
          </div>
          <div style={{ float: 'left', width: 66, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 2px 0 0', fontSize: '0.76rem', color: '#373e41' }}>
              > 配置
            </Link>
          </div>
        </Row>

        {/*是否默认打开所有的行*/}
        {/*defaultExpandAllRows={true}*/}
        <Row style={{ marginTop: 20 }}>
          <Table
            columns={columns}
            className="PermissionTitleOne"
            expandedRowRender={record => {
              let data = [...record.data]
              return (<Table
                columns={columnsT}
                className="PermissionTitle"
                pagination={false}
                expandedRowRender={record => {
                  let data = [...record.data]
                  return (<Table
                    columns={columnsS}
                    className="PermissionTitle"
                    dataSource={data}
                    pagination={false}
                  />
                  )
                }}
                dataSource={data}
              />
              )
            }}
            dataSource={data}
          />
        </Row>

        <div>
          <Button
            style={{ backgroundColor: '#0099cc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', marginLeft: 10, borderRadius: 0 }}
            onClick={this.handleSubmit}> 确定</Button>
          <Button
            style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', marginLeft: 10, borderRadius: 0 }}
            onClick={() => { browserHistory.push('/memb/staff/authority') }}
          >
            返回
          </Button>
        </div>
      </div>
    );
  }
})

class PermissionView extends Component {
  render() {
    return (
      <EquipPreserveMemberC appState={new appState()} params={this.props.params} />
    )
  }
}

export default PermissionView;