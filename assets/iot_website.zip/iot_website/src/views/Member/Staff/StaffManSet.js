import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message,Checkbox  } from 'antd';

const CheckboxGroup = Checkbox.Group;
const nameObj={
  getInfo:'获取信息',setInfo:'修改信息',getMapIdNameByContainer:'条件遍历获取ID与名称',flag:'标识',getInfoExById:'由Id获取详情',getMapIdNumberByContainer:'条件筛选获取ID与数值',
  getName:'获取名称',getTag:'获取标签',getTagById:'由ID获取标签',setTag:'修改标签',setTagById:'由ID修改标签',getCountByCondContainer:'由两个条件筛选计数',
  getRangeValueById:'由ID获取范围',setBoolValueByArrayId:'批量由ID修改布尔值',setBoolValueByCond:'由计数修改布尔值',setBoolValueById:'由ID修改布尔值',
  setRangeValueByArrayId:'由ID批量修改范围',setRangeValueByCond:'条件修改范围',setRangeValueById:'由ID修改范围',
  getArrayByUserId:'由用户ID获取列表',getArrayBriefByCondContainer:'由两个条件筛选数组',getArrayByCondContainer:'由两个条件获取数组',getBoolValueById:'由ID获取布尔值',
  getId:'获取ID',init:'取整',tool:'工具',public:'公共的',login:'登录',metadata:'标签日期',track:'跟踪',session:'会议',createArray:'新建数组',images:'图片',
  createNames:'新增名称',createMap:'新增遍历',getArrayBrief:'简单获取数组',getArrayBriefByCond:'由计数简单获取数组',getArrayByCond:'由计数获取数组',getColById:'由ID获取字段',
  getArrayNameByContainer:'条件筛选获取数组名称',getArrayNameValueByContainer:'条件筛选获取数组名称值',getInfoByName:'由名称获取信息',getMapNameValueByContainerAndCreateNames:'条件筛选遍历获取名称与数值并新建名称',
device:'设备',owner:'单位',group:'部门',user:'人员',brand:'品牌',product:'型号',file:'文件',patrol:'巡查',alarm:'预警',run:'运行',getMapNameValueByContainerAndCreateMap:'条件筛选遍历获取名称与数值并新建',
area:'建筑',fire:'消防',message:'信息',permession:'权限',position:'巡逻',report:'报表',resource:'资源',rules:'规则',schedule:'时间表',upload:'图片上传',task:'任务',types:'类型',setInfoById:'编辑',getInfoById:'查看',removeById:'删除',
create:'新建',getArray:'获取列表数组',getArrayByContainer:'条件筛选获取数组',removeById:'删除',getCountByCond:'条件获取计数',getMapNameValueByContainer:'条件筛选遍历获取名称与数值',
getArrayBriefByContainer:'简单条件筛选数组',getArrayDeviceCountByContainer:'条件筛选获取设备数目数组',getArrayDeviceCountExByContainer:'条件筛选获取设备数目数组（仅限建筑）',getArrayIdNameByContainer:'条件筛选获取ID、名称数组',
getCount:'获取数目',getCountByContainer:'条件筛选获取数目',getCountFieldByContainer:'简单条件筛选获取数目',getInfoByCond:'由计数获取信息',getInfoByNumber:'由数字获取信息',
getLocationId:'获取位置ID',getLocationName:'获取位置名称',getLocationIdName:'获取位置名称及ID',getNameById:'由ID获取名称',removeByNumber:'由数字删除'
}
class StaffManSet extends Component {
  state={
    tableData:[],
    data:[],
    defaultData:[],
    id:0

  }
   componentWillMount(){
     let id=this.props.params.id||0;
     console.log(id);
     this.setState({id})
  }
  componentDidMount(){
    // window.rpc.cache.then(data=>{
    //      console.log(data);
    //    let a=data.map((x,index)=>{
    //       console.log(x);
    //       console.log(index)
    //    })
    // },err=>{
    //      console.log(err);
    // });
   
    let cache=window.rpc.cache;
    //cache.shift();
    //let ca
    // for(let i=0;i<cache.length;i++){
    //   console.log(i)
    // }
    console.log(cache);
    var arr = [];
   　
 　　for ( let i in cache ){
   if(i!='public'){
       //console.log()
       let arrChild=[];
        let arrLen=arr.length+1;
       for (let j in cache[i] ){
          //var str ={name:cache[i][j]} ;// i 就代表 data 里面的 user pass 等等 而data[ i ] 就代表 userName    12121 就是 i 所对应的值；
       
          let len=arrChild.length+1;
        // arrChild.push({name:j,key:`${arrLen}.${len}`,layer:2,parent:i});
         let sonArr=[];
         if(typeof(cache[i][j])=="object"){
           ///console.log('~~~~~~*****~~~~~~~')
           //console.log(typeof(cache[i][j]));
            for (let z in cache[i][j] ){
              //就是 i 所对应的值；
       
             let typelen=sonArr.length+1;
             let  nextSon=[];
           if(typeof(cache[i][j][z])=="object"){
           ///console.log('~~~~~~*****~~~~~~~')
           console.log(typeof(cache[i][j][z]));
            for (let m in cache[i][j][z] ){
              //就是 i 所对应的值；
       
             let typeNextlen=nextSon.length+1;
             //let  nextSon=[];
             nextSon.push({name:m,names:nameObj[m]||m,key:`${arrLen}.${len}.${typelen}.${typeNextlen}`,layer:4,parent:i,mom:j,momNext:z,show:true});
            //  sonArr.push({name:z,names:nameObj[z]||z,key:`${arrLen}.${len}.${typelen}`,layer:3,parent:i,mom:j,show:true});
           }
              sonArr.push({name:z,names:nameObj[z]||z,key:`${arrLen}.${len}.${typelen}`,layer:3,parent:i,mom:j,children:nextSon,show:false});
　    　 }else{
              sonArr.push({name:z,names:nameObj[z]||z,key:`${arrLen}.${len}.${typelen}`,layer:3,parent:i,mom:j,show:true});
          } 
           }
             arrChild.push({name:j,names:nameObj[j]||j,key:`${arrLen}.${len}`,layer:2,parent:i,children:sonArr,show:false});
　    　 }else{
             arrChild.push({name:j,names:nameObj[j]||j,key:`${arrLen}.${len}`,layer:2,parent:i,show:true});
          }
          //arrChild.push({name:j,key:`${arrLen}.${len}`,layer:2,parent:i,show:true});
         
       }
   
         var str = {key:`${arrLen}`,name:i,names:nameObj[i]||i,children:arrChild,layer:1,show:true} ;// i 就代表 data 里面的 user pass 等等 而data[ i ] 就代表 userName    12121 就是 i 所对应的值；
        　arr.push( str );
     }
　   }
       //此处应为最外层类别
      console.log(arr);
      this.setState({tableData:arr});
     // arr.map((x)=>{
     //    window.rpc.x.
     // })
    }
  
 onChange=(record,e)=>{
   let that=this;
   console.log('checked = ', e);
   console.log(record);
   let arr=[];
   let data=this.state.data||[];
  console.log(data);
  let len=null;
  e.length==0?len=0:len=1;//{
     let parent=record.parent;
     let fun='';
    if(record.mom){
      if(record.momNext){
         let obj={fun:`${record.mom}_${record.name}_${record.momNext}`,parent:record.parent,mothod:'false'};
      }else{
        let obj={fun:`${record.mom}_${record.name}`,parent:record.parent,mothod:'false'};
        fun=`${record.mom}_${record.name}`;
      }
      
     // let parent=record.parent; 
   }else{
      let obj={fun:`${record.name}`,parent:record.parent,mothod:'false'};
       fun=`${record.name}`;
       //let parent=record.parent;
   }
    let flag=1,num=null;
     if(data.length!==0){
        data.map((x,index)=>{
       //console.log(index)
        if(x.parent==parent){
          console.log(index);
          num=index;
          flag=0;
          //data[num].children.push(fun);
           setArrState(flag,num,len?true:false);
        }else if(x.parent!=parent&&index==data.length-1){
          flag=1
          setArrState(flag,num,len?true:false)
        }
      })
     }else{
        setArrState(flag,num,len?true:false)
     }
    
      function setArrState(f,n,boolean){
          // console.log('flag:'+f);
          //console.log('num:'+n);
          if(!f){
            data[n].children.push({function:fun,Booleans:boolean});
            // if(data[n].children.function==f){

            // }
          }else{
            let obj={parent:parent,children:[{function:fun,Booleans:boolean}]}
            data.push(obj);
          }
          console.log(data);
          that.setState({defaultData:data})
       }
   //}else{
   
  // }

 }
 
 handleSubmit(){
   //请求
   let that=this;
   console.log("请在这里请求数据");
   let data=this.state.data;
   let defaultData=this.state.defaultData;
   console.log(data);
   console.log(defaultData);

   let mothodObj={};
   

let objPa=''
   for(let j=0;j<data.length;j++){

  let objChild='';
  let mothodArr=data[j].children;

 //objChild+=`{${data[j].parent}:{default:true,method:{${objChild}}}}`
for(let i=0;i<data[j].children.length;i++){
   objChild+=`${data[j].children[i].function}:${data[j].children[i].Booleans},`;
    if(i===data[j].children.length-1&&j==data.length-1){
      objPa+=`${data[j].parent}:{default:true,method:{${objChild}}},`;
      toString(objPa);
    }else if(i===data[j].children.length-1){
         objPa+=`${data[j].parent}:{default:true,method:{${objChild}}},`;
    }
}
}
function toString(objChild){
   //objChild=`{table:{default:true,${data[j].parent}:{method:{${objChild}}}}}`;
   objChild=`{default:true,table:{${objChild}}}`;
   console.log(objChild);
   let obj=eval("("+objChild+")"); 
//    var obj = eval('(' + str + ')');
// 或者
// var obj = str.parseJSON(); //由JSON字符串转换为JSON对象
// 或者
// var obj = JSON.parse(str); 
   console.log(obj);

let id=that.state.id;
console.log(id);
  //rpc.permission.group.setInfoById(18,{default:true,table:{device:{prefix:{set:false,remove:false}}}},console.log,console.error)
  window.rpc.permission.user.setInfoById(id,obj).then(data=>{
    console.log(data);
    if(data){
      message.info("权限设置成功");
      //window.location.href='/memb/staff/authority';
      window.rpc.permission.user.getInfoById(id).then(data=>{
       console.log(data);
      
     },err=>{
       console.warn(err);
     })
    }
  },err=>{
    console.warn(err)
  })
 }

 
 //
    //  for(var item in mothodArr){
    //   let ele=mothodArr[item];
    //    mothodObj[item]=mothodArr[item];   
    //   //这样循环就可以将milasUrlArr数组中的属性包括方法copy到milasUrl对象中了
    // }
    //console.log(mothodObj);
 }
 handleCancel(){
   //清空保存数组
    console.log("请在这里清空设置的缓存数据");
     //let data=this.state.tableData||[];
  
  window.location.href='/memb/staff/authority';
  
 }
  render() {
   let data=this.state.tableData||[];
  //  let obj={
  //   default:true,
  //   table:value
  // }
//let obj={device:'设施设备',owner:'单位',}
// const optionsWithDisabled = [
//   { label: '新增', value: 'update' },
//   { label: '删除', value: 'remove' },
//   { label: '修改', value: 'set'},
//   { label: '查看', value: 'get' }
// ];
const optionsWithDisabled = [ { label: '选择使用该方法', value: 'mothod' },]
     const columns = [
      {
        title: '序号',
        dataIndex: 'id',
        key: 'id',
        //sorter: (a, b) => a.id - b.id,
        //sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
        render: text => <span>{text}</span>,
      },
      { title: '权限列表', dataIndex: 'names', key: 'names' },
      {
        title: '操作数据权限', dataIndex: 'layer', key: 'layer', render: (text, record) => {
          {/*<CheckboxGroup options={optionsWithDisabled}  onChange={(e)=>this.onChange(record,e)} />*/}
          if(parseInt(text,10)==1){
            return(
             <span></span> 
            )
          }else if(text==2&&record.show){
            return(
             <span style={{ color: '#108ee9'}}>
               <CheckboxGroup options={optionsWithDisabled} defaultValue={['mothod']}  onChange={(e)=>this.onChange(record,e)} />
            </span>
            )
          }else if(text==3){
            return(
             <span style={{ color: '#108ee9'}}>
               <CheckboxGroup options={optionsWithDisabled} defaultValue={['mothod']}  onChange={(e)=>this.onChange(record,e)} />
            </span>
            )
          }
        }
       
        
      },
    ];
    return (
     <div style={{}}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125em', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 66, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/frame' style={{padding: '2px 2px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>
               人员权限
            </Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }}>
            <div style={{ float: 'left', background: '#fff', color: '#373e41', padding: 0, height: '22px',lineHeight:"22px",marginTop:"4px", borderRadius: 0 }} > 
              <span style={{marginRight:'6px'}}>></span>
              配置
            </div>     
          </div>
       
        </div>
        {/*<WrappedAdvancedSearchForm appState={this.props.appState} style={{ width: '80%', textAlign: 'center' }} />*/}

        <Row style={{ padding: '5px 0 0', marginTop: 10 }}>
          <Col span={24} className="AuthoritySet">
            <Table
              columns={columns}
              dataSource={data}
              /*pagination={pagination}
              onChange={this.handleChange} 
              rowSelection={rowSelection}*/
            />
          </Col>
        </Row>
        <div style={{marginTop:12}}>
            <Button  onClick={this.handleSubmit.bind(this)} style={{marginRight:12, backgroundColor: '#108ee9',color:"#fff"}}> 保存</Button>
            <Button  onClick={this.handleCancel}>取消</Button>
        </div>
     </div> 
    );
  }
}

//export default AuthoritySet;

export default StaffManSet;