/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:07:33 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-05-19 14:58:34
 */

import React from 'react';
import { Form, Input, Select, Button, Row, Col, message } from 'antd';
import { Link, browserHistory } from 'react-router';
// import listStore from '../listStore';
import './staff.css'
import logo from '../../../assets/images/login/logo.png';
// import moment from 'moment';
const FormItem = Form.Item;
// const Option = Select.Option;

const Personal = Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true
    };
  },
  componentWillMount() {
    console.log(this.props)
    const id = parseInt(this.props.params.id, 10);
    window.rpc.user.getInfoById(id).then((result) => {
      console.log(result.name);
      this.props.form.setFieldsValue({
        name: result.name,
        number: result.number,
        username: result.username,
        password: result.password,
        email: result.email,
        mobile: result.mobile,
        level: result.level,
        groupId: result.groupId,
        ownerId: result.ownerId,
        gender: result.gender,
      });
      let time;
      if(result.setupTime==null){
        time=new Date().toLocaleString()
      }else{
        time=result.setupTime.toLocaleString()
      }
      const device = { ...result, expiryTime: result.expiryTime.toLocaleString(), setupTime:time};
      this.setState({ device });
    }, (err) => {
      console.warn(err);
    })
  },
  handleSubmit(e) {
    e.preventDefault();
    const id = parseInt(this.props.params.id, 10);
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        // console.log('Received values of form: ', values);
        let {name, setupTime, expiryTime, networkAddr, networkId, networkMode, networkUrl, networkNode, location, productId, dtype} = values;
        let obj = { name, setupTime: new Date(setupTime.format('YYYY-MM-DD')), expiryTime: new Date(expiryTime.format('YYYY-MM-DD')), networkAddr, networkMode, networkNode, networkId, networkUrl, location: parseInt(location, 10), productId: parseInt(productId, 10), dtype: parseInt(dtype, 10) };

        if (networkAddr) {
          obj = { ...obj, networkAddr };
        }
        if (networkId) {
          obj = { ...obj, networkId };
        }

        console.log(obj);
        window.rpc.device.setInfoById(id, obj).then(() => {
          message.info('修改成功！');
          browserHistory.push('/equipment/equipmanage');
        }, (err) => {
          console.log(err);
        })
      }
    });
  },
  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },
  checkPassword(rule, value, callback) {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  },
  checkConfirm(rule, value, callback) {
    const form = this.props.form;
    if (value && this.state.passwordDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };

    // const config = {
    //   rules: [{ type: 'object', required: true, message: 'Please select time!' }],
    // };

    // function isNetworkModeEqualOne(value) {
    //   // console.log(value)
    //   // console.log(value === '网关');
    //   return value !== '1';
    // }

    return (
      <Form onSubmit={this.handleSubmit} inline style={{ marginLeft: 100 }}>
        <Row style={{marginTop:50}}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="用户名："
            >
              {getFieldDecorator('username', {
                rules: [{ required: true, message: '请输入用户名!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="密码："
            >
              {getFieldDecorator('password', {
                rules: [{ required: true, message: '请输入密码!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{marginTop:20}}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="手机号："
            >
              {getFieldDecorator('mobile', {
                rules: [{ required: false, message: '请输入手机号码!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="邮箱："
            >
              {getFieldDecorator('email', {
                rules: [{type:'email', required: false, message: '请输入邮箱!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{marginTop:20}}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="姓名："
            >
              {getFieldDecorator('name', {
                rules: [{ required: false, message: '请输入姓名!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="性别："
            >
              {getFieldDecorator('gender', {
                rules: [{ required: false, message: '请选择性别！' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="工号："
            >
              {getFieldDecorator('number', {
                rules: [{ required: false, message: '请输入工号!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{marginTop:20}}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="公司："
            >
              {getFieldDecorator('ownerId', {
                rules: [{ required: false, message: '请选择公司!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="部门："
            >
              {getFieldDecorator('groupId', {
                rules: [{ required: false, message: '请选择部门!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="等级："
            >
              {getFieldDecorator('level', {
                rules: [{ required: false, message: '请选择等级!' }],
              })(
                <Input style={{ width: 180, color:'blue'}} disabled />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{position: 'absolute', bottom: 480, right: '34%'}}>
          <Col span={12} style={{marginLeft:55,marginTop:20}}>
            <FormItem
              {...formItemLayout}
              label=""
            >
              {getFieldDecorator('picture', {
                rules: [{ message: '请上传照片!' }],
              })(
                <img src={logo} alt="logo" />
              )}
            </FormItem>
          </Col>      
        </Row>
        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 30, right: 140 }}>
          <Col span={20}></Col>
          <Col span={4}>
            <Row style={{ margin: '0' }}>
              <Col span={9}>
                <FormItem {...tailFormItemLayout}>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px' }}><Link to="/member/staff">返回</Link></Button>
                </FormItem>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>  
    );
  },
}));

export default Personal;