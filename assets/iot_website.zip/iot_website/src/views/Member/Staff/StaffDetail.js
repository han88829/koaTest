/*
 * @Author: Han.beibei 
 * @Date: 2017-03-04 15:29:18 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-05-19 14:56:06
 */

import React from 'react';
import { Form, Input, Select, Button, Row, Col } from 'antd';
import { Link, browserHistory } from 'react-router';
import logo from '../../../assets/images/logined/big-img.png';
import listStore from '../listStore';

const { genderList, levelList } = listStore;
const FormItem = Form.Item;
const Option = Select.Option;

//查部门
var groupNames = [{ name: '/' }];

//查组织
var groupownerNames = [{ name: '/' }];

const EditStaff = Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true,
      image: null,
      id: null,
    };
  },
  componentWillMount() {
    const id = parseInt(this.props.params.id, 10);
    //console.log(this.props.params)
    window.rpc.user.getInfoById(id).then((result) => {
      //console.log(result);
      this.setState({ id: result.id })
      this.setState({ image: result.image })
      this.props.form.setFieldsValue({
        name: result.name,
        number: result.number,
        username: result.username,
        email: result.email,
        mobile: result.mobile,
        level: levelList[result.level],
        gender: genderList[result.gender],
        groupId: groupNames[result.groupId]['name'],
        ownerId: groupownerNames[result.ownerId]['name']
      });
    }, (err) => {
      console.warn(err);
    })
  },
  componentDidMount() {
    setTimeout(() => {
      document.getElementById("staffEimg").style.display = "block";
    }, 100)
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    })
      window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {
        for (let value of result) {
          groupownerNames[value.id] = value;
        }
        sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
      }, (err) => {
        console.warn(err);
      })
  },
  //验证手机号
  checkAccount(rule, value, callback) {
    //const form = this.props.form;
    var regex = /^((\+)?86|((\+)?86)?)0?1[3578]\d{9}$/;
    if (regex.test(value)) {
      callback();
    } else {
      callback('请输入正确的手机号码！');
    }
  },
  //验证数字
  checkNumber(rule, value, callback) {
    //const form = this.props.form;
    var num = /^[0-9]*$/;
    if (num.test(value)) {
      callback();
    } else {
      callback('请输入数字');
    }
  },
  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },
  checkPassword(rule, value, callback) {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  },
  checkConfirm(rule, value, callback) {
    const form = this.props.form;
    if (value && this.state.passwordDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 14 },
    };
    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let genderChildren = [];
    let levelsChildren = [];
    let groupIdsChildren = [];
    let ownerIdsChildren = [];

    //var a = [], b = [];
    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }

    for (let i = 0; i < levelList.length; i++) {
      if (levelList[i] !== '/') {
        levelsChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
      }
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdsChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdsChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    return (
      <div style={{ position: 'relative' }}>
        <div style={{ float: 'left', height: '20px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ paddingLeft: 10, margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>人员基本信息</Link>
        </div> <br />
        <div style={{ width: '100%', height: 30, backgroundColor: '#f9f9f9', marginTop: 20, paddingLeft: 10 }}>
          {/*<img src={staffedit} alt="" style={{ padding: '0 10px 0 0', marginTop: 5 }} />*/}
          <span style={{ color: '#666666', fontSize: 12, fontFamily: '苹方中等' }}>以下人员基本信息均为真实信息，所有权归蓝晟监管平台所有。</span>
        </div>
        {/*头像*/}
        <div className="staffEimg" style={{ paddingBottom: 10 }}>
          <img id="staffEimg" src={this.state.image ? this.state.image : logo} alt="" style={{ display: "none", width: 180, height: 170 }} />
        </div>
        <Form onSubmit={this.handleSubmit} layout="inline" style={{ marginLeft: 15 }} className="staffEF">
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="姓名："
              >
                {getFieldDecorator('name', {
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="用户名："
              >
                {getFieldDecorator('username', {
                })(
                  <Input disabled className="StaffDetail" />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="工号："
              >
                {getFieldDecorator('number', {
                  rules: [{ message: '请输入工号!' }, {
                    validator: this.checkNumber
                  }],
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="等级："
              >
                {getFieldDecorator('level', {
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="性别："
              >
                {getFieldDecorator('gender', {
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="电话："
              >
                {getFieldDecorator('mobile', {
                  rules: [{ message: '请输入电话号码!' }, {
                    validator: this.checkAccount
                  }],
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="邮箱："
              >
                {getFieldDecorator('email', {
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="公司："
              >
                {getFieldDecorator('ownerId', {
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="部门："
              >
                {getFieldDecorator('groupId', {
                })(
                  <Input disabled className="StaffDetail" style={{ marginLeft: 6 }} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <div style={{ position: 'absolute', bottom: '-60px' }} className="search-btn" >
            <FormItem >
              <Button style={{ borderRadius: 0 }} onClick={() => { browserHistory.push(`/memb/staff/edit/${this.state.id}`); }}>编辑</Button>
              <Button style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', marginLeft: 10, borderRadius: 0 }} onClick={() => { browserHistory.push("/memb/staff"); }}>返回</Button>
            </FormItem>
          </div>
        </Form>
      </div>
    );
  },
}));

export default EditStaff;