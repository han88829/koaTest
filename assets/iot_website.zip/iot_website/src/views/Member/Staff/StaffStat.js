/*
 * @Author: Han.beibei 
 * @Date: 2017-03-06 16:03:04 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-12 16:05:14
 */

import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col } from 'antd';
import { Link } from 'react-router';
import echarts from 'echarts';
import './staff.css';
class deviceState {
  constructor() {
    extendObservable(this, {
      LevellData: [],
      GenderllData: [],
    })
  }
}

//性别
// @observer
const StaffStata = observer(class StaffStata extends Component {
  constructor() {
    super();
    this.state = {
      size: 'default'
    };
  }

  componentWillMount() {
    window.rpc.user.getArray(0, 0).then((result) => {
      //利用总数据筛选性别占比
      let users = result.map((x) => ({ ...x, gender: x.gender }))
      var a = [], b = [], c = [];
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].gender, 10) === 1) {
          a.push(users[i].gender)
        }
      }
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].gender, 10) === 2) {
          b.push(users[i].gender)
        }
      }
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].gender, 10) === 3) {
          c.push(users[i].gender)
        }
      }
      var a1 = a.length, b1 = b.length, c1 = c.length;
      this.props.deviceState.GenderllData = [{ key: 1, value: a1, name: '未知' }, { key: 2, value: b1, name: '男' }, { key: 3, value: c1, name: '女' }];
      let myChart = echarts.init(document.getElementById('StaffStata'));
      myChart.setOption({
        title: { text: '性别占比' },
        tooltip: {},
        color: ['#74cb62', '#32b3f2', '#8387c3'],
        series: [{
          name: '性别占比',
          selectedMode: 'single',
          type: 'pie',
          radius: '80%',
          data: [...this.props.deviceState.GenderllData],
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            },
            normal: {
              label: {
                show: true,
                formatter: '{b} \n\n {c}个 \n\n({d}%)',
              }
            },
            labelLine: { show: true }
          },
        }]
      });
      let myChartO = echarts.init(document.getElementById('statO'))
      myChartO.setOption({
        title: {
          "text": "性别统计",
          "x": "left",
        },
        color: ['#3398DB', '#59ADF3', '#AF89D6', '#86D560', '#FFCC67'], //可选色：'#86D560', '#AF89D6', '#59ADF3', '#FF999A', '#FFCC67'
        tooltip: {
          trigger: 'axis',
          axisPointer: {            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: ['男', '女', '未知'],
            axisTick: {
              alignWithLabel: true
            }
          }
        ],
        yAxis: [
          {
            type: 'value'
          }
        ],
        series: [
          {
            name: '性别/人数',
            type: 'bar',
            barWidth: '60%',
            data: [b1, c1, a1]
          }
        ]
      })
    }, (err) => {
      console.warn(err);
    })
  }

  render() {
    //const GenderllDatas = this.props.deviceState.GenderllData;
    return (
      <div className="ConcenHistory" style={{ height: '30vh' }}>
        <Row style={{ height: '30vh' }} gutter={16}>
          <Col span={10}>
            {/*<Table dataSource={[...this.props.deviceState.GenderllData]} bordered columns={columns} pagination={false} />*/}
            <div id="statO" style={{ height: '35vh', marginTop: 20, width: '100%', border: '1px solid gray' }}></div>
          </Col>
          <Col span={14}>
            <div id="StaffStata" style={{ height: '35vh', marginTop: 20, width: '100%', border: '1px solid gray' }}></div>
          </Col>
        </Row>
      </div>
    );
  }
})

//等级
// @observer
const StaffStatb = observer(class StaffStatb extends Component {
  constructor() {
    super();

    this.state = {
      size: 'default'
    };
  }

  componentDidMount() {
    window.rpc.user.getArray(0, 0).then((result) => {
      //利用总数据筛选性别占比
      let users = result.map((x) => ({ ...x, level: x.level }))
      var a = [], b = [], c = [], d = [], e = [];
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].level, 10) === 1) {
          a.push(users[i].level)
        }
      }
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].level, 10) === 2) {
          b.push(users[i].level)
        }
      }
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].level, 10) === 3) {
          c.push(users[i].level)
        }
      }
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].level, 10) === 4) {
          d.push(users[i].level)
        }
      }
      for (let i = 0; i < users.length; i++) {
        if (parseInt(users[i].level, 10) === 5) {
          e.push(users[i].level)
        }
      }
      var a1 = a.length, b1 = b.length, c1 = c.length, d1 = d.length, e1 = e.length;
      //console.log(a,b,c,d,e)
      this.props.deviceState.LevellData = [{ key: 1, value: a1, name: '一级' }, { key: 2, value: b1, name: '二级' }, { key: 3, value: c1, name: '三级' }, { key: 4, value: d1, name: '四级' }, { key: 5, value: e1, name: '五级' }];
      let myChart = echarts.init(document.getElementById('StaffStatb'));
      myChart.setOption({
        title: { text: '等级占比' },
        tooltip: {},
        color: ['#2db7f5', '#7dc856', '#808bc6', '#7dc856', '#808bc6', '#5d6775'],
        series: [{
          name: '等级',
          type: 'pie',
          radius: '70%',
          selectedMode: 'single',
          data: [...this.props.deviceState.LevellData],
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            },
            normal: {
              label: {
                show: true,
                formatter: '{b} \n\n {c}个 \n\n({d}%)'
              }
            },
            labelLine: { show: true }
          },
        }]
      });
      let myChartO = echarts.init(document.getElementById('Statb'));
      myChartO.setOption({
        title: {
          "text": "等级统计",
          "x": "left",
        },
        color: ['#3398DB', '#86D560', '#AF89D6'], //可选色：'#86D560', '#AF89D6', '#59ADF3', '#FF999A', '#FFCC67'
        tooltip: {
          trigger: 'axis',
          axisPointer: {            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: ['一级', '二级', '三级', '四级', '五级'],
            axisTick: {
              alignWithLabel: true
            }
          }
        ],
        yAxis: [
          {
            type: 'value'
          }
        ],
        series: [
          {
            name: '等级/人数',
            type: 'bar',
            barWidth: '60%',
            data: [a1, b1, c1, d1, e1]
          }
        ]
      });
    })

  }

  render() {
    return (
      <div className="ConcenHistory" style={{ marginTop: 30 }}>
        <Row style={{ padding: '5px 0' }} gutter={16}>
          <Col span={10}>
            <div id="Statb" style={{ height: '40vh', marginTop: 30, width: '100%', border: '1px solid gray' }}></div>
            {/*<Table dataSource={[...this.props.deviceState.LevellData]} bordered columns={columnsOne} pagination={false} />*/}
          </Col>
          <Col span={14}>
            <div id="StaffStatb" style={{ height: '40vh', marginTop: 30, width: '100%', border: '1px solid gray' }}></div>
          </Col>
        </Row>
      </div>
    );
  }
})

class StaffStat extends Component {
  render() {
    return (
      <div>
        <div style={{ height: 35, paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>人员统计</Link>
          </div>
        </div>
        <div>
          <StaffStata deviceState={new deviceState()} />
        </div>
        <div>
          <StaffStatb deviceState={new deviceState()} />
        </div>
      </div>
    )
  }
}

export default StaffStat;