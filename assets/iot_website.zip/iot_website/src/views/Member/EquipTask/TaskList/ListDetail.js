import React, { Component } from 'react';

class ListDetail extends Component {
  render() {
    return (
      <div>任务详情</div>
    )
  }
}

export default ListDetail;