/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 14:46:32 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-05-04 09:26:30
 */

import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Card, Form, message,Slider} from 'antd';
import echarts from 'echarts';
import '../equipTaskStatistics.css';
const FormItem = Form.Item;

const { RangePicker } = DatePicker;

function silderformatter(value) {
  return `${value}`;
}

class deviceState {
	constructor() {
    extendObservable(this, {
      patrolData: [{key: 1, value: 20, name: '巡检总数' }, {key: 2, value: 14, name: '巡检合格数' }, {key: 3, value: 2, name: '现场整改数' }, {key: 4, value: 3, name: '限期整改数', selected: true }, {key: 5, value: 1, name: '过期巡检数'}],
			addPatrol: action(function(){
				this.patrolData = [{key: 1, value: 30, name: '巡检总数' }, {key: 2, value: 14, name: '巡检合格数' }, {key: 3, value: 6, name: '现场整改数' }, {key: 4, value: 5, name: '限期整改数', selected: true }, {key: 5, value: 5, name: '过期巡检数'}];

				let myChart = echarts.init(document.getElementById('TaskInspectEcharts'));

				myChart.setOption({
					title: { text: '巡检情况' },
					tooltip: {},
					color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
					series: [{
						name: '销量',
						type: 'pie',
						radius: '80%',
						data: [...this.patrolData].filter(x => x.key !== 1),
						itemStyle: {
							emphasis: {
								shadowBlur: 10,
								shadowOffsetX: 0,
								shadowColor: 'rgba(0, 0, 0, 0.5)'
							},
							normal: {
								label: {
									show: true,
									formatter: '{b} \n\n {c}个 \n\n({d}%)'
								}
							},
							labelLine: { show: true }
						},
					}]
				});
			})
    })
  }
}
const PatrolSearchForm = Form.create()(React.createClass({
  handleSearch(e) {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['field-5'];
        const values = {
          ...fieldsValue,
          'field-5': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
        }
        console.log('Received values of form: ', values);
      });
      message.info('已更新');
    }catch(e) {
      console.log(e)
    }
    this.props.deviceState.addPatrol();
  },
  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
					{/*
					<Col span={6} key={2}>
						<FormItem>
							{getFieldDecorator('radio-group')(
								<Radio.Group>
									<Radio.Button value="week">周</Radio.Button>
									<Radio.Button value="month">月</Radio.Button>
									<Radio.Button value="seacon">季</Radio.Button>
								</Radio.Group>
							)}
						</FormItem>
					</Col>
					*/}
          <Col span={6} key={5}>
            <FormItem label={`时间`}>
              {getFieldDecorator(`field-5`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
				<Row style={{ margin: 10  }}>
			  <Col>
				巡检情况：
				</Col>
				</Row>
      </Form>
			 
    );
  }
}));

// @observer
const TaskInspectC = observer(class TaskInspectC extends Component {
	constructor() {
		super();

		this.state = {
			size: 'default'
		};
	}

	componentDidMount() {
		console.info("***"+this.props.deviceState.patrolData);
	
		let myChart = echarts.init(document.getElementById('TaskInspectEcharts'));

		myChart.setOption({
			title: { text: '巡检情况' },
			tooltip: {},
			color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
			series: [{
				name: '销量',
				type: 'pie',
				radius: '80%',
				data: [...this.props.deviceState.patrolData].filter(x => x.key !== 1),
				itemStyle: {
					emphasis: {
						shadowBlur: 10,
						shadowOffsetX: 0,
						shadowColor: 'rgba(0, 0, 0, 0.5)'
					},
					normal: {
						label: {
							show: true,
							formatter: '{b} \n\n {c}个 \n\n({d}%)'
						}
					},
					labelLine: { show: true }
				},
			}]
		});
	}

	
	render() {
		const valueCounts = this.props.deviceState.patrolData;
		let valueCountChildren = []; 
		//let sum = 0;
		for(let valueCount of valueCounts) {
			//sum += valueCount.value;
			valueCountChildren.push(valueCount.value);
		}
		return ( 
			<div className="TaskInspect" style={{ padding: '5px' }}>
				<PatrolSearchForm deviceState={this.props.deviceState} />
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<Col span={8}>
						<Card>
						
							<Row>
							<Col span={5}>巡检总数</Col>
							<Col span={18}>
							<div>
								<Slider tipFormatter={silderformatter}  defaultValue={valueCountChildren[0]} max={valueCountChildren[0]}/>
								</div>
							</Col>
							</Row>
							<Row style={{margin:'15px 0'}}>
							<Col span={5}>巡检合格数</Col>
								<Col span={18}><div>
                <Slider tipFormatter={silderformatter}  defaultValue={valueCountChildren[1]} max={valueCountChildren[0]}/>
								</div></Col>
							</Row>
							<Row style={{margin:'0 0 15px 0'}}>
							<Col span={5}>现场整改数</Col>
								<Col span={18}><div>
                <Slider tipFormatter={silderformatter}  defaultValue={valueCountChildren[2]} max={valueCountChildren[0]}/>
								</div></Col>
							</Row>
							<Row style={{margin:'0 0 15px 0'}}>
							<Col span={5}>限期整改数</Col>
								<Col span={18}><div>
                <Slider tipFormatter={silderformatter}  defaultValue={valueCountChildren[3]} max={valueCountChildren[0]}/>
								</div></Col>
							</Row>
							<Row style={{margin:'0 0 15px 0'}}>
							<Col span={5}>过期巡检数</Col>
								<Col span={18}><div>
                <Slider tipFormatter={silderformatter}  defaultValue={valueCountChildren[4]} max={valueCountChildren[0]}/>
								</div></Col>
							</Row>
						</Card>
					</Col> 
					<Col span={16}>
						<Card>
							<div id="TaskInspectEcharts" style={{ height: '60vh', width: '100%' }}></div> 
						</Card> 
					</Col>
				</Row>
			</div>
		);
	}
})

class TaskInspect extends Component {
	render() {
		return (
			<TaskInspectC deviceState={new deviceState()} />
		)
	}
}

export default TaskInspect;