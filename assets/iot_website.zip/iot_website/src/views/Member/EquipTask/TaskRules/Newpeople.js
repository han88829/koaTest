/*
 * @Author: Han.beibei 
 * @Date: 2017-03-23 14:28:41 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-03-24 08:51:57
 */

import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, DatePicker, Select, message, Steps } from 'antd';
import moment from 'moment';
import listStore from '../../listStore';

const { Option } = Select;
const FormItem = Form.Item;
const { genderList, levelList } = listStore;
const { Step } = Steps;

// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 取出等级 组织 用户组 性别
let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      selectIdOne: null,

    })
  }
}

const StaffC = observer(class StaffC extends Component {
  componentDidMount() {
    //const id = this.props.params.id;
    console.log(this.props.params)
    window.rpc.user.getInfoById(1).then((result) => {

      //let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      this.props.appState.tableData = [{ name: result.name, id: result.id, number: result.number, mobile: result.mobile, email: result.email, gender: genderList[result.gender] || '/', ownerId: groupownerNames[result.ownerId]['name'], level: levelList[result.level] || '/', groupId: groupNames[result.groupId]['name'], key: result.id, createTime: moment(result.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(result.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }];
      //console.log(this.props.appState.tableData)
    }, (err) => {
      console.warn(err);
    })

  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      //console.log('Received values of form: ', values);
    });
  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
    len: null
  };
  handleChange = (pagination, filters, sorter) => {
    //console.log('Various parameters', pagination, filters, sorter);
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }

  handleStaff = () => {
    if (this.props.appState.selectId != null) {
      browserHistory.push(`/member/people`);
    } else {
      message.info('请选择人员！');
    }

  }
  //更多操作选择
  handlemore = (value) => {
    console.log(`selected ${value}`);
  }
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
      sorter: (a, b) => a.number - b.number,
      sortOrder: sortedInfo.columnKey === 'number' && sortedInfo.order,
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/member/staffdetail/${record.key}`}>查看</Link>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];
    //console.log(data)
    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };

    //表格单选框设置
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
        this.setState({ len: this.props.appState.selectId.length })
        this.props.appState.selectIdOne = record.id;

      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (

      <div className="Staff" style={{ padding: 24 }}>
        <Steps current={2} style={{ width: '80%', margin: '0 auto', marginTop: 10 }}>
          <Step title="基本信息" />
          <Step title="选择设备" />
          <Step title="选择人员" />
          <Step title="生成规则" />
        </Steps>
        <Row style={{ padding: '5px 0 15px', marginTop: '20px' }}>
          <Col span={20} >
            <Button type="primary" style={{ marginRight: '20px' }}><Link to="/memb/addpeople" >添加人员</Link></Button><br />
            <Button type="" style={{ marginRight: '20px', marginTop: 20 }} onClick={this.handleStaff}>批量操作</Button>
            <Select
              showSearch
              style={{ width: 80}}
              placeholder="更多操作"
              optionFilterProp="children"
              onChange={this.handlemore}
              filterOption={(input, option) => option.props.value.toLowerCase().indexOf(input.toLowerCase()) >= 0}
            >
              <Option value="1">启用</Option>
              <Option value="2">停用</Option>
              <Option value="3">删除</Option>
            </Select>
          </Col>
          <Col span={4}>
            {/*<div>已选择{`${this.state.len}`}项数据</div>*/}
          </Col>
        </Row>
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              bordered
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
        <Row style={{ marginTop: 20, textAlign: 'center' }}>
          <Col span={24}>
            <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontSize: '12px', fontFamily: '苹方中等', borderRadius: '5px' }}><Link to="/memb/generate">下一步</Link></Button>
            <Button type="success" style={{ marginLeft: 15, fontSize: '12px', fontFamily: '苹方中等', borderRadius: '5px' }}><Link to="/memb/newrquip">返回修改</Link></Button>
          </Col>
        </Row>
      </div>
    );
  }
})


class Newpeople extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default Newpeople;