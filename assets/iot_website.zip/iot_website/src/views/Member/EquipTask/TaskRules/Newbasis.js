import React from 'react';
import { Form, Input, Cascader, Select, Button, DatePicker, Row, Col, Steps, Radio } from 'antd';
import { Link } from 'react-router';
//import moment from 'moment';
const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const Option = Select.Option;
const { Step } = Steps;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

const Newbasis = Form.create()(React.createClass({
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  },
  //审核选择
  onChange(e){
    console.log(`radio checked:${e.target.value}`);
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };

    const config = {
      rules: [{required: true, message: '请选择时间!' }],
    };

    return (
      <Form onSubmit={this.handleSubmit}>
        <Steps current={0} style={{ width: '80%', margin: '0 auto', marginTop: 10 }}>
          <Step title="基本信息" />
          <Step title="选择设备" />
          <Step title="选择人员" />
          <Step title="生成规则" />
        </Steps>

        <Row style={{ marginTop: 30, marginLeft: '35%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="规则名称"
              hasFeedback
            >
              {getFieldDecorator('name', {
                rules: [{ required: true, message: '请输入任务标题!' }],
              })(
                <Input />
                )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginLeft: '35%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="审核方式选择："
              hasFeedback
            >
              {getFieldDecorator('auditMethon', {
                rules: [
                  { required: true, message: '请选择审核方式！' },
                ],
              })(
                <RadioGroup onChange={this.onChange}>
                  <RadioButton value="1">报表系统自动审核</RadioButton>
                  <RadioButton value="2">报表人工审核</RadioButton>
                </RadioGroup>
                )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginLeft: '35%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="起止时间："
              hasFeedback
            >
              {getFieldDecorator('TaskDate', config)(
                <RangePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['开始时间', '截至时间']}
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginLeft: '35%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="检查频率（天/次）"
              hasFeedback
            >
              {getFieldDecorator('frequency', {
                rules: [
                  { required: true, message: '请输入检查频率！' },
                ],
              })(
                <Input />
                )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginLeft: '35%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备类型选择："
              hasFeedback
            >
              {getFieldDecorator('equipType', {
                rules: [{required: true, message: '请选择类型!' }],
              })(
                <Select>
                  <Option value="1">报表一</Option>
                  <Option value="2">报表二</Option>
                  <Option value="3">报表三</Option>
                  <Option value="4">报表四</Option>
                </Select>
                )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginLeft: '39%', marginTop: 50 }}>
          <Col>
            <FormItem {...tailFormItemLayout}>
              <Button type="primary" htmlType="submit" size="large"><Link to='/member/newrquip'>下一步</Link></Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  },
}));

export default Newbasis;