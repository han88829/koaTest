import React from 'react';
import { Form, Input, Cascader, Select, Button, DatePicker, Row, Col, Steps, Radio, Switch } from 'antd';
import { Link } from 'react-router';
//import moment from 'moment';
const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const Option = Select.Option;
const { Step } = Steps;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

const NewGenerate = Form.create()(React.createClass({
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  },
  //审核选择
  onChange(e) {
    console.log(`radio checked:${e.target.value}`);
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };

    const config = {
      rules: [{ required: true, message: '请选择时间!' }],
    };

    return (
      <Form onSubmit={this.handleSubmit}>
        <Steps current={3} style={{ width: '80%', margin: '0 auto', marginTop: 10 }}>
          <Step title="基本信息" />
          <Step title="选择设备" />
          <Step title="选择人员" />
          <Step title="生成规则" />
        </Steps>

        <Row style={{ marginLeft: '39%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="设备分配方式："
              hasFeedback
            >
              {getFieldDecorator('auditMethon', {
                rules: [
                  { required: true, message: '请选择分配方式！' },
                ],
              })(
                <RadioGroup onChange={this.onChange}>
                  <RadioButton value="1">共享</RadioButton>
                  <RadioButton value="2">独享</RadioButton>
                </RadioGroup>
                )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginLeft: '39%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="设备分配方式："
              hasFeedback
            >
              {getFieldDecorator('remark', {
              })(
                <div>
                  <div style={{}}>此选项下所有人员共享所有设备，所有人一起巡检设备。系统不会将设备分配到个人；</div>
                  <div style={{}}>此选项下所有人员不能共享此设备，个人进行巡检设备。</div>
                </div>
                )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginLeft: '39%' }}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="是否启用："
            >
              {getFieldDecorator('switch', {

              })(
                <Switch checkedChildren={'开'} unCheckedChildren={'关'} />
                )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginTop: 20, textAlign: 'center' }}>
          <Col span={22}>
            <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontSize: '12px', fontFamily: '苹方中等', borderRadius: '5px' }}><Link to="/memb/rules">完成</Link></Button>
            <Button type="success" style={{ marginLeft: 15, fontSize: '12px', fontFamily: '苹方中等', borderRadius: '5px' }}><Link to="/memb/newrquip">返回修改</Link></Button>
          </Col>
        </Row>
      </Form>
    );
  },
}));

export default NewGenerate;