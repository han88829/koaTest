import React, { Component } from 'react';

class Addequip extends Component {
  render() {
    return (
      <div>添加设备</div>
    )
  }
}

export default Addequip;