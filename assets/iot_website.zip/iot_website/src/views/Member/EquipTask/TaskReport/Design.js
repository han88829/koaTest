import React, { Component } from 'react';

class Desing extends Component {
  render() {
    return (
      <div>设计报表</div>
    )
  }
}

export default Desing;