/*
 * @Author: lai.haibo 
 * @Date: 2017-03-03 14:23:24 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-03-04 17:16:15
 */

import React from 'react';
import { Form, Input, Cascader, Select, Button, DatePicker, Row, Col, message } from 'antd';
import { Link, browserHistory } from 'react-router';
import listStore from '../listStore';
//import moment from 'moment';
const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const Option = Select.Option;
const {auditMethonType, InspectorsType, reportType} = listStore;

const equipTypes = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const builds = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];
// function onChange(value, dateString) {
//   console.log('Selected Time: ', value);
//   console.log('Formatted Selected Time: ', dateString);
// }

const EquipTaskInspectNew = Form.create()(React.createClass({
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
        let {name, number, username, password, email, mobile, level, groupId, ownerId, gender} = values;
        let obj = {name,  number: parseInt(number, 10), username,password,email,mobile: parseInt(mobile, 10),level,groupId,ownerId, gender};
        //设备抽检 暂时先存储到user
        window.rpc.user.create(obj).then(() => {
          message.info('创建成功！')
          browserHistory.push('/member/equiptask');
        }, (err) => {
          console.log(err);
        })
      }
    });
  },
 
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    //取出结构表里的数据添加到选项中
    let auditMethonChildren = [];
    let InspectorsChildren = [];
    let dreportChildren = [];
    for(let i = 1; i < auditMethonType.length; i++) {
      auditMethonChildren.push(<Option key={`${i}`}>{auditMethonType[i]}</Option>)
    }
    for(let i = 1; i < InspectorsType.length; i++) {
      InspectorsChildren.push(<Option key={`${i}`}>{InspectorsType[i]}</Option>)
    }
    for(let i = 1; i < reportType.length; i++) {
      dreportChildren.push(<Option key={`${i}`}>{reportType[i]}</Option>)
    }

    const config = {
      rules: [{ type: 'array', required: true, message: '请选择时间!' }],
    };
    
    return (
      <Form onSubmit={this.handleSubmit}>
        <Row style={{marginTop:20}}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检任务标题："
              hasFeedback
            >
              {getFieldDecorator('name', {
                rules: [{ required: true, message: '请输入任务标题!' }],
              })(
                <Input />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检任务说明："
              hasFeedback
            >
              {getFieldDecorator('task', {
                rules: [{ required: true, message: '请输入任务说明!' }],
              })(
                <Input type="textarea" rows={3} />
              )}
            </FormItem>
          </Col>
        </Row>
         <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="审核方式选择："
              hasFeedback
            >
              {getFieldDecorator('auditMethon', {
                rules: [
                  { required: true, message: '请选择审核方式！' },
                ],
              })(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {auditMethonChildren}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="任务开始--截至时间："
            >
              {getFieldDecorator('TaskDate', config)(
                <RangePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['开始时间', '截至时间']}
                  /*onChange={onChange}*/
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检人选择："
              hasFeedback
            >
              {getFieldDecorator('Inspectors', {
                rules: [
                  { required: true, message: '请选择巡检人！' },
                ],
              })(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {InspectorsChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检报表选择"
              hasFeedback
            >
              {getFieldDecorator('report', {
                rules: [
                  { required: true, message: '请选择报表方式！' },
                ],
              })(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {dreportChildren}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检设备类型选择："
            >
              {getFieldDecorator('equipType', {
                rules: [{ type: 'array', required: true, message: '请选择类型!' }],
              })(
                <Cascader options={equipTypes} />
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检设备建筑选择："
            >
              {getFieldDecorator('build', {
                rules: [{ type: 'array', required: true, message: '请选择建筑!' }],
              })(
                <Cascader options={builds} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 30, right: 140 }}>
          <Col span={20}></Col>
          <Col span={4}>
            <Row style={{ margin: '0' }}>
              <Col span={6}></Col>
              <Col span={9}>
                <FormItem {...tailFormItemLayout}>
                  <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontFamily: '微软雅黑', fontSize: '14px', borderRadius: '5px', position: 'absolute', right: 10 }}>创建</Button>
                </FormItem>
              </Col>
              <Col span={9}>
                <FormItem {...tailFormItemLayout}>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px' }}><Link to="/member/equiptask">返回</Link></Button>
                </FormItem>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>
    );
  },
}));

export default EquipTaskInspectNew;