/*
 * @Author: lai.haibo 
 * @Date: 2017-03-03 14:23:49 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-03-17 14:42:39
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

message.config({
  top: 216,
  duration: 2
})

class equipTaskState {
  // @observable tableData = [];
  constructor() {
    extendObservable(this, {
      tableData: []
    })
  }
}

class AdvancedSearchForm extends React.Component {

  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const values = {
          ...fieldsValue,
          'dtype': parseInt(fieldsValue['dtype'], 10),
          'dstate': parseInt(fieldsValue['dstate'], 10),
          'location': parseInt(fieldsValue['location'], 10),
          'setupTime': [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))]
          // 'setupTime': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
        }
        console.log('Received values of form: ', values);

        window.rpc.device.getArrayByContainer(values,0,0).then((result) =>{
          console.log(result);
          message.info(`共搜索到${result.length}条数据`);
          let devices = result.map((x) => ({...x, key: x.id, setupTime: '2017-2-21', sign: `*&^%$#@!`, lastPatrolDate: '2016-09-26 08:50:08'}));
          this.props.equipTaskState.tableData = devices;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch(e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form inline style={{ margin: 0 }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`任务标题`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`任务类型`}>
              {getFieldDecorator(`dtype`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  <Option value="1">巡检</Option>
                  <Option value="2">抽检</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`任务状态`}>
              {getFieldDecorator(`dstate`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  <Option value="1">待办</Option>
                  <Option value="2">提交</Option>
                  <Option value="3">审核</Option>
                  <Option value="4">离线</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`负责人`}>
              {getFieldDecorator(`location`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  <Option value="1">A</Option>
                  <Option value="2">B</Option>
                  <Option value="3" disabled>C</Option>
                  <Option value="4">D</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`截至时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker
                ranges={{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }}
                />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

// @observer
const MEquipTaskC = observer(class MEquipTaskC extends Component {
  componentDidMount() {
    window.rpc.device.getArray(0,0).then((result) =>{
      let devices = result.map((x) => ({...x, key: x.id, setupTime: '2016-07-02', sign: `!@#$%^&*`, lastPatrolDate: '2016-09-26 08:50:08'}));
      this.props.equipTaskState.tableData = devices;
    }, (err) => {
      console.warn(err);
    })
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }

  add() {
    this.props.equipTaskState.tableData.push({ key: 4, sign: '#', id: 4, name: '烟感1', type:'测温探测器', installDate: '2015-09-26 08:50:08', address: 'Sidney No. 1 Lake Park', condition: '维修中', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is Joe Black, I am 32 years old, living in Sidney No. 1 Lake Park.' })
  }

  maintain() {
    message.success('保养成功');
  }

  check() {
    message.success('检测成功');
  }

  cancel() {
    message.error('已取消');
  }

  render() {
    const data = [{
      key: 1,
      name: '2017年2月份测试任务',
      id: 1,
      age: 60,
      address: 'New York No. 1 Lake Park',
      dtype: '巡检',
      setupTime: '2016-07-06',
      endTime: '2017-12-01',
      rstate: '待办',
      patrolId: '王小明',
      parentId: '/',
      children: [{
        key: 11,
        name: '烟感',
        id: 11,
        age: 60,
        address: 'New York No. 1 Lake Park',
        dtype: '巡检',
        setupTime: '2016-07-06',
        endTime: '2017-12-01',
        rstate: '待办',
        patrolId: '王小明',
        parentId: '2017年2月份测试任务',
      }, {
        key: 12,
        name: '灭火器',
        id: 12,
        age: 60,
        address: 'New York No. 1 Lake Park',
        dtype: '巡检',
        setupTime: '2016-07-06',
        endTime: '2017-12-01',
        rstate: '待办',
        patrolId: '王小明',
        parentId: '2017年2月份测试任务',
      }],
      }, {
        key: 2,
        name: '2017年2月份测试任务',
        id: 2,
        age: 60,
        address: 'New York No. 1 Lake Park',
        dtype: '抽检',
        setupTime: '2016-07-06',
        endTime: '2017-12-01',
        rstate: '待办',
        patrolId: '王小明',
        parentId: '/',
    }];

    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '任务标题', dataIndex: 'name', key: 'name' },
      { title: '任务类型', dataIndex: 'dtype', key: 'dtype' },
      { title: '任务开始时间', dataIndex: 'setupTime', key: 'setupTime' },
      { title: '任务结束时间', dataIndex: 'endTime', key: 'endTime' },
      { title: '任务状态', dataIndex: 'rstate', key: 'rstate' },
      { title: '最后巡查人', dataIndex: 'patrolId', key: 'patrolId' },
      { title: '任务源', dataIndex: 'parentId', key: 'parentId' },
      { title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/member/equipinspecttaskdetail/${record.key}`}>查看</Link>
            <span className="ant-divider" />
            <Link to={`/member/equipinspecttaskedit/${record.key}`}>编辑</Link>
            <span className="ant-divider" />
            <Link to={`/member/equiptasksubmit/${record.key}`}>提交</Link>
            <span className="ant-divider" />
            <Link to={`/member/equiptaskpending/${record.key}`}>审核</Link>
          </span>
        )
      },
    ];

    // const data = [...this.props.equipTaskState.tableData];

    const pagination = {
      // total: this.props.equipTaskState.tableData.length,
      total: data.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    return (
      <div className="MEquipTask" style={{ padding: 24 }}>
        <WrappedAdvancedSearchForm equipTaskState={this.props.equipTaskState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={2}>
            <Button type="primary"><Link to="/member/equipinspecttasknew">新增巡检任务</Link></Button>
          </Col>
          <Col span={2}>
            <Button type="primary"><Link to="/member/equiprandomtasknew">新增抽检任务</Link></Button>
          </Col>
        </Row>
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              className="table-equipTask"
              columns={columns}
              dataSource={data}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})

class MEquipTask extends Component {
  render() {
    return (
      <MEquipTaskC equipTaskState={new equipTaskState()} />
    );
  }
}

export default MEquipTask;