/*
 * @Author: lai.haibo 
 * @Date: 2017-03-03 14:22:38 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-03-04 15:41:45
 */

import React, { Component } from 'react';
import { Input, Form, Select, DatePicker, Row,Button, Col,Cascader,InputNumber } from 'antd';
import { Link } from 'react-router';
import moment from 'moment';
const FormItem = Form.Item;
//const MonthPicker = DatePicker.MonthPicker;
const RangePicker = DatePicker.RangePicker;
//const FormItem = Form.Item;
const Option = Select.Option;
//const SHOW_PARENT = TreeSelect.SHOW_PARENT;
const options = [{
  value: 'zhejiang',
  label: 'Zhejiang',
  children: [{
    value: 'hangzhou',
    label: 'Hangzhou',
    children: [{
      value: 'xihu',
      label: 'West Lake',
    }, {
      value: 'xiasha',
      label: 'Xia Sha',
      disabled: true,
    }],
  }],
}, {
  value: 'jiangsu',
  label: 'Jiangsu',
  children: [{
    value: 'nanjing',
    label: 'Nanjing',
    children: [{
      value: 'zhonghuamen',
      label: 'Zhong Hua men',
    }],
  }],
}];

const dataDetail=[{ id:'1', name: '1', title:'国家科技园抽检任务-01',instructions:'对国家科技园进行巡检',monitorialMode:'系统' , enablePlan:'是', inspectionPeopleChose:'系统分配',startTime: ['2015-05-02', '2015-05-06'], endTime: ['2015-05-03', '2015-05-06'],periodNum:'2' ,timeKind:'天',reportForms:'总表',buildingSelect:['zhejiang', 'hangzhou', 'xihu'], kindSelect: ['zhejiang', 'hangzhou', 'xihu'] }];
class MOrgTaskInspectDetail extends Component {
  render() {
    return (
      <div className="MOrgTaskInspectDetail">
          <InspectTaskDetail />
      </div>
    );
  }
}


const InspectTaskDetail = Form.create()(React.createClass({
   getInitialState() {
    return {
       dataDetail: [],
    };
  },
   
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
   
  },
  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },
   /* componentWillMount() {

    
  // this.setState({ dataDetail});
     this.props.form.setFieldsValue({
       title: '国家科技园抽检任务-01',
    })
    },*/
  render() {
    //const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };

  //  const tailFormItemLayout = {
  //     wrapperCol: {
  //       span: 14,
  //       offset: 6,
  //     },
  //   };
     return (
      <Form onSubmit={this.handleSubmit} style={{fontSize:'12px'}}>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
                label="周期计划标题"
                style={{fontSize:'16px',color:'#555'}}
            >
               <Input type="textarea" size="large" disabled style={{height:'40px'}} defaultValue={dataDetail[0].title}/>
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
                 label="周期计划说明"
            >
              <Input type="textarea" size="large" disabled style={{height:'40px'}} defaultValue={dataDetail[0].title}/>
             </FormItem>
           </Col>
         </Row>
         <Row>
           <Col span={12}>
             <FormItem
               {...formItemLayout}
               label="审核方式"
              >
                <Select defaultValue={dataDetail[0].monitorialMode} style={{ width: 120 }} allowClear disabled>
                  <Option value={dataDetail[0].monitorialMode}>{dataDetail[0].monitorialMode}</Option>
                </Select>
             </FormItem>
           </Col>
         </Row>
         <Row>
           <Col span={12}>
             <FormItem
               {...formItemLayout}
               label="启用计划"
             >
                 <Select  defaultValue={dataDetail[0].enablePlan} style={{ width: 120 }} allowClear disabled>
                   <Option value={dataDetail[0].enablePlan}>{dataDetail[0].enablePlan}</Option>
                 </Select>
             </FormItem>
           </Col>
           <Col span={12}>
             <FormItem
               {...formItemLayout}
               label="巡检人"
              >                
                <Select  defaultValue={dataDetail[0].inspectionPeopleChose} style={{ width: 120 }} allowClear disabled>
                  <Option value={dataDetail[0].inspectionPeopleChose}>{dataDetail[0].inspectionPeopleChose}</Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
               {...formItemLayout}
               label="计划开始时间"
              >
                <RangePicker   defaultValue={[moment(`${dataDetail[0].startTime[0]}`), moment(`${dataDetail[0].startTime[1]}`)]}  disabled/>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="计划结束时间"
              >
                <RangePicker   defaultValue={[moment(`${dataDetail[0].endTime[0]}`), moment(`${dataDetail[0].endTime[1]}`)]}  disabled/>
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12} style={{textAlign:'center'}}>
              <Row>
                <Col span={8} style={{textAlign:'center'}}>  
                  <FormItem
                    {...formItemLayout}
                    label="巡检周期设定："
                    labelCol={{ span: 18 }}
                    wrapperCol={{ span: 2}}
                  >
                    <InputNumber  defaultValue={dataDetail[0].periodNum} disabled/>
                  </FormItem>
                </Col>
                <Col span={10}>  
                  <FormItem
                    {...formItemLayout}
                  >
                    <Select  defaultValue={dataDetail[0].timeKind} style={{ width: 120 }} allowClear disabled>
                      <Option value={dataDetail[0].timeKind}>{dataDetail[0].timeKind}</Option>
                    </Select>
                 </FormItem>  
               </Col>
            </Row> 
          </Col>
          <Col span={12}>
           <FormItem
             {...formItemLayout}
             label="报表选择"
           >
              <Select defaultValue={dataDetail[0].reportForms} style={{ width: 120 }} allowClear disabled>
                <Option value={dataDetail[0].reportForms}>{dataDetail[0].reportForms}</Option>
              </Select>
           </FormItem>
         </Col>
       </Row>
       <Row>
         <Col span={3} style={{textAlign:'right'}}>
           <span>巡检设备：</span>
        </Col>
        <Col span={21}  style={{textAlign:'left'}}>
          <Row>
            <Col span={20} style={{textAlign:'left'}}>
              <FormItem
                {...formItemLayout}
                label="类型选择"
                labelCol={{ span: 2 }}
                wrapperCol={{ span: 2}}
              >
              <Cascader              
                 defaultValue={dataDetail[0].kindSelect}
                 disabled
                 style={{ width: 270 }}
                 options={options}
              />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={20} style={{textAlign:'left'}}>
            <FormItem
              {...formItemLayout}
                label="建筑选择"
                labelCol={{ span: 2 }}
                wrapperCol={{ span: 2}}
            >
              <Cascader              
                 defaultValue={dataDetail[0].buildingSelect}
                 disabled
                 style={{ width: 270 }}
                  options={options}
              />
             </FormItem>
           </Col>
         </Row>
       </Col>
      </Row>
      <Row>
        <Col span={20}></Col>
        <Col span={4}>
            <FormItem>
              <Button type="success"><Link to="/member/equiptask">返回</Link></Button>
            </FormItem>
         </Col>
        </Row>     
     </Form>
   );
  },
}));

export default MOrgTaskInspectDetail;