/*
 * @Author: lai.haibo 
 * @Date: 2017-03-03 14:38:22 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-03 14:38:22 
 */

import React, { Component } from 'react';
import EquipTaskPendTr from './containers/EquipTaskPendTr.js';
import './containers/EquipTaskPend.css';


class MOrgTaskPending extends Component {
  render() {
    return (
      <div className="MOrgTaskPending" style={{ padding: '24px' }}>
          <EquipTaskPendTr/>
      </div>
    );
  }
}

export default MOrgTaskPending;