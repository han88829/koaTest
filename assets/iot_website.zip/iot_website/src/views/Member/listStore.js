const listStore = {
  dStateList: ['/','未知', '合格', '不合格'],
  rStateList: ['/','正常', '异常', '离线'],
  networkModeList: ['/','网关', '4G', 'GSM'],
  patrolTypeList: ['/','巡查', '保养', '检测'],
  patrolStateList: ['/','巡查', '保养', '检测'],
  warningType: ['/','烟感','测温设备','灭火器'],
  resultsType: ['/','测试','已修复','已报警'],
  auditMethonType: ['/','系统','人工'],
  InspectorsType: ['/','自动匹配','巡检员一','巡检员二'],
  reportType: ['/','总表','分表'],
  genderList:['/','未知','男','女'],
  levelList:['/','一级','二级','三级','四级','五级'],
  messageList:['产品消息','安全消息','服务消息','活动消息','历史消息',"故障消息"]
}

export default listStore;