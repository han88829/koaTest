/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 14:04:05 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-05-04 09:28:17
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, DatePicker, message, Radio } from 'antd';
import moment from 'moment';
import './performance.css';
// import listStore from '../listStore';

const { RangePicker } = DatePicker;
// const { Option } = Select;
const FormItem = Form.Item;

// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 结构出参量表
// const { rStateList } = listStore;

// 取出类型和locations
// let dtypes = JSON.parse(sessionStorage.getItem('dtypes'));
// let locations = JSON.parse(sessionStorage.getItem('locations'));

// 初始化mobx设置
class appState {
  // @observable tableData = [];
  constructor() {
    extendObservable(this, {
      tableData: []
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentWillMount() {
    // console.log(this.props.form);
    this.props.form.setFieldsValue({
      periods: 'month'
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        let values = {};
        values = {createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))]}
        // console.log('Received values of form: ', values);

        window.rpc.user.getArrayByContainer(values,0,0).then((result) =>{
          // console.log(result);
          message.info(`共搜索到${result.length}条数据`);
          let devices = result.map((x) => ({...x, attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: x.id}));
          this.props.appState.tableData = devices;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch(e) {
      console.warn(e);
    }
  }

  handlePeriods = (e) => {
    // console.log(e.target.value);
    let createTime = e.target.value;
    let values = {};
    switch (createTime) {
      case 'month':
        values = {createTime: [new Date(moment().subtract(1, 'month').format('YYYY-MM-DD')), new Date()]};
        break;
      case 'year':
        values = {createTime: [new Date(moment().subtract(1, 'year').format('YYYY-MM-DD')), new Date()]};
        break;
      case 'quarter':
        values = {createTime: [new Date(moment().subtract(3, 'month').format('YYYY-MM-DD')), new Date()]};
        break;
      default:
        console.log('haha!');
        break;
    }
    // console.log(values);
    window.rpc.user.getArrayByContainer(values,0,0).then((result) =>{
      // console.log(result);
      message.info(`共搜索到${result.length}条数据`);
      let devices = result.map((x) => ({...x, attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: x.id}));
      this.props.appState.tableData = devices;
    }, (err) => {
      console.warn(err);
    })
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={6} key={1}>
            <FormItem>
							{/*{getFieldDecorator('periods')(*/}
								<Radio.Group onChange={this.handlePeriods} defaultValue="month" style={{ borderRadius: 0 }}>
									<Radio.Button value="month">月</Radio.Button>
									<Radio.Button value="quarter">季</Radio.Button>
									<Radio.Button value="year">年</Radio.Button>
								</Radio.Group>
							{/*})}*/}
						</FormItem>
          </Col>
          <Col span={6} key={2}>
            <FormItem label={`时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{borderRadius: 0}} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
                style={{borderRadius: 0}}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

// @observer
const PerformanceC = observer(class PerformanceC extends Component {

  state = {
    sortedInfo: null,
  }

  handleChange = (pagination, filters, sorter) => {
    // console.log('Various parameters', pagination, filters, sorter);
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }

  componentDidMount() {
    let values = {createTime: [new Date(moment().subtract(1, 'month').format('YYYY-MM-DD')), new Date()]};
    window.rpc.user.getArrayByContainer(values,0,0).then((result) =>{
      let devices = result.map((x) => ({...x, attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: x.id}));
      this.props.appState.tableData = devices;
    }, (err) => {
      console.warn(err);
    })
  }

  render() {
    let { sortedInfo} = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '姓名', dataIndex: 'name', key: 'name' },
      { title: '出勤率', dataIndex: 'attendance', key: 'attendance', sorter: (a, b) => a.attendance - b.attendance, sortOrder: sortedInfo.columnKey === 'attendance' && sortedInfo.order, },
      { title: '任务完成数 / 任务逾期数', dataIndex: 'completion', key: 'completion' },
      // { title: '开始时间', dataIndex: 'createTime', key: 'createTime' },
      // { title: '结束时间', dataIndex: 'lastTime', key: 'lastTime' },
      { title: '打分', dataIndex: 'score', key: 'score', sorter: (a, b) => a.score - b.score, sortOrder: sortedInfo.columnKey === 'score' && sortedInfo.order, },
      { title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/memb/prfrm/${record.key}`}>查看详情</Link>
          </span>
        )
      },
    ];

    const data = [...this.props.appState.tableData];

    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        // console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        // console.log('Current: ', current);
      },
    };
    return (
      <div className="Performance" style={{ padding: 0 }}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/prfrm' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>绩效管理</Link>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              bordered
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class Performance extends Component {
  render() {
    return (
      <PerformanceC appState={new appState()} />
    )
  }
}

export default Performance;