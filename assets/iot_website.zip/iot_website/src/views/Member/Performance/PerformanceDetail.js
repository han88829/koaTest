/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 14:10:01 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-05-04 09:28:30
 */

import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Link } from 'react-router';
import { Row, Col, DatePicker, Button, Radio, Card, Form, message } from 'antd';
import moment from 'moment';
import echarts from 'echarts';

import './performance.css';
const FormItem = Form.Item;
const { RangePicker } = DatePicker;

class deviceState {
  // @observable me = {};
  // @observable patrolData = [{key: 1, value: 5, name: '任务完成数', selected: true },{key: 2, value: 2, name: '任务逾期数' }];
  // @observable patrolData3 = [[51, 43,54,55,58,41,43],[31,24,55,38,41,43,45],[41,34,12,28,41,43,25]];
  // @observable periods = [];
  // @observable periodsTime = [];
  // @observable periodsScore = [];

  constructor() {
    extendObservable(this, {
        me: {},
        patrolData: [{key: 1, value: 5, name: '任务完成数', selected: true },{key: 2, value: 2, name: '任务逾期数' }],
        patrolData3: [[51, 43,54,55,58,41,43],[31,24,55,38,41,43,45],[41,34,12,28,41,43,25]],
        periods: [],
        periodsTime: [],
        periodsScore: [],
        addPatrolUp: action(function(time = 'month') {
          switch (time) {
            case 'month':
              {
                this.periods = [moment().format('YYYY-MM')];
                this.periodsTime = [1];
                this.periodsScore = [100];
              }
              break;
            case 'quater':
              {
                // console.log();
                let arr = [];
                for(let i = 0; i < 3; i++){
                  arr.unshift(moment().subtract(i, 'month').format('YYYY-MM'))
                }
                this.periods = arr;
                this.periodsTime = [30,29,1];
                this.periodsScore = [100,99,98];
              }
              break;
            case 'year':
              {
                let arr = [];
                for(let i = 0; i < 12; i++){
                  arr.unshift(moment().subtract(i, 'month').format('YYYY-MM'))
                }
                this.periods = arr;
                this.periodsTime = [30,28,26,25,28,30,29,26,25,28,29,1];
                this.periodsScore = [100,99,96,54,88,60,11,66,88,77,88];
              }
              break;
            default:
              {
                console.log('haha!');
              }
              break;
          }

          let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
              
          myChartOne.setOption({
            title : {
              text: '出勤次数',
              textStyle: {
                font: '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {
              trigger: 'axis'
            },
            color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
            legend: {
              orient: 'horizontal',
              x: 'right',
              data:['出勤次数']
            },
            calculable : true,
            xAxis : [
              {
                type : 'category',
                /**此处应该是从外面传来的参数，最近7天 */
                data : [...this.periods]
              }
            ],
            yAxis : [
              {
                type : 'value',
                splitLine: {
                  show: false
                },
              }
            ],
            series : [
              {
                name:'出勤次数',
                type:'bar',
                barWidth: 15,
                /** 从后台拿数据*/
                data:[...this.periodsTime],
              }
            ]
          });

          let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));

          if( time === 'month'){
            myChartTwo.setOption({
              title: {
                text: '任务完成率' ,
                textStyle: {
                  font: '14px 微软雅黑 Light',               
                  color: "#666666"
                }
              },
              tooltip: {},
              color: ['#74cb62', '#32b3f2', '#8387c3'],
              series: [{
                name:'任务完成率',
                type:'pie',
                selectedMode: 'single',
                radius: ['0', '48%'],
                center: ['50%', '52%'],
                data: [...this.patrolData],
                itemStyle: {
                  emphasis: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                  },
                  normal: {
                    label: {
                      show: true,
                      //position:'inside',
                      formatter: '{b} \n\n {c}个 \n\n({d}%)',
                      textStyle : {
                        fontSize : '14',
                        fontFamily:'幼圆',
                        fontWeight:'bold'
                      }
                    }
                  }
                      /*labelLine: { show: true }*/
                },
              }]
            });
          }else {
            myChartTwo.setOption({
              title: {
                text: '任务完成率',
                textStyle: {
                  font:  '14px 微软雅黑 Light',               
                  color: "#666666"
                }
              },
              tooltip: {
                trigger: 'axis'
              },
              color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
              legend: {
                orient: 'horizontal',
                x: 'right',
                right: '50px',
                data: ['任务完成率']
              },
              /**网格 */
              grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
              },
              xAxis: {
                type: 'category',//category  种类
                boundaryGap: false,
                /*设置此处横的网格线不显示*/ 
                splitLine: {
                  show: false
                },
                data: [...this.periods]
              },
              yAxis: {
                type: 'value',
                splitLine: {
                  show: false
                },
              },
              series: [
                {
                  name:'任务完成率',
                  type:'line',
                  data:[...this.periodsTime]
                }
              ]
            });
          }

          let myChartThree = echarts.init(document.getElementById('DeviceTypeMountEcharts03'));
          myChartThree.setOption({
            title : {
              text: '得分',
              textStyle: {
                font: '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {
              trigger: 'axis'
            },
            color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
            legend: {
              orient: 'horizontal',
              x: 'right',
              data:['得分']
            },
            calculable : true,
            xAxis : [
              {
                type : 'category',
                /**此处应该是从外面传来的参数，最近7天 */
                data : [...this.periods]
              }
            ],
            yAxis : [
              {
                type : 'value',
                splitLine: {
                  show: false
                },
              }
            ],
            series : [
              {
                name:'得分',
                type:'bar',
                barWidth: 15,
                /** 从后台拿数据*/
                data:[...this.periodsScore],
              }
            ]
          });
        })
    })
  }
}

const TrendSearchFormUp = Form.create()(React.createClass({
  handleSearch(e) {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['field-5'];
        // const values = {
        //   'field-5': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
        // }
        // console.log('Received values of form: ', values);
        const start = moment(rangeValue[0].format('YYYY-MM-DD'));
        const end = moment(rangeValue[1].format('YYYY-MM-DD'));
        const diff = end.diff(start, 'month') + 1;

        let arr = [];
        let arrTime = [];
        let arrScore = [];
        for(let i = 0; i < diff; i++){
          arr.unshift(moment(rangeValue[1].format('YYYY-MM-DD')).subtract(i, 'month').format('YYYY-MM'));
          arrTime.unshift(Math.floor(Math.random() * 30));
          arrScore.unshift(Math.floor(Math.random() * 100));
        }

        this.props.deviceState.periods = arr;
        this.props.deviceState.periodsTime = arrTime;
        this.props.deviceState.periodsScore = arrScore;

        let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
            
        myChartOne.setOption({
          title : {
            text: '出勤次数',
            textStyle: {
              font: '14px 微软雅黑 Light',               
              color: "#666666"
            }
          },
          tooltip: {
            trigger: 'axis'
          },
          color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
          legend: {
            orient: 'horizontal',
            x: 'right',
            data:['出勤次数']
          },
          calculable : true,
          xAxis : [
            {
              type : 'category',
              /**此处应该是从外面传来的参数，最近7天 */
              data : [...this.props.deviceState.periods]
            }
          ],
          yAxis : [
            {
              type : 'value',
              splitLine: {
                show: false
              },
            }
          ],
          series : [
            {
              name:'出勤次数',
              type:'bar',
              barWidth: 15,
              /** 从后台拿数据*/
              data:[...this.props.deviceState.periodsTime],
            }
          ]
        });

        let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));

        if( diff === 1 ){
          myChartTwo.setOption({
            title: {
              text: '任务完成率' ,
              textStyle: {
                font: '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {},
            color: ['#74cb62', '#32b3f2', '#8387c3'],
            series: [{
              name:'任务完成率',
              type:'pie',
              selectedMode: 'single',
              radius: ['0', '48%'],
              center: ['50%', '52%'],
              data: [...this.props.deviceState.patrolData],
              itemStyle: {
                emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                },
                normal: {
                  label: {
                    show: true,
                    //position:'inside',
                    formatter: '{b} \n\n {c}个 \n\n({d}%)',
                    textStyle : {
                      fontSize : '14',
                      fontFamily:'幼圆',
                      fontWeight:'bold'
                    }
                  }
                }
                    /*labelLine: { show: true }*/
              },
            }]
          });
        }else {
          myChartTwo.setOption({
            title: {
              text: '任务完成率',
              textStyle: {
                font:  '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {
              trigger: 'axis'
            },
            color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
            legend: {
              orient: 'horizontal',
              x: 'right',
              right: '50px',
              data: ['任务完成率']
            },
            /**网格 */
            grid: {
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true
            },
            xAxis: {
              type: 'category',//category  种类
              boundaryGap: false,
              /*设置此处横的网格线不显示*/ 
              splitLine: {
                show: false
              },
              data: [...this.props.deviceState.periods]
            },
            yAxis: {
              type: 'value',
              splitLine: {
                show: false
              },
            },
            series: [
              {
                name:'任务完成率',
                type:'line',
                data:[...this.props.deviceState.periodsTime]
              }
            ]
          });
        }

        let myChartThree = echarts.init(document.getElementById('DeviceTypeMountEcharts03'));
        myChartThree.setOption({
          title : {
            text: '得分',
            textStyle: {
              font: '14px 微软雅黑 Light',               
              color: "#666666"
            }
          },
          tooltip: {
            trigger: 'axis'
          },
          color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
          legend: {
            orient: 'horizontal',
            x: 'right',
            data:['得分']
          },
          calculable : true,
          xAxis : [
            {
              type : 'category',
              /**此处应该是从外面传来的参数，最近7天 */
              data : [...this.props.deviceState.periods]
            }
          ],
          yAxis : [
            {
              type : 'value',
              splitLine: {
                show: false
              },
            }
          ],
          series : [
            {
              name:'得分',
              type:'bar',
              barWidth: 15,
              /** 从后台拿数据*/
              data:[...this.props.deviceState.periodsScore],
            }
          ]
        });
      });
      message.info('已更新');
    }catch(e) {
      console.log(e)
    }
  },
	onChange(e) {
    const time = e.target.value;
		this.props.deviceState.addPatrolUp(time);
	},
  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
					<Col span={6} key={2}>
						<FormItem>
              <Radio.Group onChange={this.onChange} defaultValue="month">
                <Radio.Button value="month">月</Radio.Button>
                <Radio.Button value="quater">季</Radio.Button>
                <Radio.Button value="year">年</Radio.Button>
              </Radio.Group>
						</FormItem>
					</Col>
          <Col span={6} key={5}>
            <FormItem label={`时间`}>
              {getFieldDecorator(`field-5`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}));

// @observer
const DeviceTrendC = observer(class DeviceTrendC extends Component {
	constructor() {
		super();

		this.state = {
			size: 'default'
		};
	}

	componentDidMount(){
    const id = this.props.params.id;
    window.rpc.user.getArrayByCond({id},0,0).then((result) => {
      const me = {...result[0], attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: result[0].id};
      // console.log(me);
      this.props.deviceState.me = me;
    }, (err) => {
      console.warn(err);
    })
  
		/*图表一*/
		let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
		myChartOne.setOption({
			title : {
				text: '出勤次数',
				textStyle: {
					font: '14px 微软雅黑 Light',               
					color: "#666666"
				}
			},
			tooltip : {
				trigger: 'axis'
			},
			color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
			legend: {
			orient: 'horizontal',
				x: 'right',
				data:['出勤次数']
			},
			calculable : true,
			xAxis : [
				{
					type : 'category',
					/**此处应该是从外面传来的参数，最近7天 */
					data : ['2017-03']
				}
			],
			yAxis : [{
					type : 'value',
					splitLine: {
						show: false
					},
				}
			],
			series : [
				{
					name:'出勤次数',
					type:'bar',
					barWidth: 15,
					/** 从后台拿数据*/
					data:[...this.props.deviceState.patrolData3[0]],
				}
			]
		});

    /*图表二*/
		let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));
		myChartTwo.setOption({
			title: {
				text: '任务完成率' ,
				textStyle: {
					font: '14px 微软雅黑 Light',               
					color: "#666666"
				}
			},
			tooltip: {},
			color: ['#74cb62', '#32b3f2', '#8387c3'],
			series: [{
				name:'任务完成率',
				type:'pie',
				selectedMode: 'single',
				radius: ['0', '48%'],
				center: ['50%', '52%'],
				data: [...this.props.deviceState.patrolData],
				itemStyle: {
					emphasis: {
						shadowBlur: 10,
						shadowOffsetX: 0,
						shadowColor: 'rgba(0, 0, 0, 0.5)'
					},
					normal: {
						label: {
							show: true,
							//position:'inside',
							formatter: '{b} \n\n {c}个 \n\n({d}%)',
							textStyle : {
								fontSize : '14',
								fontFamily:'幼圆',
								fontWeight:'bold'
							}
						}
					}
							/*labelLine: { show: true }*/
				},
			}]
		});

    /*图表三*/
		let myChartThree = echarts.init(document.getElementById('DeviceTypeMountEcharts03'));
    myChartThree.setOption({
			title : {
				text: '得分',
				textStyle: {
					font: '14px 微软雅黑 Light',               
					color: "#666666"
				}
			},
			tooltip : {
				trigger: 'axis'
			},
			color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
			legend: {
			orient: 'horizontal',
				x: 'right',
				data:['得分']
			},
			calculable : true,
			xAxis : [
				{
					type : 'category',
					/**此处应该是从外面传来的参数，最近7天 */
					data : ['2017-03']
				}
			],
			yAxis : [{
					type : 'value',
					splitLine: {
						show: false
					},
				}
			],
			series : [
				{
					name:'得分',
					type:'bar',
					barWidth: 15,
					/** 从后台拿数据*/
					data:[...this.props.deviceState.patrolData3[0]],
				}
			]
		});
  }

	render() {
    let me = {...this.props.deviceState.me};
		return (
			<div className="DeviceTrend">
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/prfrm' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>绩效详情</Link>
          </div>
        </div>
        <Row style={{ padding: '5px 0' }} gutter={16}>
          <Col>
            姓名：{me.name}
          </Col>
        </Row>
				<TrendSearchFormUp deviceState={this.props.deviceState} />
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<Col span={8} style={{ padding: '-2px'}}>
						<Card style={{ margin: '0 40px 0 2px'}}>
						<div id="DeviceTypeMountEcharts01" style={{ height: '50vh', width: '100%' }}></div>
						</Card>
					</Col>
					<Col span={8}>
						<Card>
							<div id="DeviceTypeMountEcharts02" style={{ height: '50vh', width: '100%'}}></div>
						</Card>
					</Col>
					<Col span={8}>
						<Card style={{ margin: '0 40px 0 2px'}}>
						<div id="DeviceTypeMountEcharts03" style={{ height: '50vh', width: '100%'}}></div>
						</Card>
					</Col>
				</Row>
			</div>
		);
	}
})

class PerformanceDetail extends Component {
  componentDidMount() {
  }
  render() {
    return (
      <div className="PerformanceDetail" style={{ padding: 0 }}>
        <DeviceTrendC deviceState={new deviceState()} params={this.props.params} />
      </div>
    );
  }
}

export default PerformanceDetail;