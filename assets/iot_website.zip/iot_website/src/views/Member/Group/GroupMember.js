/*
 * @Author: Han.beibei 
 * @Date: 2017-03-04 15:29:25 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-15 18:02:23
 */

import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message } from 'antd';
import moment from 'moment';
import listStore from '../listStore';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const { genderList, levelList } = listStore;
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

//去重
// function removeDuplicates(arr) {

//   var temp = {}, r = [];

//   for (var i in arr) {
//     temp[arr[i]] = true;
//   }

//   for (var k in temp) {
//     r.push(k);
//   }

//   return r;

// }

//查部门
var groupNames = [{ name: '/' }];

//查组织
var groupownerNames = [{ name: '/' }];


// 初始化mobx设置
class appState {
  // @observable tableData = [];
  // @observable selectId = null;
  // @observable selectIdOne = null;
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      selectIdOne: null
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {

      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    })

    window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {

        for (let value of result) {
          groupownerNames[value.id] = value;
        }
        sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
        // })
        //console.log(groupownerNames);
      }, (err) => {
        console.warn(err);
      })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const level = fieldsValue['level'];
        const groupId = fieldsValue['groupId'];
        const ownerId = fieldsValue['ownerId'];
        const gender = fieldsValue['gender'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (level) {
          values = { ...values, level: fieldsValue['level'].map(x => parseInt(x, 10)) }
        }
        if (groupId) {
          values = { ...values, groupId: fieldsValue['groupId'].map(x => parseInt(x, 10)) }
        }
        if (ownerId) {
          values = { ...values, ownerId: fieldsValue['ownerId'].map(x => parseInt(x, 10)) }
        }
        if (gender) {
          values = { ...values, gender: fieldsValue['gender'].map(x => parseInt(x, 10)) }
        }
        if (rangeValue) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        //console.log('Received values of form: ', values);

        window.rpc.user.getArrayByContainer(values, 0, 0).then((result) => {
          //console.log(values);
          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
          this.props.appState.tableData = users;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let levelChildren = [];
    let groupIdChildren = [];
    let ownerIdChildren = [];
    let genderChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={3} key={2}>
            <FormItem label={`性别`}>
              {getFieldDecorator(`gender`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {genderChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={3}>
            <FormItem label={`等级`}>
              {getFieldDecorator(`level`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={4}>
            <FormItem label={`部门`}>
              {getFieldDecorator(`groupId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {groupIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          {/*<Col span={3} key={5}>
            <FormItem label={`公司`}>
              {getFieldDecorator(`ownerId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {ownerIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>*/}
          <Col span={6} key={6}>
            <FormItem label={`加入时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);


const StaffC = observer(class StaffC extends Component {
  componentDidMount() {
    window.rpc.user.getArray(0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      this.props.appState.tableData = users;
    }, (err) => {
      console.warn(err);
    })

  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      //console.log('Received values of form: ', values);
    });
  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
  };
  handleChange = (pagination, filters, sorter) => {
    //console.log('Various parameters', pagination, filters, sorter);
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }

  handleStaff = () => {
    //console.log(this.props.appState.selectId);
    if (this.props.appState.selectId != null) {
      browserHistory.push(`/memb/staff/edit/${this.props.appState.selectId}`);
    } else {
      message.info('请选择人员！');
    }

  }
  //人员详情跳转
  handleStaffOne = () => {
    if (this.props.appState.selectId != null) {
      browserHistory.push(`/memb/staff/detail/${this.props.appState.selectIdOne}`);
    } else {
      message.info('请选择人员！');
    }
  }
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    //filteredInfo = filteredInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
      sorter: (a, b) => a.number - b.number,
      sortOrder: sortedInfo.columnKey === 'number' && sortedInfo.order,
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/memb/staff/detail/${record.key}`}>详情</Link>
          <span className="ant-divider" />
          <Link to={`/memb/staff/edit/${record.key}`}>编辑</Link>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];

    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        // console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        //console.log('Current: ', current);
      },
    };

    //表格单选框设置
    const rowSelection = {
      type: 'radio',
      onChange: (selectedRowKeys, selectedRows) => {
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
        this.props.appState.selectIdOne = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (

      <div className="ConcenHistory" style={{ padding: 0 }}>
        <div style={{ height: 35, paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>部门人员</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }}>
            <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to="/memb/staff/new">新增人员</Link></Button>
            <Button style={{ marginLeft: 5, float: 'left', background: '#d9dee4',  padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaff} >编辑人员</Button>
            <Button style={{ marginLeft: 5, float: 'left', background: '#d9dee4',  padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaffOne} >人员详情</Button>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        {/*<Row style={{ padding: '5px 0 15px', marginTop: '20px' }}>
          <Col span={24} >
            <Button type="primary" style={{ marginRight: '20px' }}><Link to="/memb/staff/new">新增人员</Link></Button>
            <Button type="" style={{ marginRight: '20px' }} onClick={this.handleStaff}>编辑人员</Button>
            <Button type="" style={{ marginRight: '20px' }} onClick={this.handleStaffOne}>人员详情</Button>
          </Col>
        </Row>*/}
        <Row style={{ marginTop: 20 }}>
          <Col span={24}>
            <Table
              //bordered
              style={{ color: '#999' }}
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class Staff extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default Staff;