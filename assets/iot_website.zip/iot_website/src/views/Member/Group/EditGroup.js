/*
 * @Author: xmj 
 * @Date: 2017-03-04 09:34:59 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-05-19 14:56:48
 */
import React from 'react';
import { Form, Input, Button, Row, Col, message, Select } from 'antd';
import { Link, browserHistory } from 'react-router';
import listStore from '../listStore';

const FormItem = Form.Item;
const Option = Select.Option;
// 取出等级
//let levels = JSON.parse(sessionStorage.getItem('grouplevels'))|| [];

//结构出参量表
const { levelList } = listStore;

const EditGroup = Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true
    };
  },
  componentWillMount() {
    //console.log(this.props)
    const id = parseInt(this.props.params.id, 10);
    window.rpc.group.getInfoById(id).then((result) => {
      //console.log(result);
      this.props.form.setFieldsValue({
        name: result.name,
        remark: result.remark,
        level: levelList[result.level],
      });
    }, (err) => {
      console.warn(err);
    })
  },
  handleSubmit(e) {
    e.preventDefault();
    const id = parseInt(this.props.params.id, 10);
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let { name, remark, level } = values;
        if (isNaN(level)) {
          level = levelList.indexOf(level);
        }
        let obj = { name, remark, level: parseInt(level, 10) };

        //console.log(obj, level);
        window.rpc.group.setInfoById(id, obj).then(() => {
          message.info('修改成功！');
          browserHistory.push('/memb/group');
        }, (err) => {
          console.log(err);
        })
      }
    });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    // const tailFormItemLayout = {
    //   wrapperCol: {
    //     span: 14,
    //     offset: 6,
    //   },
    // };
    let levelChildren = [];
    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }

    return (
      <Form onSubmit={this.handleSubmit} layout="inline">
        <Row style={{ marginTop: 80 }}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="名称："
              hasFeedback
            >
              {getFieldDecorator('name', {
                rules: [{ required: true, message: '请输入名称!' }],
              })(
                <Input style={{ width: 180 }} />
                )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="等级："
              hasFeedback
            >
              {getFieldDecorator(`level`)(
                <Select style={{ width: 180 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginTop: 20 }}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="备注："
              hasFeedback
            >
              {getFieldDecorator('remark')(
                <Input style={{ width: 180 }} />
              )}
            </FormItem>
          </Col>
          <Col span={6}>

          </Col>
        </Row>


        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 10 }}>

          <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontFamily: '微软雅黑', fontSize: '14px', borderRadius: '5px', float: 'left', marginRight: 10 }}>保存</Button>
          <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', float: 'left' }}><Link to="/memb/group">返回</Link></Button>

        </Row>
      </Form>
    );
  },
}));

export default EditGroup;


