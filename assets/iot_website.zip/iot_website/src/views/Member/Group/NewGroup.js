/*
 * @Author: xmj 
 * @Date: 2017-03-04 09:36:00 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-05-19 14:56:30
 */

import React, { Component } from 'react';
import { Form, Input, Button, Row, Col, message, Select } from 'antd';
import { Link, browserHistory } from 'react-router';
import listStore from '../listStore';
// import moment from 'moment';  
const FormItem = Form.Item;
const Option = Select.Option;

// 取出等级
//let levels = JSON.parse(sessionStorage.getItem('grouplevels'))|| [];
//结构出参量表
const { levelList } = listStore;

const NewGroupMes = Form.create()(React.createClass({
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
        let { name, level, remark } = values;
        let obj = { name, level: parseInt(level, 10), remark };
        window.rpc.group.create(obj).then(() => {
          message.info('创建成功！')
          browserHistory.push('/memb/group');
        }, (err) => {
          console.log(err);
        })
      }
    });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 3 },
      wrapperCol: { span: 14 },
    };
    // const tailFormItemLayout = {
    //   wrapperCol: {
    //     span: 14,
    //     offset: 6,
    //   },
    // };

    let levelChildren = [];
    // let res=[];
    // let json = {};
    // for (let i = 0; i < levels.length; i++) {
    //   if (!json[levels[i].level]) {
    //     res.push(levels[i]);
    //     json[levels[i].level] = 1;
    //   }
    // }
    // for(let value of res) {
    //   if (value && value.id) {
    //     levelChildren.push(<Option key={`${value.level}`}>{value.level}</Option>)
    //   }
    // }
    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={i}>{levelList[i]}</Option>)
    }

    return (
      <Form onSubmit={this.handleSubmit} style={{ marginTop: -4, paddingTop: 30 }}>
        <Row style={{ marginBottom: 0 }}>
          <Col span={10}>
            <FormItem
              {...formItemLayout}
              label="名称："
              hasFeedback
            >
              {getFieldDecorator('name', {
                rules: [{ required: true, message: '请输入名称!' }],
              })(
                <Input style={{ height: 30, width: 250 }} placeholder="请输入" rows={1} />
                )}
            </FormItem>
          </Col>
          <Col span={10}>
            <FormItem
              {...formItemLayout}
              label="等级:"
              hasFeedback
            >,
              {getFieldDecorator(`level`)(
                <Select style={{ width: 180 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginBottom: 0 }}>
          <Col span={10}>
            <FormItem
              {...formItemLayout}
              label="备注:"
              hasFeedback
            >
              {getFieldDecorator('remark')(
                <Input style={{ height: 30, width: 250 }} placeholder="请输入" rows={1} />
              )}
            </FormItem>
          </Col>
          <Col span={10}>
          </Col>
        </Row>
        <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />

          <Row style={{ margin: '10px 0',position: 'absolute', bottom: 10}}>

          <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontFamily: '微软雅黑', fontSize: '14px', borderRadius: '5px', float: 'left', marginRight: 10 }}>提交</Button>
          <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', float: 'left' }}><Link to="/memb/group">返回</Link></Button>

        </Row>
      </Form>
    );
  }
}));

class NewGroup extends Component {
  render() {
    return (
      <div className="NewGroup">
        <NewGroupMes />
      </div>
    );
  }
}

export default NewGroup;