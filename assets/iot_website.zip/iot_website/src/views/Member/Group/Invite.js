/*
 * @Author: xmj 
 * @Date: 2017-03-04 09:35:43 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-05-24 16:01:50
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { observable } from 'mobx';
import { observer } from 'mobx-react';

import { Form, Select, Button, Row, Col } from 'antd';
const FormItem = Form.Item;
const Option = Select.Option;
import './invite.css';

class inviteState {
  @observable tableDate = '';
  @observable group = [];
  @observable groupChildren = [];
}

class App extends React.Component {
  state = {
    group: []
  }
  handleSubmit = (e) => {
    e.preventDefault();
    const getRegisterToken = (config) => {
      return window.rpc.owner.buildRegisterToken(config);
    };

    const init = async (config) => {
      try {
        const result = await getRegisterToken(config);
        this.props.inviteState.tableDate = result;
      } catch (err) {
        console.log(err);
      }
    }

    this.props.form.validateFields((err, values) => {
      if (!err) {
        // console.log('Received values of form: ', values);
        init(values);
      }
    });
  }
  handleSelectChange = value => {
    // console.log(value);
    // this.props.form.setFieldsValue({
    //   note: `Hi, ${value === 'male' ? 'man' : 'lady'}!`,
    // });
  }
  componentDidMount() {
    // console.log(this.props);
    // const id = parseInt(this.props.params.id, 10);
    // window.rpc.group.getInfoById(id).then((result) => {
    window.rpc.group.getArray(0, 0).then((result) => {
      const group = result.map(x => ({ ...x, key: x.id }));
      this.setState({ group });
      this.props.form.setFieldsValue({
        groupId: this.props.params.id,
      });
    }, (err) => {
      console.log(err);
    })

  }
  render() {
    const { getFieldDecorator } = this.props.form;
    const options = this.state.group.map(d => <Option key={`${d.id}`} value={`${d.id}`}>{d.name}</Option>);
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 2 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };

    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem
          label="选择部门："
          {...formItemLayout}
          style={{margin: '10px 0'}}
        >
          {getFieldDecorator('groupId', {
            rules: [{ required: true, message: '请选择组织!' }],
            onChange: this.handleSelectChange,
          })(
            <Select style={{ width: 180, height: 20 }}>
              {options}
            </Select>
            )}
        </FormItem>
        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 30, left: 314 }}>
          <Col span={20}></Col>
          <Col span={4}>
            <Row style={{ margin: '0' }}>
              <Col span={6}></Col>
              <Col span={9}>
                <FormItem>
                  <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontFamily: '微软雅黑', fontSize: '14px', borderRadius: '5px', position: 'absolute', right: 10 }}>生成二维码</Button>
                </FormItem>
              </Col>
              <Col span={9}>
                <FormItem>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px' }}><Link to="/memb/group">返回</Link></Button>
                </FormItem>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedApp = Form.create()(App);

class QrCode extends React.Component {
  render() {
    return (
      <div style={{marginLeft:1}}>
        <img src={`http://s.jiathis.com/qrcode.php?url=http://iot.lszpcn.com/register/${this.props.id}`} alt="qrcode" style={{ visibility: this.props.id ? 'visible' : 'hidden' }} />
      </div>
    );
  }
}

// @observer
const InviteC = observer(class InviteC extends Component {
  render() {
    return (
      <div className="Invite" style={{ padding: 0 }}>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>邀请注册</Link>
          </div>
        </div>
        <WrappedApp inviteState={this.props.inviteState} params={this.props.params} />
        <div style={{ padding: '0 0 0 4px', visibility: this.props.inviteState.tableDate ? 'visible' : 'hidden' }}>
          {`注册地址: http://iot.lszpcn.com/register/${this.props.inviteState.tableDate}`}
        </div>
        <QrCode id={this.props.inviteState.tableDate} style={{ visibility: this.props.inviteState.tableDate ? 'visible' : 'hidden' }} />
      </div>
    )
  }
})

class Invite extends Component {
  render() {
    return (
      <InviteC inviteState={new inviteState()} params={this.props.params} />
    );
  }
}

export default Invite;