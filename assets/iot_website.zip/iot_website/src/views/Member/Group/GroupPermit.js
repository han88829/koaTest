import React, { Component } from 'react';
//import {Link,Button} from 'antd';
import {  Button,Icon} from 'antd';
import './GroupPermit.css';
class GroupPermit extends Component {
  constructor() {
    super();
    this.state = {
      groupNames:[],
      ownerName:'',
      flag:true
    };
  }
 // componentDidMount()
  componentWillMount(){
    window.rpc.user.getInfo().then(res=>{

      //console.log(res)
      window.rpc.owner.getInfoById(res.ownerId).then(result=>{
        console.log(result.name) ;
        this.setState({ownerName:result.name});
      },err=>{
        console.log(err)
      })
      window.rpc.group.getArrayByContainer({ownerId:res.ownerId},0,0).then(data=>{
        //console.log(data)
        let names=data.map(x=>({...x})).filter(x=>x.name);
        console.log(names);
         this.setState({groupNames:names,flag:false});
      },err=>{
          console.log(err)
      })
    },err=>{
      console.log(err)//position:'absolute',top:"286px",
    })
  
  }
  render() {
    let len=this.state.groupNames.length;
    let padding=(300-8*len)/(len-1);
    return (
      <div className="GroupPermit">
        <div 
           style={{ 
             height: 35,
             paddingBottom: '1.125rem', 
             color: '#333', fontSize: '0.75rem',
             fontFamily: '苹方中等', 
             borderBottom: '#ddd 1px solid',
             marginBottom: 20 
            }}
         >
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <a href="" style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>部门结构</a>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }}>
            <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }}>
              <a href="">组织架构</a>
            </Button>
          </div>
        </div>
        <div style={{marginTop:20}}>
          <p className="title"  style={{position:'relative',paddingLeft:68,marginBottom: 20}}>
            组织架构    
          </p> 
          <div className="PermitContent" style={{overflow:'hidden',paddingTop:20,}}>
            <div style={{display:this.state.flag?'none':'block',textAlign:'center'}}><span><Icon style={{fontSize:20}} type="frown-o"/>{this.state.ownerName}账户暂未提供组织架构信息</span></div>
            <div className="PermitContentPlay" style={{display:this.state.flag?'block':'none'}}> 
                <div className="totalLeft" style={{float:'left',fontSize:12,position:'relative'}}>
               <span  style={{paddingRight:50,paddingLeft:30, display: 'inline-block',marginTop: 293}}>{this.state.ownerName}</span>
            </div>
             <div className="everyRight" style={{float:'left',fontSize:12,position:'relative' }}>
               {this.state.groupNames.map((x,index)=>(
                 <div key={index} className="portion" style={{paddingTop:index==0?0:`${padding}px`,paddingBottom:index==(len-1)?0:`${padding}px`,paddingLeft:38}}>
                   <span>{x.name}</span>
                 </div>
               ))}
             </div>  
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default GroupPermit;