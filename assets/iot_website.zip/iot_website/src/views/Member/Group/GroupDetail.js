/*
 * @Author: xmj 
 * @Date: 2017-03-04 09:35:15 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-05-04 09:34:43
 */

import React from 'react';
import { Form, Input, Button, Row, Col} from 'antd';
import { Link} from 'react-router';
import listStore from '../listStore';

const FormItem = Form.Item;

//结构出参量表
const { levelList } = listStore;

const GroupDetail = Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true
    };
  },
  componentWillMount() {
    //console.log(this.props)
    const id = parseInt(this.props.params.id, 10);
    window.rpc.group.getInfoById(id).then((result) => {
      //console.log(result);
      this.props.form.setFieldsValue({
        name: result.name,
        remark: result.remark,
        level: levelList[result.level],
      });

      const group = { ...result, name: result.name };
      this.setState({ group });
    }, (err) => {
      console.warn(err);
    })
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    // const tailFormItemLayout = {
    //   wrapperCol: {
    //     span: 14,
    //     offset: 6,
    //   },
    // };

    return (
      <Form layout="inline">
        <Row style={{ marginTop: 80 }}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="名称："
              hasFeedback
            >
              {getFieldDecorator('name')(
                <Input style={{ width: 180 }} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="等级："
              hasFeedback
            >
              {getFieldDecorator('level')(
                <Input style={{ width: 180 }} disabled />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ marginTop: 20 }}>
          <Col span={6}>
            <FormItem
              {...formItemLayout}
              label="备注："
              hasFeedback
            >
              {getFieldDecorator('remark')(
                <Input style={{ width: 180 }} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={6}>

          </Col>
        </Row>
    
          <Row style={{ margin: '10px 0',position: 'absolute', bottom: 10}}>
          <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', float: 'left' }}><Link to="/memb/group">返回</Link></Button>

        </Row>
      </Form>
    );
  },
}));

export default GroupDetail;



