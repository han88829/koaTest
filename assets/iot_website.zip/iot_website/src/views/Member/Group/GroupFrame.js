
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message } from 'antd';
import moment from 'moment';
import listStore from '../listStore';
//import './groupManage.css';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;


// 设置message消息
message.config({
  top: 216,
  duration: 2
})

//结构出参量表
const { levelList } = listStore;



// 初始化mobx设置
class appState {
  // @observable tableData = [];
  // @observable selectId = null;
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      // selectIdOne: null
    })
  }
}

/*class AdvancedSearchForm extends React.Component {
  componentDidMount() {
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const createTime = fieldsValue['createTime'];
        //const registeredTime = fieldsValue['registeredTime'];
        const name = fieldsValue['name'];
        const ownerId = fieldsValue['ownerId'];
        //const location = fieldsValue['location'];
        const level = fieldsValue['level'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (ownerId) {
          values = { ...values, ownerId: fieldsValue['ownerId'].map(x => parseInt(x, 10)) }
        }
        if (level) {
          values = { ...values, level: fieldsValue['level'].map(x => parseInt(x, 10)) }
        }
        if (createTime) {
          values = { ...values, createTime: [new Date(createTime[0].format('YYYY-MM-DD')), new Date(createTime[1].format('YYYY-MM-DD'))] }
        }
        console.log('Received values of form: ', values);

        window.rpc.group.getArrayBriefByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let groups = result.map((x) => ({ ...x, key: x.id, level: levelList[x.level], ownerId: x.ownerId, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          this.props.appState.tableData = groups;

        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    // let levels = JSON.parse(sessionStorage.getItem('grouplevels')) || [];
    let ownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let levelChildren = [];
    let ownerNameChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of ownerNames) {
      if (value && value.id) {
        ownerNameChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 180 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`等级`}>
              {getFieldDecorator(`level`)(
                <Select multiple style={{ width: 180 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`户籍`}>
              {getFieldDecorator(`ownerId`)(
                <Select multiple style={{ width: 180 }} placeholder="请选择">
                  {ownerNameChildren}
                </Select>
              )}
            </FormItem>
          </Col>

          <Col span={6} key={4}>
            <FormItem label={`创建时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={5}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);*/


const GroupManageC = observer(class GroupManageC extends Component {
  state = {
    //filteredInfo: null,
    sortedInfo: null,
  };
  handleChange = (pagination, filters, sorter) => {
    console.log('Various parameters', pagination, filters, sorter);
    this.setState({
      sortedInfo: sorter,
    });
  }
  clearAll = () => {
    this.setState({
      //filteredInfo: null,
      sortedInfo: null,
    });
  }

  componentDidMount() {
    window.rpc.group.getArrayBriefByContainer(null, 0, 0).then((result) => {
      //console.table(levels)
      let groups = result.map((x) => ({ ...x, key: x.id, level: levelList[x.level], remark: x.remark, ownerName: x.ownerName, createTime: moment(x.registerTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = groups;
    }, (err) => {
      console.warn(err);
    })

  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }
  
  
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    //filteredInfo = filteredInfo || {};
    const columns = [
      {
        title: '序号',
        dataIndex: 'id',
        key: 'id',
        sorter: (a, b) => a.id - b.id,
        sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
        render: text => <span>{text}</span>,
      },
      { title: '名称', dataIndex: 'name', key: 'name' },
      { title: '等级', dataIndex: 'level', key: 'level' },
      { title: '部门', dataIndex: 'ownerName', key: 'ownerName' },
      { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '备注', dataIndex: 'remark', key: 'remark' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/memb/frame/set/${record.key}`}>数据权限</Link>
            <span className="ant-divider" />
            <Link to={`/memb/group/permission/${record.key}`}>菜单权限</Link>
          </span>
        )
      },
    ];
    const data = [...this.props.appState.tableData];

    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };

    //表格单选框设置
    const rowSelection = {
      type: 'radio',
      onChange: (selectedRowKeys, selectedRows) => {
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
        this.props.appState.selectIdOne = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (

      <div className="ConcenHistory">
        <div style={{ fontSize: '0.75em', height: 35, paddingBottom: '1.125em', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/group' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>部门权限</Link>
          </div>
         
        </div>
        {/*<WrappedAdvancedSearchForm appState={this.props.appState} style={{ width: '80%', textAlign: 'center' }} />*/}

        <Row style={{ padding: '5px 0 0', marginTop: 10 }}>
          <Col span={24}>
            <Table
              //bordered
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class GroupFrame extends Component {
  render() {
    return (
      <GroupManageC appState={new appState()} />
    )
  }
}

export default GroupFrame;