/*
 * @Author: Han.beibei 
 * @Date: 2017-04-06 09:35:10 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 11:27:40
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { Form, Input, Row, Col, Card, Progress, Icon, Modal, Button, message } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import moment from 'moment';
import $ from 'jquery';

const FormItem = Form.Item;

import logo from '../../assets/images/account/big-img.png';
import qqq from '../../assets/images/account/qqq.png';
import bad from '../../assets/images/account/bad.png';
import suss from '../../assets/images/account/suss.png';
import man from '../../assets/images/account/man.png';
import logoOne from '../../assets/images/account/logo.png';
import android from '../../assets/images/account/android.png';
import apple from '../../assets/images/account/apple.png';

class appState {
  constructor() {
    extendObservable(this, {
      src: { qqq },
    })
  }
}
class ModalImg extends Component {
  //图片上传
  componentWillMount() {
    let id = null;
    window.rpc.user.getInfo().then((result) => {
      id = result.id;
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
    window.rpc.upload.images.getDefaultConfig().then((res) => {
      //console.info($("#staffUser"));
      let { domain, uptoken } = res;
      window.Qiniu.uploader({
        runtimes: 'html5,flash,html4',    //上传模式,依次退化
        browse_button: 'upload',       //上传选择的点选按钮，**必需**
        // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
        uptoken: uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
        //unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
        //save_key: true,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
        domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
        // domain: `http://omdwajej6.bkt.clouddn.com/`,
        get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
        // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
        max_file_size: '5mb',           //最大文件体积限制
        unique_names: true,
        multi_selection: false,
        // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
        max_retries: 3,                   //上传失败最大重试次数
        // dragdrop: true,                   //开启可拖曳上传
        // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
        chunk_size: '4mb',                //分块上传时，每片的体积
        auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
        filters: {
          max_file_size: '5mb',
          prevent_duplicates: true,
          // Specify what files to browse for
          mime_types: [
            { title: "Image files", extensions: "jpg,gif,png" }, // 限定jpg,gif,png后缀上传
          ]
        },
        init: {
          'FilesAdded': function (up, files) {
            //plupload.each(files, function (file) {
            // 文件添加进队列后,处理相关的事情
            //});
          },
          'BeforeUpload': function (up, file) {
            // 每个文件上传前,处理相关的事情
            $("#seeImgEdit").attr({ "src": '' }).css("display", "inline");
          },
          'UploadProgress': function (up, file) {
            // 每个文件上传时,处理相关的事情
          },
          'FileUploaded': function (up, file, info) {
            let domain = up.getOption('domain');
            let res = JSON.parse(info);
            var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
            console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
            var asc = sourceLink;
            $("#uploadSuess").attr('src', asc)
          },
          'Error': function (up, err, errTip) {
            //上传出错时,处理相关的事情
            $('#suess').html('上传失败，请稍后重试！');
          },
          'UploadComplete': function () {
            //队列文件处理完毕后,处理相关的事情
            var offer = true;
            $('#upload').html('重新选择');
            $('#suess').html('取消上传');
            if ($('#suess').html('取消上传') === '取消上传' && !$("#uploadSuess").attr('src')) {
              $('#suess').html('网络出错，请重新上传！')
            }
            if (offer) {
              $('#suess').click(function () {
                $('#upload').html('请上传图片');
                $('#suess').html('');
                $("#uploadSuess").attr('src', null)
                offer = false;
              })
            }
          },
          'Key': function (up, file) {
            // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
            // 该配置必须要在 unique_names: false , save_key: false 时才生效
            var key = `user-${id}`;
            // do something with key here
            return key
          }
        }
      });
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  handleUl() {
    let Img = $(".safeUl li img").eq(0).attr("src")
    $('#img').attr('src', Img)
  }
  handleUl1() {
    let Img = $(".safeUl li img").eq(1).attr("src")
    $('#img').attr('src', Img)
  }
  handleUl2() {
    let Img = $(".safeUl li img").eq(2).attr("src")
    $('#img').attr('src', Img)
  }
  handleUl3() {
    let Img = $(".safeUl li img").eq(3).attr("src")
    $('#img').attr('src', Img)
  }
  handleUl4() {
    let Img = $(".safeUl li img").eq(4).attr("src")
    $('#img').attr('src', Img)
  }
  handleEdit() {
    $(".upload_title").css('border-top', '2px solid #1086ee').css('line-height', '28px');
    $(".upload_title_one").css('border-top', '1px solid #dddddd').css('line-height', '30px');
    $(".Img_edit").css('display', 'block');
    $(".Img_upload").css('display', 'none');
  }
  handleEditOne() {
    $(".upload_title_one").css('border-top', '2px solid #1086ee').css('line-height', '28px');
    $(".upload_title").css('border-top', '1px solid #dddddd').css('line-height', '30px');
    $(".Img_edit").css('display', 'none');
    $(".Img_upload").css('display', 'block').css('margin-top', '20px');
  }
  render() {
    return (
      <div>
        <div>
          <div className="upload_title" onClick={this.handleEdit}>个性头像编辑</div>
          <div className="upload_title_one" onClick={this.handleEditOne}>本地头像上传</div>
          <div className="upload_hr"></div>
          <div className="Img_edit" style={{ display: 'block' }}>
            <div style={{ height: 50, lineHeight: '50px' }}>从以下头像库里选择一张作为头像</div>
            <ul className="safeUl">
              <li><img src={man} onClick={this.handleUl} style={{ width: 95, height: 95 }} alt="" /></li>
              <li><img src={logoOne} onClick={this.handleUl1} style={{ width: 95, height: 95 }} alt="" /></li>
              <li><img src={logo} onClick={this.handleUl2} style={{ width: 95, height: 95 }} alt="" /></li>
              <li><img src={android} onClick={this.handleUl3} style={{ width: 95, height: 95 }} alt="" /></li>
              <li><img src={apple} onClick={this.handleUl4} style={{ width: 95, height: 95 }} alt="" /></li>
            </ul>
            <div style={{ float: 'left', marginTop: 20, marginLeft: 30, textAlign: 'center' }}>
              <img id="img" src='' style={{ width: 95, height: 95 }} alt="" />
              <br />
              <span style={{}}>头像预览</span>
            </div>
          </div>
          <div className="Img_upload" style={{ display: 'block', marginTop: 300 }}>
            <Button id="upload">
              <Icon type="upload" /> 请上传照片!
            </Button><br />
            <div id="suess" style={{ cursor: 'pointer', }}>支持扩展名 .jpg.png</div><br />
            <img src="" alt="" id="uploadSuess" />
          </div>
        </div>
      </div>

    )
  }
}

const StaffC = observer(Form.create()(React.createClass({
  getInitialState() {
    return {
      visible: false,
      src: { qqq },
      users: [],
      createTime: null,
      mobile: null,
      mobileColor: null,
      emailColor: null,
      number: 1,
      visiblePassword: false,
      visibleMobile: false,
      visibleEmail: false,
      visibleQuestion: false,
      visibleLast: false,
    };
  },
  componentDidMount() {
    //查用户信息
    window.rpc.user.getInfo().then((result) => {
      let createTime = moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString
      let a = 0, b = 0, c = 0, d = 0, e = 0;
      result.email ? b = 1 : b = 0;
      result.mobile ? c = 1 : c = 0;
      a = b + c + d + e;
      let mobileOne = result.mobile ? result.mobile.split("") : " ";
      if (mobileOne.length > 9) {
        for (let i = 3; i < 7; i++) {
          mobileOne[i] = "*";
        }
      }
      this.setState({
        users: result,
        createTime: createTime,
        mobile: result.mobile ? mobileOne.join("") : "",
        mobileColor: result.mobile ? 'green' : 'red',
        emailColor: result.email ? 'green' : 'red',
        number: (a + 1) / 5 * 100,
      })
    }, (err) => {
      console.warn(err); function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  },
  //modal 
  showModal() {
    this.setState({
      visible: true,
    });
  },
  handleOk(e) {
    //console.log(e);
    this.setState({
      visible: false,
    });
    let img = $('#img').attr('src') ? $('#img').attr('src') : $("#uploadSuess").attr('src');
    let obj = { image: img };
    if (img) {
      window.rpc.user.setInfo(obj).then(() => {
        console.log(obj)
        message.info('修改成功！');
        if ($('#img').attr('src')) {
          $("#logo").attr("src", $('#img').attr('src'))
          setTimeout(() => {
            $('#img').attr('src', '')
          }, 0)
        } else if ($('#uploadSuess').attr('src')) {
          $("#logo").attr("src", $('#uploadSuess').attr('src'))
          setTimeout(() => {
            $('#uploadSuess').attr('src', '')
          }, 0)
        }
      }, (err) => {
        console.log(err);
      })
    } else {

    }
  },
  handleCancel(e) {
    //console.log(e);
    this.setState({
      visible: false,
    });
  },
  callback(key) {
    console.log(key);
  },
  // 修改密码
  showModalPassword() {
    this.setState({
      visiblePassword: true,
    });
  },
  handleOkPassword(e) {
    let id = this.state.users.id;
    let obj = { password: document.getElementById("password").value };
    if (document.getElementById("password").value) {
      window.rpc.user.setInfoById(id, obj).then(() => {
        message.info('修改成功！')
        //查用户信息
        window.rpc.user.getInfo().then((result) => {
          let createTime = moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString
          let a = 0, b = 0, c = 0, d = 0, e = 0;
          result.email ? b = 1 : b = 0;
          result.mobile ? c = 1 : c = 0;
          a = b + c + d + e;
          let mobileOne = result.mobile.split("");
          for (let i = 3; i < 7; i++) {
            mobileOne[i] = "*";
          }
          this.setState({
            users: result,
            createTime: createTime,
            mobile: mobileOne.join(""),
            mobileColor: result.mobile ? 'green' : 'red',
            emailColor: result.email ? 'green' : 'red',
            number: (a + 1) / 5 * 100,
          })
          document.getElementById("password").value = null;
          this.setState({
            visiblePassword: false,
          });
        }, (err) => {
          console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })

      }, (err) => {
        console.log(err);
      })
    } else {
      message.info("请输入密码！")
    }

  },
  handleCancelPassword(e) {
    //console.log(e);
    this.setState({
      visiblePassword: false,
    });
  },
  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },
  checkPassword(rule, value, callback) {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('两次输入的密码不一致!');
    } else {
      callback();
    }
  },
  checkConfirm(rule, value, callback) {
    const form = this.props.form;
    if (value && this.state.passwordDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  },
  // checkPasswordOld(rule, value, callback) {
  //   const form = this.props.form;
  //   if (value && value !== this.state.users.password) {
  //     callback('请输入正确的原密码!');
  //   } else {
  //     callback();
  //   }
  // },

  // 绑定手机
  showModalMobile() {
    this.setState({
      visibleMobile: true,
    });
  },
  handleOkMobile(e) {
    let id = this.state.users.id;
    let obj = { mobile: document.getElementById("mobile").value };
    var regex = /^((\+)?86|((\+)?86)?)0?1[3578]\d{9}$/;
    if (regex.test(document.getElementById("mobile").value)) {
      window.rpc.user.setInfoById(id, obj).then(() => {
        message.info('修改成功！')
        //查用户信息
        window.rpc.user.getInfo().then((result) => {
          let createTime = moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString
          let a = 0, b = 0, c = 0, d = 0, e = 0;
          result.email ? b = 1 : b = 0;
          result.mobile ? c = 1 : c = 0;
          a = b + c + d + e;
          let mobileOne = result.mobile.split("");
          for (let i = 3; i < 7; i++) {
            mobileOne[i] = "*";
          }
          this.setState({
            users: result,
            createTime: createTime,
            mobile: mobileOne.join(""),
            mobileColor: result.mobile ? 'green' : 'red',
            emailColor: result.email ? 'green' : 'red',
            number: (a + 1) / 5 * 100,
          })

        }, (err) => {
          console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
        document.getElementById("mobile").value = null;
        this.setState({
          visibleMobile: false,
        });
      }, (err) => {
        console.log(err);
      })
    } else {
      message.info("请输入电话号码！")
    }
  },
  handleCancelMobile(e) {
    //console.log(e);
    this.setState({
      visibleMobile: false,
    });
  },
  //验证手机号
  checkAccount(rule, value, callback) {
    //const form = this.props.form;
    var regex = /^0\d{2,3}-?\d{7,8}$|^((\+)?86|((\+)?86)?)0?1[3578]\d{9}$/;
    if (regex.test(value)) {
      callback();
    } else {
      callback('请输入正确的电话号码！');
    }
  },

  //邮箱修改
  showModalEmail() {
    this.setState({
      visibleEmail: true,
    });
  },
  handleOkEmail(e) {
    let id = this.state.users.id;
    let obj = { email: document.getElementById("email").value };
    let rege = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
    if (rege.test(document.getElementById("email").value)) {
      window.rpc.user.setInfoById(id, obj).then(() => {
        message.info('修改成功！')
        //查用户信息
        window.rpc.user.getInfo().then((result) => {
          let createTime = moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString
          let a = 0, b = 0, c = 0, d = 0, e = 0;
          result.email ? b = 1 : b = 0;
          result.mobile ? c = 1 : c = 0;
          a = b + c + d + e;
          let mobileOne = result.mobile.split("");
          for (let i = 3; i < 7; i++) {
            mobileOne[i] = "*";
          }
          this.setState({
            users: result,
            createTime: createTime,
            mobile: mobileOne.join(""),
            mobileColor: result.mobile ? 'green' : 'red',
            emailColor: result.email ? 'green' : 'red',
            number: (a + 1) / 5 * 100,
          })
        }, (err) => {
          console.warn(err); function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
        document.getElementById("email").value = null;
        this.setState({
          visibleEmail: false,
        });
      }, (err) => {
        console.log(err);
      })
    } else {
      message.info("请输入正确的邮箱号！")
    }
  },
  handleCancelEmail(e) {
    //console.log(e);
    this.setState({
      visibleEmail: false,
    });
  },

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 12 },
      wrapperCol: { span: 12 },
    };
    return (
      <div className="Real">
        <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>安全设置</Link>
        </div> <br />
        <div style={{ marginTop: 10 }}>
          <Card style={{ width: '100%' }}>
            <div style={{ float: 'left', textAlign: 'center' }}>
              <img id="logo" src={this.state.users.image ? this.state.users.image : man} alt="" style={{ width: 150, height: 150, border: '1px solid #cccccc', borderRadius: 80 }} />
              <p onClick={this.showModal} style={{ color: 'blue', cursor: 'pointer' }}>修改头像</p>
              {/*头像上传修改*/}
              <Modal title="修改头像" visible={this.state.visible}
                onOk={this.handleOk} onCancel={this.handleCancel}
                className="safeTitle"
              >
                <ModalImg />
              </Modal>
            </div>
            <div style={{ width: '80%', float: 'left', marginTop: 30, marginLeft: 30 }}>
              <div>
                登陆账号 ：{this.state.users.username} &nbsp;&nbsp;&nbsp; (<span style={{ color: 'blue', marginLeft: 15, marginRight: 15 }}>您已通过实名认证</span>)
              </div>
              <div style={{ marginTop: 10 }}>
                账号ID ： {this.state.users.id}
              </div>
              <div style={{ marginTop: 10 }}>
                注册时间 ： {this.state.createTime}
              </div>
            </div>
          </Card>
        </div>
        {/*安全程度*/}
        <div style={{ marginTop: 30, height: 50, borderBottom: '1px dashed gray' }}>
          <span>您当前的账号的安全程度</span>&nbsp;&nbsp;&nbsp;
          <Progress strokeWidth={30} percent={this.state.number} style={{ width: '30%' }} />&nbsp;&nbsp;
          <span>安全级别： <span style={{ color: 'red' }}>{this.state.number >= 60 ? '高' : '低'}</span></span>&nbsp;&nbsp;&nbsp;
          <span>建议开启安全产品</span>
        </div>
        {/*登录密码*/}
        <div style={{ marginTop: 30, height: 50, borderBottom: '1px dashed gray' }}>
          <span style={{ marginRight: 50 }}>登录密码</span>
          <span>安全性高的密码可以使账号更安全。建议您顶起更换密码，设置一个包括字幕，符号或者数字中至少两项且长度超过6位的密码</span>
          <span style={{ float: 'right', cursor: 'pointer' }}>
            <span style={{ color: 'green', fontSize: 15, position: 'relative' }}><img src={suss} alt="" style={{ position: 'absolute', arginRight: 10, height: 18, top: 2, left: '-25px' }} />已设置</span>
            <span className="ant-divider" />
            <span style={{ color: 'blue', fontSize: 15 }} onClick={this.showModalPassword}>修改</span>
            <Modal title="修改密码" visible={this.state.visiblePassword}
              onOk={this.handleOkPassword} onCancel={this.handleCancelPassword}
              className="safePass"
            >
              <Form style={{ textAlign: 'center', marginTop: 50 }}>
                <Row style={{ marginLeft: '15%' }}>
                  <Col span={16}>
                    <FormItem
                      {...formItemLayout}
                      label="新密码"
                      hasFeedback
                    >
                      {getFieldDecorator('password', {
                        rules: [{
                          required: true, message: '请输入您的密码!',
                        }, {
                          validator: this.checkConfirm,
                        }],
                      })(
                        <Input type="password" id="passwordOne" style={{ width: 180 }} />
                        )}
                    </FormItem>
                  </Col>
                </Row>
                <Row style={{ marginLeft: '15%' }}>
                  <Col span={16}>
                    <FormItem
                      {...formItemLayout}
                      label="密码确认"
                      hasFeedback
                    >
                      {getFieldDecorator('confirm', {
                        rules: [{
                          required: true, message: '请输入您的密码!',
                        }, {
                          validator: this.checkPassword,
                        }],
                      })(
                        <Input type="password" id="password" onBlur={this.handleConfirmBlur} style={{ width: 180 }} />
                        )}
                    </FormItem>
                  </Col>
                </Row>
              </Form>
            </Modal>
          </span>
        </div>
        {/*手机绑定*/}
        <div style={{ marginTop: 30, height: 50, borderBottom: '1px dashed gray' }}>
          <span style={{ marginRight: 50 }}>手机绑定</span>
          <span>
            {this.state.mobile ? '您已经绑定了手机' : '您未绑定手机，请设置手机号！'}
            <span style={{ color: 'green' }}>&nbsp;&nbsp;{this.state.mobile || ""}&nbsp;&nbsp;</span>
            [您的手机号可以用于登陆、找回密码等]
          </span>
          <span style={{ float: 'right', cursor: 'pointer' }}>
            <span style={{ color: `${this.state.mobile ? "green" : "red"}`, fontSize: 15, position: 'relative' }}>
              <img src={this.state.mobile ? suss : bad} alt="" style={{ position: 'absolute', arginRight: 10, height: 18, top: 2, left: '-25px' }} />
              {this.state.mobile ? '已设置' : '未设置'}
            </span>
            <span className="ant-divider" />
            <span style={{ color: 'blue', fontSize: 15 }} onClick={this.showModalMobile}>{this.state.mobile ? '修改' : '设置'}</span>
            <Modal title="修改绑定电话" visible={this.state.visibleMobile}
              onOk={this.handleOkMobile} onCancel={this.handleCancelMobile}
              className="safePass"
            >
              <Form style={{ textAlign: 'center', marginTop: 50 }}>
                <Row style={{ marginLeft: '15%' }}>
                  <Col span={16}>
                    <FormItem
                      {...formItemLayout}
                      label="电话"
                      hasFeedback
                    >
                      {getFieldDecorator('mobile', {
                        rules: [{
                          required: true, message: '请输入电话号码!',
                        }, {
                          validator: this.checkAccount,
                        }],
                      })(
                        <Input id="mobile" style={{ width: 180 }} />
                        )}
                    </FormItem>
                  </Col>
                </Row>
              </Form>
            </Modal>
          </span>
        </div>
        {/*邮箱*/}
        <div style={{ marginTop: 30, height: 50, borderBottom: '1px dashed gray' }}>
          <span style={{ marginRight: 50 }}>备用邮箱</span>
          <span>绑定备用邮箱后可以用来接受蓝晟控制台发送的各类系统、营销、服务通知等。</span>
          <span style={{ float: 'right', cursor: 'pointer' }}>
            <span style={{ color: `${this.state.users.email ? "green" : "red"}`, fontSize: 15, position: 'relative' }}>
              <img src={this.state.users.email ? suss : bad} alt="" style={{ position: 'absolute', arginRight: 10, height: 18, top: 2, left: '-25px' }} />
              {this.state.users.email ? '已设置' : '未设置'}
            </span>
            <span className="ant-divider" />
            <span style={{ color: 'blue', fontSize: 15 }} onClick={this.showModalEmail}>{this.state.users.email ? '修改' : '设置'}</span>
            <Modal title="修改绑定邮箱" visible={this.state.visibleEmail}
              onOk={this.handleOkEmail} onCancel={this.handleCancelEmail}
              className="safePass"
            >
              <Form style={{ textAlign: 'center', marginTop: 50 }}>
                <Row style={{ marginLeft: '15%' }}>
                  <Col span={16}>
                    <FormItem
                      {...formItemLayout}
                      label="新邮箱："
                      hasFeedback
                    >
                      {getFieldDecorator('email', {
                        rules: [{ type: 'email', required: true, message: '请输入邮箱!' }],
                      })(
                        <Input id="email" style={{ width: 180, color: '#111111', fontSize: 10, fontFamily: '微软雅黑 Light', background: 'none' }} />
                        )}
                    </FormItem>
                  </Col>
                </Row>
              </Form>
            </Modal>
          </span>
        </div>
        {/*密保问题*/}
        <div style={{ marginTop: 30, height: 50, borderBottom: '1px dashed gray' }}>
          <span style={{ marginRight: 50 }}>密保问题</span>
          <span>是您找回登陆密码的方式之一。建议您设置三个容易记住，且最不容易被他人获取的问题及答案，更有效保障您的密码安全。</span>
          <span style={{ float: 'right', cursor: 'pointer' }}>
            <span style={{ color: 'red', fontSize: 15, position: 'relative' }}>
              <img src={bad} alt="" style={{ position: 'absolute', arginRight: 10, height: 18, top: 2, left: '-25px' }} />
              未设置
            </span>
            <span className="ant-divider" />
            <span style={{ color: 'blue', fontSize: 15 }}>设置</span>
          </span>
        </div>
        {/*操作保护*/}
        <div style={{ marginTop: 30, height: 50, borderBottom: '1px dashed gray' }}>
          <span style={{ marginRight: 50 }}>操作保护</span>
          <span>在控制台关键操作（如：释放、修改密码等）时，通过设置保护强度和验证方式再次确认您的身份，进一步提高账号安全性，有效保护您安全是使用平台。</span>
          <span style={{ float: 'right', cursor: 'pointer' }}>
            <span style={{ color: 'red', fontSize: 15, position: 'relative' }}>
              <img src={bad} alt="" style={{ position: 'absolute', arginRight: 10, height: 18, top: 2, left: '-25px' }} />
              未设置
            </span>
            <span className="ant-divider" />
            <span style={{ color: 'blue', fontSize: 15 }}>设置</span>
          </span>
        </div>
      </div>
    );
  }
})))

class Safe extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default Safe;