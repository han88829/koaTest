/*
 * @Author: Han.beibei 
 * @Date: 2017-04-06 09:35:10 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-04-22 15:04:50
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { Card } from 'antd';

import suss from '../../assets/images/account/suss.png';
import man from '../../assets/images/account/head.png';
import tex from '../../assets/images/account/tex.png';
import qqq from '../../assets/images/account/qqq.png';

class Real extends Component {
  state = {
    name: null,
    mobile: null
  }
  componentDidMount() {
    //查用户信息
    window.rpc.user.getInfo().then((result) => {
      let mobileOne = result.mobile ? result.mobile.split("") : " ";
      if (mobileOne.length > 9) {
        for (let i = 3; i < 7; i++) {
          mobileOne[i] = "*";
        }
      }
      this.setState({
        name: result.name,
        //mobile: result.mobile ? mobileOne.join("") : "",
        mobile:result.mobile,
      })
    }, (err) => {
      console.warn(err);
    })
  }
  render() {
    return (
      <div className="Real" style={{ position: 'relative' }}>
        <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>实名认证</Link>
        </div> <br />
        <Card style={{ marginTop: 30 }}>
          <div style={{ position: 'relative' }}>
            <img src={suss} style={{ width: 30, height: 30, position: 'absolute', top: '-2px' }} alt="" />
            <span style={{ marginLeft: 39, fontFamily: '苹方中等', fontSize: '18px', color: '#333744' }}>您已成功通过蓝晟管控平台个人认证</span>
          </div>
          <div style={{ fontFamily: '苹方中等', fontSize: 12, color: '#333744' }}>
            <div style={{ marginTop: 30, marginLeft: 118, float: 'left' }}>认证途径： 微信、QQ等第三方快捷认证</div>
            <div style={{ marginTop: 30, marginLeft: 100, float: 'left' }}>认证手机号码 ： {this.state.mobile}</div><br /><br /><br />
          </div>
          <div style={{ marginLeft: 118, fontFamily: '苹方中等', fontSize: 12, color: '#333744' }}>真实姓名： {this.state.name}</div>
          <div className="basis" style={{ position: 'absolute', top: 20, left: '50%' }}>
            <div style={{ width: 140, height: 140, textAlign: 'center' }}>
              <div style={{ width: 140, height: 110, textAlign: 'center' }}>
                <img src={man} alt="" style={{ width: 80, height: 80, marginTop: 20 }} />
              </div>
              <div style={{ width: 140, height: 30, textAlign: 'center' }}>
                <span style={{ color: '#111111' }} >蓝晟管控平台个人认证</span>
              </div>
            </div>
          </div>
          <img src={qqq} alt="" style={{ width: 80, height: 80, position: 'absolute', top: 30, left: '53%' }} />
        </Card>
        <div style={{ marginTop: '12px', marginLeft: 18 }}>
          <div style={{ fontFamily: '苹方中等', fontSize: 14, color: '#373d41' }}>亲爱的个人用户，我们为您准备了丰厚的新手礼包，上蓝晟平台就是这么简单，遇到问题，请拨打40086663183</div>
          <div style={{ height: 60, float: 'left', marginLeft: 12 }}>
            <img src={tex} style={{ width: 50, height: 50, marginTop: 20 }} alt="" />
          </div>
          <div style={{ height: 20, width: '80%', float: 'left', marginLeft: 20, marginTop: 20, fontFamily: '苹方中等', fontSize: 14, color: '#373d41' }}>售前咨询：<span style={{ color: '#ff9800' }}>86663转1</span></div>
          <div style={{ height: 20, float: 'left', marginLeft: 20, marginTop: 10, fontFamily: '苹方中等', fontSize: 12, color: '#373d41' }}>
            我们为您提供了全方位的购买服务、精准的配置推荐、灵活的价格方案、1对1的贴心服务。<br />
            <Link>了解详情>></Link>
          </div>
        </div>
      </div>
    );
  }
}

export default Real;