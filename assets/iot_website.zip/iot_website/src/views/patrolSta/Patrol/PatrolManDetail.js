/*
 * @Author: Han.beibei 
 * @Date: 2017-05-20 10:45:59 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-14 18:00:57
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Modal } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

// 设置message消息
message.config({
  top: 216,
  duration: 2
})

//查人员 
var userNames = [{ name: '/' }];

//查位置
var areaNames = [{ name: '/' }];
let arr = ["正常", "未巡逻"];
let userId = [];

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      selectIdOne: null,
      visible: false,
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
    window.rpc.cache.user.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        userNames[value.id] = value.name;
      }
      sessionStorage.setItem('userNames', JSON.stringify(userNames));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.cache.area.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        areaNames[value.id] = value.name;
      }
      sessionStorage.setItem('areaNames', JSON.stringify(areaNames));
    }, (err) => {
      console.warn(err);
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const state = fieldsValue['state'];
        let values = {};
        if (state) {
          values = { ...values, state: fieldsValue['state'].map(x => parseInt(x, 10)) }
        }
        if (rangeValue) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        window.rpc.user.getInfo().then((result) => {
          if (result.id) {
            values = { ...values, userId: result.id }
          }
          window.rpc.position.log.getArrayByContainer(values, 0, 0).then((result) => {
            message.info(`共搜索到${result.length}条数据`);
            let users = result.map((x) => ({ ...x, key: x.id, positionId: areaNames[x.positionId] || "/", userId: userNames[x.userId], state: arr[x.state], remark: x.remark, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
            this.props.appState.tableData = users;
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={4} key={3}>
            <FormItem label={`巡逻结果`}>
              {getFieldDecorator(`state`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  <Option key={`0`}>正常</Option>
                  <Option key={`1`}>未巡查</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={6}>
            <FormItem label={`巡查时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);


const StaffC = observer(class StaffC extends Component {
  componentDidMount() {
    window.rpc.user.getInfo().then((result) => {
      window.rpc.position.log.getArrayByContainer({ userId: result.id }, 0, 0).then((result) => {
        let users = result.map((x) => ({ ...x, key: x.id, positionId: areaNames[x.positionId] || "/", userId: userNames[x.userId], state: arr[x.state], remark: x.remark, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
        this.props.appState.tableData = users;
      }, (err) => {
        console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    }, (err) => {
      console.warn(err);
    })

  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
    display: false,
  };
  handleChange = (pagination, filters, sorter) => {
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }
  handleDele = (num) => {
    message.info(`你要删除序号为 ${num} 的巡逻人？`)

  }
  showModal = (num) => {
    this.props.appState.visible = true;
    this.setState({ display: true });
  }
  handleOk = (e) => {
    this.setState({ display: false });
  }
  handleCancel = (e) => {
    this.setState({ display: false });
  }
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
    }, {
      title: '巡逻点',
      dataIndex: 'positionId',
      key: 'positionId'
    }, {
      title: '巡逻时间',
      dataIndex: 'createTime',
      key: 'createTime',
    },
    { title: '巡逻结果', dataIndex: 'state', key: 'state' },
    { title: '巡逻人', dataIndex: 'userId', key: 'userId' },
    ];

    const data = [...this.props.appState.tableData];

    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };

    return (
      <div className="ConcenHistory" style={{ padding: '0 15px' }}>
        <div style={{ height: 35, paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>个人巡逻详情</Link>
          </div>
          <Modal title="巡逻详情"
            visible={this.state.display}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
            className="PatrolManModal"
          >
            <div style={{ display: "inline-block", }}>
              <div style={{ height: 30, lineHeight: "25px", color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left" }}>巡查名称 ：</div>
              <Input disabled style={{ color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left", width: 180, marginLeft: 20 }} value="第一次测试巡查" />
            </div>
            <div style={{ display: "inline-block", }}>
              <div style={{ height: 30, lineHeight: "25px", color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left" }}>巡查时间 ：</div>
              <Input disabled style={{ color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left", width: 180, marginLeft: 20 }} value="第一次测试巡查" />
            </div>
            <div style={{ display: "inline-block", }}>
              <div style={{ height: 30, lineHeight: "25px", color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left" }}>处理结果 ：</div>
              <Input disabled style={{ color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left", width: 180, marginLeft: 20 }} value="第一次测试巡查" />
            </div>
            <div style={{ display: "inline-block", }}>
              <div style={{ height: 30, lineHeight: "25px", color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left" }}>巡查详情事项 ：</div>
              <Input disabled style={{ color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left", width: 180, marginLeft: 20 }} value="第一次测试巡查" />
            </div>
            <div style={{ display: "inline-block", }}>
              <div style={{ height: 30, lineHeight: "25px", color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left" }}>巡查名称 ：</div>
              <Input disabled style={{ color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left", width: 180, marginLeft: 20 }} value="第一次测试巡查" />
            </div>
            <div style={{ display: "inline-block", }}>
              <div style={{ height: 30, lineHeight: "25px", color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left" }}>巡查名称 ：</div>
              <Input disabled style={{ color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left", width: 180, marginLeft: 20 }} value="第一次测试巡查" />
            </div>
            <div style={{ display: "inline-block", }}>
              <div style={{ height: 30, lineHeight: "25px", color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left" }}>巡查名称 ：</div>
              <Input disabled style={{ color: "#333333", fontSize: "12px", fontFamily: '苹方中等', float: "left", width: 180, marginLeft: 20 }} value="第一次测试巡查" />
            </div>
          </Modal>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ marginTop: 20 }}>
          <Col span={24}>
            <Table
              bordered
              style={{ color: '#999' }}
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class PatrolManDetail extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default PatrolManDetail;