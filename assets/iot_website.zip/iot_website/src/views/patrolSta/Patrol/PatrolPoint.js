import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import moment from 'moment';
import listStore from '../listStore';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Icon, Modal, Cascader, Card } from 'antd';
import './PatrolPoint.css';

import QuitScreen from '../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../assets/images/application/shut-o.png';
import ditu from '../../../assets/images/task/大学科技园.png';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const { genderList, levelList } = listStore;
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

//查部门
var groupNames = [{ name: '/' }];

//查组织
var groupownerNames = [{ name: '/' }];


// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      mData: [],
      selectId: [],
      selectIdOne: null,
      removeSelected: [],
      Value: null,
      newPointX: 0,
      newPointY: 0,
      extend: {},
      piliangcao: [],
      tableDetailData: [],
      keyId: null,
      num: null,
      number: null
    })
  }
}

class QrCode extends React.Component {
  componentDidMount() {
    window.rpc.owner.getMapIdNameByContainer(null, 0, 0).then((res) => {
      window.rpc.position.getInfoById(this.props.id).then((result) => {
        this.setState({ ownerId: res[result.ownerId], tag: result.tag });
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
    })
  }

  state = {
    modal2Visible: false,
    ownerId: null,
    tag: null,
  }
  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }
  preview = () => {
    let id = 'PrintContentDiv';
    var sprnhtml = document.getElementById(id).innerHTML;
    var selfhtml = window.document.body.innerHTML; //获取当前页的html
    window.document.body.innerHTML = sprnhtml;
    window.print();
    // note
    // Re-refresh the page to load, replace the html structure directly, the binding event is destroyed
    window.location.href = `/memb/patrol/point`;
  }
  render() {
    let ie = `http://qr.liantu.com/api.php?&bg=ffffff&text=http://xiot.lszpcn.com/SPatrol/${this.props.id}`
    return (
      <span className="QrCode">
        <Link to={``} onClick={() => this.setModal2Visible(true)} style={{ color: '#0099cc' }}>查看二维码</Link>
        <Modal
          title="请扫以下二维码"
          wrapClassName="vertical-center-modal"
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          style={{ height: "400px" }}
          className="PatrolPoint"
        >
          <Button name="print" onClick={this.preview} style={{ position: 'absolute', left: 12, bottom: 12, zIndex: 999 }}>打印</Button>
          {/*<div id="PrintContentDiv" style={{ height: "90%", width: "100%" }}>*/}
          <div id="PrintContentDiv">
            <img src={ie} alt="" style={{ position: 'absolute', left: '50%', top: '50%', marginLeft: '-150px', marginTop: '-150px' }} />
            {/*<div style={{ width: "100%", height: '100%', padding: 10 }}>
              <div style={{ width: '80%', height: '80%' }}>
                <div style={{ width: '100%', float: "left", height: '100%', border: "5px solid #cccccc", borderRadius: "7px", textAlign: 'center' }}>
                  <img src={ie} alt="" style={{ width: "100%", height: '100%' }} />
                </div>
                <div style={{ float: "left", width: "45%", height: "100%", paddingLeft: 15, fontSize: "2em", fontWeight: 'bold' }}>
                  <div>名称： {this.props.name}</div>
                  <div style={{ marginTop: 15 }}> 所属企业名称:<br />{this.state.ownerId}</div>
                  <div style={{ marginTop: 10 }}>nfc:{this.state.tag}</div>
                </div>
              </div>
              <div style={{ width: '90%', height: '25%' }}>
                <img src={ditu} alt="" style={{ width: "100%", height: "100%" }} />
              </div>
            </div>*/}
          </div>
        </Modal>
      </span>
    );
  }
}

class AdvancedSearchFormOne extends React.Component {
  componentDidMount() {
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    }),
      window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {
        for (let value of result) {
          groupownerNames[value.id] = value;
        }
        sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
      }, (err) => {
        console.warn(err);
      })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const level = fieldsValue['level'];
        const groupId = fieldsValue['groupId'];
        const ownerId = fieldsValue['ownerId'];
        const gender = fieldsValue['gender'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (level) {
          values = { ...values, level: fieldsValue['level'].map(x => parseInt(x, 10)) }
        }
        if (groupId) {
          values = { ...values, groupId: fieldsValue['groupId'].map(x => parseInt(x, 10)) }
        }
        if (ownerId) {
          values = { ...values, ownerId: fieldsValue['ownerId'].map(x => parseInt(x, 10)) }
        }
        if (gender) {
          values = { ...values, gender: fieldsValue['gender'].map(x => parseInt(x, 10)) }
        }
        if (rangeValue) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }

        window.rpc.user.getArrayByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          this.props.appState.tableData = users;
          this.setState({ data: users });
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;

    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let levelChildren = [];
    let groupIdChildren = [];
    let ownerIdChildren = [];
    let genderChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={3} key={2}>
            <FormItem label={`性别`}>
              {getFieldDecorator(`gender`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {genderChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={3}>
            <FormItem label={`等级`}>
              {getFieldDecorator(`level`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={4}>
            <FormItem label={`部门`}>
              {getFieldDecorator(`groupId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {groupIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={5}>
            <FormItem label={`公司`}>
              {getFieldDecorator(`ownerId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {ownerIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={5} key={6}>
            <FormItem label={`加入时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7} style={{ marginTop: 32, marginLeft: 20 }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchFormOne = Form.create()(AdvancedSearchFormOne);
const PopoverPreserve = observer(class appState extends Component {
  constructor() {
    super();
    this.state = {
      data: [],
      selectId: [],
      visibleOne: false,

    }
  }
  componentDidMount() {
    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    window.rpc.user.getArray(0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = users;
      this.setState({ data: users });
    }, (err) => {
      console.warn(err);
    })
  }
  state = { visible: false, selectedRowKeys: null }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    this.setState({
      visible: false,
    });
    this.props.appState.selectId = this.state.Selected;//添加人员
    window.rpc.user.getArrayByContainer({ id: [...this.props.appState.selectId] }, 0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, tag: x.tag, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.mData = users;
      // 清楚选中状态
      setTimeout(() => {
        this.setState({
          selectedRowKeys: [],
        })
      }, 1000)
    }, (err) => {
      console.warn(err);
    })

  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    this.setState({ Selected, selectedRowKeys });
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  handelClick = (e) => {
    if (this.state.Selected.length !== 0 && this.state.Value) {
      let EquipSelected = this.state.Selected;
      sessionStorage.setItem('EquipPreserve', JSON.stringify(EquipSelected));
    }

  }
  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
        this.setState.Selected = selected;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.Selected = selected;
      },
    };
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>

          <Link to={`/member/staff/detail/${record.key}`}>详情</Link>
          <span className="ant-divider" />
          <Link to={`/member/edit/staff/${record.key}`}>编辑</Link>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];
    return (
      <div style={{ float: "left" }}>
        <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.showModal}>添加人员</Button>
        <Modal visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
          style={{ minWidth: 1300, minHeight: 700, marginLeft: 300, marginTop: '-70px' }}
          className="peopleModal"
        >
          <Row style={{ padding: '5px 0 0', }}>
            <WrappedAdvancedSearchFormOne appState={this.props.appState} />
            <Col span={24} style={{ marginTop: 30 }}>
              <Table
                bordered
                columns={columns}
                dataSource={data}
                rowSelection={rowSelection}
              />
            </Col>
          </Row>
        </Modal>
      </div>
    )
  }
})

class AdvancedSearchForm extends React.Component {
  state = {
    floor: 0,
    storey: 0,
    buildings: [],
    position: [],
  }
  componentDidMount() {
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {

      for (let value of result) {
        groupownerNames[value.id] = value;
      }
      sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
    }, (err) => {
      console.warn(err);
    })

    const getBuildings = () => {
      return window.rpc.area.getArrayByContainer({ type: 50 }, 0, 0);
    }

    const getFloors = () => {
      return window.rpc.area.getArrayByContainer({ type: 51 }, 0, 0);
    }

    const getPics = async () => {
      try {
        let buildings = await getBuildings().map(x => ({ id: x.id, name: x.name, label: x.name, value: `${x.id}`, children: [] }));
        let floors = await getFloors().map(x => ({ id: x.id, name: x.name, label: x.name, value: `${x.id}`, mapUrl: x.mapUrl ? x.mapUrl : '', parentId: x.parentId }));
        for (let value of buildings) {
          value.children = floors.filter(x => x.parentId === value.id);
        }
        this.setState({ buildings });
      } catch (error) {
        console.error(error)
      }
    }

    getPics();
  }

  onChange(value) {
    let floor = parseInt(value[0], 10);
    let storey = parseInt(value[1], 10);
    this.setState({ floor, storey });
  }

  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const enable = fieldsValue['enable'];
        const floor = this.state.floor;
        const storey = this.state.storey;
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (enable) {
          values = { ...values, enable: parseInt(enable, 10) }
        }

        if (floor) {
          values = { ...values, floor, storey }
        }

        window.rpc.position.getArrayByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
          this.props.appState.mData = users;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={5} key={1}>
            <FormItem label={`巡逻点名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 170 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={5} key={2}>
            <FormItem label={`是否启用`}>
              {getFieldDecorator(`enable`)(
                <Select style={{ width: 170 }} placeholder="请选择">
                  <Option value="1">是</Option>
                  <Option value="2">否</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={5} key={3} style={{ height: 32, linHeight: 32 }}>
            <span style={{ fontSize: 12, marginRight: 8 }}>巡逻位置选择:</span>
            <Cascader options={this.state.buildings} onChange={this.onChange.bind(this)} placeholder="" style={{ width: 170, height: 32 }} />
          </Col>
          <Col span={9} key={7} style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

class AddModal extends React.Component {
  state = {
    visible: false,
    newPointName: '',
    newPointX: 0,
    newPointY: 0,
    enable: 1,
    position: [],
    loucengpinmiantu_visible: false,
    extend: {}
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    let name = this.state.newPointName;
    let enable = this.state.enable;
    let floor = parseInt(this.state.position[0], 10);
    let storey = parseInt(this.state.position[1], 10);
    let mapX = this.state.newPointX;
    let mapY = this.state.newPointY;
    let extend = this.state.extend;
    if (!name) {
      message.info('请输入名称')
      return;
    }
    if (!mapX) {
      message.info('请选择点')
      return;
    }

    window.rpc.position.create({ name, enable, mapX, mapY, floor, storey, extend }).then((result) => {
      message.info(`新建成功，更新地图`);
      this.setState({
        visible: false,
      });
    })
    window.rpc.position.getArray(0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
      this.props.appState.mData = users;
    }, (err) => {
      console.warn(err);
    })
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  handleChange(value) {
    this.setState({ enable: parseInt(value, 10) });
  }
  onChange(value) {
    let lcpmt_src = this.state.buildings.filter(x => x.value === value[0])[0].children.filter(x => x.value === value[1])[0].mapUrl;
    this.setState({ lcpmt_src, position: value });
    let floor = parseInt(value[0], 10);
    let storey = parseInt(value[1], 10);
  }
  componentDidMount() {
    const getBuildings = () => {
      return window.rpc.area.getArrayByContainer({ type: 50 }, 0, 0);
    }

    const getFloors = () => {
      return window.rpc.area.getArrayByContainer({ type: 51 }, 0, 0);
    }

    const getPics = async () => {
      try {
        let buildings = await getBuildings().map(x => ({ id: x.id, name: x.name, label: x.name, value: `${x.id}`, children: [] }));
        let floors = await getFloors().map(x => ({ id: x.id, name: x.name, label: x.name, value: `${x.id}`, mapUrl: x.mapUrl ? x.mapUrl : '', parentId: x.parentId }));
        for (let value of buildings) {
          value.children = floors.filter(x => x.parentId === value.id);
        }
        this.setState({ buildings });
      } catch (error) {
        console.error(error)
      }
    }

    getPics();
  }
  render() {
    return (
      <div>
        <Button type="primary" onClick={this.showModal}>新增</Button>
        <Modal title="新增巡逻点" visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
          wrapClassName="addPositionModal"
          maskClosable={false}
        >
          <Row>
            <Col span="8"><span style={{ color: 'red' }}>*</span> 巡逻点名称</Col>
            <Col span="16"><Input defaultValue={this.state.newPointName} value={this.state.newPointName} onChange={(e) => {
              this.setState({ newPointName: e.target.value })
            }} /></Col>
          </Row>
          <Row style={{ marginTop: 24 }}>
            <Col span="8"><span style={{ color: 'red' }}>*</span> 是否启用</Col>
            <Col span="16">
              <Select defaultValue="1" style={{ width: 160 }} onChange={this.handleChange.bind(this)}>
                <Option value="1">是</Option>
                <Option value="2">否</Option>
              </Select>
            </Col>
          </Row>
          <Row style={{ marginTop: 24 }}>
            <Col span="8"><span style={{ color: 'red' }}>*</span> 巡逻位置选择</Col>
            <Col span="16">
              <Input value={`${this.state.newPointX},${this.state.newPointY}`} />
              <Button icon="plus" style={{ marginLeft: 12 }} onClick={() => {
                this.setState({ loucengpinmiantu_visible: true })
              }} />
            </Col>
          </Row>
          <div className="loucengpinmiantu" style={{ display: this.state.loucengpinmiantu_visible ? 'block' : 'none' }}>
            <div className="pingmiantu-top">
              <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ loucengpinmiantu_visible: !prevState.loucengpinmiantu_visible }))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>
              <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ loucengpinmiantu_visible: !prevState.loucengpinmiantu_visible }))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
            </div>
            <div className="pmt_inner">
              <div className="pmt_select">
                <span style={{ margin: '0 12px 0 25px', fontSize: '0.75rem' }}>楼层选择：</span>
                <Cascader options={this.state.buildings} onChange={this.onChange.bind(this)} placeholder="请选择" />
              </div>
              <div className="lcpmt_container" style={{ display: this.state.lcpmt_src ? 'block' : 'none' }}>
                <div className="lcpmt_wrap" style={{ display: 'inline-block', position: 'relative' }}>
                  <img src={this.state.lcpmt_src} alt="pmt" onMouseDown={(event) => {
                    event.persist();
                    let newPointX = event.clientX - event.target.x;
                    let newPointY = event.clientY - event.target.y;
                    let extend = { offsetHeight: event.target.offsetHeight, offsetWidth: event.target.offsetWidth };
                    message.info(`已选择点(${newPointX, newPointY})`)
                    this.setState({ newPointX, newPointY, loucengpinmiantu_visible: false, extend });
                  }} />
                </div>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}

class EdditModal extends React.Component {
  state = {
    visible: false,
    newPointName: '',
    newPointX: 0,
    newPointY: 0,
    enable: 1,
    position: [],
    loucengpinmiantu_visible: false,
    extend: {},
    tag: ''
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    let name = this.state.newPointName;
    let enable = this.state.enable;
    let floor = parseInt(this.state.position[0], 10);
    let storey = parseInt(this.state.position[1], 10);
    let tag = this.state.tag;
    let mapX = this.state.newPointX;
    let mapY = this.state.newPointY;
    let id = this.state.id;
    let extend = this.state.extend;

    let g = Array.from(new Array(100), (item, idx) => {
      if (idx % 15 === 0) {
        return `FizzBuzz`;
      } else if (idx % 5 === 0) {
        return 'Buzz'
      } else if (idx % 3 === 0) {
        return 'Fizz'
      } else {
        return idx
      }
    })
    if (!name) {
      message.info('请输入名称')
      return;
    }
    if (!mapX) {
      message.info('请选择点')
      return;
    }
    window.rpc.position.setInfoById(id, { name, tag, enable, mapX, mapY, floor, storey, extend }).then((result) => {
      message.info(`修改成功`);
      this.setState({
        visible: false,
      });
    })
    window.rpc.position.getArray(0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
      this.props.appState.mData = users;
    }, (err) => {
      console.warn(err);
    })
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  handleChange(value) {
    this.setState({ enable: parseInt(value, 10) });
  }
  onChange(value) {
    let lcpmt_src = this.state.buildings.filter(x => x.value === value[0])[0].children.filter(x => x.value === value[1])[0].mapUrl;
    this.setState({ lcpmt_src, position: value });
    let floor = parseInt(value[0], 10);
    let storey = parseInt(value[1], 10);
  }

  componentDidMount() {
    let record = this.props.record;
    this.setState((prevState) => ({ ...prevState, tag: record.tag, newPointName: record.name, id: record.id, newPointX: record.mapX, newPointY: record.mapY, position: [record.floor, record.storey], extend: record.extend }));


    const getBuildings = () => {
      return window.rpc.area.getArrayByContainer({ type: 50 }, 0, 0);
    }

    const getFloors = () => {
      return window.rpc.area.getArrayByContainer({ type: 51 }, 0, 0);
    }

    const getPics = async () => {
      try {
        let buildings = await getBuildings().map(x => ({ id: x.id, key: x.id, name: x.name, label: x.name, value: `${x.id}`, children: [] }));
        let floors = await getFloors().map(x => ({ id: x.id, key: x.id, name: x.name, label: x.name, value: `${x.id}`, mapUrl: x.mapUrl ? x.mapUrl : '', parentId: x.parentId }));
        for (let value of buildings) {
          value.children = floors.filter(x => x.parentId === value.id);
        }
        this.setState({ buildings });
      } catch (error) {
        console.error(error)
      }
    }

    getPics();
  }
  render() {
    return (
      <div style={{ display: 'inline-block' }}>
        <Link to={``} onClick={this.showModal} style={{ color: '#0099cc' }} >修改</Link>
        <Modal title="新增巡逻点" visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
          wrapClassName="addPositionModal"
          maskClosable={false}
        >
          <Row>
            <Col span="8"><span style={{ color: 'red' }}>*</span> 巡逻点名称</Col>
            <Col span="16"><Input value={this.state.newPointName} onChange={(e) => {
              this.setState({ newPointName: e.target.value })
            }} /></Col>
          </Row>
          <Row style={{ marginTop: 24 }}>
            <Col span="8"><span style={{ color: 'red' }}>*</span> NFC</Col>
            <Col span="16"><Input value={this.state.tag} onChange={(e) => {
              this.setState({ tag: e.target.value })
            }} /></Col>
          </Row>
          <Row style={{ marginTop: 24 }}>
            <Col span="8"><span style={{ color: 'red' }}>*</span> 是否启用</Col>
            <Col span="16">
              <Select defaultValue="1" style={{ width: 160 }} onChange={this.handleChange.bind(this)}>
                <Option value="1">是</Option>
                <Option value="2">否</Option>
              </Select>
            </Col>
          </Row>
          <Row style={{ marginTop: 24 }}>
            <Col span="8"><span style={{ color: 'red' }}>*</span> 巡逻位置选择</Col>
            <Col span="16">
              <Input value={`${this.state.newPointX},${this.state.newPointY}`} />
              <Button icon="plus" style={{ marginLeft: 12 }} onClick={() => {
                this.setState({ loucengpinmiantu_visible: true })
              }} />
            </Col>
          </Row>
          <div className="loucengpinmiantu" style={{ display: this.state.loucengpinmiantu_visible ? 'block' : 'none' }}>
            <div className="pingmiantu-top">
              <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ loucengpinmiantu_visible: !prevState.loucengpinmiantu_visible }))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>
              <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ loucengpinmiantu_visible: !prevState.loucengpinmiantu_visible }))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
            </div>
            <div className="pmt_inner">
              <div className="pmt_select">
                <span style={{ margin: '0 12px 0 25px', fontSize: '0.75rem' }}>楼层选择：</span>
                <Cascader options={this.state.buildings} onChange={this.onChange.bind(this)} placeholder="请选择" />
              </div>
              <div className="lcpmt_container" style={{ display: this.state.lcpmt_src ? 'block' : 'none' }}>
                <div className="lcpmt_wrap" style={{ display: 'inline-block', position: 'relative' }}>
                  <img src={this.state.lcpmt_src} alt="pmt" onMouseDown={(event) => {
                    event.persist();
                    let newPointX = event.clientX - event.target.x;
                    let newPointY = event.clientY - event.target.y;
                    let extend = { offsetHeight: event.target.offsetHeight, offsetWidth: event.target.offsetWidth };
                    console.log(event.clientX - event.target.x, event.clientY - event.target.y);
                    message.info(`已选择点(${newPointX, newPointY})`)
                    this.setState({ newPointX, newPointY, loucengpinmiantu_visible: false, extend });
                  }} />
                </div>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}

class DeleteModal extends React.Component {
  state = { visible: false }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    let id = this.props.id;
    window.rpc.position.removeById(id).then(result => {
      message.info('删除成功！')
      this.setState({
        visible: false,
      });
    })
    window.rpc.position.getArrayByContainer({}, 0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
      this.props.appState.mData = users;
    }, (err) => {
      console.warn(err);
      function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
    })
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  render() {
    return (
      <div style={{ display: 'inline-block' }}>
        <Link to={``} onClick={this.showModal} style={{ color: '#0099cc' }} >删除</Link>
        <Modal title="删除巡逻点" visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
          wrapClassName="deletePositionModal"
        >
          <p>您确认要删除巡逻点么？</p>
        </Modal>
      </div>
    );
  }
}

const PatrolPointC = observer(class PatrolPointC extends Component {
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  state = {
    buildings: [],
    loucengpinmiantu_visible: false,
    lcpmt_src: '',
    position: [],
    filteredInfo: null,
    sortedInfo: null,
    point_on_map: [],
    newPointX: 0,
    newPointY: 0,
    visible: false,
    enable: 1,
    extend: {}
  }
  handleChange = (pagination, filters, sorter) => {
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }

  handleStaff = () => {
    if (this.props.appState.selectIdOne != null) {
      browserHistory.push(`/memb/staff/edit/${this.props.appState.selectIdOne}`);
    } else {
      message.info('请选择人员！');
    }

  }
  //人员详情跳转
  handleStaffOne = () => {
    if (this.props.appState.selectIdOne != null) {
      browserHistory.push(`/memb/staff/detail/${this.props.appState.selectIdOne}`);
    } else {
      message.info('请选择人员！');
    }
  }

  componentDidMount() {
    const getBuildings = () => {
      return window.rpc.area.getArrayByContainer({ type: 50 }, 0, 0);
    }

    const getFloors = () => {
      return window.rpc.area.getArrayByContainer({ type: 51 }, 0, 0);
    }

    const getPics = async () => {
      try {
        let buildings = await getBuildings().map(x => ({ id: x.id, name: x.name, label: x.name, value: `${x.id}`, children: [] }));
        let floors = await getFloors().map(x => ({ id: x.id, key: x.id, name: x.name, label: x.name, value: `${x.id}`, mapUrl: x.mapUrl ? x.mapUrl : '', parentId: x.parentId }));
        for (let value of buildings) {
          value.children = floors.filter(x => x.parentId === value.id);
        }
        this.setState({ buildings });
      } catch (error) {
        console.error(error)
      }
    }

    getPics();

    window.rpc.position.getArray(0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
      this.props.appState.mData = users;
    }, (err) => {
      console.warn(err);
      function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
    })
  }

  onChange(value) {
    let lcpmt_src = this.state.buildings.filter(x => x.value === value[0])[0].children.filter(x => x.value === value[1])[0].mapUrl;
    this.setState({ lcpmt_src, position: value });
    let floor = parseInt(value[0], 10);
    let storey = parseInt(value[1], 10);
    window.rpc.position.getArrayByContainer({ floor, storey }, 0, 0).then((result) => {
      this.setState({ point_on_map: result });
    })
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    let name = this.state.newPointName;
    let enable = this.state.enable;
    let floor = parseInt(this.state.position[0], 10);
    let storey = parseInt(this.state.position[1], 10);
    let mapX = this.state.newPointX;
    let mapY = this.state.newPointY;
    let extend = this.state.extend;
    if (!name) {
      message.info('请输入名称')
      return;
    }
    if (!mapX) {
      message.info('请选择点')
      return;
    }
    window.rpc.position.create({ name, enable, mapX, mapY, floor, storey, extend }).then((result) => {
      message.info(`新建成功，更新地图`);
    })
    window.rpc.position.getArrayByContainer({ floor, storey }, 0, 0).then((result) => {
      this.setState({ point_on_map: result, visible: false });
    })
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  handleChangeM(value) {
    this.setState({ enable: parseInt(value, 10) });
  }

  handlePiliangOperate() {
  }

  handlePiliangOperateQ() {
    let selected = [...this.props.appState.piliangcao];
    if (selected.length === 0) {
      message.info('请选择')
    } else {
      window.rpc.position.updateEnableByArrayId(selected, 1).then((result) => {
        message.info('启用成功')
      });
      window.rpc.position.getArray(0, 0).then((result) => {
        let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
        this.props.appState.mData = users;
      }, (err) => {
        console.warn(err);
      })
    }
  }

  handlePiliangOperateT() {
    let selected = [...this.props.appState.piliangcao];
    if (selected.length === 0) {
      message.info('请选择')
    } else {
      window.rpc.position.updateEnableByArrayId(selected, 2).then((result) => {
        message.info('停用成功')
      });
      window.rpc.position.getArray(0, 0).then((result) => {
        let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
        this.props.appState.mData = users;
      }, (err) => {
        console.warn(err);
      })
    }
  }

  handlePiliangOperateS() {
    let selected = [...this.props.appState.piliangcao];
    if (selected.length === 0) {
      message.info('请选择')
    } else {
      window.rpc.position.removeByArrayId(selected).then((result) => {
        message.info('删除成功')
      });
      window.rpc.position.getArray(0, 0).then((result) => {
        let users = result.map((x) => ({ ...x, key: x.id, tag: x.tag, state: x.state === 1 ? '已巡查' : '未巡逻', enable: x.enable === 1 ? '启用' : '禁用' }))
        this.props.appState.mData = users;
      }, (err) => {
        console.warn(err);
      })
    }
  }
  showModalOneTable = (key) => {
    let id = parseInt(key + 1, 10);
    window.rpc.position.log.getCountByContainer({ positionId: key.id }).then(res => {
      this.props.appState.num = res;
    });
    this.props.appState.keyId = key.id;
    window.rpc.position.getMapIdNameByContainer(null, 0, 0).then(res => {
      window.rpc.user.getMapIdNameByContainer({}, 0, 0).then(data => {
        window.rpc.alias.getValueByName('position.state').then(state => {
          window.rpc.position.log.getArrayByContainer({ positionId: key.id }, 0, 10).then((result) => {
            let devices = result.map((x) => ({ ...x, key: x.id, state: state[x.state] || '未知', userId: data[x.userId] || x.userId, positionId: res[x.positionId] || x.positionId, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
            this.props.appState.tableDetailData = devices;
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        })
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
    })
    this.setState({
      visibleOne: true,
    });
  }
  showModalOne = () => {
    this.setState({
      visibleOne: true,
    });
  }
  handleOkOne = (e) => {
    this.setState({
      visibleOne: false,
    });
  }
  handleCancelOne = (e) => {
    this.setState({
      visibleOne: false,
    });
  }
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id'
    }, {
      title: '巡逻点名称',
      dataIndex: 'name',
      key: 'name'
    },
    { title: '状态', dataIndex: 'state', key: 'state' },
    { title: 'NFC', dataIndex: 'tag', key: 'tag' },
    {
      title: '是否启用',
      dataIndex: 'enable',
      key: 'enable',
      render: (text, record) => record.enable === '启用' ? <span style={{ color: 'green' }}>启用</span> : <span>禁用</span>,
    },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record, index) => (
        <span>
          <Link to={``} onClick={() => this.showModalOneTable(record)} style={{ color: '#0099cc' }}>查看详情</Link>
          <span className="ant-divider" />
          <EdditModal record={record} appState={this.props.appState} />
          <span className="ant-divider" />
          <DeleteModal id={record.id} appState={this.props.appState} />
          <span className="ant-divider" />
          <QrCode id={record.id} name={record.name} />
        </span>
      )
    },
    ];
    const detailColumns = [
      { title: 'ID', dataIndex: 'id', key: 'id' },
      {
        title: '巡逻点名称', dataIndex: 'positionId', key: 'positionId', render: (text, record) => (
          <span>
            {text}
          </span>
        )
      },
      { title: '巡查人', dataIndex: 'userId', key: 'userId' },
      { title: '巡查时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '处理结果', dataIndex: 'state', key: 'state' },
    ];
    const data = [...this.props.appState.mData];
    const detailData = [...this.props.appState.tableDetailData];
    const pagination = {
      total: this.props.appState.mData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };
    const detailPagination = {
      total: this.props.appState.num,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
        const pageNum = (parseInt(current, 10) - 1) * 10;
        let keyId = this.props.appState.keyId;
        window.rpc.cache.owner.getMapIdNameByContainer(null, 0, 0).then(res => {
          window.rpc.user.getMapIdNameByContainer({}, 0, 0).then(data => {
            window.rpc.alias.getValueByName('position.state').then(state => {
              window.rpc.position.log.getArrayByContainer({ positionId: keyId }, pageNum, 10).then((result) => {
                let devices = result.map((x) => ({ ...x, state: state[x.state] || '未知', userId: data[x.userId] || x.userId, positionId: res[x.positionId] || x.positionId, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
                this.props.appState.tableDetailData = devices;
              }, (err) => {
                console.warn(err);
              })
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        })
      },
    };
    //表格单选框设置
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        let selected = selectedRows.map(x => x.id);
        this.props.appState.piliangcao = selected;
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectIdOne = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (
      <div className="ConcenHistory">
        <div style={{ fontSize: '0.75em', height: 35, paddingBottom: '1.125em', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 96, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/patrol/point' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>巡逻点管理</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px', display: 'flex' }} className="TaskRules">
            <Button style={{ backgroundColor: '#00c2de', borderColor: '#00c2de', color: '#fff', width: 122, paddingLeft: 0, marginRight: 8 }} onClick={() => this.setState((prevState) => ({ loucengpinmiantu_visible: !prevState.loucengpinmiantu_visible }))}><Icon type="enter" />进入视图模式</Button>
            <AddModal appState={this.props.appState} />
            <Button className="operatPatrolP" onClick={this.handlePiliangOperateQ.bind(this)}>启用</Button>
            <Button className="operatPatrolP" onClick={this.handlePiliangOperateT.bind(this)}>停用</Button>
            <Button className="operatPatrolP" onClick={this.handlePiliangOperateS.bind(this)}>删除</Button>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Modal title="巡逻详情"
          visible={this.state.visibleOne}
          onOk={this.handleOkOne}
          onCancel={this.handleCancelOne}
          style={{ height: 760, position: 'absolute', left: '50%', marginLeft: '-380px', padding: '0 22px' }}
          className="patrolrModalPoint"
        >
          <Table
            style={{ color: '#999' }}
            columns={detailColumns}
            dataSource={detailData}
            pagination={detailPagination}
          />
        </Modal>
        <Row style={{ padding: '5px 0 0', marginTop: 10 }}>
          <Col span={24}>
            <Table
              style={{ color: '#999' }}
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
        <div className="loucengpinmiantu" style={{ display: this.state.loucengpinmiantu_visible ? 'block' : 'none' }}>
          <div className="pingmiantu-top">
            <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ loucengpinmiantu_visible: !prevState.loucengpinmiantu_visible }))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ loucengpinmiantu_visible: !prevState.loucengpinmiantu_visible }))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <div className="pmt_inner">
            <div className="pmt_select">
              <span style={{ margin: '0 12px 0 25px', fontSize: '0.75rem' }}>楼层选择：</span>
              <Cascader options={this.state.buildings} onChange={this.onChange.bind(this)} placeholder="请选择" />
            </div>
            <div className="lcpmt_container" style={{ display: this.state.lcpmt_src ? 'block' : 'none' }}>
              <div className="lcpmt_wrap" style={{ display: 'inline-block', position: 'relative' }}>
                <img src={this.state.lcpmt_src} alt="pmt" onMouseDown={(event) => {
                  event.persist();
                  let newPointX = event.clientX - event.target.x;
                  let newPointY = event.clientY - event.target.y;
                  let extend = { offsetHeight: event.target.offsetHeight, offsetWidth: event.target.offsetWidth };
                  this.setState({ newPointX, newPointY, visible: true, extend });
                  this.props.appState.newPointX = newPointX;
                  this.props.appState.newPointY = newPointY;
                }} />
                <Modal title="新增巡逻点" visible={this.state.visible}
                  onOk={this.handleOk} onCancel={this.handleCancel}
                  wrapClassName="addPositionModal"
                >
                  <Row>
                    <Col span="8"><span style={{ color: 'red' }}>*</span> 巡逻点名称</Col>
                    <Col span="16"><Input defaultValue={this.state.newPointName} value={this.state.newPointName} onChange={(e) => {
                      this.setState({ newPointName: e.target.value })
                    }} /></Col>
                  </Row>
                  <Row style={{ marginTop: 24 }}>
                    <Col span="8"><span style={{ color: 'red' }}>*</span> 是否启用</Col>
                    <Col span="16">
                      <Select defaultValue="1" style={{ width: 160 }} onChange={this.handleChangeM.bind(this)}>
                        <Option value="1">是</Option>
                        <Option value="2">否</Option>
                      </Select>
                    </Col>
                  </Row>
                  <Row style={{ marginTop: 24 }}>
                    <Col span="8"><span style={{ color: 'red' }}>*</span> 巡逻位置选择</Col>
                    <Col span="16"><Input value={`${this.state.newPointX},${this.state.newPointY}`} /></Col>
                  </Row>
                </Modal>
                {this.state.point_on_map.map(x => <div key={x.id} className={x.enable === 1 ? 'point_able' : 'point_disable'} style={{ position: 'absolute', top: x.mapY, left: x.mapX }}><div style={{ height: 32, width: 32 }}></div><div className="point_hover_label">
                  <Card className="card_high" style={{ width: 272 }}>
                    <div className="card_up">
                      <p>巡逻点名称：{x.name}</p>
                      <p>是否启用：<span style={{ color: x.enable === 1 ? 'green' : 'gray' }}>{x.enable === 1 ? '启用' : '禁用'}</span></p>
                    </div>
                    <div className="card_down">
                      <EdditModal record={x} appState={this.props.appState} />
                      <DeleteModal id={x.id} appState={this.props.appState} />
                    </div>
                  </Card></div></div>)}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
})

class PatrolPoint extends Component {
  render() {
    return (
      <PatrolPointC appState={new appState()} />
    )
  }
}
export default PatrolPoint;