import React, { Component } from 'react';

import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message,Checkbox,Card } from 'antd';
import echarts from 'echarts';
import moment from 'moment';
import warnInfo_pic from '../../../assets/images/application/warnInfo.png';
import fly_pic from '../../../assets/images/application/fly.png';
import technology_pic from '../../../assets/images/application/technology.png';
import patrolTask from '../../../assets/images/task/巡检任务.png';
import './PatalStcTable.css'
const FormItem = Form.Item;
let nowday = new Date();
let beginTime = '';
let lastTime = moment(nowday).format('YYYY-MM-DD');
const { RangePicker } = DatePicker;
class deviceState {
	constructor() {
    extendObservable(this, {
      data:[],
      manData:[],
      values:{}
    })
	}
}
const TrendSearchFormUp = Form.create()(React.createClass({
//valueArr
    // constructor() {
	// 	super();
	// 	this.state = {
	// 		valueArr:[]
	// 	};
	// },
	getInitialState() {
      return {
       valueArr:[]

     };
   },
	componentWillMount() {
  
	},
  handleChange(value){
      console.log(value);
      let createTime=[new Date(value[0].format('YYY-MM-DD')), new Date(value[1].format('YYY-MM-DD'))] ;
      console.log(createTime);
      let values={createTime:createTime};
      this.props.deviceState.values=values;
    window.rpc.position.log.getArrayCountUserBriefByContainer(values,0,0).then(data=>{
      console.log(data);
      message.info(`搜索成功`)
      this.props.deviceState.manData=data;
    },err=>{
      console.warn(err)
    })
    window.rpc.position.log.getArrayCountBriefByContainer(values,0,10).then(data=>{
      console.log(data);
      //message.info(`搜索成功`)
      let mans=data.map(x=>({...x,gender:x.total}))
      this.props.deviceState.data=data;
    },err=>{
      console.warn(err)
    })
  },
	render() {
		const { getFieldDecorator } = this.props.form;
     	return (
		 	<Form inline style={{ paddingLeft:10}}>
         <Row>
			    <Col span={6} key={1}>
            <div className="Row-info-patrol patrolClearfix">
                <div style={{float:'left',marginRight:5,height:32,lineHeight:'32px',fontSize:12}}>
                  <img src={patrolTask} style={{padding:'0 8px 0 0',    position: 'absolute',top: 8}} alt=""/>
                  <span style={{paddingLeft:20}}>巡逻时间：</span>
                </div>
					    	<FormItem  style={{float:'left'}}>
						    	{getFieldDecorator(`targetTime`)(
							    	<RangePicker
								    	showTime
								    	format="YYYY-MM-DD"
								    	placeholder={['开始日期', '结束日期']}
                      onChange={this.handleChange}
				 				     	style={{ width: 200 ,height:32}} />
							     )}
					  	</FormItem>
					  </div>
          </Col>
				</Row>
			</Form>
		);
	}
}));

@observer
class PatrolManStcC extends Component {
  state={
    pointTotal:null,
    patrolLog:null,
    stateNum:null,

  }
   componentWillMount() {
    window.rpc.position.getCount().then(data=>{
      console.log(data);
      this.setState({pointTotal:data})

    },err=>{
      console.warn(err)
    })
    window.rpc.position.log.getCount().then(data=>{
      console.log(data);
      this.setState({patrolLog:data})

    },err=>{
      console.warn(err)
    })
     window.rpc.position.log.getCountByContainer({state:2}).then(data=>{
      console.log(data);
      this.setState({stateNum:data})

    },err=>{
      console.warn(err)
    })
  }
  componentDidMount() {
    window.rpc.position.log.getArrayCountUserBriefByContainer({},0,0).then(data=>{
      console.log(data.length);
      this.props.deviceState.num=data.length;
    },err=>{
      console.warn(err)
    })
    window.rpc.position.log.getArrayCountBriefByContainer({},0,0).then(data=>{
      console.log(data.length);
      this.props.deviceState.numB=data.length;
    },err=>{
      console.warn(err)
    })
    window.rpc.position.log.getArrayCountUserBriefByContainer({},0,10).then(data=>{
      console.log(data);
      this.props.deviceState.manData=data;
      //this.props.deviceState.numB=data.length;
    },err=>{
      console.warn(err)
    })
    window.rpc.position.log.getArrayCountBriefByContainer({},0,10).then(data=>{
      console.log(data);
      let mans=data.map(x=>({...x,gender:x.total}))
      this.props.deviceState.data=data;
    },err=>{
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  render() {
    const columnsA = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '巡逻人',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '巡逻次数',
      dataIndex: 'total',
      key: 'total',
      render: (text, record) => (
        <span>
          <Link to={``}>{text}</Link>  
        </span>
      )
    },
    { title: '异常', dataIndex: 'count', key: 'count' , render: (text, record) => (
        <span>
          <Link to={``}>{text}</Link>  
        </span>
      )
    },
    ]
   
    
    const columnsB = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '巡逻点名称',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '位置',
      dataIndex: 'location',
      key: 'location',
      render: (text, record) => {
          let textArr = text.split(',');
          if (textArr[2]) {
            return (
              <span>
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>--
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/area/cont/${textArr[2].split(':')[0]}`}>{textArr[2].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[1]) {
            return (
              <span>
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[0]) {
            return (
              <span>
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>
              </span>
            )
          }
      }
    },
    { title: '异常', dataIndex: 'count', key: 'count' , render: (text, record) => (
        <span>
          <Link to={``}>{text}</Link>  
        </span>
      )
    },
   
    ];
    let dataA=[...this.props.deviceState.manData];
    //console.log(dataA);
    let dataB=[...this.props.deviceState.data];
    // value={...values,createTime:[...values.createTime]};
    const paginationA = {
      total:this.props.deviceState.num,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        //console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        //console.log('Current: ', current);
        const pageNum = (parseInt(current, 10) - 1) * 10;
        //再调用
        //得到values  
        let values=this.props.deviceState.values||{};
        let value={};
        if(values.createTime){
           value={...values,createTime:[...values.createTime]};
        }else{
           value={};
        }
        window. window.rpc.position.log.getArrayCountUserBriefByContainer(value,pageNum,10).then(data=>{
          console.log(data);
          this.props.deviceState.manData=data;
        },err=>{
          console.warn(err)
        })
 
      },
    };
    const paginationB = {
      total:this.props.deviceState.numB,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        //console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        //console.log('Current: ', current);
        const pageNum = (parseInt(current, 10) - 1) * 10;
        //再调用
        //得到values  
        let values=this.props.deviceState.values||{};
        let value={};
        if(values.createTime){
           value={...values,createTime:[...values.createTime]};
        }else{
           value={};
        }
        window. window.rpc.position.log.getArrayCountBriefByContainer(value,pageNum,10).then(data=>{
          //console.log(data);
          this.props.deviceState.data=data;
        },err=>{
          console.warn(err)
        })
 
      },
    };
    return (
     <div className="PatrolStcTable" style={{padding:'15px',marginLeft:3,borderTop:'1px solid #ddd'}}>
           <div style={{marginBottom:12}}>    
               <TrendSearchFormUp deviceState={this.props.deviceState} />
           </div>
         <div style={{background:"rgb(234, 237, 241)",height:110}}>
          
           
            <div classNme="total-num-bottom">
              <div style={{height:'110px',width: '100%',marginTop:12}}>
                  <div style={{width:"30%",float:'left'}}>
                   <div classNme="total-num-top" style={{paddingTop:15}}>
                  
                      <span style={{paddingLeft:20}}>
                         巡逻概览   
                      </span>
                      </div>
                     <img src={technology_pic} style={{marginLeft:120,marginTop: 12,paddingRight:12}} alt=""/>
                     <span style={{position: 'absolute',lineHeight:'80px'}}>
                         <span style={{position: 'absolute',width: 60, top: 0}}>总巡逻点：</span>
                         <span className="hover-underline" style={{color:'green',fontSize:24,paddingLeft: 100}}>{this.state.pointTotal}</span>
                     </span>
                     
                  </div>
                  <div className="liHover" style={{width:"34%",marginRight:'1%',marginTop:18,float:'left',lineHeight:'80px',background:'#fff',height:80}} >
                     <span style={{display:'inline-block',height:80,lineHeight:'80px',position:'relative'}}>
                         <img src={fly_pic} style={{padding:'0 12px 0 30px',position:'absolute',top:28}} alt=""/>
                          <span style={{marginLeft:80}}>已巡逻点：</span>
                     </span>
                     <span style={{color:'#999',float:'right',marginRight:30}}>
                         <span className="hover-underline"  style={{color:'rgb(0, 194, 222)',padding:'0 40px',fontSize:20}}>{this.state.patrolLog}</span>
                         个
                     </span> 
                  </div>
                  <div className="liHover"  style={{width:"34%",marginRight:'1%',marginTop:18,float:'left',lineHeight:'80px',height:80,background:'#fff'}}>
                     <span style={{display:'inline-block',height:80,lineHeight:'80px',position:'relative'}}>
                         <img src={warnInfo_pic} style={{padding:'0 12px 0 30px',position:'absolute',top:22}} alt=""/>
                         <span  style={{marginLeft:80}}>异常信息：</span>
                     </span>
                     <span style={{color:'#999',float:'right',marginRight:30}}>
                         <span className="hover-underline" style={{color:'red',padding:'0 40px',fontSize:20}}>{this.state.stateNum}</span>
                         个
                     </span> 
                  </div>
              </div>
            </div>
         </div>
	    
        <div className="twoTable OrgManage">
            <div style={{margin:' 15px 0 0'}}>
                 <p style={{marginBottom:12,font:'14px #4e4e4e PingFang-SC-Medium'}}>巡逻人分析列表</p>
                 <Table
                   dataSource={dataA}
                   columns={columnsA}
                   pagination={paginationA}
                  />
            </div>
            <div style={{margin:'15px 0 0'}}>
                 <p style={{marginBottom:12,font:'14px #4e4e4e PingFang-SC-Medium'}}>巡逻点分析列表</p>
                  <Table 
                   dataSource={dataB}
                   columns={columnsB}
                   pagination={paginationB}
                  />
            </div>
            

        </div>
     </div> 
    );
  }
}
class PatrolStcTable extends Component {
	render() {
		return (
			<div><PatrolManStcC deviceState={new deviceState()} /></div>
		)
	}
}


export default PatrolStcTable;