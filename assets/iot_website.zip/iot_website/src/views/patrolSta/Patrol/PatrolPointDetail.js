import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import echarts from 'echarts';
import { Row, Col,  Button, Form,  DatePicker,message,Icon,Tabs} from 'antd';
import listStore from '../listStore';
import PatrolPointStc from './PatrolPointStc';
import PatrolManStc from './PatrolManStc';
import PatrolStcTable  from './PatrolStcTable';
import './PatrolStc.css'
const FormItem = Form.Item;
const { TabPane } = Tabs;
message.config({
  top: 216,
  duration: 2
})

//结构出参量表
const { warningType, resultsType } = listStore;

//取出设备类型和建筑
//let dtypes = JSON.parse(sessionStorage.getItem('dtypes'));
//let fildes = JSON.parse(sessionStorage.getItem('fields'));
//let locations = JSON.parse(sessionStorage.getItem('locations'));

// class patrolState {
//   @observable timer = 0;
//   @observable tableData = [];

//   add() {
//     this.tableData.push({ key: 4, id: 4, sign: '$', name: 'John Brown', dtype:'烟感', warningDate: '2016-09-26 08:50:08', installDate: '2015-09-26 08:50:08', address: 'New York No. 1 Lake Park', condition: '正常', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is John Brown, I am 32 years old, living in New York No. 1 Lake Park.' })
//   }
// }
class patrolState {
  constructor() {
    extendObservable(this, {
      timer: 0,
      tableData: [],
      obj:{}
    
    })
  }
}

let number = 0;
const PatrolDetailC = observer(class patrolState extends React.Component {
  state={
   visible:false,
   obj:{}
  }
  componentDidMount() {
  
  }
 
  render() {
   
    return (
      <div className="PatrolStic" style={{}}>  
         {/*<div style={{position:'absolute',left:0,top:10,width:100,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/org/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0',fontFamily: `苹方中等`}}>巡逻统计分析</Link>
         </div>*/}
        <Tabs defaultActiveKey="1"  style={{fontSize:'0.75rem' }} className='PatrolInfoTabOne ' >
           
          <TabPane  tab={<span className="small-tap-buttonn"><Icon type="info-circle-o" />数量统计</span>} key="1">
           <div style={{position:'absolute',left:0,top:10,width:100,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/org/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0',fontFamily: `苹方中等`}}>巡逻统计分析</Link>
           </div>
           <div> 
              <PatrolStcTable />
           </div>
            {/*<PatrolManStc />*/}
          </TabPane>
          <TabPane  tab={<span className="large-tap-buttonn"><Icon type="info-circle-o" />趋势分析：按巡逻人</span>} key="2">
           <div style={{position:'absolute',left:0,top:10,width:100,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/org/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0',fontFamily: `苹方中等`}}>巡逻统计分析</Link>
           </div>
            <PatrolManStc />
          </TabPane>
          <TabPane  tab={<span className="large-tap-buttonn"><Icon type="info-circle-o" />趋势分析：按巡逻点</span>} key="3">
            <div style={{position:'absolute',left:0,top:10,width:100,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/org/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0',fontFamily: `苹方中等`}}>巡逻统计分析</Link>
            </div>
            <PatrolPointStc  />
          </TabPane>
        </Tabs>
      </div>
    );
  }
})

class PatrolPointDetail extends Component {
  render() {
    return (
      <PatrolDetailC patrolState={new patrolState()} params={this.props.params} />
    )
  }
}

export default PatrolPointDetail;