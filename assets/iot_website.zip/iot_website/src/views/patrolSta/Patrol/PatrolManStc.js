import React, { Component } from 'react';

import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message,Checkbox,Card } from 'antd';
import echarts from 'echarts';
import moment from 'moment';
//import './deivceWarnning.css'
const FormItem = Form.Item;
const { Option } = Select;
let nowday = new Date();
let beginTime = '';
let lastTime = moment(nowday).format('YYYY-MM-DD');
const { RangePicker } = DatePicker;
class deviceState {
	constructor() {
	}
}
const TrendSearchFormUp = Form.create()(React.createClass({
//valueArr
    // constructor() {
	// 	super();
	// 	this.state = {
	// 		valueArr:[]
	// 	};
	// },
	getInitialState() {
      return {
       valueArr:[],
       types:[] 
     };
   },
	componentWillMount() {
    window.rpc.position.patrol.user.getArrayIdNameByContainer({},0,0).then(data=>{
      let types=data.map((x)=>({...x}))
      this.setState({
        types
      })
    },err=>{
      //console.log(err);
    })

	},
  handleChange(value){
      //console.log(value);
      let point=parseInt(value,10);
      //console.log(point);
       const form = this.props.form;
       let rangeValueOne = form.getFieldValue('setupTime');
       //console.log(rangeValueOne)
      //   if(point)
      let values={userId:point};
      //let values={};//测试暂不放
      if(rangeValueOne){
	    let before = rangeValueOne[0].format('YYYY-MM-DD');
	   	let after = rangeValueOne[1].format('YYYY-MM-DD');	
        ////console.log(before+'...'+after);
        let d1Ms = new Date(before).getTime();  
        let d2Ms =  new Date(after).getTime(); 
      
        var dayMilliSeconds  = 1000*60*60*24; 
          let afterTime= d2Ms+1000*60*60*24;
          ////console.log(new Date(rangeValueOne[1]))
          //获取后一个时间后一天的形式
          let realAfter=new Date(afterTime);
          //console.log(realAfter);
           let setupTime=[new Date(rangeValueOne[0].format('YYY-MM-DD')), realAfter] ;
         //console.log(setupTime);
         values={...values,createTime:setupTime};
        let 	 dataArr=[];
         //const reduces = (new Date(after).getTime()-new Date(before).getTime())/86400/1000;
         for (d1Ms; d1Ms <= d2Ms; d1Ms += dayMilliSeconds) {  
        // 如果ret为空，则无需添加","作为分隔符
        // for (let i = reduces; i >= 0; i--) {
              (function () {//afer=>d1Ms
                    dataArr.push(`${new Date(d1Ms).getFullYear()}-${(new Date(d1Ms).getMonth() + 1).toString().length === 1 ? '0' + (new Date(d1Ms).getMonth() + 1) : (new Date(d1Ms).getMonth() + 1)}-${((new Date(d1Ms).getDate() ).toString().length === 1 ? '0' + (new Date(d1Ms).getDate()) : (new Date(d1Ms).getDate()))}`)
              })(d1Ms)
        }
       //console.log(dataArr)
      let  colors = ['#5793f3', '#d14a61', '#675bba','yellow'];
      let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
     window.rpc.position.log.getTrendCountFieldByContainer(values,"state","date").then(data=>{
        //console.log(data);
         let arr=[],arr1=[];
         for (var i in data) {
				arr.unshift({ name: i, value:data[i][1] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') });
           arr1.unshift({ name: i, value:data[i][2] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') });
			}
      
			////console.log(arr);
 
      let nomalArr=chartArr(dataArr,arr);
      let specialArr=chartArr(dataArr,arr1);
      function chartArr(dataArr,arr){
         let nomalArr=[];
         for(let i=0;i<dataArr.length;i++){
          for(let j=0;j<arr.length;j++){
          if(dataArr[i]==arr[j]['name']){
           let value=arr[j]['value']
                getValueArr(value);
                break;//continue
          }else{ if(j===(arr.length-1)){
             getValueArr(0);
             //console.log(j+'==i:='+i)
          }
          }
        }
       }
        function getValueArr(value){
        nomalArr.push(value)   
      }
      return nomalArr;
      }
      
    let option = {
       color: colors,
       tooltip: {
        trigger: 'axis',
        //axisPointer: {type: 'cross'}
      },
      grid: {
        right: '20%'
      },
      legend: {
        data:['正常','异常']
      },
      xAxis: [
        {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            data: dataArr
        }
      ],
      yAxis: [
          {
            type: 'value',
            name: '',
            //min: 0,
            //max: 250,
            position: 'left',
            axisLine: {
                lineStyle: {
                    color: colors[0]
                }
            },
            axisLabel: {
                formatter: '{value} 次'
            }
          },
         {
            type: 'value',
            name: '',
            //min: 0,
            //max: 250,
            position: 'left',
            //offset: 80,
            axisLine: {
                lineStyle: {
                    color: colors[1]
                }
            },
            axisLabel: {
                formatter: '{value} 次'
            }
        },
        { position: 'left',
            //offset: 80,
            axisLine: {
                lineStyle: {
                    color:'rgba(155,255,255,0)'
                }
            },
        }
    ],
    series: [
        {
            name:'正常',
            type:'bar',
            data:nomalArr
        },
        {
            name:'异常',
            type:'bar',
            yAxisIndex: 1,
            data:specialArr
        },
        {   
         name:'正常',   
        type: 'line',
        data:nomalArr 
        },{     
          name:'异常',   
        type: 'line',
        data:specialArr
        }
    ]
   };
   myChartTwo.setOption(option);
    },err=>{
      console.warn(err);
    }) 
    }
    //console.log(values);
  },
	render() {
		const { getFieldDecorator } = this.props.form;
     let dtypes=this.state.types||[];
    //let fildes = JSON.parse(sessionStorage.getItem('fildes')) || [];
    let dtypeChildren = [];
    // let fildeChildren = [];
    // let waringstateChildren = [];
    // let destateChildren = [];

    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
		return (
		<Form inline style={{paddingLeft:10}}>
		  <Row>
		   <Col span={6} key={1}>
            <div key={3} className="Row-info-patrol patrolClearfix">
                <div style={{float:'left',marginRight:5,height:32,lineHeight:'32px',fontSize:12}}>
                  <span>巡逻时间：</span>
                </div>
                <FormItem   style={{float:'left'}}>
                  {getFieldDecorator(`setupTime`)(
                   	<RangePicker
					        	   showTime
					        	   format="YYYY-MM-DD"
						           placeholder={['开始日期', '结束日期']}
                       // onChange={this.handleChange.bind(this)}
				 		           style={{ width: 220 }} />
                  )}
                </FormItem>
               </div>
            </Col>
            <Col span={6} key={2}>
			         <div key={4} className="Row-info-patrol patrolClearfix">
                <div style={{float:'left',marginRight:5,height:32,lineHeight:'32px',fontSize:12}}>
                 <span>巡逻人：</span>
                </div>
                <FormItem   style={{float:'left'}}>
                  {getFieldDecorator(`point`)(
                    <Select  style={{ width: 220 }} onChange={this.handleChange} placeholder="请选择" >
                      {dtypeChildren}
                    </Select>
                  )}
                </FormItem>
               </div>
              </Col>	
			</Row>
			</Form>
		);
	}
}));

@observer
class PatrolManStcC extends Component {
  componentDidMount() {
   let  colors = ['#5793f3', '#d14a61', '#675bba','yellow'];
     let myChartTwo= echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
     let after=new Date();
     let afterTime= new Date().getTime();
     let beforeM = new Date(afterTime-6*1000*60*60*24);  
    ////console.log(after);
    ////console.log(beforeM);
    let values={createTime:[beforeM,after]};
    ////console.log(beforeTime);
    	let now= moment(new Date()).format('YYYY-MM-DD');
         let d1Ms = afterTime-6*1000*60*60*24;  
        let d2Ms =  afterTime; 
        var dayMilliSeconds  = 1000*60*60*24; 
        let 	 dataArr=[];
         //const reduces = (new Date(after).getTime()-new Date(before).getTime())/86400/1000;
         for (d1Ms; d1Ms <= d2Ms; d1Ms += dayMilliSeconds) {  
              (function () {//afer=>d1Ms
                    dataArr.push(`${new Date(d1Ms).getFullYear()}-${(new Date(d1Ms).getMonth() + 1).toString().length === 1 ? '0' + (new Date(d1Ms).getMonth() + 1) : (new Date(d1Ms).getMonth() + 1)}-${((new Date(d1Ms).getDate() ).toString().length === 1 ? '0' + (new Date(d1Ms).getDate()) : (new Date(d1Ms).getDate()))}`)
              })(d1Ms)
        }
      // //console.log(dataArr)
     window.rpc.position.log.getTrendCountFieldByContainer(values,"state","date").then(data=>{
      // //console.log(data);
       //此处数据处理
       let arr=[],arr1=[];
      for (var i in data) {
				arr.unshift({ name: i, value:data[i][1] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') });
        arr1.unshift({ name: i, value:data[i][2] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') });
			}
      
			////console.log(arr);
 
      let nomalArr=chartArr(dataArr,arr);
      let specialArr=chartArr(dataArr,arr1);
      function chartArr(dataArr,arr){
         let nomalArr=[];
         for(let i=0;i<dataArr.length;i++){
          for(let j=0;j<arr.length;j++){
          if(dataArr[i]==arr[j]['name']){
           let value=arr[j]['value']
                getValueArr(value);
                break;//continue
          }else{ if(j===(arr.length-1)){
             getValueArr(0);
             //console.log(j+'==i:='+i)
          }
          }
        }
       }
        function getValueArr(value){
        nomalArr.push(value)   
      }
        return nomalArr;
      }
       let option = {
       color: colors,
       tooltip: {
        trigger: 'axis',
        //axisPointer: {type: 'cross'}
      },
      grid: {
        right: '20%'
      },
      legend: {
        data:['正常','异常']
      },
      xAxis: [
        {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            data: dataArr
        }
      ],
      yAxis: [
          {
            type: 'value',
            name: '',
            //min: 0,
            //max: 250,
            position: 'left',
            axisLine: {
                lineStyle: {
                    color: colors[0]
                }
            },
            axisLabel: {
                formatter: '{value} 次'
            }
          },
         {
            type: 'value',
            name: '',
            //min: 0,
            //max: 250,
            position: 'left',
            //offset: 80,
            axisLine: {
                lineStyle: {
                    color: colors[1]
                }
            },
            axisLabel: {
                formatter: '{value} 次'
            }
        },
        { position: 'left',
            //offset: 80,
            axisLine: {
                lineStyle: {
                    color:'rgba(155,255,255,0)'
                }
            },
        }
    ],
    series: [
        {
            name:'正常',
            type:'bar',
            data:nomalArr
        },
        {
            name:'异常',
            type:'bar',
            yAxisIndex: 1,
            data:specialArr
        },
        {   
         name:'正常',   
          type: 'line',
          data:nomalArr 
        },{     
          name:'异常',   
          type: 'line',
          data:specialArr
        }
    ]
   };
      

   myChartTwo.setOption(option);
    },err=>{
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })

    //  //console.log(data);
  
  }
  render() {

    return (
     <div style={{padding:'15px 0',borderTop:'1px solid #ddd'}}>
       <div>
           <TrendSearchFormUp deviceState={this.props.deviceState} />
       </div>
      
					<Row  style={{ padding: '3px',marginTop:12}} >
					
						<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc',background:"rgb(234, 237, 241)"}}>
               
							<div id="DeviceTypeMountEcharts01" style={{ height: '60vh', width: '100%' }}></div>
						</Card>
				
				</Row>
     </div> 
    );
  }
}
class PatrolManStc extends Component {
	render() {
		return (
			<div><PatrolManStcC deviceState={new deviceState()} /></div>
		)
	}
}
export default PatrolManStc;