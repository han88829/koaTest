/*
 * @Author: Han.beibei 
 * @Date: 2017-05-20 10:45:14 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-14 18:00:53
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Modal, Icon } from 'antd';
import moment from 'moment';
import listStore from '../listStore';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const { genderList, levelList } = listStore;
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

//查部门
var groupNames = [{ name: '/' }];

//查组织
var groupownerNames = [{ name: '/' }];


// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      mData: [],
      selectId: [],
      selectIdOne: null,
      removeSelected: [],
      Value: null,
    })
  }
}

class AdvancedSearchFormOne extends React.Component {
  componentDidMount() {
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    }),
      window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {
        for (let value of result) {
          groupownerNames[value.id] = value;
        }
        sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
      }, (err) => {
        console.warn(err);
      })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const level = fieldsValue['level'];
        const groupId = fieldsValue['groupId'];
        const ownerId = fieldsValue['ownerId'];
        const gender = fieldsValue['gender'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (level) {
          values = { ...values, level: fieldsValue['level'].map(x => parseInt(x, 10)) }
        }
        if (groupId) {
          values = { ...values, groupId: fieldsValue['groupId'].map(x => parseInt(x, 10)) }
        }
        if (ownerId) {
          values = { ...values, ownerId: fieldsValue['ownerId'].map(x => parseInt(x, 10)) }
        }
        if (gender) {
          values = { ...values, gender: fieldsValue['gender'].map(x => parseInt(x, 10)) }
        }
        if (rangeValue) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }

        window.rpc.user.getArrayByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          this.props.appState.tableData = users;
          this.setState({ data: users });
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;

    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let levelChildren = [];
    let groupIdChildren = [];
    let ownerIdChildren = [];
    let genderChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={3} key={2}>
            <FormItem label={`性别`}>
              {getFieldDecorator(`gender`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {genderChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={3}>
            <FormItem label={`等级`}>
              {getFieldDecorator(`level`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={4}>
            <FormItem label={`部门`}>
              {getFieldDecorator(`groupId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {groupIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={5}>
            <FormItem label={`公司`}>
              {getFieldDecorator(`ownerId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {ownerIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={5} key={6}>
            <FormItem label={`加入时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7} style={{ marginTop: 32, marginLeft: 20 }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchFormOne = Form.create()(AdvancedSearchFormOne);
const PopoverPreserve = observer(class appState extends Component {
  constructor() {
    super();
    this.state = {
      data: [],
      selectId: []
    }
  }
  componentDidMount() {
    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    window.rpc.user.getArray(0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = users;
      this.setState({ data: users });
    }, (err) => {
      console.warn(err);
    })

  }
  state = { visible: false, selectedRowKeys: null }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    this.setState({
      visible: false,
    });
    this.props.appState.selectId = this.state.Selected;//添加人员

    window.rpc.position.patrol.user.appendArrayId([...this.props.appState.selectId]).then((result) => {
      message.info("添加成功！")
      window.rpc.position.patrol.user.getArrayByContainer(null, 0, 0).then((result) => {
        let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
        this.props.appState.mData = users;
      }, (err) => {
        console.warn(err);
      })
      // 清楚选中状态
      setTimeout(() => {
        this.setState({
          selectedRowKeys: [],
        })
      }, 1000)
    }, (err) => {
      console.warn(err);
    })

  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    this.setState({ Selected, selectedRowKeys });
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  handelClick = (e) => {
    //console.log(this.state.Selected);
    //console.log(this.state.Value);
    if (this.state.Selected.length !== 0 && this.state.Value) {
      let EquipSelected = this.state.Selected;
      sessionStorage.setItem('EquipPreserve', JSON.stringify(EquipSelected));
    }

  }
  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
        this.setState.Selected = selected;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.Selected = selected;
      },
    };
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/memb/staff/detail/${record.key}`}>详情</Link>
          <span className="ant-divider" />
          <Link to={`/memb/staff/edit/${record.key}`}>编辑</Link>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];
    return (
      <div style={{ float: "left" }}>
        <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.showModal}>添加人员</Button>
        <Modal visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
          style={{ minWidth: 1300, minHeight: 700, marginLeft: 300, marginTop: '-70px' }}
          className="peopleModal"
        >
          <Row style={{ padding: '5px 0 0', }}>
            <WrappedAdvancedSearchFormOne appState={this.props.appState} />
            <Col span={24} style={{ marginTop: 30 }}>
              <Table
                bordered
                columns={columns}
                dataSource={data}
                rowSelection={rowSelection}
              />
            </Col>
          </Row>
        </Modal>
      </div>
    )
  }
})

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {

      for (let value of result) {
        groupownerNames[value.id] = value;
      }
      sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
    }, (err) => {
      console.warn(err);
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const level = fieldsValue['level'];
        const groupId = fieldsValue['groupId'];
        const ownerId = fieldsValue['ownerId'];
        const gender = fieldsValue['gender'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (level) {
          values = { ...values, level: fieldsValue['level'].map(x => parseInt(x, 10)) }
        }
        if (groupId) {
          values = { ...values, groupId: fieldsValue['groupId'].map(x => parseInt(x, 10)) }
        }
        if (ownerId) {
          values = { ...values, ownerId: fieldsValue['ownerId'].map(x => parseInt(x, 10)) }
        }
        if (gender) {
          values = { ...values, gender: fieldsValue['gender'].map(x => parseInt(x, 10)) }
        }
        if (rangeValue) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }

        window.rpc.position.patrol.user.getArrayByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
          this.props.appState.mData = users;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let levelChildren = [];
    let groupIdChildren = [];
    let ownerIdChildren = [];
    let genderChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={3} key={2}>
            <FormItem label={`性别`}>
              {getFieldDecorator(`gender`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {genderChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={3}>
            <FormItem label={`等级`}>
              {getFieldDecorator(`level`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={4}>
            <FormItem label={`部门`}>
              {getFieldDecorator(`groupId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {groupIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={5}>
            <FormItem label={`公司`}>
              {getFieldDecorator(`ownerId`)(
                <Select multiple style={{ width: 150 }} placeholder="请选择">
                  {ownerIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={6}>
            <FormItem label={`加入时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);


const StaffC = observer(class StaffC extends Component {
  componentDidMount() {
    window.rpc.position.patrol.user.getArrayByContainer(null, 0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      this.props.appState.mData = users;
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
  };
  handleChange = (pagination, filters, sorter) => {
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }

  handleStaff = () => {
    if (this.props.appState.selectIdOne != null) {
      browserHistory.push(`/memb/staff/edit/${this.props.appState.selectIdOne}`);
    } else {
      message.info('请选择人员！');
    }

  }
  //人员详情跳转
  handleStaffOne = () => {
    if (this.props.appState.selectIdOne != null) {
      browserHistory.push(`/memb/staff/detail/${this.props.appState.selectIdOne}`);
    } else {
      message.info('请选择人员！');
    }
  }
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
      sorter: (a, b) => a.number - b.number,
      sortOrder: sortedInfo.columnKey === 'number' && sortedInfo.order,
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/memb/staff/detail/${record.key}`}>详情</Link>
          <span className="ant-divider" />
          <Link to={`/memb/staff/edit/${record.key}`}>编辑</Link>
          <span className="ant-divider" />
          <Link to={``} onClick={() => {
            window.rpc.position.patrol.user.removeId(record.key).then((res) => {
              if (res) {
                message.info("删除成功！")
                window.rpc.position.patrol.user.getArrayByContainer(null, 0, 0).then((result) => {
                  let users = result.map((x) => ({ ...x, gender: genderList[x.gender] || '/', ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
                  this.props.appState.mData = users;
                }, (err) => {
                  console.warn(err);
                })
              } else {
                message.info("删除失败，请联系管理员！")
              }
            }, (err) => {
              console.warn(err);
            })
          }}>删除</Link>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.mData];

    const pagination = {
      total: this.props.appState.mData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };

    //表格单选框设置
    const rowSelection = {
      type: 'radio',
      onChange: (selectedRowKeys, selectedRows) => {
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectIdOne = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (
      <div className="ConcenHistory" style={{ padding: '0 15px' }}>
        <div style={{ height: 35, paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 90, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>巡逻人管理</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }}>
            <PopoverPreserve appState={this.props.appState} />
          </div>
          <div style={{ float: 'right', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ backgroundColor: '#00c2de', borderColor: '#00c2de', color: '#fff', width: 130, paddingLeft: 0 }} onClick={() => { browserHistory.push("/memb/patrol/man/detail") }}><Icon type="enter" />个人巡逻详情查看</Button>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ marginTop: 20 }}>
          <Col span={24}>
            <Table
              style={{ color: '#999' }}
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class PatrolMan extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default PatrolMan;