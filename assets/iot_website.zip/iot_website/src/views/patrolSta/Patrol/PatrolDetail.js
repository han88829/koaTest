/*import React, { Component } from 'react';

class PatrolDetail extends Component {
  render() {
    return (
      <div className="PatrolDetail">
        巡查详情
      </div>
    );
  }
}

export default PatrolDetail;*/

import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message,Modal,Icon} from 'antd';
import listStore from '../listStore';
import './PatrolDetail.css';
import warning from '../../../assets/images/task/warning.png';
import moment from 'moment';
import  PatrolDetailImg from './PatrolDetailImg';
import detail_img from '../../../assets/images/task/detail.png';
import imgShow_img from '../../../assets/images/task/imgShow.png';
import write_img from '../../../assets/images/task/write.png';
import abnormal_img from '../../../assets/images/task/abnormal.png';
//const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

message.config({
  top: 216,
  duration: 2
})

//结构出参量表
const { warningType, resultsType } = listStore;

//取出设备类型和建筑
//let dtypes = JSON.parse(sessionStorage.getItem('dtypes'));
//let fildes = JSON.parse(sessionStorage.getItem('fields'));
//let locations = JSON.parse(sessionStorage.getItem('locations'));

// class patrolState {
//   @observable timer = 0;
//   @observable tableData = [];

//   add() {
//     this.tableData.push({ key: 4, id: 4, sign: '$', name: 'John Brown', dtype:'烟感', warningDate: '2016-09-26 08:50:08', installDate: '2015-09-26 08:50:08', address: 'New York No. 1 Lake Park', condition: '正常', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is John Brown, I am 32 years old, living in New York No. 1 Lake Park.' })
//   }
// }
class patrolState {
  constructor() {
    extendObservable(this, {
      timer: 0,
      tableData: [],
      obj:{},
      values:{},
      num:null
    
    })
  }
}
class AdvancedSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      types: []
    }
  }
  componentWillMount(){
    window.rpc.user.getArrayIdNameByContainer({},0,10).then(data=>{
      let types=data.map((x)=>({...x}))
      this.setState({
        types
      })
    },err=>{
      console.log(err);
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        //console.log(fieldsValue);
        const rangeValueOne = fieldsValue['setupTime'];
        const rangeValueTwo = fieldsValue['endTime'];
       // const name = fieldsValue['name'];
        const userId = fieldsValue['userId'];
       // const lastPatrolDate = fieldsValue['lastPatrolDate'];
        //const filde = fieldsValue['field-7'];
        const condition = fieldsValue['condition'];
        let values = {};
        // if (name) {
        //   values = { ...values, name }
        // }
        if (userId) {
          values = { ...values,userId: fieldsValue['userId'].map(x => parseInt(x, 10)) }
        }
        // if (condition) {
        //   values = { ...values, condition}//: fieldsValue['filde'].map(x => parseInt(x, 10))
        
        // }
        if (rangeValueOne&&rangeValueTwo) {
          //console.log(rangeValueOne);
          values = { ...values,createTime: [new Date(rangeValueOne.format('YYY-MM-DD')), new Date(rangeValueTwo.format('YYY-MM-DD'))] }
        }
        //console.log(values);
        this.props.patrolState.values=values;
        //  if (rangeValueTwo) {
        //   values = { ...values, rangeValueTwo: [new Date(rangeValueOne[0].format('YYY-MM-DD')), new Date(rangeValueOne[1].format('YYY-MM-DD'))] }
        // }

        console.log('Received values of form: ', values);
     window.rpc.position.log.getArrayByContainer({values},0,0).then((num) =>{
        
        this.props.patrolState.num=num.length;
        //console.log(num.length)
        message.info(`共搜索到${num.length}条数据`);
     },(err) =>{
        //console.warn(err);
     })
        window.rpc.cache.position.getMapIdNameByContainer(null, 0, 0).then(res=>{

  
       window.rpc.cache.user.getMapIdNameByContainer({},0,0).then(data=>{

         window.rpc.cache.alias.getValueByName('position.state').then(state=>{

         window.rpc.position.log.getArrayByContainer({values},0,10).then((result) => {
          //console.log(result);
      
          let devices = result.filter(x => x.rstate !== 1).map((x) => ({ ...x,key:x.id,pstate:state[x.state]||'未知',state:x.state,userId:data[x.userId]||x.userId,positionId:res[x.positionId]||x.positionId, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
         // console.log(devices);
          this.props.patrolState.tableData = devices;
        }, (err) => {
          console.warn(err);
        })
       }, (err) => {
          console.warn(err);
        })
       }, (err) => {
          console.warn(err);
       })
      }, (err) => {
          console.warn(err);
     })   
      });
    } catch (e) {
      console.warn(e);
    }
  }


  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes=this.state.types||[];
    //let fildes = JSON.parse(sessionStorage.getItem('fildes')) || [];
    let dtypeChildren = [];
    // let fildeChildren = [];
    // let waringstateChildren = [];
    // let destateChildren = [];

    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    // for (let value of fildes) {
    //   if (value && value.id) {
    //     fildeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
    //   }
    // }
    // for (let i = 1; i < warningType.length; i++) {
    //   waringstateChildren.push(<Option key={`${i}`}>{warningType[i]}</Option>)
    // }
    // for (let i = 1; i < resultsType.length; i++) {
    //   destateChildren.push(<Option key={`${i}`}>{resultsType[i]}</Option>)
    // }

    return (
      <Form inline style={{padding:'12px 0 10px 0'}}>
         <Row>
           <div key={1} className="Row-info-patrol patrolClearfix">
             <div style={{float:'left',marginRight:5,height:32,lineHeight:'32px',fontSize:12}}>
               <span>开始时间：</span>
             </div>
              <FormItem   style={{float:'left'}}>
                  {getFieldDecorator(`setupTime`)(
                    <DatePicker
                       showTime
                       format="YYYY-MM-DD HH:mm:ss"
                       placeholder="请选择开始时间"
                       style={{ width: 220 }}
                     />
                  )}
                </FormItem>
              </div>
              <div key={2} style={{height: '32px',lineHeight: '32px',float:'left'}}>
                 <span style={{paddingLeft:0,fontSize:12,paddingRight:8}}>至</span>
              </div>
               <div className="Row-info-patrol patrolClearfix">
             <div key={3} style={{float:'left',marginRight:5,height:32,lineHeight:'32px',fontSize:12}}>
               <span>结束时间：</span>
             </div>
                <FormItem   style={{float:'left'}}>
                  {getFieldDecorator(`endTime`)(
                    <DatePicker 
                       showTime
                       format="YYYY-MM-DD HH:mm:ss"
                       placeholder="请选择结束时间"
                       style={{ width: 220 }} 
                     />
                  )}
                </FormItem>
              </div>
             <div key={4} className="Row-info-patrol patrolClearfix">
             <div style={{float:'left',marginRight:5,height:32,lineHeight:'32px',fontSize:12}}>
               <span>巡逻人：</span>
             </div>
                <FormItem   style={{float:'left'}}>
                  {getFieldDecorator(`userId`)(
                    <Select multiple style={{ width: 220 }} placeholder="请选择">
                      {dtypeChildren}
                    </Select>
                  )}
                </FormItem>
              </div>
              <div key={5} className="search-btn" >
                <FormItem style={{ float: 'right', marginRight: '10px' }}>
                  <Button
                    type="primary"
                    onClick={this.handleSearch}
                    style={{ height: '32px', width: '80px', padding: 0, margin: 0, fontSize: '0.75rem' }}
                  >
                    搜索
                 </Button>
             </FormItem>
          </div>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

// @observer
// class EquipWarningC extends Component {
let number = 0;
const PatrolDetailC = observer(class patrolState extends React.Component {
  state={
   visible:false,
   obj:{},
   userIdObj:{},
   positionIdObj:{},
   positionStateObj:{},
   images:[],
   Obj:{}

  }
  componentDidMount() {
    let type = this.props.params;
    let obj = {};
    switch (type.type) {
      case '1':
        obj = {rstate:1}
        break;
      case '2':
        obj = {rstate:2}
        break;
      case '3':
        obj = {rstate:3}
        break;
      default:
        obj = {}
        break;
    }
    //console.info(type,obj);
    window.rpc.position.log.getCount().then(res => {
      //number = res;
      this.props.patrolState.num=res;
      //console.log(res);
    });
     window.rpc.cache.position.getMapIdNameByContainer(null, 0, 0).then(res=>{

  
       window.rpc.cache.user.getMapIdNameByContainer({},0,0).then(data=>{

         window.rpc.cache.alias.getValueByName('position.state').then(state=>{

         window.rpc.position.log.getArrayByContainer({},0,10).then((result) => {
          console.log(result);
          let devices = result.filter(x => x.rstate !== 1).map((x) => ({ ...x,key:x.id,pstate:state[x.state]||'未知',state:x.state,userId:data[x.userId]||x.userId,positionId:res[x.positionId]||x.positionId, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
          //console.log(devices);
          this.props.patrolState.tableData = devices;
        }, (err) => {
          console.warn(err);
           console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
        }, (err) => {
          console.warn(err);
        })
       }, (err) => {
         console.warn(err);
       })
      }, (err) => {
        console.warn(err);
     })   
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) };
    this.setState({ Selected });
     //this.props.patrolState.tableData=
  }

  //详情跳转
 
  cancel() {
    message.error('已取消');
  }
  showModal=(index,record)=>{
    console.log(index);
    console.log(record);
    let id=parseInt(index,10);
    let Obj={};
    Obj={...record,point:record.positionId,time:record.createTime,remark:record.remark};
    let images=[...record.images];
    this.setState({
      images:images,
      Obj
    });
    window.rpc.position.log.getInfoById(id).then(data=>{
       console.log(data);
    })
   this.setState({
      visible: true
    });
  }
 handleOk=(e)=>{
   //console.log(e);
    this.setState({
      visible: false,
    });
   // console.log(this.state.Selected);
    this.props.appState.selectId = this.state.Selected;
    //console.log(this.state.Selected);
    //{id:[46, 45, 34, 31, 19, 15, 8, 7, 6, 5]},0,0
  
    //this.props.appState.mData = 
 }
 handleCancel=(e)=>{
   //console.log(e);
    this.setState({
      visible: false,
    });
 }

  handleSearch = (e) => {
    e.preventDefault();
    //console.log(this.props.form);
    this.props.form.validateFields((err, values) => {
     // console.log('Received values of form: ', values);
    });
  }

  add() {
    this.props.patrolState.tableData.push({ key: 4, id: 4, sign: '$', name: 'John Brown', dtype: '烟感', warningDate: '2016-09-26 08:50:08', installDate: '2015-09-26 08:50:08', address: 'New York No. 1 Lake Park', condition: '正常', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is John Brown, I am 32 years old, living in New York No. 1 Lake Park.' })
  }

  maintain() {
    message.success('保养成功');
  }

  check() {
    message.success('检测成功');
  }

  // cancel() {
  //   message.error('已取消');
  // }

  render() {
    const rowSelection = {
      //type: 'radio',
      onChange: this.onSelectChange,
    };
    const columns = [
      { title: 'ID', dataIndex: 'id', key: 'id' },
      {
        title: '巡逻点名称', dataIndex: 'positionId', key: 'positionId', render: (text, record) => (
          <span>
          {text}
          </span>
        )
      },
      { title: '巡查人', dataIndex: 'userId', key: 'userId' },
      { title: '巡查时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '巡逻结果', dataIndex: 'state', key: 'state', render: (text, record,index) => {
          if(text=="1"){
            return(
               <span   style={{color:'green'}}>
                {"正常"}
               </span>
            )
        
        }else if(text=="2"){
             return(
               <span onClick={()=>this.showModal(index,record)} style={{color:'red',position:'relative'}}>
                {"异常"}<img style={{paddingLeft:8,position:'absolute',top:0}} src={abnormal_img} alt="" />
               </span>
            )
        }else{
             return(
               <span style={{}}>
                {"未巡查"}
               </span>
            )
        }
         
      }
      
        },
      /*{
        title: '操作', dataIndex: '', key: 'x', render: (text, record,index) => (
          <span>
            <Link to={``}   onClick={()=>this.showModal(index)} style={{ color: '#0099cc' }}>查看详情</Link>
          </span>
        )
      },*/
    ];

    const data = [...this.props.patrolState.tableData];
    //console.log(data);
    const pagination = {
      total:this.props.patrolState.num,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        //console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        //console.log('Current: ', current);
        const pageNum = (parseInt(current, 10) - 1) * 10;
        //再调用
        //得到values  
        let values=this.props.patrolState.values||{};
        let value={};
        if(values.createTime){
           value={...values,createTime:[...values.createTime]};
        }else{
           value={};
        }

        //let value={...values,createTime:[...values.createTime]};
        //console.log(value);
        // let values={...this.props.appState.values};
        window.rpc.cache.position.getMapIdNameByContainer(null, 0, 0).then(res=>{

  
         window.rpc.cache.user.getMapIdNameByContainer({},0,0).then(data=>{

         window.rpc.cache.alias.getValueByName('position.state').then(state=>{

         window.rpc.position.log.getArrayByContainer(value,pageNum,10).then((result) => {
          console.log(result);
          let devices = result.filter(x => x.rstate !== 1).map((x) => ({ ...x,pstate:state[x.state]||'未知',state:x.state,userId:data[x.userId]||x.userId,positionId:res[x.positionId]||x.positionId, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
          //console.log(devices);
          this.props.patrolState.tableData = devices;
        }, (err) => {
          console.warn(err);
        })
       }, (err) => {
          console.warn(err);
        })
       }, (err) => {
          console.warn(err);
       })
      }, (err) => {
          console.warn(err);
     })   
      },
    };
    return (
      <div className=" OrgManage" style={{ padding: 0 }}>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 104, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/equip/warning' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>巡逻详情查看</Link>
          </div>
          <div style={{float:'left',width:152,height:32,marginRight:4}}>
             <PatrolDetailImg />
            {/*<Button type="" style={{ background: 'rgb(0, 193, 222)', padding: '0 15px', width: 134, paddingLeft: 0 ,height: '32px', borderRadius: 0, color: '#fff' }} onClick={this.handleStaffOne}><Icon type="enter" />实时签到平面图</Button>*/}
          </div>
           {/*<div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button  onClick={this.showModalOne} style={{background:'rgb(0, 193, 222)',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0,fontSize:'0.875em'}} ><Link to={``} onClick={this.handelClick} >删除</Link></Button>
           
            <Modal title="删除巡逻列表" 
              visible={this.state.visibleOne}
              onOk={this.handleOkOne}
              onCancel={this.handleCancelOne}
              style={{height:260,position: 'absolute',left:'50%',marginLeft: '-380px',padding:'0 22px'}}
              className="patrolrModalOne"
            >
            
             <Row type="flex" justify="start"  style={{padding:'12px 20px 28px 20px',height:120,width:'700px'}}>
               <Col span={2} ><span ><img src={`${warning}`} alt=""/></span></Col>
               <Col span={18} >
                   你确定要删除巡逻详情列表吗？
               </Col>
             </Row>
            
          </Modal>    
       
          </div>*/}
        </div>
        <WrappedAdvancedSearchForm patrolState={this.props.patrolState} /> 
        <Modal 
          title="巡逻结果异常信息" 
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          style={{height:510,position: 'absolute',left:'50%',marginLeft: '-400px',width:800,padding:'0 22px'}}
          className="patrolrModal"
         >
           <div style={{width:'96%',position:'absolute',marginLeft:'0px'}}>
            <Row style={{ padding: '5px 0 0' }}>
              <Row type="flex" justify="start" style={{lineHeight:'50px',height:50,fontSize:20,color:'#555'}}>
                <h3><img src={detail_img} style={{position:'absolute',top:20}} alt=""/><span style={{paddingLeft:30}}>记录详情</span></h3>
              </Row>
              <Row type="flex" justify="start"  style={{linHeight:'30px',padding:'0 0 0 12px',height:30,background:'#fff'}}>
                 <div>
                   <p style={{width:'100%',lineHeight:'30px',height:30}}><Icon type="edit" />{this.state.Obj.remark||''}</p>
                 </div>
              </Row>
              <Row type="flex" justify="start"  style={{lineHeight:'30px',height:180,background:'#fff',boxShadow:"0 0 2px #ccc"}}>
                  <p style={{width:'100%',lineHeight:'30px',padding:'0 0 0 12px',height:30}}><Icon type="camera" /><span style={{color:'#ccc'}}>图片</span>{`${this.state.images.length}/${this.state.images.length}`}</p>
                  <Row style={{height:150,width:'100%',}}>
                    {this.state.images.map((point,index)=>(
                        <Col span={4} key={index}>
                          <img src={point} alt="" style={{padding:10,width:150,height:150}} />
                        </Col>
                    ))}
                   
                  </Row>
              </Row>
              <Row type="flex" justify="start"  style={{lineHeight:'30px',height:60,background:'#fff',marginTop: 15,boxShadow:"0 0 2px #ccc"}}>
                 <p style={{width:'100%',paddingLeft:12,boxShadow:"0 0 2px #ccc"}}>{this.state.Obj.time||''}</p>
                 <p style={{width:'100%',paddingLeft:12}}>{this.state.Obj.point||''}</p>
              </Row>
             </Row>
            </div>
        </Modal>    
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={data}
              pagination={pagination}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})

class PatrolDetail extends Component {
  render() {
    return (
      <PatrolDetailC patrolState={new patrolState()} params={this.props.params} />
    )
  }
}

export default PatrolDetail;