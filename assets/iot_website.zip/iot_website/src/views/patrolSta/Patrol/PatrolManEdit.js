/*
 * @Author: Han.beibei 
 * @Date: 2017-05-20 10:45:59 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-05-20 16:52:53
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Icon } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import './PatrolMan.css';

const FormItem = Form.Item;

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
    })
  }
}

const NewStaffMes = observer(Form.create()(React.createClass({
  getInitialState() {
    return {
    };
  },
  componentDidMount() {
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let { name, username, mobile, } = values;
        let obj = { name, username, mobile: parseInt(mobile, 10), };
        console.log(values)
        // window.rpc.user.create(obj).then(() => {
        //   message.info('创建成功！')
        //   browserHistory.push('/memb/staff');
        // }, (err) => {
        //   console.log(err);
        // })

      }
    });
  },
  //验证手机号
  checkAccount(rule, value, callback) {
    var regex = /^0\d{2,3}-?\d{7,8}$|^((\+)?86|((\+)?86)?)0?1[3578]\d{9}$/;
    if (regex.test(value)) {
      callback();
    } else {
      callback('请输入正确的电话号码');
    }
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 2 },
      wrapperCol: { span: 22 },
    };
    return (
      <div className="PatrolManEdit" style={{ position: 'relative' }}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 96, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/patrol/point' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>巡逻人管理</Link>
          </div>
          <div style={{ float: 'right', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ backgroundColor: '#00c2de', borderColor: '#00c2de', color: '#fff', width: 130, paddingLeft: 0 }} onClick={() => { browserHistory.push("/memb/patrol/man/detail") }}><Icon type="enter" />个人巡逻详情查看</Button>
          </div>
        </div>
        <div style={{ width: '100%', height: 30, backgroundColor: '#f9f9f9', marginTop: 20, paddingLeft: 10, border: "1px solid #ddd" }}>
          <span style={{ color: '#666666', fontSize: 12, fontFamily: '苹方中等' }}>以下信息仅仅针对于巡逻人设置，以方便于我们更好的联系。</span>
        </div>
        <Form onSubmit={this.handleSubmit} className="PatrolManEdit-form" style={{ textAlign: 'left', marginTop: 20 }}>
          <div style={{ fontSize: 12 }}><span style={{ fontWeight: 'blod', fontSize: 14, color: '#666666', }}>基本信息设置</span></div>
          <FormItem
            {...formItemLayout}
            label="用户名："
            hasFeedback
            style={{ marginTop: 20 }}
          >
            {getFieldDecorator('username', {
              rules: [{ required: true, message: '请输入用户名!' }],
            })(
              <Input style={{ width: "100%" }} />
              )}
          </FormItem>
          <FormItem
            {...formItemLayout}
            label="姓名："
            hasFeedback
            style={{ marginTop: 20 }}
          >
            {getFieldDecorator('name', {
              rules: [{ required: true, message: '请输入姓名!' }],
            })(
              <Input style={{ width: "100%" }} />
              )}
          </FormItem>
          <FormItem
            {...formItemLayout}
            label="手机号："
            hasFeedback
            style={{ marginTop: 20 }}
          >
            {getFieldDecorator('mobile', {
              rules: [{ required: true, message: '请输入手机号!' }, {
                validator: this.checkAccount,
              }],
            })(
              <Input style={{ width: "100%" }} />
              )}
          </FormItem>
          <div style={{ position: 'absolute', bottom: '-80px' }} className="search-btn" >
            <FormItem >
              <Button onClick={this.handleSubmit} style={{ borderRadius: 0 }}> 增加</Button>
              <Button style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', marginLeft: 10, borderRadius: 0 }}>修改</Button>
              <Button style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', marginLeft: 10, borderRadius: 0 }}>删除</Button>
            </FormItem>
          </div>
        </Form>
      </div>
    );
  }
})));

class PatrolManDetail extends Component {
  render() {
    return (
      <div className="NewStaff">
        <NewStaffMes appState={new appState()} />
      </div>
    );
  }
}

export default PatrolManDetail;