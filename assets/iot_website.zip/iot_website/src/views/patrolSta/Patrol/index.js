/*import React, { Component } from 'react';

class Patrol extends Component {
  render() {
    return (
      <div className="Patrol">
        Patrol管理
      </div>
    );
  }
}

export default Patrol;*/
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import moment from 'moment';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Icon } from 'antd';
import compliance_pic from '../../../assets/images/application/达标率.png';
import warning_pic from '../../../assets/images/application/告警率.png';
import Probability_pic from '../../../assets/images/application/巡更频率.png';
import Cycle_pic from '../../../assets/images/application/巡逻周期.png';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import './PatrolDetail.css';
import $ from 'jquery';
const dateFormat = 'YYYY-MM-DD';
const FormItem = Form.Item;

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      lenData:[],
      len:null,
      PatrolProb:null,
    })
  }
}

const NewStaffPatrolMes = observer(Form.create()(React.createClass({
  getInitialState() {
    return {
      len:0,
      prob:0,
      id:0
    };
  },
  componentWillMount() {
     window.rpc.position.patrol.schedule.getInfoAndCreate({}).then(data=>{
       console.log(data);  
          this.setState({
          
          id:data.id
             
      })
      //for(let i=0;i<data.table.length;i++){
        let fz=data.table.length;
        let startHour=data.createTime.getHours();
          let startHour1=data.table[0].getHours();
          let startHourM=data.table[fz-1].getHours();
          let len=startHourM-startHour1;
          //console.log(startHour);
          //console.log(len);
          //巡逻周期，len data lenTable//需要存暂时时间
          let tableNew=[];
          for(let i=0;i<data.table.length;i++){

            let startHourI=data.table[i].getHours()-startHour;
            tableNew.push(startHourI);
          }
          console.log(tableNew);
      //}
      let alarmRate=data.alarmRate||'';
      let completeRate=data.completeRate||'';
       this.props.form.setFieldsValue({
          warning:alarmRate,
          Compliance:completeRate,
          createTime:moment(data.createTime, dateFormat),
          PatrolCycle:`${data.extend.len}`||``,
          PatrolProbability:`${data.table.length}`
      });
      console.log(data.id);
      this.setState({
          len:parseInt(data.extend.len,10),
          prob:parseInt(fz,10), 
          id:parseInt(data.id,10)
             
      })
       //this.props.appState.lenData=;
       this.props.appState.len=parseInt(data.extend.len,10)||null;
       this.props.appState.PatrolProb=parseInt(fz,10)||null;
       this.props.appState.lenData=data.extend.lenData.map(x=>parseInt(x,10))||[];
    },err=>{
       console.log(err);
    })
  },
  componentDidMount() {
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      function getDaysInOneMonth(year, month){  
         month = parseInt(month, 10);  
         var d= new Date(year, month, 0);  
         return d.getDate();  
     }
      if (!err) {
        let {warning,Compliance,PatrolCycle,PatrolProbability} = values;
        //let obj = { name, username, mobile: parseInt(mobile, 10), };
        //console.log(values)
        // window.rpc.user.create(obj).then(() => {
        //   message.info('创建成功！')
        //   browserHistory.push('/memb/staff');
        // }, (err) => {
        //   console.log(err);
        // })
        //setupTime: [new Date(rangeValueOne.format('YYY-MM-DD')), new Date(rangeValueTwo.format('YYY-MM-DD'))]
       
       // console.log(values.startTime);
       let startTime=new Date(values.createTime);
        //let startTime=new Date(values.createTime.format('YYY-MM-DD HH:mm:ss'));
         //console.log(startTime);
         //以什么开始以什么结束
         //var startHour=`${startTime}`.substring(18,20);
         //console.log(startHour);
         //得到当前年月日
         let startHour=startTime.getHours();
         let startMonth=startTime.getMonth()+1;
         let startYear=startTime.getFullYear();
         let startWeekDay=startTime.getDay();
         // console.log( startMonth+'--'+startYear);
         let monthDay=getDaysInOneMonth(startYear,startMonth);
          let monthArr=['Jan','Feb','Mat','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
         let weekDayArr=['Mon','Tus','Wed','Thu','Fri','Sat','Sun'];
        // console.log(monthDay);
         //console.log(startHour);//10
         //let lenData=[...this.props.appState.lenData];
         let length= this.props.appState.PatrolProb;
         //console.log(lenData[1]);
         //console.log(length);
        // let length=lenData.length-1;
         let len=this.props.appState.len;
         let lenDataOne=[...this.props.appState.lenData];
         if(lenDataOne[length-1]>len){
             message.info("已超出巡逻周期，请重新划分时间")
         }else{
            let tableA=[];
             let lenData=[...this.props.appState.lenData];
            for(let i=0;i<length;i++){
              //  let e=getDaysInOneMonth(2017, 6);
              
               // console.log(lenData)
               let lenDataI=lenData[i]
               let newHours=startHour+lenDataI;
               let newHour=newHours%24;
               let newDay=parseInt(newHours/24,10);
               //if(newDay/)
              
               //console.log(newDay);
                if(newHour<10){
                    newHour=`0${newHour}`;
                  }
               let b=`${startTime}`.replace(` ${startHour}:`,` ${newHour}:`);
               //如果换天
               if(newDay){
                 //console.log(startTime);
                 let startDay=startTime.getDate();
                 //console.log(startDay);
                 let newWeekDay=(startWeekDay+newDay)%7;
                 newDay+=startDay;
                 //console.log(newDay);
                 let newDays=newDay%monthDay;
                 let newMonth=parseInt(newDay/monthDay,10);
                  if(startDay<10){
                    startDay=`0${startDay}`;
                  }
                 
                  if(newDay<10){
                      newDays=`0${newDays}`;
                  }
                    b=b.replace(` ${startDay} `,` ${newDays} `);
                    //console.log(newWeekDay);
                    b=b.replace(`${ weekDayArr[startWeekDay-1]} `,`${ weekDayArr[newWeekDay-1]} `);
                    //console.log(b)
                    //如果巡查进入下一个月份
                  if(newMonth){
                     newMonth+=startMonth;
                    //console.log(newMonth);
                    b=b.replace(` ${monthArr[startMonth-1]} `,` ${monthArr[newMonth-1]} `);
                  }
                 
                  ;
               }
               b=new Date(b);
               tableA.push(b);
               //console.log(b)
          }
          //console.log(tableA);
          //let lenData=[this.props.appState.lenData] ;           
          let value={...values,createTime:startTime,extend:{len:this.props.appState.len,lenData:lenData},table:tableA,completeRate:parseFloat(values.Compliance,10),alarmRate:parseFloat(values.warning,10)};
          //values = { ...values,  }
          console.log(value);
          //console.log(this.state.id);
          window.rpc.position.patrol.schedule.setInfoById(this.state.id,value).then(data=>{
            console.log(data);  
            if(data){
              message.info("巡逻设置保存成功")
            }
          },err=>{
           console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);

          })
       }
      

      }
    });
  },
 handleChangeLen(e){
    const form = this.props.form;
    let len= form.getFieldValue('PatrolCycle');
    console.log(len);
    this.setState({
      len
    })
    // let lenData=[];
    // for(let i=0;i<=len;i++){
    //   lenData.push(i);
    // }
    // console.log(lenData);
    // this.props.appState.lenData=lenData;
    this.props.appState.len=len;
 },
 handleChange(e){
    const form = this.props.form;
    let prob= parseInt(form.getFieldValue('PatrolProbability'),10);
    console.log(prob);
    this.setState({prob});
   this.props.appState.PatrolProb= prob;

   let len = this.props.appState.len;
    let IData=[];
    let every=len/(prob+1);
    console.log(every);
    for(let i=1;i<=prob;i++){
         let num=parseInt(i*every,10);
         IData.push(num);
    }
    let lenData=IData;
    console.log(lenData);
    this.props.appState.lenData=lenData;
 },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 2 },
      wrapperCol: { span: 22 },
    };
    return (
      <div className="PatrolSetForm" style={{ position: 'relative' }}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 96, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>巡逻设置</Link>
          </div>
          {/*<div style={{ float: 'right', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ backgroundColor: '#00c2de', borderColor: '#00c2de', color: '#fff', width: 130, paddingLeft: 0 }} onClick={() => { browserHistory.push("/memb/patrol/man/detail") }}><Icon type="enter" />个人巡逻详情查看</Button>
          </div>*/}
        </div>
        {/*<div style={{ width: '100%', height: 30, backgroundColor: '#f9f9f9', marginTop: 20, paddingLeft: 10, border: "1px solid #ddd" }}>
          <span style={{ color: '#666666', fontSize: 12, fontFamily: '苹方中等' }}>以下信息仅仅针对于巡逻人设置，以方便于我们更好的联系。</span>
        </div>*/}
        <Form  className="PatrolManEdit-form" style={{ textAlign: 'left', marginTop: 20,fontSize: 12 }}>
          <div  className="Row-info-left clearfix">
           <div style={{float:'left',marginRight:24,height:18,lineHeight:'18px',marginTop:10}}>
               <img src={warning_pic} style={{position:'absolute',left:27}} alt=""/>
               <span style={{ paddingLeft: 46}}>告警率：</span>
             </div>
            <FormItem
                 style={{float:'left'}}
                 hasFeedback
            >
              {getFieldDecorator('warning', {
                rules: [{ required: true, message: '请输入用户名!' }],
              })(
                <Input style={{ width: "400px" }} placeholder="请填写" />
              )}
            </FormItem>
          </div>
        <div  className="Row-info-left clearfix">
           <div style={{float:'left',marginRight:24,height:18,lineHeight:'18px',marginTop:10}}>
               <img src={compliance_pic} style={{position:'absolute',left:27}} alt=""/>
               <span style={{ paddingLeft: 46}}>达标率：</span>
           </div>
          <FormItem
            hasFeedback
            style={{float:'left'}}
          >
            {getFieldDecorator('Compliance', {
              rules: [{ required: true, message: '请输入姓名!' }],
            })(
              <Input style={{ width: "400px" }}  placeholder="请填写"  />
            )}
          </FormItem>
        </div>
        <div  className="Row-info-left clearfix">
          <div style={{float:'left',marginRight:12,height:18,lineHeight:'18px',marginTop:10}}>
            <img src={Cycle_pic} style={{position:'absolute',left:27}} alt=""/>
            <span style={{ paddingLeft: 46}}>开始时间：</span>
          </div>
          <FormItem
            hasFeedback
            style={{float:'left'}}
          >
            {getFieldDecorator('createTime', {
              //rules: [{ required: false ,message: '请输入巡逻周期!' }, {}],
            })(
                <DatePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder="请选择开始时间"
                  style={{ width: 400 }}
               />
            )}
          </FormItem>
        </div>
        <div  className="Row-info-left clearfix">
           <div style={{float:'left',marginRight:12,height:18,lineHeight:'18px',marginTop:10}}>
               <img src={Cycle_pic} style={{position:'absolute',left:27}} alt=""/>
               <span style={{ paddingLeft: 46}}>巡逻周期：</span>
             </div>
          <FormItem
            hasFeedback
            style={{float:'left'}}
          >
            {getFieldDecorator('PatrolCycle', {
              rules: [{ required: true ,message: '请输入巡逻周期!' }, {
              }],
            })(
              <Input style={{  width: "400px"  }}  placeholder="请填写并以空格结束" onBlur={this.handleChangeLen}  />
            )}
            </FormItem>
          </div>
          <div  className="Row-info-left clearfix">
             <div style={{float:'left',marginRight:12,height:18,lineHeight:'18px',marginTop:10}}>
               <img src={Probability_pic} style={{position:'absolute',left:27}} alt=""/>
               <span style={{ paddingLeft: 46}}>巡逻频率：</span>
             </div>
             <FormItem
              hasFeedback
              style={{float:'left'}}
             >
              {getFieldDecorator('PatrolProbability', {
                rules: [{ required: true ,message: '请输入巡逻频率!' }, {
                  validator: this.checkAccount,
                }],
              })(
                <Input style={{  width: "400px" }}  placeholder="请填写并以空格结束" onBlur={this.handleChange} />
              )}
          </FormItem>
         </div>
          <div style={{ position: 'absolute', bottom: '-380px' }} className="search-btn" >
            <FormItem >
              <Button onClick={this.handleSubmit} style={{ borderRadius: 0 }}>保存</Button>
              <Button style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '12px', fontFamily: '微软雅黑', marginLeft: 10, borderRadius: 0 }}>取消</Button>
            </FormItem>
          </div>
        </Form>
      </div>
    );
  }
})));
const PatrolC = observer(class appState extends React.Component {
  handleProlClick=(index)=>{
    console.log(index);
    let lenData=[...this.props.appState.lenData];
    let lLen=lenData.length-1;
    let prol=lLen/index;
    this.props.appState.PatrolProb=prol;
  }
  handleMouseMove=(index)=>{
    let thisA=this;
    let Index=index+1;
    var scroll = document.getElementById(`scroll`);
    var bar = document.getElementById(`bar${Index}`);
    var mask = document.getElementById(`mask`);
    //console.log(bar);
    //console.log(scroll);
      var p = document.getElementById(`Text${Index}`);
    //let ptxt=$(`.progressText${index+1}`);
    //console.log(p);
    var len=this.props.appState.len||8;   
    console.log(this.props.appState.len);
    var barleft = 0;
    bar.onmousedown = function(event){
      var event = event || window.event;
      var leftVal = event.clientX - this.offsetLeft;
      var that = this;
       // 拖动一定写到 down 里面才可以
      document.onmousemove = function(event){
        var event = event || window.event;
        barleft = event.clientX - leftVal;     
        if(barleft < 0)
          barleft = 0;
        else if(barleft > scroll.offsetWidth - bar.offsetWidth)
          barleft = scroll.offsetWidth - bar.offsetWidth;
          //mask.style.width = barleft +'px' ;
          that.style.left = barleft + "px";//bar小方块定位位置
           p.style.left = barleft + "px";
          let lenEle=parseInt(barleft/(scroll.offsetWidth-bar.offsetWidth) * len,10);
            console.log(lenEle)
      
          //替换元素
          let lenData=[...thisA.props.appState.lenData];
          lenData[index]=lenEle;
          //console.log(lenData);
          // //console.log(lenEle) ;   
          // if(index==0){
          //  // console.log(index)
          //       let lenBefore=lenData[index];
          //      lenData[index]=lenEle;
             
          //       //console.log(lenBefore);//改编前第一个元素的值
          //       //   console.log(lenEle);//本次选中的间隔
          //        //  console.log(lenData[1]);//之前该元素的值
          //     for(let j=index+1;j<lenData.length;j++){
          //          lenData[j]=lenData[j]-lenBefore+lenEle;
                  
          //      } 
          // }else{
          //   //  let lenS=0;
          //   //  for(let i=0;i<index;i++){
          //   //    lenS+=lenData[i];
          //   //  }
          //     let lenBefore=lenData[index-1];
          //     let beforeIndex=lenData[index];
          //     lenData[index]=lenEle+lenBefore;
          //     for(let j=index+1;j<lenData.length;j++){
          //          lenData[j]= lenData[j]+lenEle+lenBefore-beforeIndex;
          //      }
          // }
         //p.innerHTML = "巡逻间隔已选择" + parseInt(barleft/(scroll.offsetWidth-bar.offsetWidth) * len) + "小时";
          p.innerHTML = "" + lenEle + "h";
          //console.log(lenData);
          thisA.props.appState.lenData=lenData;
          console.log(lenData);
          //防止选择内容--当拖动鼠标过快时候，弹起鼠标，bar也会移动，修复bug
          window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
      }
 
    }
    document.onmouseup = function(){
      document.onmousemove = null; //弹起鼠标不做任何操作
    }
  }
//class PatrolC extends Component {
  render() {
    console.log(this.props);
    //let lenData=[...this.props.appState.lenData]||[];
    let len=this.props.appState.len;
    let IndexNum=parseInt(this.props.appState.PatrolProb,10);
    let IData=[];
    let every=len/IndexNum;
    console.log(every);
    for(let i=1;i<=IndexNum;i++){
        // let num=i*every;
         IData.push(i);
    }
    console.log(IData);
    let IndexData=IData;
    //if()
   
console.log(len/(IndexNum+1))
    return (
      <div className="NewStaff">
        <NewStaffPatrolMes appState={this.props.appState} />
        <div style={{fontSize:12}}>
         
             <div  className="progress"  id={`progress`} style={{display:len?'block':'none'}}>
                <div style={{position:'absolute',left:120,top:20}}>0h</div>
                 <div className="scroll" id={`scroll`}>
                   <span>{`巡逻时间点确定：`}</span>
                    {IndexData.map((point,index) => (
                      <div key={index+1}>
                        <div key={index} className="bar" id={`Text${index+1}`} onMouseMove={()=>this.handleMouseMove(index)} id={`bar${index+1}`} style={{left: `${500/(parseInt(IndexNum,10)+1)*(index+1)}px`}}></div> 
                        <span className={`progressText`} id={`Text${index+1}`} style={{left: `${500/(parseInt(IndexNum,10)+1)*(index+1)}px`}}>{parseInt(len/(IndexNum+1)*(index+1),10)}h</span>
                      </div>
                    ))}
                   <div className="mask" id={`mask`} style={{width: `0px`}}></div>
                 </div>
                 <div  style={{position:'absolute',left:610,top:20}}>{len}h</div>     
             </div>
            
          
        </div>
      </div>
    );
  }
})

class Patrol extends Component {
  render() {
    return (
      <div className="PatrolSet">
        <PatrolC appState={new appState()}  />
      </div>
    );
  }
}
export default Patrol;