import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import {Checkbox,Tooltip,Button,Icon,Select,Row,Col,Form, message,DatePicker,Cascader} from 'antd';
import $ from 'jquery';
import delete_pic from '../../../assets/images/build/delete.png';
import big_pic from '../../../assets/images/build/big.png';
import small_pic from '../../../assets/images/build/small.png';
import left_pic from '../../../assets/images/build/left.png';
import right_pic from '../../../assets/images/build/right.png';
import QuitScreen from '../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../assets/images/application/shut-o.png';
import textbox from '../../../assets/images/apply/textbox.png';
import './PatrolDetail.css';
const { Option } = Select;
const FormItem = Form.Item;
const options = [{
  value: 'zhejiang',
  label: 'Zhejiang'
}, {
  value: 'jiangsu',
  label: 'Jiangsu'
}];
class patrolState {
  constructor() {
    extendObservable(this, {
      state: 0,
      mapPoints: [],
      mapPointsOne:[],
      detailSrc:null
    })
  }
}
class AdvancedSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      types: [],
      floorName:[],
      buildings:[],
      detailSrc:'',
      mapPoints: [],
      mapPointsOne:[]
    }
  }
  componentWillMount(){
    window.rpc.position.getArrayIdNameByContainer({},0,0).then((data)=>{
       let floorName=data.map((x)=>({...x}));
       // console.log( OrgsType);
       this.setState({
        floorName
       }) ;
    })
  }
  componentDidMount(){
    //   const getBuildings = () => {
    //   return window.rpc.area.getArrayByContainer({type: 50},0,0);
    // }

    // const getFloors = () => {
    //   return window.rpc.area.getArrayByContainer({type: 51},0,0);
    // }
    window.rpc.area.getArrayBriefByContainer({type: 50},0,0).then(data=>{
       let buildings = data.map(x => ({id: x.id, name: x.name, label:x.name, value: `${x.id}`,children: []}));
       window.rpc.area.getArrayByContainer({type: 51},0,0).then(res=>{
       let floors = res.map(x => ({id: x.id, name: x.name, label:x.name, value: `${x.id}`, mapUrl: x.mapUrl? x.mapUrl : '', parentId:x.parentId}));
       console.log(buildings, floors);
       for(let value of buildings) {
          value.children = floors.filter(x => x.parentId === value.id);
      };
      console.log(buildings);
      this.setState({buildings});
    },err=>{
      console.log(err);
    })
    },err=>{
      console.log(err);
    })
   
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        console.log(fieldsValue);
        const rangeValueOne = fieldsValue['setupTime'];
         const rangeValueTwo = fieldsValue['endTime'];
       // const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
       // const lastPatrolDate = fieldsValue['lastPatrolDate'];
        //const filde = fieldsValue['field-7'];
        const condition = fieldsValue['condition'];
        let values = {};
        // if (name) {
        //   values = { ...values, name }
        // }
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => parseInt(x, 10)) }
        }
        if (condition) {
          values = { ...values, condition}//: fieldsValue['filde'].map(x => parseInt(x, 10))
        
        }
        if (rangeValueOne&&rangeValueTwo) {
          console.log(rangeValueOne);
          values = { ...values, setupTime: [new Date(rangeValueOne.format('YYY-MM-DD')), new Date(rangeValueTwo.format('YYY-MM-DD'))] }
        }
        console.log(values);
        //  if (rangeValueTwo) {
        //   values = { ...values, rangeValueTwo: [new Date(rangeValueOne[0].format('YYY-MM-DD')), new Date(rangeValueOne[1].format('YYY-MM-DD'))] }
        // }

        //console.log('Received values of form: ', values);

        // window.rpc.device.getArrayByContainer(values, 0, 9).then((result) => {
        //   //console.log(result);
        //   message.info(`共搜索到${result.length}条数据`);
        //   let devices = result.filter(x => x.rstate !== 1).map((x) => ({ ...x, deviceName: `巡逻${x.id}`, patrolState: '正常', location: x.location, key: x.id, rstate: x.rstate, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
        //   this.props.patrolState.tableData = devices;
        // }, (err) => {
        //   console.warn(err);
        // })
        //if（state==1）   this.props.patrolState.mapPoints=devices,mapPointsOne=[]
        //if（state==2）   this.props.patrolState.mapPoints=[],mapPointsOne=devices;
       // if（!state）    {...values ,state:1 }mapPointsOne=devices1,{...values ,state:2 }  mapPointsOne=devices2
      });
    } catch (e) {
      console.warn(e);
    }
  }
  onChange=(value)=>{
    let detailSrc = this.state.buildings.filter(x => x.value === value[0])[0].children.filter(x => x.value === value[1])[0].mapUrl;
    this.setState({detailSrc});
    this.props.patrolState.detailSrc=detailSrc;
    const form = this.props.form;
    let rangeValueOne = form.getFieldValue('setupTime');
    let rangeValueTwo = form.getFieldValue('endTime');
    console.log(value);
    let floor= parseInt(value[0],10);
    let storey = parseInt(value[1],10);
    let values={floor:floor,storey:storey};
    if(rangeValueOne&&rangeValueTwo){
         let setupTime=[new Date(rangeValueOne.format('YYY-MM-DD')), new Date(rangeValueTwo.format('YYY-MM-DD'))] ;
         console.log(setupTime);
         values={...values,setupTime:setupTime};
    }
    //this.setState({floor,storey});
    window.rpc.position.getArrayBriefByContainer({values},0,0).then(data=>{
       
        data=data.map((x)=>({...x,mapX:parseInt(x.mapX/x.extend.offsetWidth*100),mapY:parseInt(x.mapY/x.extend.offsetHeight*100)}));
         console.log(data);
        let res=data.filter(x => x.state === 1)   
        this.props.patrolState.mapPoints=res;
        this.setState({mapPoints:res});
        let nres=data.filter(x => x.state != 1)   
        this.props.patrolState.mapPointsOne=nres;
        this.setState({mapPointsOne:nres});
    },err=>{
       console.warn(err);
        console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  handleChange=(value)=>{
    console.log(value)
    //const form = this.props.form;
    //let condition = form.getFieldValue('condition');
    //console.log(condition);
    if(value.length==2){
        this.props.patrolState.mapPointsOne=this.state.mapPointsOne;
        this.props.patrolState.mapPoints=this.state.mapPoints;      
    }else{
      if(value[0]=="1"){
        this.props.patrolState.mapPointsOne=[];
        this.props.patrolState.mapPoints=this.state.mapPoints;
     }else if(value[0]=="2"){
         this.props.patrolState.mapPointsOne=this.state.mapPointsOne;
         console.log(this.state.mapPointsOne);
        this.props.patrolState.mapPoints=[];      
     }else {
       console.log(2)
        this.props.patrolState.mapPointsOne=this.state.mapPointsOne;
        this.props.patrolState.mapPoints=this.state.mapPoints;      
     } 
    }
   
  }
  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = this.state.floorName;
    let dtypeChildren = [];
    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    return (
      <Form inline style={{padding:'12px 0 10px 0'}}>
            <Row>
               <Col span={5} key={1}>
                <FormItem label={`开始时间`}>
                  {getFieldDecorator(`setupTime`)(
                       <DatePicker
                          showTime
                          format="YYYY-MM-DD HH:mm:ss"
                          placeholder="请选择开始时间"
                          style={{ width: 220 }}
                        />
                  )}
                </FormItem>
              </Col>
              <Col span={1} key={2} style={{height: '32px',lineHeight: '32px'}}>
                 <span style={{paddingLeft:20,fontSize:12}}>至</span>
              </Col>
               <Col span={5} key={3}>
                <FormItem label={`结束时间`}>
                  {getFieldDecorator(`endTime`)(
                    <DatePicker 
                       showTime
                       format="YYYY-MM-DD HH:mm:ss"
                       placeholder="请选择结束时间"
                       style={{ width: 220 }} 
                     />
                  )}
                </FormItem>
              </Col>
              <Col span={5} key={4}>
                {/*<FormItem label={`楼层选择`}>
                  {getFieldDecorator(`floor`)(
                    <Select multiple style={{ width: 140 }} placeholder="请选择">
                      {dtypeChildren}
                    </Select>
                  )}*/}
                <span style={{margin:'0 12px 0 25px',fontSize:'0.75rem'}}>楼层选择：</span>
                <Cascader options={this.state.buildings} onChange={this.onChange.bind(this)} style={{width:"220px"}} placeholder="请选择" />
                {/*</FormItem>*/}
              </Col>
              <Col span={4} key={5}>
                <FormItem label={`巡查状态`}>
                  {getFieldDecorator(`condition`)(
                     
                    <Select multiple options={options}  style={{ width: 140 }} placeholder="请选择" onChange={this.handleChange.bind(this)} >
                      <Option value="1">已巡查</Option>
                      <Option value="2">未巡查</Option>
                    </Select>
                    
                  )}
                 
                </FormItem>
                 
              </Col>
        </Row>
      </Form>
    );
  }
}
const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
const PatrolDetailImgC = observer(class patrolState extends React.Component {
 //class PatrolDetailImgC extends Component { 

 constructor() {
    super();
    this.state = {
      new_pingmiantu:false,
      buildingImgUrl:'',
      areaId:[],
      mapPoints: [],
      mapPointsOne: [],
      buildImg:'',
      drag : 0,
      move:0,
      isdrag:false
    };
  }
  componentWillMount(){
    //  var str = window.location.href;
    //  var index = str.lastIndexOf("\/");
    //  str =parseInt(str.substring(index + 1, str.length),10) ;
      // let mapPoints=[{state:1,location:"中官西路",time:'2017-3-2',mapX:30,mapY:40},{state:1,location:'创E慧谷',time:'2017-3-2',mapX:70,mapY:31}];
      // this.setState({mapPoints});
      // let mapPointsOne=[{state:2,location:"中官西路777号",time:'2017-3-2',mapX:60,mapY:20},{state:2,location:'创E慧谷',time:'2017-3-2',mapX:30,mapY:51}];
      // this.setState({mapPointsOne});
   
  }
  
  handleStaffOne=()=>{
    this.setState({
        new_pingmiantu:true
    })
  }
  handleClick=(id)=>{
    console.log('aaaa');
    // e.stopPropagation();
    $(`fix_button1-${id}`).css({
      display:'none!important'
    });
   $(`fix_button2-${id}`).css({
      display:'none!important'
    })
  }
  render() {
  //console.log(this.state.mapPoints[0].state);
  let that=this;
   $('.unpack').click(function () {
        that.setState({new_pingmiantu:true});
    });
   $(function () {
      var _move = false;//移动标记
      var _x, _y;//鼠标离控件左上角的相对位置
      $(".showImg").click(function () {
      }).mousedown(function (e) {
        _move = true;
        _x = e.pageX - parseInt($(".showImg").css("left"));
        _y = e.pageY - parseInt($(".showImg").css("top"));
        $(".showImg").fadeTo(20, 1);//点击后开始拖动并透明显示
      });
      $(document).mousemove(function (e) {
        if (_move) {
          var x = e.pageX - _x;//移动时根据鼠标位置计算控件左上角的绝对位置
          var y = e.pageY - _y;
          $(".showImg").css({ top: y, left: x });//控件新位置
        }
      }).mouseup(function () {
        _move = false;
        $(".showImg").fadeTo("fast", 1);//松开鼠标后停止移动并恢复成不透明
      });

    });
      $(function () {
      var currents = 0;
     var sWidth = 1;
       $('.showImg').on("mousewheel DOMMouseScroll", function (e) {
      var delta = (e.originalEvent.wheelDelta && (e.originalEvent.wheelDelta > 0 ? 1:-1))||(e.originalEvent.detail && (e.originalEvent.detail > 0 ? -1 : 1));  
      //console.log(delta);
      //console.log(event);
      if (delta < 0) {    
         sWidth=sWidth>=0.3?0.9*sWidth:sWidth;
          //sHeight=sWidth>=0.3?0.9*sHeight:sHeight;
        }else if(delta >0){
          sWidth=sWidth<=2.5?1.1*sWidth:sWidth;
       }
           $(".showImg").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
    });
   })
 
         $('.map-point-1').each((i) => {
          $('.map-point-1').eq(i).mouseenter((e) => {
             $('.map-point-1').eq(i).find('ul').css({
               display:"inline-block",
               top:'-150px',
               left:'-90px'
             })
          
          });
           $('.map-point-1').eq(i).mouseleave((e) => {
             $('.map-point-1').eq(i).find('ul').css({
               display:"none",
               top:'-150px',
               left:'-90px'
             })
          
          })
         })
        $('.fix_button1').each((i) => {
          $('.fix_button1').eq(i).click((e) => {
           //+ console.log($('.fix_button1').parent().parent());
           console.log(111)
             $('.fix_button1').eq(i).css({
               display:"none!important",
               top:'-150px',
               left:'-90px'
             })
          
          });


        })
          $('.fix_button2').each((i) => {
          $('.fix_button2').eq(i).click((e) => {
            console.log(222);
             $('.fix_button2').eq(i).css({
               display:"none!important",
               top:'-150px',
               left:'-90px'
             })
          
          });


        })
    return (
      <div className="PatrolDetailImg">
        <Button 
          type=""
          className="unpack"
          style={{ background: 'rgb(0, 193, 222)', padding: '0 15px', width: 134, paddingLeft: 0 ,height: '32px', borderRadius: 0, color: '#fff' }} 
          onClick={this.handleStaffOne}
         >
           <Icon type="enter" />
           实时签到平面图
         </Button>
          <div className="new_pingmiantu" style={{ display: this.state.new_pingmiantu ? 'flex': 'none',position:'fixed',top:0,left:0,zIndex:1000,height:'100vh',width:'100vw',backgroundColor:'#fff' }}>
          <div className="pingmiantu-top">
            <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu}))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>返回巡逻列表</span></Button>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu}))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <div className="ImgSearch" style={{position:"fixed",left:0,top:48,zIndex:99999999,width:"100vw",margin:"3px 1vw",backgroundColor:"rgba(224,224,224,0.7)"}}>
              <WrappedAdvancedSearchForm patrolState={this.props.patrolState} style={{padding:"0 100px"}} />       
          </div>
          <div className="pingmiantu-left" >
           <div className="showImg" style={{position:'relative',display: this.props.patrolState.detailSrc?'block':'none'}} >
            <img id="img2" src={this.props.patrolState.detailSrc} style={{ display: this.props.patrolState.detailSrc ? 'block' : 'none' }} alt="right-pic" />
            {this.props.patrolState.mapPoints.map((point,index) => (//已巡逻
              <div key={index} 
              className={`map-point map-point-${point.state}`} 
              style={{ position: 'absolute', height:20, width: 20, top:`${point.mapY}%`, left:`${point.mapX}%`}}
              >
               <em>{point.count}</em>
               <ul style={{position:'absolute',left:-90,top:-150,fontSize:14,borderRight: '1px solid #ddddd1',height:150,zIndex: 99999999,lineHeight:'14px',display:'none',width:'270px',textAlign:'left',color:'#666',background: `url(${textbox})`}}>
                 <li style={{marginLeft:4,padding: '15px 0px 5px 16px',background:'#f9f9f9',borderTop:'1px solid #ddddd1',height:38,}}>巡逻点名称：{point.name}</li>
                 <li style={{marginLeft:4,padding: '5px 0px 5px 16px',background:'#f9f9f9',height:38,}}>巡逻次数：{point.count}</li>
                 <li style={{borderTop:'1px #ddddd1 solid',cursor:'pointer',padding:'12px 0'}}>
                    <a href="" style={{fontSize:'12px',border:'1px #ddddd1 solid',width:60,textAlign:'center',display:'inline-block',padding: '5px 0',background:'#f6f6f6',color:'#010101',float:'left',marginLeft:'50'}}>
                      查看详情
                    </a>
                    <span  id={`fix_button1-${point.id}`} className="fix_button2" onClick={()=>this.handleClick(point.id)} style={{fontSize:'12px',border:'1px #ddddd1 solid',width:50,textAlign:'center',display:'inline-block',padding: '5px 0',background:'#f6f6f6',color:'#010101',float:'left',marginLeft:'50'}}>
                       关闭
                    </span>
                 </li>
                </ul>
              </div>
            ))}
             {this.props.patrolState.mapPointsOne.map((point,index) => (//未巡逻
              <div key={index} className={`map-point map-point-${point.state}`} style={{ position: 'absolute', height:20, width: 20, top:`${point.mapY}%`, left:`${point.mapX}%`}}>
                 <em></em>
                 <ul style={{position:'absolute',left:-90,top:-150,fontSize:14,borderRight: '1px solid #ddddd1',height:150,lineHeight:'14px',display:'none',width:'270px',textAlign:'left',color:'#666',background: `url(${textbox})`, zIndex: 99999999}}>
                 <li style={{marginLeft:4,padding: '15px 0px 5px 16px',background:'#f9f9f9',height:38,borderTop:'1px solid #ddddd1'}}>巡逻点名称：{point.name}</li>
                 <li style={{marginLeft:4,padding: '5px 0px 5px 16px',height:38,background:'#f9f9f9'}}>巡逻次数：{point.count}</li>
                 <li style={{borderTop:'1px #ddddd1 solid',cursor:'pointer',padding:'12px 0'}}>
                    <a href="" style={{fontSize:'12px',border:'1px #ddddd1 solid',width:60,textAlign:'center',display:'inline-block',padding: '5px 0',background:'#f6f6f6',color:'#010101',float:'left',marginLeft:'50'}}>
                      查看详情
                    </a>
                    <span  id={`fix_button2-${point.id}`} className="fix_button1" onClick={()=>this.handleClick(point.id)} style={{fontSize:'12px',border:'1px #ddddd1 solid',width:50,textAlign:'center',display:'inline-block',padding: '5px 0',background:'#f6f6f6',color:'#010101',float:'left',marginLeft:'50'}}>
                       关闭
                    </span>
                 </li>
                </ul>
                {/*<span className="span" 
                style={{width:100,boxShadow:'0 0 5px rgb(0, 193, 222)',background:'#fff',border:'1px solid #ccc',display:'none',position:'absolute',top:-54,height:36,lineHeight:'36px',textAlign:'center'}}
                >未处理</span>*/}
              </div>
            ))}
            </div>
          </div>
        </div>
      </div>
    );
  }
})
class PatrolDetailImg extends Component {
  render() {
    return (
      <PatrolDetailImgC patrolState={new patrolState()}  />
    )
  }
}
export default PatrolDetailImg;