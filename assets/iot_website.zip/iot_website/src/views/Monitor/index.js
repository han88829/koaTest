import React, { Component } from 'react';
import { Link } from 'react-router';
import { Layout, Menu, Breadcrumb } from 'antd';
import './Monitor.css';

import org_message_pic from '../../assets/images/orgs/org-message-icon.png';
import org_type_pic from '../../assets/images/orgs/org-type-icon.png';
import build_message_pic from '../../assets/images/orgs/build-message-icon.png';

import device_bread_pic from '../../assets/images/logined/device-bread.png';

const { Content, Sider } = Layout;

class Monitor extends Component {
  constructor() {
    super();
    this.state = {
      breadRight: '监控中心',
      breadTitle: '监控管理',
      breadLink: '/monitor/monitormanage'
    }
    this.handClick = this.handClick.bind(this);
  }
  handClick(e) {
    this.setState({
      breadRight: e.target.innerText,
      breadTitle: e.target.getAttribute('data-parent'),
      breadLink: e.target.getAttribute('data-link')
    })
  }
  componentWillMount() {
    //console.log(this.props.routes.length);
  }
  render() {
    // function itemRender(route, params, routes, paths) {
    //   const last = routes.indexOf(route) === routes.length - 1;
    //   return last ? <span>{route.breadcrumbName}</span> : <Link to={paths.join('/')}>{route.breadcrumbName}</Link>;
    // }

    return (
      <Layout className="Monitor" style={{ background: '#333744' }}>
        <Sider
          width={200}
          style={{ background: '#333744', height: '100%' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['sub1', 'sub2', 'sub3']}
            style={{ height: '100%', backgroundColor: '#333744' }}
          >
            <Menu.Item key="1"><Link to="/monitor/monitormanage" onClick={this.handClick} data-link="/monitor/monitormanage" data-parent="监控中心"><img src={org_message_pic} alt="" style={{ padding: '0 10px 0 0' }} />监控管理</Link></Menu.Item>
            <Menu.Item key="2"><Link to="/monitor/resource" onClick={this.handClick} data-link="/monitor/resource" data-parent="监控中心"><img src={org_type_pic} alt="" style={{ padding: '0 10px 0 0' }} />资源管理</Link></Menu.Item>
            <Menu.Item key="3"><Link to="/monitor/realtime" onClick={this.handClick} data-link="/monitor/realtime" data-parent="监控中心"><img src={build_message_pic} alt="" style={{ padding: '0 10px 0 0' }} />实时监控</Link></Menu.Item>
          </Menu>
        </Sider>
        <Layout style={{ paddingRight: '20px', background: "#fff" }}>
          <Content style={{ padding: '0 20px', background: "#fafafa" }}>
            <Content style={{ padding: '0 20px' }}>
              <Breadcrumb separator="" style={{ margin: '12px 0', width: '393px', height: '20px', fontSize: '16px', lineHeight: '20px', padding: '20px 0', color: '#666', fontFamily: '苹方中等', fontWeight: 200 }}>
                <Breadcrumb.Item style={{ fontWeight: '500' }}><Link to={this.state.breadLink}><img src={device_bread_pic} alt="" style={{ padding: '0 10px 0 0', verticalAlign: 'middle' }} />{this.state.breadTitle}</Link></Breadcrumb.Item>
                <Breadcrumb.Item style={{ fontWeight: '500' }}><Link to={this.state.breadLink}>>{this.state.breadRight}</Link></Breadcrumb.Item>
                <Breadcrumb.Item style={{ fontWeight: '500' }}><Link to="">{this.props.routes.length >= 4 ? '>' : ''}{this.props.routes.length >= 4 ? this.props.children.props.routes[3].breadcrumbName : ''}</Link></Breadcrumb.Item>
                {/* <Breadcrumb.Item>App</Breadcrumb.Item> */}
              </Breadcrumb>
              <div style={{ padding: '0 24', background: '#fff', minHeight: 400, height: '100%' }}>
                {this.props.children}
              </div>
            </Content>
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Monitor;