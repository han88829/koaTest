import React, { Component } from 'react';
import { Form, Input, Select, Row, Button, DatePicker, TreeSelect, message } from 'antd';
import { Link, browserHistory } from 'react-router';

import star from '../../../assets/images/equipment/设备名称.png';
import time from '../../../assets/images/equipment/安装时间.png';
import state from '../../../assets/images/equipment/布设状态.png';
// import models from '../../../assets/images/equipment/采集模块.png';
// import create from '../../../assets/images/equipment/创立时间.png';
import address from '../../../assets/images/equipment/地址.png';
import dtype from '../../../assets/images/equipment/设备型号.png';
import net from '../../../assets/images/equipment/网关地址.png';
const FormItem = Form.Item;
const Option = Select.Option;

let selectOption = '', brand = [], model = [], brandMap = new Map(), product = new Map();

class RegistrationForm extends React.Component {
  constructor() {
    super();
    this.state = {
      confirmDirty: false,
      line: 'block',
      Dvr: 'none',
      Nvr: 'none',
      data: [],
      types: [],
      disabled: true,
      model: []
    };
  }
  componentWillMount() {

    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    window.rpc.area.getArray(0, 0).then((res) => {
      let tableDate = [];
      res.forEach(function (x) {
        if (x.name !== "") {
          tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
        }
      })
      loop(tableDate)
      this.setState({
        data: tableDate
      })
    }, (err) => {
      console.warn(err);
    })
    window.rpc.brand.getMapIdNameByContainer(null, 0, 0).then((res) => {
      for (var i in res) {
        brand.push(<Option key={res[i]}>{res[i]}</Option>)
        brandMap[res[i]] = i;
      }
    }, (err) => {
      console.warn(err);
    })
  }
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      //console.log('Received values of form: ', values);
      let DVRs;
      if (values.DVRselect === undefined) {
        DVRs = null;
      } else {
        DVRs = parseInt(values.DVRselect, 10)
      }
      let value = { ...values, networkUrl: values.networkUrl, networkId: DVRs, dtype: 56, networkMode: parseInt(values.networkMode, 10), location: parseInt(values.location, 10), brandId: brandMap[values.brandId], productId: product[values.productId], setupTime: values.setupTime._d, expiryTime: values.expiryTime._d, param: { IP: values.IP, port: values.port, username: values.username, password: values.password, NVRpass: values.NVRpass, DVRpass: values.DVRpass, brandId: brandMap[values.brandId], NVRip: values.NVRip, NVRport: values.NVRport, NVRusername: values.NVRusername, NVRpassword: values.NVRpassword, NVRselect: values.NVRselect, DVRselect: values.DVRselect } }
      delete value.DVRpass; delete value.IP; delete value.DVRselect; delete value.NVRip; delete value.NVRpass; delete value.NVRpassword; delete value.NVRport; delete value.NVRselect; delete value.NVRusername; delete value.port; delete value.username; delete value.password; delete value.brandId;
      window.rpc.device.create(value).then((res) => {
        message.info('创建成功');
        browserHistory.push("/moni/manage")
      }, (err) => {
        console.warn(err);
        function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
    });
  }
  handleConfirmBlur = (e) => {
    const value = e.target.value;
    this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  }
  checkPassword = (rule, value, callback) => {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  }

  checkConfirm = (rule, value, callback) => {
    const form = this.props.form;
    if (value && this.state.confirmDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  }
  onChange = (value) => {
    switch (value) {
      case "1":
        selectOption = "line";
        break;
      case "2":
        selectOption = "Nvr";
        break;
      case "3":
        selectOption = "Dvr";
        break;
      default:
        break;
    }
    this.setState({
      line: 'none',
      Dvr: 'none',
      Nvr: 'none',
    })
    this.setState({
      [selectOption]: 'block'
    })
  }
  changeType = (e) => {
    window.rpc.product.getArrayIdNumberByContainer({ brandId: brandMap[e] }, 0, 0, console.log, console.error).then((info) => {
      //console.log(info)
      model = [];
      for (let value of info) {
        if (value && value.id) {
          model.push(<Option key={`${value.number}`}>{value.number}</Option>)
          product[value.number] = value.id;
        }
      }
      this.setState({
        model,
        disabled: false
      })
    }, (err) => {
      console.warn(err);
    })

  }
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const config = {
      rules: [{ type: 'object', required: true, message: '请选择日期!' }],
    };

    return (
      <div className='NewMonitor'>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>监控新建</Link>
          </div>
        </div>
        <Form onSubmit={this.handleSubmit} style={{ marginTop: 24 }}>
          <div className="Row-info">
            <div className="Row-info-left clearfix">
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>名称:</span>
              </div>
              <FormItem
                {...formItemLayout}
                label=""
                hasFeedback
              >
                {getFieldDecorator('name', {
                  rules: [{
                    required: true, message: '请输入名称',
                  }],
                })(
                  <Input />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-left clearfix">
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={time} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>有效期限:</span>
              </div>
              <FormItem
                {...formItemLayout}
                label=""
                hasFeedback
              >
                {getFieldDecorator('expiryTime', config)(
                  <DatePicker />
                )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix">
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={state} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>品牌:</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('brandId', {
                  rules: [
                    { required: true, message: '请选择品牌!' },
                  ],
                })(
                  <Select placeholder="请选择品牌" onChange={this.changeType}>
                    {brand}
                  </Select>
                  )}
              </FormItem>
            </div>
            <div className="Row-info-left clearfix">
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={time} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>安装时间:</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('setupTime', config)(
                  <DatePicker />
                )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix">
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={dtype} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>型号:</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('productId', {
                  rules: [
                    { message: '请选择型号!' },
                  ],
                })(
                  <Select placeholder="请选择型号" disabled={this.state.disabled}>
                    {this.state.model}
                  </Select>
                  )}
              </FormItem>
            </div>
            <div className="Row-info-left clearfix">
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>安装位置:</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('location', {
                  rules: [
                    { required: true, message: '请选择安装位置' },
                  ],
                })(
                  <TreeSelect
                    style={{ width: 300 }}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.data.filter(x => x.layer === 1)}
                    placeholder="请选择安装位置"
                  />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info-left clearfix">
            <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
              <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
              <span style={{ fontSize: "0.75rem" }}>RTSP:</span>
            </div>
            <FormItem
              {...formItemLayout}
              hasFeedback
            >
              {getFieldDecorator('networkUrl', {
                rules: [
                  { required: true, message: '输入RTSP地址!' },
                ],
              })(
                <Input />
                )}
            </FormItem>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix">
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={net} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>联网模式:</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('networkMode', {
                  rules: [
                    { required: true, message: '请选择联网模式!' },
                  ],
                })(
                  <Select placeholder="请选择联网模式" onChange={this.onChange}>
                    <Option value="1" key="1">直连</Option>
                    <Option value="2" key="2">NVR</Option>
                    <Option value="3" key="3">DVR</Option>
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <Row style={{ border: "1px solid #000", padding: "20px" }}>
            <Row style={{ display: this.state.line }}>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>IP:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('IP', {
                      rules: [{
                        required: true, message: '请输入名称',
                      }],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>端口:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('port', {
                      rules: [{
                        required: true, message: '请输入名称',
                      }]
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>账号:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('username', {
                      rules: [{
                        required: true, message: '请输入名称',
                      }],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>密码:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('password', {
                      rules: [{
                        required: true, message: '请输入名称',
                      }],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
              </div>
            </Row>
            <Row style={{ display: this.state.Nvr }}>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>选择NVR:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('NVRselect', {
                      rules: [
                        { required: true, message: '请选择NVR!' },
                      ],
                    })(
                      <Select placeholder="请选择NVR!">
                        <Option key="大华">大华</Option>
                        <Option key="海康">海康</Option>
                      </Select>
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>选择通道:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('NVRpass', {
                      rules: [
                        { required: true, message: '请选择通道!' },
                      ],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>摄像头IP:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('NVRip', {
                      rules: [{
                        required: true, message: '请输入摄像头IP',
                      }],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>端口:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('NVRport', {
                      rules: [{
                        required: true, message: '请输入端口',
                      }],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>账号:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('NVRusername', {
                      rules: [{
                        required: true, message: '请输入账号',
                      }],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>密码:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('NVRpassword', {
                      rules: [{
                        required: true, message: '请输入密码',
                      }],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
              </div>
            </Row>
            <Row style={{ display: this.state.Dvr }}>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>选择DVR:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('DVRselect', {
                      rules: [
                        { required: true, message: '请选择DVR!' },
                      ],
                    })(
                      <Select placeholder="请选择DVR!">
                        <Option key="大华">大华</Option>
                        <Option key="海康">海康</Option>
                      </Select>
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>选择通道:</span>
                  </div>
                  <FormItem
                    {...formItemLayout}
                    hasFeedback
                  >
                    {getFieldDecorator('DVRpass', {
                      rules: [
                        { required: true, message: '请选择通道!' },
                      ],
                    })(
                      <Input />
                      )}
                  </FormItem>
                </div>
              </div>
            </Row>
          </Row>
          <Row style={{ float: "left", marginTop: 100 }}>
            <Button type="primary" htmlType="submit" size="large" style={{ float: "left" }}>创建</Button>
            <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginLeft: 10, float: 'left' }} onClick={() => { browserHistory.push("/moni") }}>返回</Button>
          </Row>
        </Form >
      </div>
    );
  }
}

const WrappedRegistrationForm = Form.create()(RegistrationForm);

class NewMonitor extends Component {
  state = {
    display: ''
  }
  componentDidMount() {
    window.rpc.menu.getInfo().then((res) => {
      let display = res[4].data[0].data[0].default ? '' : 'none';
    })
  }
  render() {
    return (
      <div className="NewMonitor">
        <div style={{ display: this.state.display }}>
          <WrappedRegistrationForm />
        </div>
        <div style={{ display: this.state.display === 'none' ? '' : 'none', textAlign: "center", marginTop: '10%', background: '#fff', fontSize: '2rem', minHeight: 280 }}>
          权限不足
        </div>
      </div>
    )
  }
}

export default NewMonitor;