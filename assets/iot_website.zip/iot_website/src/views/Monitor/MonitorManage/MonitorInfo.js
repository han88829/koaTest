import React, { Component } from 'react';
import { Form, Select, Row, message, Button } from 'antd';
import { Link, browserHistory } from 'react-router';
import moment from 'moment';
import './Monitor.css';

import star from '../../../assets/images/equipment/设备名称.png';

const Option = Select.Option;
const dateFormat = 'YYYY-MM-DD';

let selectOption = '', brand = [], model = [], brandMap = new Map(), product = new Map(), locationMap = new Map(), netMode = new Map();

class RegistrationForm extends React.Component {
  constructor() {
    super();
    this.state = {
      confirmDirty: false,
      line: 'block',
      Dvr: 'none',
      Nvr: 'none',
      data: [],
      types: [],
      disabled: true,
      result: {},
      param: {}
    };
  }
  componentWillMount() {
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
              locationMap[layerNow[i].id] = layerNow[i].name
              locationMap[layerNow[i].name] = layerNow[i].id
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
              locationMap[layerNow[i].id] = layerNow[i].name
              locationMap[layerNow[i].name] = layerNow[i].id
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    window.rpc.area.getArray(0, 0).then((res) => {
      let tableDate = [];
      res.forEach(function (x) {
        if (x.name !== "") {
          tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
        }
      })
      loop(tableDate)
      res.filter(x => x.layer === 1).forEach((x) => {
        locationMap[x.id] = x.name
        locationMap[x.name] = x.id
      })
      //console.log(tableDate)
      //console.log(product)
      this.setState({
        data: tableDate
      })
    }, (err) => {
      console.warn(err);
    })

    window.rpc.product.getArray(0, 0).then((res) => {
      res.forEach((x) => {
        product[x.id] = x.number;
      })
    }, (err) => {
      console.warn(err);
    })
  }
  componentDidMount() {
    const brands = () => {
      return window.rpc.brand.getMapIdNameByContainer(null, 0, 0)
    }

    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = Number(str.substring(index + 1, str.length));
    //console.log(str)
    const ghost = async () => {
      const res = await brands();
      //console.log(res[1])
      for (var i in res) {
        brand.push(<option key={res[i]}>{res[i]}</option>)
        brandMap[res[i]] = i;
        brandMap[i] = res[i];
      }
      window.rpc.device.getInfoById(str).then((result) => {
        let selectOption, Net;
        switch (result.networkMode) {
          case 1:
            selectOption = "line";
            Net = "直连";
            break;
          case 2:
            selectOption = "Nvr";
            Net = "NVR";
            break;
          case 3:
            selectOption = "Dvr";
            Net = "DVR";
            break;
          default:
            break;
        }
        this.setState({
          line: 'none',
          Dvr: 'none',
          Nvr: 'none',
        })
        //console.log(Net)
        setTimeout(() => {
          let time;
          if (result.setupTime != null) {
            time = result.setupTime
          } else {
            time = new Date();
          }
          const results = { ...result, networkUrl: result.networkUrl, expiryTime: moment(result.expiryTime).format(dateFormat), setupTime: moment(result.setupTime || new Date()).format(dateFormat), location: locationMap[result.location], productId: product[result.productId], networkMode: Net }

          const param = { ...result.param, brandId: brandMap[result.param.brandId], DVRselect: result.param.DVRselect, NVRselect: result.param.NVRselect }
          this.setState({
            [selectOption]: 'block',
            result: results,
            param
          })
        }, 200)
      }, (err) => {
        console.warn(err);
        function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
    }
    ghost();
  }
  handleConfirmBlur = (e) => {
    const value = e.target.value;
    this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  }
  checkPassword = (rule, value, callback) => {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  }

  checkConfirm = (rule, value, callback) => {
    const form = this.props.form;
    if (value && this.state.confirmDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  }
  onChange = (value) => {
    switch (value) {
      case "直连":
        selectOption = "line";
        break;
      case "NVR":
        selectOption = "Nvr";
        break;
      case "DVR":
        selectOption = "Dvr";
        break;
      default:
        break;
    }
    this.setState({
      line: 'none',
      Dvr: 'none',
      Nvr: 'none',
    })
    this.setState({
      [selectOption]: 'block'
    })
  }
  changeType = (e) => {
    window.rpc.product.getArrayIdNumberByContainer({ brandId: brandMap[e] }, 0, 0, console.log, console.error).then((info) => {
      model = [];
      for (let value of info) {
        if (value && value.id) {
          model.push(<Option key={`${value.number}`}>{value.number}</Option>)
        }
      }
    }, (err) => {
      console.warn(err);
    })
    this.setState({
      disabled: false
    })
  }
  render() {
    return (
      <div>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>监控详情</Link>
          </div>
        </div>
        <Form onSubmit={this.handleSubmit} className="monitorInfos" style={{ marginTop: 24, float: "left", width: "100%" }}>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />名称： {this.state.result.name}</div>
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />有效期限： {this.state.result.expiryTime}</div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />品牌 : {this.state.param.brandId}</div>
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />安装时间 : {this.state.result.setupTime}</div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />型号 : {this.state.result.productId}</div>
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />安装位置 : {this.state.result.location}</div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />RTSP : {this.state.result.networkUrl}</div>
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />联网模式 : {this.state.result.networkMode}</div>
              </div>
            </div>
          </div>

          <Row style={{ border: "1px solid #000", padding: "20px" }}>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41', display: this.state.line }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left" style={{ width: '100%' }}><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />IP : {this.state.param.IP}</div>
                </div>
              </div>

              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left" style={{ width: '100%' }}><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />端口 : {this.state.param.port}</div>
                </div>
              </div>

              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left" style={{ width: '100%' }}><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />账号 : {this.state.param.username}</div>
                </div>
              </div>

              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left" style={{ width: '100%' }}><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />密码 : {this.state.param.password}</div>
                </div>
              </div>
            </div>

            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41', display: this.state.Nvr }} >
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />选择NVR : {this.state.param.NVRselect}</div>
                  <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />选择通道 : {this.state.param.NVRpass}</div>
                </div>
              </div>

              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />摄像头IP : {this.state.param.NVRip}</div>
                  <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />端口 : {this.state.param.NVRport}</div>
                </div>
              </div>

              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />账号 : {this.state.param.NVRusername}</div>
                  <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />密码 : {this.state.param.NVRpassword}</div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41', display: this.state.Dvr }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />选择DVR : {this.state.param.DVRselect}</div>
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />选择通道 : {this.state.param.DVRpass}</div>
              </div>
            </div>
          </Row>
          <Row style={{ margin: '30px 0 10px', width: "100%" }}>
            <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginLeft: 10, float: 'left' }} onClick={() => { browserHistory.push("/moni") }}>返回</Button>
          </Row>
        </Form >
      </div >
    );
  }
}

const WrappedRegistrationForm = Form.create()(RegistrationForm);

class MonitorInfo extends Component {
  state = {
    display: ''
  }
  componentDidMount() {
    window.rpc.menu.getInfo().then((res) => {
      let display = res[4].data[0].data[0].default ? '' : 'none';
    })
  }
  render() {
    return (
      <div className="MonitorInfo">
        <div style={{ display: this.state.display }}>
          <WrappedRegistrationForm />
        </div>
        <div style={{ display: this.state.display === 'none' ? '' : 'none', textAlign: "center", marginTop: '10%', background: '#fff', fontSize: '2rem', minHeight: 280 }}>
          权限不足
        </div>
      </div>
    )
  }
}

export default MonitorInfo;