/*
 * @Author: lai.haibo 
 * @Date: 2017-03-24 09:26:03 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-15 15:32:52
 */

import React, { Component } from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router';
const { Header, Sider, Content } = Layout;
const MenuItemGroup = Menu.ItemGroup;

let routes = {
  manage: [{
    name: '监控管理',
    path: '/moni/manage',
    key: '1'
  }],
  file: [{
    name: '视频管理',
    path: '/moni/resource/vedio',
    key: '2'
  }, {
    name: '截图管理',
    path: '/moni/resource/pic',
    key: '3'
  }],
  realtime: [{
    name: '实时监控',
    path: '/moni/realtime',
    key: '4'
  }]
}

class Moni extends Component {
  state = {
    collapsed: false,
    seconds: {
      background: '#eaedf1'
    },
    route: routes.manage,
    routeName: '监控管理',
    routeKey: '1',
    display: '',
    data: [true, true, true, true,]
  };
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
      seconds: {
        background: '#eaedf1',
        display: this.state.collapsed ? 'block' : 'none'
      }
    });
  };
  componentWillMount() {
    if (this.props.children) {
      let path = this.props.children.props.route.path;
      if (!path || path === '/moni/manage' || path === '/moni') {
        this.setState({
          route: routes.manage,
          routeName: '监控管理',
          routeKey: '1'
        })
        routes.manage.length == 1 ? this.setState({ collapsed: true, seconds: { background: '#eaedf1', display: 'none' }, }) : this.setState({ collapsed: false, seconds: { background: '#eaedf1', display: 'block' }, })
      } else if (path === '/moni/resource/vedio') {
        this.setState({
          route: routes.file,
          routeName: '文件管理',
          routeKey: '2',
          collapsed: false,
          seconds: { background: '#eaedf1', display: 'block' }
        })
        //if(routes.file.length!==1) this.setState({collapsed: false,seconds: {background: '#eaedf1',display:'block'},})
      } else if (path === '/moni/realtime') {
        this.setState({
          route: routes.realtime,
          routeName: '实时监控',
          routeKey: '3'
        })
        routes.realtime.length == 1 ? this.setState({ collapsed: true, seconds: { background: '#eaedf1', display: 'none' }, }) : this.setState({ collapsed: false, seconds: { background: '#eaedf1', display: 'block' }, })
      }
    }
    window.rpc.menu.getInfo().then((res) => {
      let display = res[4].default ? '' : 'none';
      let data = [];
      data.push(res[4].data[0].data[0].default, res[4].data[1].data[0].default, res[4].data[1].data[1].default, res[4].data[2].data[0].default, )
      this.setState((prevState) => ({ data, display }));
    })
  };
  componentWillReceiveProps(nextProps) {
    let path = nextProps.children.props.route.path;
    if (!path || path === '/moni/manage' || path === '/moni') {
      this.setState({
        route: routes.manage,
        routeName: '监控管理',
        routeKey: '1', collapsed: true,
        seconds: { background: '#eaedf1', display: 'none' }
      })
    } else if (path === '/moni/resource/vedio') {
      this.setState({
        route: routes.file,
        routeName: '文件管理',
        routeKey: '2', collapsed: false,
        seconds: { background: '#eaedf1', display: 'block' }
      })
    } else if (path === '/moni/realtime') {
      this.setState({
        route: routes.realtime,
        routeName: '实时监控',
        routeKey: '3', collapsed: true,
        seconds: { background: '#eaedf1', display: 'none' }
      })
    }
    let routerkeys = Object.keys(routes);
    let route = [...routes[routerkeys[0]], ...routes[routerkeys[1]],];
    let routeKey = route.filter(x => x.path === path)[0] ? route.filter(x => x.path === path)[0].key : '10000';
    this.setState({
      routeKey
    });

  };
  render() {
    return (
      <Layout className="Moni">
        <Sider
          trigger={null}
          collapsible
          collapsed={this.state.collapsed}
          style={this.state.seconds}
          width={180}
        >
          <div className="logo" style={{ background: '#eaedf1', height: '70px', lineHeight: '70px', paddingLeft: '24px' }}>{this.state.routeName}</div>
          <Menu theme="light" mode="inline" defaultSelectedKeys={[this.state.routeKey]} selectedKeys={[this.state.routeKey]} style={{ background: '#eaedf1' }}>
            {this.state.route.map(
              route => {
                return (
                  <Menu.Item style={{ display: this.state.data[parseInt(route.key) - 1] ? '' : 'none', height: '40px' }} disabled={!this.state.data[parseInt(route.key) - 1]} key={route.key} ><Link to={route.path} style={{ color: "#666" }}>{route.name}</Link></Menu.Item>
                )
              })}
          </Menu>
        </Sider>
        <Layout style={{ padding: '0', position: 'static!important' }}>
          <div className="toggle" style={{ height: '32px', width: '18px', background: this.state.collapsed ? '#eaedf1' : '#fff', textAlign: 'center', position: 'absolute', top: '50vh', marginLeft: this.state.collapsed ? 0 : '-18px' }}>
            <Icon
              className="trigger-right"
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
              onClick={this.toggle}
            />
          </div>
          <Content key='1' style={{ display: this.state.display, padding: 24, margin: 0, background: '#fff', minHeight: 280 }}>
            {this.props.children}
          </Content>
          <Content key='2' style={{ display: this.state.display === 'none' ? '' : 'none', padding: 24, margin: 0, textAlign: "center", marginTop: '10%', background: '#fff', fontSize: '2rem', minHeight: 280 }}>
            权限不足！
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Moni;