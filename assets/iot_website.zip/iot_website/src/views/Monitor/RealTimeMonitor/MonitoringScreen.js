import React, { Component } from 'react';
// import { message } from 'antd';
import { Link } from 'react-router';

import ico_image from '../../../assets/images/monitoring/全屏-icon.png';

var MyVedio = React.createClass({
  getInitialState: function () {
    return {
      MonitData: [],
      mData: [],
      nameData: [],
      location: null,
      brandId: null,
      networkMode: null,
    }
  },
  componentWillMount() {

  },
  componentDidMount() {
    let mesid = parseInt(this.props.params.id, 10) || 1027;
    var SSOcxs = document.getElementById("div_boxs");

    window.rpc.device.getArrayCameraByContainer({ id: mesid }, 0, 0).then((res) => {
      let nameData = { key: res[0].id, ownerName: res[0].ownerName, name: res[0].name, location: res[0].location, };
      let loca = res[0].location;
      let location = loca.replace(/\:/ig, "").replace(/[\d]+/ig, "").replace(/\,/ig, "-");
      this.setState({ nameData, location });
    })
    window.rpc.device.getInfoById(mesid).then((result) => {
      window.rpc.public.tool.replaceNslookup(result.networkUrl).then((res) => {
        SSOcxs.innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
      <param name='mrl' value=${res} />
      <param name='volume' value='50' />
      <param name='autoplay' value='true' />
      <param name='loop' value='false' />
      <param name='fullscreen' value='false' />
      <param name='controls' value='true' />
      </object>`
      }, (err) => {
        console.error(err);
      })
    }, (err) => {
      console.warn(err);
    })
  },

  render() {
    return <div className="MonitorScreen" style={{ position: "absolute", width: "100%", height: "100%", top: 0, left: 0, zIndex: 99 }}>
      <div style={{ width: "100%", height: "100%", background: "pink", float: "left", border: "1px solid white" }}>
        <div style={{ width: "100%", height: "3%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 12, position: "relative" }}>
          摄像头名称：{this.state.nameData ? this.state.nameData.name : "一号摄像头"}&nbsp;-->&nbsp;安装位置： {this.state.nameData ? this.state.nameData.ownerName + "-" + this.state.location : "国家科技园-科创大厦-园区咖啡厅二楼"}
          <span style={{ position: "absolute", right: 20, marginTop: 4 }}><Link to="/moni/realtime" title="退出全屏"><img src={ico_image} alt="退出" /></Link> </span>
        </div>
        <div style={{ width: "100%", height: "94%", background: "black" }}>
          <div style={{ width: "100%", height: "100%" }} id="div_boxs"></div>
        </div>
        <div style={{ width: "100%", height: "3%", background: "#333" }}>
        </div>
      </div>
    </div>
  }
});

class MonitorScreens extends Component {
  componentWillMount() {
  }
  render() {
    return (
      <div>
        <MyVedio params={this.props.params} />
      </div>
    )
  }
}

export default MonitorScreens;