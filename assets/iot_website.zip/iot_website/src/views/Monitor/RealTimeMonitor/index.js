﻿import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Button, message } from 'antd';
import "./RealTimeMonitor.css";

import ico_image from '../../../assets/images/monitoring/全屏-icon.png';
import ico_images from '../../../assets/images/monitoring/视频管理-icon.png';

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      data: [],
    })
  }
}

const StaffC = observer(class StaffC extends Component {
  state = {
    loading: false,
    visible: false,
    previewImage: '',
    fileList: [{
      uid: -1,
      name: 'xxx.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    }],
    route: [],
    nameData: [],
    netData: [],
    display: "none",
    top: "-20px",
    data: [],
    numId: 0,
    text: null,
    color: null,
  }
  componentWillMount() {

  }
  componentDidMount() {
    window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, 0, 9).then(res => {
      if (res.length <= 0) {
        message.info("已经到底啦！")
        if (this.state.numId <= 9) {
          this.setState({ numId: 0 });
        } else {
          let numId = this.state.numId - 9;
          this.setState({ numId });
        }
        console.log(this.state.numId)
      } else {
        let data = res.map((x) => ({ key: x.id, brandId: parseInt(x.param.brandId, 10), id: x.id, pass: parseInt(x.param.NVRpass, 10) || 0, ip: x.param.NVRip, password: x.param.NVRpassword, username: x.param.NVRusername, port: x.param.NVRport }));
        this.props.appState.monitData = data;
        let nameData = res.map((x) => ({ key: x.id, id: x.id, ownerName: x.ownerName, name: x.name, location: x.location, }))
        this.setState({ nameData });
        let route = [];
        for (let i = 0; i < data.length; i++) {
          route.push(data[i].key)
        }
        this.setState({ route });
        let box = ["div_box", "div_boxa", "div_boxb", "div_boxc", "div_boxd", "div_boxe", "div_boxf", "div_boxg", "div_boxh"];
        let length = res.length;
        for (let i = 0; i < length; i++) {
          window.rpc.device.getInfoById(res[i].id).then((result) => {
            window.rpc.public.tool.replaceNslookup(result.networkUrl).then((x) => {
              document.getElementById(box[i]).innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
            <param name='mrl' value=${x} />
            <param name='volume' value='50' />
            <param name='autoplay' value='false' />
            <param name='loop' value='false' />
            <param name='fullscreen' value='false' />
            <param name='controls' value='true' />
            </object>`
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          })
        }

      }
      // if (length < 9) {
      //   for (let i = 0; i < length; i++) {
      //     window.rpc.device.getInfoById(res[i].id).then((result) => {
      //       window.rpc.public.tool.replaceNslookup(result.networkUrl).then((res) => {
      //         document.getElementById(box[i]).innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
      //       <param name='mrl' value=${res} />
      //       <param name='volume' value='50' />
      //       <param name='autoplay' value='false' />
      //       <param name='loop' value='false' />
      //       <param name='fullscreen' value='false' />
      //       <param name='controls' value='true' />
      //       </object>`
      //       }, (err) => {
      //         console.warn(err);
      //       })
      //     }, (err) => {
      //       console.warn(err);
      //     })
      //   }
      // } else {
      //   for (let i = 0; i < 9; i++) {
      //     window.rpc.device.getInfoById(res[i].id).then((result) => {
      //       window.rpc.public.tool.replaceNslookup(result.networkUrl).then((res) => {
      //         document.getElementById(box[i]).innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
      //       <param name='mrl' value=${res} />
      //       <param name='volume' value='50' />
      //       <param name='autoplay' value='false' />
      //       <param name='loop' value='false' />
      //       <param name='fullscreen' value='false' />
      //       <param name='controls' value='true' />
      //       </object>`
      //       }, (err) => {
      //         console.warn(err);
      //       })
      //     }, (err) => {
      //       console.warn(err);
      //     })
      //   }
      //   let data = [];
      //   for (let i = 9; i < length; i++) {
      //     window.rpc.device.getInfoById(res[i].id).then((result) => {
      //       window.rpc.public.tool.replaceNslookup(result.networkUrl).then((res) => {
      //         data[i] = { id: result.id, key: result.id, networkUrl: res, name: result.name, }
      //         this.setState({ data });
      //       }, (err) => {
      //         console.warn(err);
      //       })
      //     }, (err) => {
      //       console.warn(err);
      //     })
      //   }
      // }
    })
  }
  handleUp = () => {
    let numId = this.state.numId;
    if (numId <= 9) {
      this.setState({ numId: 0, text: "已经到顶啦！", color: "red" });
    } else {
      numId -= 9;
      window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, numId, 9).then(res => {
        this.setState({ text: `共刷新${res.length}条监控视频!`, color: "#00c1d1" });
        let data = res.map((x) => ({ key: x.id, brandId: parseInt(x.param.brandId, 10), id: x.id, pass: parseInt(x.param.NVRpass, 10) || 0, ip: x.param.NVRip, password: x.param.NVRpassword, username: x.param.NVRusername, port: x.param.NVRport }));
        this.props.appState.monitData = data;
        let nameData = res.map((x) => ({ key: x.id, id: x.id, ownerName: x.ownerName, name: x.name, location: x.location, }))
        this.setState({ nameData });
        let route = [];
        for (let i = 0; i < data.length; i++) {
          route.push(data[i].key)
        }
        this.setState({ route });
        let box = ["div_box", "div_boxa", "div_boxb", "div_boxc", "div_boxd", "div_boxe", "div_boxf", "div_boxg", "div_boxh"];
        let length = res.length;
        for (let i = 0; i < length; i++) {
          window.rpc.device.getInfoById(res[i].id).then((result) => {
            window.rpc.public.tool.replaceNslookup(result.networkUrl).then((x) => {
              document.getElementById(box[i]).innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
                <param name='mrl' value=${x} />
                <param name='volume' value='50' />
                <param name='autoplay' value='false' />
                <param name='loop' value='false' />
                <param name='fullscreen' value='false' />
                <param name='controls' value='true' />
                </object>`
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          })
        }
      })
    }
    setTimeout(() => {
      this.setState({ text: "" });
    }, 3000)
  }
  handleDown = () => {
    let numId = this.state.numId;
    numId += 9;
    window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, numId, 9).then(res => {
      if (res.length <= 0) {
        this.setState({ text: `已经到底啦！`, color: "red" });
      } else {
        this.setState({ numId, text: `共刷新${res.length}条监控视频！`, color: "#00c1d1" });
        let data = res.map((x) => ({ key: x.id, brandId: parseInt(x.param.brandId, 10), id: x.id, pass: parseInt(x.param.NVRpass, 10) || 0, ip: x.param.NVRip, password: x.param.NVRpassword, username: x.param.NVRusername, port: x.param.NVRport }));
        this.props.appState.monitData = data;
        let nameData = res.map((x) => ({ key: x.id, id: x.id, ownerName: x.ownerName, name: x.name, location: x.location, }))
        this.setState({ nameData });
        let route = [];
        for (let i = 0; i < data.length; i++) {
          route.push(data[i].key)
        }
        this.setState({ route });
        let box = ["div_box", "div_boxa", "div_boxb", "div_boxc", "div_boxd", "div_boxe", "div_boxf", "div_boxg", "div_boxh"];
        let length = res.length;
        for (let i = 0; i < length; i++) {
          window.rpc.device.getInfoById(res[i].id).then((result) => {
            window.rpc.public.tool.replaceNslookup(result.networkUrl).then((x) => {
              document.getElementById(box[i]).innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
                <param name='mrl' value=${x} />
                <param name='volume' value='50' />
                <param name='autoplay' value='false' />
                <param name='loop' value='false' />
                <param name='fullscreen' value='false' />
                <param name='controls' value='true' />
                </object>`
            }, (err) => {
              console.warn(err);
               console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
            })
          }, (err) => {
            console.warn(err);
          })
        }
      }
    })
    setTimeout(() => {
      this.setState({ text: "" });
    }, 3000)
  }
  render() {
    return (
      <div className="Orgs Orgss" style={{ marginTop: 30, width: "100%", height: "800px", position: "relative", marginRight: 20 }}>
        <div style={{ position: "absolute", top: "-30px", width: "100%", borderBottom: "1px solid #bbbbbb", paddingBottom: 10 }}>
          <span style={{ display: "inline-block", width: 2, height: 16, marginRight: 10, marginTop: 3, background: "#88b9e1", float: "left" }}></span>
          <span style={{ display: "inline-block", float: "left", fontFamily: "苹方中等", color: "#373d41", fontSize: "14px" }}>监控管理</span>
          <div style={{ float: 'left', height: 32, marginRight: 4, marginLeft: 15, marginTop: "-7px" }}>
            <Button type="" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }}
              onClick={this.handleUp} >
              上一批
            </Button>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4, marginTop: "-7px", }}>
            <Button type="" style={{ background: '#d9dee4', color: '#000', padding: '0 15px', height: '32px', borderRadius: 0 }}
              onClick={this.handleDown}>
              <Link to="">下一批</Link>
            </Button>
          </div>
          <div style={{ float: 'left',fontWeight:"100", color: `${this.state.color}`, lineHeight: "30px", marginLeft: 15, height: 32, marginRight: 4, marginTop: "-7px", fontSize: "18px", }}>
            {this.state.text}
          </div>
        </div>
        <div style={{ position: "absolute", color: "red", zIndex: 99, fontSize: "16px", display: `${this.state.display}`, backgroundColor: "yellow", width: 250, height: 30, textAlign: "center", lineHeight: "30px", left: "35%", top: `${this.state.top}` }}>播放错误，请在IE浏览器下播放！</div>
        <div style={{ width: "100%", height: "66.666%", paddingTop: 26 }}>
          <div style={{ width: "50%", height: "100%", float: "left", border: "1px solid white" }}>
            <div style={{ width: "100%", height: "5%", background: "#333744", color: "white", lineHeight: "26.66px", fontSize: "1rem", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[0] ? this.state.nameData[0].name : "一号摄像头"}&nbsp;-->&nbsp;安装位置： {this.state.nameData[0] ? this.state.nameData[0].ownerName + "-" + this.state.nameData[0].location.replace(/\:/ig, "").replace(/[\d]+/ig, "").replace(/\,/ig, "-") : "国家科技园-科创大厦-园区咖啡厅二楼"}</div>
            <div style={{ width: "100%", height: "90%", background: "black" }}>
              <div style={{ width: "100%", height: "100%" }} id="div_box"></div>
            </div>
            <div style={{ width: "100%", height: "5%", background: "#333" }}>
              <div className="button_list" style={{ padding: "0 35%", position: "relative" }}>
                <span><Link to={`/moni/realtime/screens/${this.state.route[0]}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
              </div>
            </div>
          </div>
          <div style={{ width: "50%", height: "100%", background: "green", float: "left" }}>
            <div style={{ width: "50%", height: "50%", background: "pink", float: "left", border: "1px solid white", position: "relative" }}>
              <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[1] ? this.state.nameData[1].name : "未检测到摄像头！"}</div>
              <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxa"></div>
              <div style={{ width: "100%", height: "10%", background: "#333" }}>
                <div className="button_list">
                  <span ><Link to={`/moni/realtime/screens/${this.state.route[1] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
                </div>
              </div>
            </div>
            <div style={{ width: "50%", height: "50%", background: "green", float: "left", border: "1px solid white", position: "relative" }}>
              <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[2] ? this.state.nameData[2].name : "未检测到摄像头！"}</div>
              <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxb"></div>
              <div style={{ width: "100%", height: "10%", background: "#333" }}>
                <div className="button_list">
                  <span ><Link to={`/moni/realtime/screens/${this.state.route[2] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
                </div>
              </div>
            </div>
            <div style={{ width: "50%", height: "50%", background: "green", float: "left", border: "1px solid white", position: "relative" }}>
              <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[3] ? this.state.nameData[3].name : "未检测到摄像头！"}</div>
              <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxc"></div>
              <div style={{ width: "100%", height: "10%", background: "#333" }}>
                <div className="button_list">
                  <span ><Link to={`/moni/realtime/screens/${this.state.route[3] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
                </div>
              </div>
            </div>

            <div style={{ width: "50%", height: "50%", background: "pink", float: "left", border: "1px solid white", position: "relative" }}>
              <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[4] ? this.state.nameData[4].name : "未检测到摄像头！"}</div>
              <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxd"></div>
              <div style={{ width: "100%", height: "10%", background: "#333" }}>
                <div className="button_list">
                  <span ><Link to={`/moni/realtime/screens/${this.state.route[4] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div style={{ width: "100%", height: "33.333%", background: "blue", float: "left", position: "relative" }}>
          <div style={{ width: "25%", height: "100%", background: "pink", float: "left", border: "1px solid white", position: "relative" }}>
            <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[5] ? this.state.nameData[5].name : "未检测到摄像头！"}</div>
            <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxe"></div>
            <div style={{ width: "100%", height: "10%", background: "#333" }}>
              <div className="button_list">
                <span ><Link to={`/moni/realtime/screens/${this.state.route[5] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
              </div>
            </div>
          </div>
          <div style={{ width: "25%", height: "100%", background: "blue", float: "left", border: "1px solid white", position: "relative" }}>
            <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[6] ? this.state.nameData[6].name : "未检测到摄像头！"}</div>
            <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxf"></div>
            <div style={{ width: "100%", height: "10%", background: "#333" }}>
              <div className="button_list">
                <span ><Link to={`/moni/realtime/screens/${this.state.route[6] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
              </div>
            </div>
          </div>
          <div style={{ width: "25%", height: "100%", background: "pink", float: "left", border: "1px solid white", position: "relative" }}>
            <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[7] ? this.state.nameData[7].name : "未检测到摄像头！"}</div>
            <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxg"></div>
            <div style={{ width: "100%", height: "10%", background: "#333" }}>
              <div className="button_list">
                <span ><Link to={`/moni/realtime/screens/${this.state.route[7] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
              </div>
            </div>
          </div>
          <div style={{ width: "25%", height: "100%", background: "yellow", float: "left", border: "1px solid white", position: "relative" }}>
            <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{this.state.nameData[8] ? this.state.nameData[8].name : "未检测到摄像头！"}</div>
            <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxh"></div>
            <div style={{ width: "100%", height: "10%", background: "#333" }}>
              <div className="button_list">
                <span ><Link to={`/moni/realtime/screens/${this.state.route[8] || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
              </div>
            </div>
          </div>
        </div>
        {/*动态*/}
        <div>{this.state.data.map(data => (
          <div key={data.key} style={{ width: "25%", height: "33.33vh", background: "yellow", float: "left", border: "1px solid white", position: "relative" }}>
            <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：{data.name ? data.name : "未检测到摄像头！"}</div>
            <div style={{ width: "100%", height: "80%", background: "black" }} id="div_boxh">
              <object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
                <param name='mrl' value={data.networkUrl} />
                <param name='volume' value='50' />
                <param name='autoplay' value='false' />
                <param name='loop' value='false' />
                <param name='fullscreen' value='false' />
                <param name='controls' value='true' />
              </object>
            </div>
            <div style={{ width: "100%", height: "10%", background: "#333" }}>
              <div className="button_list">
                <span ><Link to={`/moni/realtime/screens/${data.id || 1027}`} ><img src={ico_image} alt="全屏显示" /></Link> </span>
              </div>
            </div>
          </div>
        ))}
        </div>
      </div>
    )
  }
})

class RealTimeMonitor extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default RealTimeMonitor;
