import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Link } from 'react-router';

import ico_image from '../../../assets/images/monitoring/全屏-icon.png';

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
    })
  }
}

var MyVedio = React.createClass({
  getInitialState: function () {
    return {
      MonitData: [],
    }
  },
  componentWillMount() {
    //console.log(this.props)
    // window.rpc.device.getArrayCameraByContainer({ dtype: 56, }, 0, 0).then((res) => {
    //   console.log(res)
    // })
  },
  componentDidMount() {
    var SSOcxs = document.getElementById("div_boxs");
    //console.log(SSOcxs)
    // SSOcxs.innerHTML = '<object classid="CLSID:CAFCF48D-8E34-4490-8154-026191D73924"  standby="Waiting..." id="playOcxs" width="100%" height="100%" name="playOcxs" ></object>';
    SSOcxs.innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%">
      <param name='mrl' value='rtsp://admin:admin@192.168.0.35:40001/cam/realmonitor?channel=2&subtype=0' />
      <param name='volume' value='50' />
      <param name='autoplay' value='true' />
      <param name='loop' value='false' />
      <param name='fullscreen' value='false' />
      <param name='controls' value='true' />
    </object>`
  },
  StartPlay() {
    // 用来检测浏览器
    function myBrowser() {
      var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
      var isOpera = userAgent.indexOf("Opera") > -1;
      if (isOpera) {
        return "Opera"
      }; //判断是否Opera浏览器
      if (userAgent.indexOf("Firefox") > -1) {
        return "FF";
      } //判断是否Firefox浏览器
      if (userAgent.indexOf("Chrome") > -1) {
        return "Chrome";
      }
      if (userAgent.indexOf("Safari") > -1) {
        return "Safari";
      } //判断是否Safari浏览器
      if (userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera) {
        return "IE";
      }; //判断是否IE浏览器
    }
    //以下是调用上面的函数
    var mb = myBrowser();
    if ("FF" === mb || "Chrome" === mb || "Opera" === mb || "Safari" === mb) {
      alert("哎呀！播放错误，请在IE浏览器下播放");
    }
    var SSOcx = document.getElementById("playOcxs");
    console.log(SSOcx)
    SSOcx.Login("192.168.0.19", 8000, "admin", "lszp2016");
    SSOcx.StartRealPlay(5, 0, 0); //播放通道5的视频 通道号 协议类型 码流
    console.log(SSOcx.StartRealPlay(5, 0, 0))
    //SSOcx.GetServerInfo();获取通道
  },

  StopPlay() {
    var SSOcx = document.getElementById("playOcxs");
    SSOcx.StopRealPlay();//暂停预览
  },
  Capture() {
    var SSOcx = document.getElementById("playOcxs");
    SSOcx.BMPCapturePicture("D:/OCXBMPCaptureFiles", 1)
  },
  StartRecord() {
    alert("开始录屏");
    var SSOcx = document.getElementById("playOcxs");
    SSOcx.StartRecord("D:/OCXRecordFiles") //录屏
  },
  StopRecord() {
    alert("停止录屏");
    var SSOcx = document.getElementById("playOcxs");
    SSOcx.StopRecord(1)//停止录制
  },

  render() {
    return (
      <div className="MonitorScreen" style={{ position: "absolute", width: "100%", height: "100%", top: 0, left: 0, zIndex: 10000000000 }}>
        <div style={{ width: "100%", height: "100%", background: "pink", float: "left", border: "1px solid white" }}>
          <div style={{ width: "100%", height: "3%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 12, position: "relative" }}>
            {this.state.name}
            <span style={{ position: "absolute", right: 20, marginTop: 4 }}><Link to="/moni/realtime" title="退出全屏"><img src={ico_image} alt="" /></Link> </span>
          </div>
          <div style={{ width: "100%", height: "94%", background: "black" }}>
            <div style={{ width: "100%", height: "100%" }} id="div_boxs"></div>
          </div>
          <div style={{ width: "100%", height: "3%", background: "#333" }}>
            <div className="button_list" style={{ padding: 0, position: "relative" }}>
              <div onClick={this.StartPlay} className="zhanting_div" title="播放"><Link className="button_  zhanting"></Link></div>
              <div onClick={this.StopPlay} title="暂停"><Link className="button_  bofang"></Link></div>
              <div onClick={this.Capture} title="拍照"><Link className="button_  paizhao"></Link>
              </div>
              <div onClick={this.StartRecord} title="录像"><Link className="button_  luxiang"></Link></div>
              <div onClick={this.StopRecord} title="停止录像"><Link className="button_  luxiangt"></Link></div>
            </div>
          </div>
        </div>
      </div>
    )
  }
});

class TestMonit extends Component {
  componentWillMount() {
    // console.log(this.props);
  }
  render() {
    return (
      <div>
        <MyVedio params={this.props.params} />
      </div>
    )
  }
}

export default TestMonit;