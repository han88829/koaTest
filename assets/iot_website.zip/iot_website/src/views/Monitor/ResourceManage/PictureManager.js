import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Tooltip, Table, Row, Col, Input, Button, message, Form, Popconfirm, DatePicker, Tabs, Checkbox } from 'antd';
import moment from 'moment';
import $ from 'jquery';
import './PictureManager.css';

import anticlokwise from '../../../assets/images/monitoring/anticlokwise.png';
import magnify from '../../../assets/images/monitoring/magnify.png';
import rightRotation from '../../../assets/images/monitoring/rightRotation.png';
import shrink from '../../../assets/images/monitoring/shrink.png';
import tupians from '../../../assets/images/monitoring/tupians.png';

const FormItem = Form.Item;

const TabPane = Tabs.TabPane;
var Num = '';
const RangePicker = DatePicker.RangePicker;
class appState {
  constructor() {
    extendObservable(this, {
      tableData: []
    })
  }
}
class BrandSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [],
      value: undefined
    }
  }

  handleCancel = () => this.setState({ previewVisible: false })

  handlePreview = (file) => {
    this.setState({
      previewImage: file.url || file.thumbUrl,
      previewVisible: true,
    });
  }

  handleChange = ({ fileList }) => this.setState({ fileList })

  componentWillMount() {
    //初始化数据
    window.rpc.device.file.getArrayByContainer({ type: 2 }, 0, 0).then((result) => {
      let type = result.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      Num = type.length;
      this.props.appState.tableData = type;
    }, (err) => {
      console.warn(err);
       console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  // 搜索匹配
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        let values = { type: 2 };

        if (name) {
          values = { ...values, name: name };
        }
        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        window.rpc.device.file.getArrayByContainer(values, 0, 0).then((result) => {
          let type = result.map(x => ({ ...x, key: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          Num = type.length;
          this.props.appState.tableData = type;
          message.info(`共搜索到${type.length}条数据`);
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    let dataOwner = JSON.parse(sessionStorage.getItem('owner')) || [];

    return (
      < Form layout="inline" style={{ margin: "12px 0" }}>
        <Row>
          <Col span={5} key="1">
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 190 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={6} key="2">
            <FormItem label={`安装时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{ width: 200 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key="3">
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form >
    );
  }
}
const BrandNameAdvancedSearchForm = Form.create()(BrandSearchForm);

class Photos extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [],
    }
  }
  componentWillMount() {
    window.rpc.device.file.getArrayByContainer({ type: 2 }, 0, 0).then((res) => {
      if (res != null) {
        this.setState({
          data: res.map(x => ({ ...x, key: x.id }))
        })
      }
    })
  }
  render() {
    var items = [];
    $(function () {
      $(".unpack").click(function () {
        $(".overlay").height(document.body.scrollHeight);
        $(".overlay").width(document.body.scrollWidth);
        // fadeTo第一个参数为速度，第二个为透明度
        // 多重方式控制透明度，保证兼容性，但也带来修改麻烦的问题
        $(".overlay").fadeTo(200, 0.5);
        // 解决窗口缩小时放大后不全屏遮罩的问题
        // 简单来说，就是窗口重置的问题
        $(window).resize(function () {
          $(".overlay").height(document.body.scrollHeight);
          $(".overlay").width(document.body.scrollWidth);
        });
      })

      $(".open").click(function () {
        $(".overlay").fadeOut(200);
      })

      var _move = false;//移动标记
      var _x, _y;//鼠标离控件左上角的相对位置
      $(".show").click(function () {
      }).mousedown(function (e) {
        _move = true;
        _x = e.pageX - parseInt($(".show").css("left"), 10);
        _y = e.pageY - parseInt($(".show").css("top"), 10);
        $(".show").fadeTo(20, 0.5);//点击后开始拖动并透明显示
      });
      $(document).mousemove(function (e) {
        if (_move) {
          var x = e.pageX - _x;//移动时根据鼠标位置计算控件左上角的绝对位置
          var y = e.pageY - _y;
          $(".show").css({ top: y, left: x });//控件新位置
        }
      }).mouseup(function () {
        _move = false;
        $(".show").fadeTo("fast", 1);//松开鼠标后停止移动并恢复成不透明
      });

    })

    $(function () {
      var currents = 0;

      $(".zuofan").click(function () {
        currents = (currents + 90) % 360;
        $(".show").css("transform", 'rotate(' + currents + 'deg)');

      })

      var sWidth = 1;
      $(".fanfa").click(function () {
        if (sWidth < 2) {
          sWidth = 1.2 * sWidth;
          $(".show").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
        }
      });

      $(".suofa").click(function () {
        if (sWidth > 0.3) {
          sWidth = 0.8 * sWidth;
          $(".show").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
        }
      });

      $(".youfan").click(function () {
        currents = -((currents + 90) % 360);
        $(".show").css("transform", 'rotate(' + currents + 'deg)');

      })

    })

    for (var i = 0; i < this.props.appState.tableData.length; i++) {
      items.push(
        <div key={i}>
          <Checkbox style={{ position: "absolute", top: 2, left: 2, borderRadius: "10px" }}></Checkbox>
          <Tooltip title="点击图片查看">
            <span>
              <img className="unpack" style={{ width: 83, height: 83, display: "block", border: "1px solid #ffffff", marginLeft: 18, marginTop: 10 }} src={this.props.appState.tableData[i].url} />
            </span>
            <div className="overlay">
              <div key="1" style={{ width: 560, height: 32, color: "white", cursor: "pointer", position: "fixed", left: 690, top: 730, zIndex: 100000000000000 }} >
                <ul className="selects">
                  <li key="1" className="zuofan" title="点击左旋转"><img src={anticlokwise} alt="" /></li>
                  <li key="2" className="youfan" title="点击右旋转"><img src={rightRotation} alt="" /></li>
                  <li key="3" className="fanfa" title="点击放大"><img src={magnify} alt="" /></li>
                  <li key="4" className="suofa" title="点击缩小"><img src={shrink} alt="" /></li>
                </ul>
              </div>
              <div key="2" style={{ width: 40, height: 40, fontSize: 30, float: "right", color: "white", borderRadius: "0 0 0 80%", background: "#cccccc", cursor: "pointer", padding: "0 0 30px 15px" }} className="open">X</div>
              <div key="3" style={{
                width: 800,
                padding: 10,
                height: 561,
                top: 164,
                position: "absolute",
                left: "50%",
                marginLeft: "-400px",
                zIndex: 100000000,
                display: "block"
              }} className="show">
                <img className="unpack" style={{ width: "100%", height: "100%", display: "block", border: "1px solid #ffffff", padding: 10 }} src={this.props.appState.tableData[i].url} />
              </div>
            </div>
          </Tooltip>
          <p style={{ textAlign: "center", lineHeight: "20px" }}>{this.props.appState.tableData[i].name}</p>
        </div>);
    }
    return (
      <div>
        {items}
      </div>
    )
  }
}
const PhotosZhangshi = Form.create()(Photos);

const EquipBrandManageC = observer(class appState extends React.Component {
  constructor() {
    super();
    this.state = {
      Selected: {
        Id: null
      },
      data: [],
      pageSize: 10
    }
  }
  componentDidMount() {
    window.rpc.device.file.getInfoById(2).then((res) => {
    })
  }
  componentWillMount() {
    window.rpc.device.file.getArray(0, 0).then((res) => {
      let type = [res].map(x => ({ ...x, key: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
      Num = type.length;
      this.props.appState.tableData = type;
      this.setState({
        data: this.props.appState.tableData
      })
    }, (err) => {
      console.warn(err);
    })
  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) }
    this.setState({ Selected });
  }

  onDelete = (key, index) => {
    window.rpc.device.file.removeById(index).then((res) => {
    }, (err) => {
      console.warn(err);
    })
    this.props.appState.tableData.splice(key, 1);
  }
  handleSearchs = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        let values = { dtype: 56 };

        if (name) {
          values = { ...values, name: name };
        }
        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        window.rpc.device.file.getArrayByContainer(values, 0, 0).then((result) => {
          let type = result.map(x => ({ ...x, key: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          Num = type.length;
          this.props.appState.tableData = type;
          message.info(`共搜索到${type.length}条数据`);
          this.setState({
            data: this.props.appState.tableData
          })
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }
  // handleSearchs = (e) => {
  //   window.rpc.device.file.getArrayByContainer({ type: 2 }, 0, 0).then((res) => {
  //     let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
  //     Num = type.length;
  //     this.props.appState.tableData = type;
  //     this.setState({
  //       data: this.props.appState.tableData
  //     })
  //     message.info(`共搜索到${type.length}条数据`);
  //   }, (err) => {
  //     console.warn(err);
  //   })
  // }
  render() {
    const data = [...this.props.appState.tableData];
    const pagination = {
      total: Num,
      showTotal: total => `共搜索到${Num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        let pagenum = (parseInt(current, 10) - 1) * pageSize;
        window.rpc.device.file.getArrayByContainer({ type: 2 }, pagenum, pageSize).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      },
      onChange: (page, PageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * this.state.pageSize;
        window.rpc.device.file.getArrayByContainer({ type: 2 }, pagenum, PageSize).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      },
    };
    const rowSelection = {
      type: 'Checkbox',
      onChange: this.onSelectChange,
    };
    $(function () {
      $(".unpack").click(function () {
        $(".overlay").height(document.body.scrollHeight);
        $(".overlay").width(document.body.scrollWidth);
        // fadeTo第一个参数为速度，第二个为透明度
        // 多重方式控制透明度，保证兼容性，但也带来修改麻烦的问题
        $(".overlay").fadeTo(200, 0.5);
        // 解决窗口缩小时放大后不全屏遮罩的问题
        // 简单来说，就是窗口重置的问题
        $(window).resize(function () {
          $(".overlay").height(document.body.scrollHeight);
          $(".overlay").width(document.body.scrollWidth);
        });
      })

      $(".open").click(function () {
        $(".overlay").fadeOut(200);
      })

      var _move = false;//移动标记
      var _x, _y;//鼠标离控件左上角的相对位置
      $(".show").click(function () {
      }).mousedown(function (e) {
        _move = true;
        _x = e.pageX - parseInt($(".show").css("left"));
        _y = e.pageY - parseInt($(".show").css("top"));
        $(".show").fadeTo(20, 0.5);//点击后开始拖动并透明显示
      });
      $(document).mousemove(function (e) {
        if (_move) {
          var x = e.pageX - _x;//移动时根据鼠标位置计算控件左上角的绝对位置
          var y = e.pageY - _y;
          $(".show").css({ top: y, left: x });//控件新位置
        }
      }).mouseup(function () {
        _move = false;
        $(".show").fadeTo("fast", 1);//松开鼠标后停止移动并恢复成不透明
      });


    })
    $(function () {
      var currents = 0;

      $(".zuofan").click(function () {
        currents = (currents + 90) % 360;
        $(".show").css("transform", 'rotate(' + currents + 'deg)');

      })
      var sWidth = 1;
      $(".fanfa").click(function () {
        if (sWidth < 2) {
          sWidth = 1.2 * sWidth;
          $(".show").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
        }
      });

      $(".suofa").click(function () {
        if (sWidth > 0.3) {
          sWidth = 0.8 * sWidth;
          $(".show").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
        }
      });

      $(".youfan").click(function () {
        currents = -((currents + 90) % 360);
        $(".show").css("transform", 'rotate(' + currents + 'deg)');

      })
    })
    const columns = [
      { title: '名称', dataIndex: 'name', key: 'name', render: (text, record) => (<span><a href="javascript:;" className="unpack"><span style={{ display: "inline-block", position: "relative", width: 26 }}><img style={{ width: 20, height: 20, display: "inline-block", position: "absolute", top: "-15px", right: 5 }} src={tupians} /></span>{text}</a></span>) },
      { title: '安装时间', dataIndex: 'createTime', key: 'createTime' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record, index) => (
          <div key={index + "@"}>
            <span style={{ display: "inline-block", width: "100%", height: "100%", position: "relative" }}>
              <span key="1">
                <a href="javascript:;" className="unpack">查看</a>
                <div className="overlay">
                  <div key="1" style={{ width: 560, height: 32, color: "white", cursor: "pointer", position: "fixed", left: 690, top: 730, zIndex: 100000000000000 }} >
                    <ul className="selects">
                      <li key="1" className="zuofan" title="点击左旋转"><img src={anticlokwise} alt="" /></li>
                      <li key="2" className="youfan" title="点击右旋转"><img src={rightRotation} alt="" /></li>
                      <li key="3" className="fanfa" title="点击放大"><img src={magnify} alt="" /></li>
                      <li key="4" className="suofa" title="点击缩小"><img src={shrink} alt="" /></li>
                    </ul>
                  </div>
                  <div key="2" style={{ width: 40, height: 40, fontSize: 30, float: "right", color: "white", borderRadius: "0 0 0 80%", background: "#cccccc", cursor: "pointer", padding: "0 0 30px 15px" }} className="open">X</div>
                  <div key="3" style={{
                    width: 800,
                    background: "#cccccc",
                    padding: 10,
                    height: 561,
                    top: 164,
                    position: "absolute",
                    left: "50%",
                    marginLeft: "-400px",
                    display: "block"
                  }} className="show">
                    <img className="unpack  imgsrote" style={{ width: "100%", height: "100%", display: "block", border: "1px solid #ffffff", padding: 10 }} src={data[index].url} />
                  </div>
                </div>
              </span>
              <span key="2" className="ant-divider" />
              <Popconfirm title="确定 删除?" onConfirm={() => this.onDelete(index, record.key)} >
                <a href="#">删除</a>
              </Popconfirm>

            </span>
          </div>
        )
      },
    ];

    return (
      <div className="typeManage">
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>截图管理</Link>
          </div>
        </div>
        <div>
          <Tabs type="card" key="card" className="tabsd">
            <TabPane tab="列表模式" key="1">
              <BrandNameAdvancedSearchForm key="122" appState={this.props.appState} className="TabsPanes" />
              <Row>
                <Col span={24}>
                  <Table
                    columns={columns}
                    rowSelection={rowSelection}
                    bordered
                    dataSource={data}
                    onChange={this.handleChange}
                    pagination={pagination}
                  />
                </Col>
              </Row>
            </TabPane>
            <TabPane tab="预览模式" key="2" className="TabsPanes">
              <div className="">
                {/*< Form layout="inline" style={{ margin: "12px 0" }}>
                  <Row>
                    <Col span={5} key="{3}">
                      <FormItem label={`名称`}>
                        <Input style={{ width: 190 }} placeholder="请输入名称" />
                      </FormItem>
                    </Col>
                    <Col span={6} key="{5}">
                      <FormItem label={`安装时间`}>

                        <RangePicker style={{ width: 200 }} />

                      </FormItem>
                    </Col>
                    <Col span={1} key="{6}">
                      <FormItem>
                        <Button type="primary" onClick={this.handleSearchs}>
                          搜索
                        </Button>
                      </FormItem>
                    </Col>
                  </Row>
                </Form >*/}
                <BrandNameAdvancedSearchForm key="112" appState={this.props.appState} className="TabsPanes" />
                <div className="TabPane">
                  <PhotosZhangshi appState={this.props.appState} />
                </div>
              </div>
            </TabPane>
          </Tabs>
        </div>

      </div>
    )
  }
})

class MonitorManage extends Component {
  render() {
    return (
      <div className="Monitors"  >
        <EquipBrandManageC appState={new appState()} />
      </div>

    )
  }
}

export default MonitorManage;
