import React, { Component } from 'react';
import {Button,Radio,Icon} from 'antd';

class ButtonSize extends React.Component {
  state = {
    size: 'large',
  };

  handleSizeChange = (e) => {
    this.setState({ size: e.target.value });
  }

  render() {
    const size = this.state.size;
    return (
      <div>
        <Radio.Group value={size} onChange={this.handleSizeChange}>
          <Radio.Button key="1" value="large">Large</Radio.Button>
          <Radio.Button key="2" value="default">Default</Radio.Button>
          <Radio.Button key="3" value="small">Small</Radio.Button>
        </Radio.Group>
      </div>
    );
  }
}
class ResourceManage extends Component {

  render() {
    return (
      <div className="Orgs"  >
        <ButtonSize />
      </div>
    )
  }
}

export default ResourceManage;