import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Table, Row, Col, Input, Button, message, Form, Popconfirm, DatePicker, Tabs, Checkbox, Tooltip, Modal } from 'antd';

import moment from 'moment';
import ico_imgs from '../../../assets/images/monitoring/bofang_.png';
import shipins from '../../../assets/images/monitoring/shipins.png';
import './PictureManager.css';
const FormItem = Form.Item;



const TabPane = Tabs.TabPane;
var Num = '';
const RangePicker = DatePicker.RangePicker;
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      num: null,
      photoData: [],
      number: null,
    })
  }
}

class BrandSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [],
      value: undefined
    }
  }

  handleCancel = () => this.setState({ previewVisible: false })

  handlePreview = (file) => {
    this.setState({
      previewImage: file.url || file.thumbUrl,
      previewVisible: true,
    });
  }

  handleChange = ({ fileList }) => this.setState({ fileList })
  componentWillMount() {

  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const ownerId = fieldsValue['orgs'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['state'];
        let values = { type: 1 };

        if (name) {
          values = { ...values, name: name };
        }
        if (ownerId) {
          values = { ...values, ownerId: parseInt(ownerId, 10) }
        }
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        if (location) {
          values = { ...values, location: location }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        window.rpc.device.file.getArrayByContainer(values, 0, 0).then((result) => {
          let type = result.map(x => ({ ...x, key: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          Num = type.length;
          this.props.appState.tableData = type;
          message.info(`共搜索到${type.length}条数据`);
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: "12px 0" }}>
        <Row>
          <Col span={5} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 190 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`安装时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{ width: 200 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form >
    );
  }
}
const BrandNameAdvancedSearchForm = Form.create()(BrandSearchForm);

class Photos extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [],
      visibleA: false,
      number: null,
      url: [],
    }
  }

  showModalA = (num) => {
    this.setState({
      visibleA: true,
      number: num
    });
    this.props.appState.num = num;
  }
  handleOkA = () => {
    this.setState({
      visibleA: false,
    });
  }
  handleCancellA = () => {
    this.setState({
      visibleA: false,
    });
  }

  componentDidMount() {
    window.rpc.device.file.getArrayByContainer({ type: 1 }, 0, 0).then((res) => {
      let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
      this.props.appState.photoData = type;
      this.props.appState.tableData = type;
      let url = [];
      for (let i = 0; i < res.length; i++) {
        url[i] = res[i].url;
      }
      this.setState({
        data: type,
        url
      })
    }, (err) => {
      console.warn(err);
    })
  }
  render() {
    var items = [];

    for (var i = 0; i < this.props.appState.tableData.length; i++) {
      items.push(
        <div key={i}>
          <Checkbox style={{ position: "absolute", top: 2, left: 2, borderRadius: "10px" }}></Checkbox>
          <Tooltip title="点击播放" className="tooltip_">
            <div>
              <img src={ico_imgs} alt="" style={{ width: 83, height: 83, display: "block", border: "1px solid #ffffff", marginLeft: 18, marginTop: 10 }} onClick={this.showModalA.bind(this, i)} />
              <p style={{ textAlign: "center", lineHeight: "40px" }}>{this.props.appState.tableData[i].name}</p>
            </div>
            <div className="tooltip_modu" >
              <div aria-labelledby="rcDialogTitle4">
              </div>
            </div>
          </Tooltip>
        </div>);
    }
    return (
      <div>
        {items}
        <Modal visible={this.state.visibleA}
          onOk={this.handleOkA} onCancel={this.handleCancellA} width="680px" style={{}}
          okText="OK" cancelText="Cancel" className="tooltip_modus show"
        >
          <video src={this.state.url[this.props.appState.num]} width="640px" height="480px" autoPlay controls="controls" style={{ marginTop: "-16px", background: "black", cursor: "pointer" }}>
          </video>
        </Modal>
      </div>
    )
  }
}
const PhotosZhangshi = Form.create()(Photos);

const EquipBrandManageC = observer(class appState extends React.Component {
  constructor() {
    super();
    this.state = {
      Selected: {
        Id: null
      },
      data: [],
      pageSize: 10,
      num: null,
      urll: []
    }
  }

  state = { visible: false }
  showModal = (num) => {
    this.setState({
      visible: true,
    });
    this.props.appState.number = num;
  }
  handleOk = () => {
    this.setState({
      visible: false,
    });
  }
  handleCancell = () => {
    this.setState({
      visible: false,
    });
  }
  componentDidMount() {
    window.rpc.device.file.getArrayByContainer({ type: 1 }, 0, 0).then((res) => {
      let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
      Num = type.length;
      this.props.appState.tableData = type;
      let urll = [];
      for (let i = 0; i < res.length; i++) {
        urll[res[i].id] = res[i].url;
      }
      this.setState({
        data: this.props.appState.tableData,
        urll
      })
    }, (err) => {
      console.warn(err);
       console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) }
    this.setState({ Selected });
  }

  onDelete = (key, index) => {
    window.rpc.device.file.removeById(index).then((res) => {
    }, (err) => {
      console.warn(err);
    })
    this.props.appState.tableData.splice(key, 1);
  }
  render() {
    const data = [...this.props.appState.tableData];
    const pagination = {
      total: Num,
      showTotal: total => `共搜索到${Num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        let pagenum = (parseInt(current, 10) - 1) * pageSize;
        window.rpc.device.file.getArrayByContainer({ type: 1 }, pagenum, pageSize).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      },
      onChange: (page, PageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * this.state.pageSize;
        window.rpc.device.file.getArrayByContainer({ type: 1 }, pagenum, PageSize).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, name: x.name, url: x.url, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      },
    };
    const rowSelection = {
      type: 'Checkbox',
      onChange: this.onSelectChange,
    };

    const columns = [
      { title: '名称', dataIndex: 'name', key: 'name', render: (text, record) => (<div><img style={{ width: 26, height: 26, display: "inline-block", marginTop: "-5px", marginRight: 5, float: "left" }} src={shipins} alt="" /><a href="javascript:;" onClick={this.showModal.bind(this, record.key)}>{text}</a></div>) },
      { title: '安装时间', dataIndex: 'createTime', key: 'createTime' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record, index) => (

          <div>
            <span >
              <a href="javascript:;" onClick={this.showModal.bind(this, record.key)}>查看</a>
              <span className="ant-divider" />
              <Popconfirm title="确定 删除?" onConfirm={() => this.onDelete(index, record.key)} style={{ position: "absolute", top: 0 }}>
                <a href="#">删除</a>
              </Popconfirm>
            </span>
            <div className="tooltip_modu" style={{ display: "none", background: "black" }}>
              <div aria-labelledby="rcDialogTitle4">
              </div>
            </div>
          </div>
        )
      },
    ];

    return (
      <div className="typeManage">
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>视频管理</Link>
          </div>
        </div>
        <Modal visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancell} width="680px" style={{ background: "#cccccc" }}
          okText="OK" cancelText="Cancel" className="tooltip_modus show"
        >
          <video src={this.state.urll[this.props.appState.number]} width="640px" height="480px" autoPlay controls="controls" style={{ marginTop: "-16px", background: "black" }}>
          </video>
        </Modal>
        <div>
          <Tabs type="card" className="tabsd">
            <TabPane tab="列表模式" key="1">
              <BrandNameAdvancedSearchForm appState={this.props.appState} className="TabsPanes" />
              <Row>
                <Col span={24}>
                  <Table
                    columns={columns}
                    rowSelection={rowSelection}
                    bordered
                    dataSource={data}
                    onChange={this.handleChange}
                    pagination={pagination}
                  />
                </Col>
              </Row>
            </TabPane>
            <TabPane tab="预览模式" key="2" className="TabsPanes">

              <div className="">
                <BrandNameAdvancedSearchForm appState={this.props.appState} className="TabsPanes" />
                {/*< Form layout="inline" style={{ margin: "12px 0" }}>
                  <Row>
                    <Col span={5} key={1}>
                      <FormItem label={`名称`}>
                        <Input style={{ width: 190 }} placeholder="请输入名称" />
                      </FormItem>
                    </Col>
                    <Col span={6} key={5}>
                      <FormItem label={`安装时间`}>
                        <RangePicker style={{ width: 200 }} />
                      </FormItem>
                    </Col>
                    <Col span={1} key={6}>
                      <FormItem>
                        <Button
                          type="primary"
                          onClick={this.handleSearch}
                        >
                          搜索
                        </Button>
                      </FormItem>
                    </Col>
                  </Row>
                </Form >*/}
                <div className="TabPane">
                  <PhotosZhangshi appState={this.props.appState} />
                </div>
              </div>
            </TabPane>
          </Tabs>
        </div>

      </div>
    )
  }
})

class MonitorManage extends Component {
  render() {
    return (
      <div className="Monitors"  >
        <EquipBrandManageC appState={new appState()} />
        <div>
        </div>
      </div>
    )
  }
}

export default MonitorManage;
