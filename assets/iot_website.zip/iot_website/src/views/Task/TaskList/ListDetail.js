import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Input, Select, message, Steps, Checkbox } from 'antd';
import moment from 'moment';
import chakan_pic from '../../../assets/images/task/chakan.png';

const { Option } = Select;
const Step = Steps.Step;


// 设置message消息
message.config({
    top: 216,
    duration: 2
})



// 取出等级
//let levels = JSON.parse(sessionStorage.getItem('grouplevels'))|| [];;
//let ownerNames = JSON.parse(sessionStorage.getItem('groupownerNames'))|| [];;
//let locations = JSON.parse(sessionStorage.getItem('locations'));

// 初始化mobx设置
class appState {
    // @observable tableData = [];
    // @observable selectId = null;
    constructor() {
        extendObservable(this, {
            tableData: [],
            basicMes: [],
            logtableData: [],
            // selectIdOne: null

        })
    }
}


// @observer
const TaskDeatailC = observer(class TaskDeatailC extends Component {
    constructor() {
        super();
        this.state = {
            basicMes: [],
        };
    }

    componentDidMount() {
        const id = parseInt(this.props.params.id, 10);
        let values = { 'id': id };

        // 基础信息
        window.rpc.alias.getInfoByName('task.state').then((stateData) => {
            return window.rpc.alias.getInfoByName('task.type').then((typeData) => ({ state: stateData.value, type: typeData.value }))
                .then((result) => {
                    return window.rpc.task.user.getMapIdNameByContainer(values, 0, 0).then((userdata) => ({
                        userdata, type: result.type, state: result.state
                    })).then((users) => {
                        return window.rpc.task.getInfoById(id).then((data) => ({ data, userNames: users.userdata, type: users.type, state: users.state })).then((taskData) => {
                            const res = taskData.data
                            let userObj = taskData.userNames;
                            let userNameStr = '';
                            for (let value in userObj) {
                                userNameStr += userObj[value] + ',';
                            }
                            if (userNameStr) {
                                userNameStr = userNameStr.substring(0, 10) + "...";
                            }
                            const basicMes = { ...res, name: res.name, userNames: userNameStr, number: res.number, beginTime: moment(res.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(res.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), setupTime: moment(res.createTime).format('YYYY-MM-DD'), expireTime: moment(res.endTime).format('YYYY-MM-DD'), type: taskData.type[res.type], state: taskData.state[res.state] };
                            //const basicMes =[];
                            this.setState({ basicMes });
                        })

                    })
                })
        }, (err) => {

            console.warn(err);
        })

        //设备清单
        window.rpc.task.device.getArrayBriefByContainer(values, 0, 10).then((result) => {
            let devices = result.map((x) => ({ ...x, key: x.id, name: x.name, state: x.state, location: x.location, typeName: x.typeName, setupTime: moment(result.setupTime).format("YYYY年MM月DD日") || new Date().toLocaleString }));
            this.props.appState.tableData = devices;

        }, (err) => {
            console.warn(err);
        })

        //任务日志
        window.rpc.alias.getInfoByName('task.log.opcode').then((opcodeData) => {
            return window.rpc.task.log.getArrayBriefByContainer(values, 0, 0).then((data) => {
                return { data, opcode: opcodeData.value };
            }).then((res) => {
                const result = res.data;
                let remarkStr = result.remark;
                if (remarkStr) {
                    remarkStr = remarkStr.substring(0, 10) + "...";
                }
                let logMes = result.map((x) => ({ ...x, key: x.id, id: x.id, userName: x.userName, opcode: res.opcode[x.opcode], remark: remarkStr, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString }));
                this.props.appState.logtableData = logMes;
                console.log(logMes)
            }, (err) => {
                console.warn(err);
            })
        })
    }



    render() {
        const columns = [
            { title: '名称', dataIndex: 'name', key: 'name' },
            { title: '类型', dataIndex: 'typeName', key: 'typeName' },
            { title: '安装时间', dataIndex: 'setupTime', key: 'setupTime' },
            {
                title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record) => {
                    let textArr = text.split(',');
                    if (textArr[2]) {
                        return (
                            <span>
                                <Link to={`/org/building/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                                 <Link to={`/org/floor/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>--
                                 <Link to={`/org/areacontent/${textArr[2].split(':')[0]}`}>{textArr[2].split(':')[1]}</Link>
                            </span>
                        )
                    }
                    if (textArr[1]) {
                        return (
                            <span>
                                <Link to={`/org/building/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                                <Link to={`/org/floor/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>
                            </span>
                        )
                    }
                    if (textArr[0]) {
                        return (
                            <span>
                                <Link to={`/org/building/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>
                            </span>
                        )
                    }
                }
            },
            {
                title: '是否已检查', dataIndex: 'state', key: 'state',
                render: (text, record, index) => (
                    <Checkbox style={{ marginLeft: "50%" }} checked={record.state}></Checkbox>
                ),
            },
            {
                title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
                    <span>
                        <Link to={`/member/groupdetail/${record.key}`} style={{ marginRight: 8, float: 'left' }}>查看</Link>
                        <img src={chakan_pic} style={{ float: 'left', padding: '2px 0' }} alt="" />
                    </span>
                )
            },
        ];

        const dataSource = [...this.props.appState.tableData];
        const pagination = {
            total: this.props.appState.tableData.length,
            showTotal: total => `共 ${total} 条`,
            showSizeChanger: true,
            showQuickJumper: true,
            onShowSizeChange: (current, pageSize) => {
                console.log('Current: ', current, '; PageSize: ', pageSize);
            },
            onChange: (current) => {
                console.log('Current: ', current);
            },
        };

        const logdataSource = [...this.props.appState.logtableData];
        const logcolumns = [
            { title: '时间', dataIndex: 'createTime', key: 'createTime' },
            { title: '操作', dataIndex: 'opcode', key: 'opcode' },
            { title: '操作人', dataIndex: 'userName', key: 'userName' },
            { title: '日志编号', dataIndex: 'id', key: 'id' },
            { title: '系统信息', dataIndex: 'remark', key: 'remark' },
            {
                title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
                    <span>
                        <Link to={`/member/groupdetail/${record.key}`}>查看</Link>
                    </span>
                )
            },
        ];
        let personName = '小叶子，小树，何，张，李，蔡'.substring(0, 10) + "...";
        return (
            <div className="TaskDetail" style={{ padding: 24 }}>
                <Row style={{ padding: '5px 0 10px 0' }}>
                    <span style={{ fontWeight: 'bold' }}>任务编号2016062334521</span>
                </Row>
                <Row style={{ padding: '5px 0 10px 0' }}>
                    <Col span={24} style={{ marginTop: 25, marginBottom: 8 }}>
                        <Steps current={1}>
                            <Step title="创建" status="finish" description={<div><span>海纳</span><span><br />2016-6-23 18:23:04</span></div>} />
                            <Step title="发布" status="finish" description={<div><span>钟欣</span><span><br />2016-6-23  19:23:04</span></div>} />
                            <Step title="进行中" status="process" description={<div><span>{personName}</span><br /><a>催 ta 一下</a></div>} />
                            <Step title="完成" status="wait" />
                        </Steps>
                    </Col>
                </Row>
                <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />

                <Row style={{ padding: '8px 0 15px 0' }}>
                    <span style={{ fontWeight: 'bold' }}>基本信息</span>
                </Row>
                <Row type="flex" justify="center" align="middle" style={{ marginLeft: '5%' }}>
                    <Col span={8} style={{ marginTop: 10 }}>

                        任务名称： {this.state.basicMes.name}
                    </Col>
                    <Col span={8} style={{ marginTop: 10 }}>
                        任务状态： {this.state.basicMes.state}
                    </Col>
                    <Col span={8} style={{ marginTop: 10 }}>
                        任务类型： {this.state.basicMes.type}
                    </Col>
                </Row>
                <Row type="flex" justify="center" align="top" style={{ marginLeft: '5%' }}>
                    <Col span={8} style={{ marginTop: 10 }}>

                        任务编号：{this.state.basicMes.number}
                    </Col>
                    <Col span={8} style={{ marginTop: 10 }}>
                        开始时间：{this.state.basicMes.beginTime}
                    </Col>
                    <Col span={8} style={{ marginTop: 10 }}>
                        截止时间： {this.state.basicMes.endTime}
                    </Col>
                </Row>
                <Row type="flex" justify="center" align="top" style={{ marginLeft: '5%', paddingBottom: '15px' }}>
                    <Col span={8} style={{ marginTop: 10 }}>

                        负责人： {this.state.basicMes.userNames}
                    </Col>
                    <Col span={8} style={{ marginTop: 10 }}>

                    </Col>
                    <Col span={8} style={{ marginTop: 10 }}>

                    </Col>
                </Row>
                <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />

                <Row style={{ padding: '8px 0 15px 0' }}>
                    <span style={{ fontWeight: 'bold' }}>设备清单（列表）</span>
                </Row>
                <Row style={{ padding: '5px 0 0' }}>
                    <Col span={24}>
                        <Table
                            bordered
                            columns={columns}
                            dataSource={dataSource}
                            pagination={pagination}
                        />
                    </Col>
                </Row>
                <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />

                <Row style={{ padding: '5px 0 0' }}>
                    <span style={{ fontWeight: 'bold' }}>任务日志</span>
                </Row>
                <Row style={{ padding: '5px 0 0' }}>
                    <Col span={24}>
                        <Table
                            bordered
                            columns={logcolumns}
                            dataSource={logdataSource}
                            pagination={false}
                        />
                    </Col>
                </Row>
            </div>

        );
    }
})

class ListDetail extends Component {
    render() {
        return (
            <div className="ListDetail">
                <TaskDeatailC appState={new appState()} params={this.props.params} />
            </div>
        );
    }
}

export default ListDetail;