/*
 * @Author: cai.jiadi 
 * @Date: 2017-03-17 15:53:49 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-12 09:36:38
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { observable } from 'mobx';
import { observer } from 'mobx-react';
import { Menu, Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Checkbox } from 'antd';
import moment from 'moment';
// import Ps from '../../../assets/images/ps.png';
import './index.css';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

class appState {
  @observable todos: {}
}

let typeChildren = [], stateChildren = [], number = 0;
class AdvancedSearchForm extends React.Component {
  componentWillMount() {
    window.rpc.alias.getInfoByName('task.type').then((result) => {
      for (let i in result.type) {
        typeChildren.push(<Option key={`${i}`}>{result.type[i]}</Option>)
      }
    })
    window.rpc.alias.getInfoByName('task.state').then((result) => {
      for (let i in result.state) {
        stateChildren.push(<Option key={`${i}`}>{result.state[i]}</Option>)
      }
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        const concat = fieldsValue['concat'];
        const dstate = fieldsValue['state'];
        let values = {restype:256};
        if (name) {
          values = { ...values, name };
        }
        //设备类型
        if (dtype) {
          values = { ...values, type: fieldsValue['dtype'].map(x => parseInt(x, 10)) }
        }
        //运行状态
        if (dstate) {
          values = { ...values, state: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        //所属建筑
        if (concat) {
          values = { ...values, concat: fieldsValue['concat'].map(x => x) }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        let hash = false;
        for (let i in values) {
          if (values[i].length > 0) {
            hash = true;
            break;
          }
        }
        window.rpc.task.getArrayByContainer(values, 0, 0).then((data) => {
          number = data.length
          if (!hash) message.info(`共搜索到${data.length}条数据`);
        })
        window.rpc.alias.getInfoByName('task.state').then((info) => {
          return window.rpc.alias.getInfoByName('task.type').then((res) => ({ state: info.value, type: res.value }))
            .then((result) => {
              return window.rpc.task.getArrayByContainer(values, 0, 10).then((data) => {
                return { data, type: result.type, state: result.state };
              }).then((result) => {
                const res = result.data;
                if (hash) message.info(`共搜索到${res.length}条数据`);
                const device = res.map(x => ({ ...x, key: x.id, setupTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD'), expireTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD'), type: result.type[x.type], state: result.state[x.state], stop: '停用' }))
                this.props.appState.todos = device
              })
            })
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form inline style={{ margin: "12px 0 0 0" }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 190 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`类型`}>
              {getFieldDecorator(`dtype`)(
                <Select multiple style={{ width: 190 }} placeholder="请选择">
                  {typeChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`状态`}>
              {getFieldDecorator(`dstate`)(
                <Select multiple style={{ width: 190 }} placeholder="请选择">
                  {stateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`联系人`}>
              {getFieldDecorator(`concat`)(
                <Select multiple style={{ width: 170 }} placeholder="请选择">

                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`巡查日期`} style={{ width: "100%" }}>
              {getFieldDecorator(`expireTime`)(
                <RangePicker style={{ width: 250 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}
function desiper(a) {
  return function update(state) {
    return {
      value: state.value * a
    }
  }
}
const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
@observer
class EquipList extends React.Component {
  state = {
    selectedRowKeys: [],  // Check here to configure the default column
    record: [],
    data: [],
    pageSize: 10,
    desipertion: {},
    value: 1
  };
  componentWillReceiveProps(nextProps) {
    this.setState({
      desipertion: nextProps.desipertion
    })
  }
  componentWillMount() {
    this.setState(desiper(5))
    window.rpc.task.getArrayByContainer({restype:256}, 0, 0).then(res => {
      number = res.length;
    })
    window.rpc.alias.getInfoByName('task.state').then((info) => {
      return window.rpc.alias.getInfoByName('task.type').then((res) => ({ state: info.value, type: res.value }))
        .then((result) => {
          return window.rpc.task.getArrayByContainer({restype:256}, 0, 10).then((data) => {
            return { data, type: result.type, state: result.state };
          }).then((result) => {
            //console.info(result);
            const res = result.data
            //console.log(result.type)
            for (let i in result.type) {
              //console.log(i)
              typeChildren.push(<Option key={`${i}`}>{result.type[i]}</Option>)
            }
            for (let i in result.state) {
              stateChildren.push(<Option key={`${i}`}>{result.state[i]}</Option>)
            }
            const device = res.map(x => ({ ...x, key: x.id, setupTime: moment(x.createTime).format('YYYY-MM-DD'), expireTime: moment(x.endTime).format('YYYY-MM-DD'), type: result.type[x.type], state: result.state[x.state], stop: '停用' }))
            //console.log(device);
            this.props.appState.todos = device
            this.setState({
              record: device
            })

          })
        })
    })
  }
  //列表选择改变
  onSelectChange = (selectedRowKeys, record, selectRow) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    console.log(record)
    console.log(selectRow)
    this.setState({ selectedRowKeys, record });
  }
  //选择框启用/停用绑定 点击
  handleMenuClick = (e) => {
    console.log(this.state.record)
    if (this.state.selectedRowKeys.length <= 0) {
      message.info('请选择任务设备或任务单位');
    }
    let record = [];
    switch (e.key) {
      case "1":
        record = this.state.record.map(x => ({ ...x, stop: '启用' }));
        console.log(record)
        this.setState({
          record
        })
        break;
      default:
        break;
    }
  }
  //批量操作点击
  onMutilple = () => {
    console.log(this.state.record);
     let state=parseInt(this.props.appState.number,10);
    //console.log(state);
    //console.log(this.state.record);
    let id=this.state.selectedRowKeys;
     //console.log(id)
    // window.rpc.rules.updateStateByArrayId(id,state).then(data=>{
    //    console.log(data);
    //    if(data){
    //       message.info('操作成功！') 
    //    }   
    //    //message.info('')   
    // },err=>{
    //    console.log(err);    
    // })
  }
  //onExpand 表格展开事件
  onExpand = (expanded, record) => {
    console.log(record)
    let desipertion, self = this;
    function expand() {
      return new Promise((resolve, reject) => {
        window.rpc.task.owner.getArrayBriefByContainer({ id: record.id }, 0, 0).then((res) => {
          resolve();
          desipertion = res.map(x => ({ ...x, key: x.id, setupTime: moment(x.createTime).format('YYYY-MM-DD'), safetyLevel:x.safetyLevel||'' ,address:x.address||'' ,userName:x.userName||'', number:x.number||''}));
        })
      })
    }
    async function execute() {
      await expand();
      const des = self.state.desipertion;
      des[record.key] = desipertion
      self.setState({
        desipertion: des
      })
    }
    execute();
    setTimeout(() => {
      for (var i = 0; i < document.getElementsByClassName('ant-table-expanded-row').length; i++) {
        document.getElementsByClassName('ant-table-expanded-row')[i].children[1].setAttribute('colspan', 8)
      }
    }, 0)
  }
  getCheckboxProps = (record) => {
    console.log(record)
  }
  //启用停用输出 表格操作启停修改   +++ 需要加操作同批量操作点击
  flagState = (record,e) => {
    console.log(record);
    console.log(e.target.getAttribute("data-flag"));
    let state=parseInt(e.target.getAttribute("data-flag"),10)+1;
    console.log(state);
    
    //  window.rpc.rules.updateStateByArrayId([record.id],state).then(data=>{
    //    if(data){
    //       message.info('操作成功！') 
    //    }      
    // },err=>{
    //    console.log(err);    
    // })
    if (e.target.getAttribute("data-flag") === "1") {
      e.target.setAttribute("data-flag", "0")
      e.target.innerText = '启用'
    } else {
      e.target.setAttribute("data-flag", "1")
      e.target.innerText = '停用'
    }
  }
  //更多操作 onchange
  handlemore = (value) => {
    //console.log(`selected ${value}`);
    this.props.appState.number = value;
    //document.getElementById("select").style.border = 'none';
    console.log(this.props.appState.number);
  
  }
  render() {
    const menu = (
      <Menu onClick={this.handleMenuClick}>
        <Menu.Item key="1">停用</Menu.Item>
        <Menu.Item key="2">启用</Menu.Item>
      </Menu>
    );
    let { selectedRowKeys } = this.state;
    let hellcotion = 0;
    if (selectedRowKeys) {
      hellcotion = selectedRowKeys.length;
    }
    const columns = [
      {
        key: 'id',
        title: '序号',
        dataIndex: 'id',
      }, {
        key: 'name',
        title: '名称',
        dataIndex: 'name',
      }, {
        key: 'type',
        title: '类型',
        dataIndex: 'type',
      }, {
        key: 'setupTime',
        title: '创建日期',
        dataIndex: 'setupTime',
      }, {
        key: 'expireTime',
        title: '截止日期',
        dataIndex: 'expireTime',
      }, {
        key: 'state',
        title: '处理结果',
        dataIndex: 'state',
      }, {
        key: 'contact',
        title: '巡查人',
        dataIndex: 'contact',
      }, {
        key: 'operation',
        title: '操作',
        dataIndex: 'operation',
        render: (text, record) => (
          <span>
            <Link to={`/task/list/org/detail/${record.key}`} style={{ marginRight: 10 }}>查看</Link>
            <Link to='' data-flag="1" onClick={(e)=>this.flagState(record,e)}>{record.stop === '停用' ? '停用' : '启用'}</Link>
          </span>
        )
      }
    ];

    const columnsChildren = [{
      key: 'id',
      title: '单位名称',
      dataIndex: 'name',
      render: ((text, record) => <Link to={`/equip/device/info/${record.key}`}>{text}</Link>)
    }, {
      key: 'safetyLevel',
      title: '安全等级',
      dataIndex: 'safetyLevel',
    }, {
      key: 'address',
      title: '单位地址',
      dataIndex: 'address',
    },
     {
      key: 'userName',
      title: '联系人',
      dataIndex: 'userName',
    },{
      key: 'number',
      title: '联系电话',
      dataIndex: 'number',
    },{
      key: 'execute',
      title: '是否执行',
      dataIndex: 'execute',
      render: (text, record) => (
        <span>
          <Checkbox>是</Checkbox>
        </span>
      )
    }, {
      key: 'operation',
      title: '操作',
      dataIndex: 'operation',
      render: (text, record) => (
        <span>
          <Link to={`/equip/device/info/${record.key}`} style={{ marginRight: 10 }}>查看</Link>
          <Link to='' onClick={(e)=>this.flagState(record,e)} data-flag="1">停用</Link>
        </span>
      )
    }
    ];

    const pagination = {
      total: number,
      showTotal: total => `共 ${number} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log(pageSize)
        this.setState({
          pageSize
        })
        let pagenum = (parseInt(current, 10) - 1) * pageSize;
        window.rpc.alias.getInfoByName('task.state').then((info) => {
          return window.rpc.alias.getInfoByName('task.type').then((res) => ({ state: info.value, type: res.value }))
            .then((result) => {
              return window.rpc.task.getArrayByContainer({restype:256}, pagenum, pageSize).then((data) => {
                return { data, type: result.type, state: result.state };
              }).then((result) => {
                const res = result.data
                console.log(res)
                const device = res.map(x => ({ ...x, key: x.id, setupTime: moment(x.createTime).format('YYYY-MM-DD'), expireTime: moment(x.endTime).format('YYYY-MM-DD'), type: result.type[x.type], state: result.state[x.state], stop: '停用' }))
                console.log(device)
                this.props.appState.todos = device
              })
            })
        })
      },
      onChange: (page, pageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * 10;
        console.log(pageSize)
        window.rpc.alias.getInfoByName('task.state').then((info) => {
          return window.rpc.alias.getInfoByName('task.type').then((res) => ({ state: info.value, type: res.value }))
            .then((result) => {
              return window.rpc.task.getArrayByContainer({}, pagenum, this.state.pageSize).then((data) => {
                return { data, type: result.type, state: result.state };
              }).then((result) => {
                const res = result.data
                console.log(res)
                const device = res.map(x => ({ ...x, key: x.id, setupTime: moment(x.createTime).format('YYYY-MM-DD'), expireTime: moment(x.endTime).format('YYYY-MM-DD'), type: result.type[x.type], state: result.state[x.state], stop: '停用' }))
                this.props.appState.todos = device
              })
            })
        })
      }
    }
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      selections: [{
        key: 'odd',
        text: 'Select Odd Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((key, index) => {
            if (index % 2 !== 0) {
              return false;
            }
            return true;
          });
          this.setState({ selectedRowKeys: newSelectedRowKeys });
        },
      }, {
        key: 'even',
        text: 'Select Even Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((key, index) => {
            if (index % 2 !== 0) {
              return true;
            }
            return false;
          });
          this.setState({ selectedRowKeys: newSelectedRowKeys });
        },
      }],
      onSelection: this.onSelection,
    };
    return (
      <div className="TaskList ConcenHistory">
        <div style={{ fontSize: '0.75em', overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>任务清单</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 8 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.onMutilple}>批量操作</Button>
          </div>
          <div style={{ float: 'left', marginRight: 4 }} className="TaskRules">
            <div style={{ marginLeft: 5, float: 'left', width: 110, height: 32, background: '#d9dee4' }} className='select-small'>
              <Select
                showSearch
                style={{ width: 100, height: 32, color: '#373e41' }}
                id="select"
                placeholder="更多操作"
                optionFilterProp="children"
                onChange={this.handlemore}
                filterOption={(input, option) => option.props.value.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                <Option value="1">启用</Option>
                <Option value="2">停用</Option>
              </Select>
            </div>
          </div>
        </div>
        <div style={{ marginBottom: 15 }}> <WrappedAdvancedSearchForm equipTaskState={this.props.equipTaskState} appState={this.props.appState} /></div>
        <Table rowSelection={rowSelection} columns={columns} getCheckboxProps={this.getCheckboxProps} onExpand={this.onExpand} dataSource={this.props.appState.todos} pagination={pagination} style={{ textAlign: "center", width: "100%" }} expandedRowRender={record => <Table rowSelection={rowSelection} columns={columnsChildren} dataSource={this.state.desipertion[record.key]} />} />
      </div >
    );
  }
}

class TaskList extends Component {
  render() {
    return (
      <div className="tableList"><EquipList appState={new appState()} /></div>
    )
  }
}

export default TaskList;