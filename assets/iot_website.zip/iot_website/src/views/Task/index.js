/*
 * @Author: lai.haibo 
 * @Date: 2017-03-24 09:25:17 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-15 15:25:17
 */

import React, { Component } from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router';
const { Header, Sider, Content } = Layout;
const MenuItemGroup = Menu.ItemGroup;

const routes = {
  list: [{
    name: '设备检查任务',
    path: '/task/list',
    key: '1'
  },
  {
    name: '安全检查任务',
    path: '/task/list/org',
    key: '2'
  },],
  rule: [{
    name: ' 设备检查任务规则',
    path: '/task/rule',
    key: '3'
  }, {
    name: '安全检查任务规则',
    path: '/task/rule/taskequip',
    key: '4'
  }],
  report: [{
    name: '任务报表',
    path: '/task/report',
    key: '5'
  }]
}

class Task extends Component {
  state = {
    collapsed: false,
    seconds: {
      background: '#eaedf1'
    },
    route: routes.list,
    routeName: '设备任务清单',
    routeKey: '1',
    data: [true, true, true, true, true],
    display: ''
  };
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
      seconds: {
        background: '#eaedf1',
        display: this.state.collapsed ? 'block' : 'none'
      }
    });
  };
  componentWillMount() {
    if (this.props.children) {
      let path = this.props.children.props.route.path;
      if (path === '/task/list') {
        this.setState({
          route: routes.list,
          routeName: '任务清单',
          routeKey: '1'
        })
      } else if (path === '/task/rule' || path === '/task/rule/taskequip') {
        this.setState({
          route: routes.rule,
          routeName: '任务规则',
          routeKey: '2'
        })
      } else if (path === '/task/report') {
        this.setState({
          route: routes.report,
          routeName: '任务报表',
          routeKey: '3'
        })
      }
    }
  };
  componentDidMount() {
    //查报表
    window.rpc.report.template.getArrayBriefByContainer(null, 0, 0).then((result) => {
      let reportName = [{ name: '/' }];
      for (let value of result) {
        reportName[value.id] = value;
      }
      sessionStorage.setItem('reportName', JSON.stringify(reportName));
    }, (err) => {
      console.warn(err);
    })
    // 查区域
    window.rpc.area.getMapIdNameByContainer(null, 0, 0).then((result) => {
      let locationName = result;
      sessionStorage.setItem('locationName', JSON.stringify(locationName));
    }, (err) => {
      console.warn(err);
    })
    //查设备类型
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let dtypes = [{ name: '/' }];
      for (let value of result) {
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes', JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })
    // 查权限
    window.rpc.menu.getInfo().then((res) => {
      let display = res[7].default ? '' : 'none';
      let data = [];
      data.push(res[7].data[0].data[0].default, res[7].data[0].data[1].default, res[7].data[1].data[0].default, res[7].data[1].data[1].default, res[7].data[2].data[0].default, )
      this.setState((prevState) => ({ data, display }));
    })
  }
  componentWillReceiveProps(nextProps) {
    let path = nextProps.children.props.route.path;
    if (path === '/task/list') {
      this.setState({
        route: routes.list,
        routeName: '任务清单',
        routeKey: '1'
      })
    } else if (path === '/task/rule' || path === '/task/rule/taskequip') {
      this.setState({
        route: routes.rule,
        routeName: '任务规则',
        routeKey: '2'
      })
    } else if (path === '/task/report') {
      this.setState({
        route: routes.report,
        routeName: '任务报表',
        routeKey: '3'
      })
    }
    let routerkeys = Object.keys(routes);
    let route = [...routes[routerkeys[0]], ...routes[routerkeys[1]], ...routes[routerkeys[2]]];
    let routeKey = route.filter(x => x.path === path)[0] ? route.filter(x => x.path === path)[0].key : '10000';
    this.setState({
      routeKey
    });
  };
  render() {
    return (
      <Layout className="Task">
        <Sider
          trigger={null}
          collapsible
          collapsed={this.state.collapsed}
          style={this.state.seconds}
          width={180}
        >
          <div className="logo" style={{ background: '#eaedf1', height: '70px', lineHeight: '70px', paddingLeft: '24px' }}>{this.state.routeName}</div>
          <Menu theme="light" mode="inline" defaultSelectedKeys={[this.state.routeKey]} selectedKeys={[this.state.routeKey]} style={{ background: '#eaedf1' }}>
            {this.state.route.map(route =>
              (<Menu.Item
                key={route.key}
                disabled={!this.state.data[parseInt(route.key) - 1]} key={route.key}
                style={{ display: this.state.data[parseInt(route.key) - 1] ? '' : 'none', height: '40px' }}
              >
                <Link to={route.path} style={{ color: "#666" }}>
                  {route.name}
                </Link>
              </Menu.Item>))}
          </Menu>
        </Sider>
        <Layout style={{ padding: '0', position: 'static!important' }}>
          <div className="toggle" style={{ height: '32px', width: '18px', background: this.state.collapsed ? '#eaedf1' : '#fff', textAlign: 'center', position: 'absolute', top: '50vh', marginLeft: this.state.collapsed ? 0 : '-18px' }}>
            <Icon
              className="trigger-right"
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
              onClick={this.toggle}
            />
          </div>
          <Content style={{ display: this.state.display, padding: 24, margin: 0, background: '#fff', minHeight: 280 }}>
            {this.props.children}
          </Content>
          <Content key='2' style={{ display: this.state.display === 'none' ? '' : 'none', padding: 24, margin: 0, textAlign: "center", marginTop: '10%', background: '#fff', fontSize: '2rem', minHeight: 280 }}>
            权限不足！
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Task;