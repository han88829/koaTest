/*
 * @Author: Han.beibei 
 * @Date: 2017-03-24 11:07:15 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-03-24 19:19:56
 */

import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Popconfirm } from 'antd';
import moment from 'moment';
import listStore from '../listStore';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
var number = '';
let rStateChildren = [], rState = new Map();
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 结构出参量表
const { rStateList } = listStore;

let reg = /\,/ig;
class appState {
  constructor() {
    extendObservable(this, {
      tableDataOne: []
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
    window.rpc.alias.getValueByName('device.rstate').then((res) => {
      console.log(res)
      for (let value in res) {
        rStateChildren.push(<Option key={`${value}`}>{res[value]}</Option>)
        rState[value] = res[value];
        rState[res[value]] = value;
      }
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['state'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        //设备类型
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => parseInt(x, 10)) }
        }
        //运行状态
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        //所属建筑
        if (location) {
          values = { ...values, location: fieldsValue['location'].map(x => x) }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        //console.log('Received values of form: ', values);
        window.rpc.device.getArrayBriefByCondContainer({}, values, 0, 0).then((result) => {
          console.log(result);
          message.info(`共搜索到${result.length}条数据`);
          let devi = result.map((x) => ({ ...x, dtype: x.name, location: x.location, key: x.id, rstate: rState[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          number = devi.length;
          this.props.appState.tableDataOne = devi;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let locations = JSON.parse(sessionStorage.getItem('locations')) || [];
    let dtypeChildren = [];
    let locationChildren = [];

    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of locations) {
      if (value && value.id && value.type === 50) {
        locationChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    return (
      <Form inline style={{ margin: 0 }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`设备名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 100 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`设备类型`}>
              {getFieldDecorator(`dtype`)(
                <Select multiple style={{ width: 100 }} placeholder="请选择">
                  {dtypeChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`设备状态`}>
              {getFieldDecorator(`dstate`)(
                <Select multiple style={{ width: 100 }} placeholder="请选择">
                  {rStateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`所属建筑`}>
              {getFieldDecorator(`location`)(
                <Select multiple style={{ width: 100 }} placeholder="请选择">
                  {locationChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`安装时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{ width: 200 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
let loca = '';
const EquipManageC = observer(class appState extends React.Component {

  constructor() {
    super();
    this.state = {
      display: "none",
      Selected: {
        Id: null
      },
      pagenum: ""
    }
  }
  componentDidMount() {
    if (sessionStorage.getItem('flag')) {
      this.setState({
        display: 'inline-block'
      })
    } else {
      this.setState({
        display: 'none'
      })
    } 
    if (sessionStorage.getItem("equipment")) {
       let devic=JSON.parse(sessionStorage.getItem("equipment"));
       window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
         return {devic,rstate}
       }).then((data)=>{
         let result = data.devic
       result.forEach(function (x) {
        if (x.location) {
          loca = x.location.replace(reg, '-');
        } else {
          loca = '';
        }
      })
      let equipmentMap = result.map((x) => ({ ...x, dtype: x.name, location: loca, key: x.id, rstate: rState[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableDataOne = equipmentMap;
      })
    } else {
      window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
        return window.rpc.device.getArrayBriefByCondContainer(null, null, 0, 10).then(device => { return { device, rstate } });
      }).then((data) => {
        let result = data.device
        console.log(result);
        let devices;
        result.forEach(function (x) {
          if (x.location) {
            loca = x.location.replace(reg, '-');
          } else {
            loca = '';
          }
        })

        devices = result.map(x => ({ ...x, dtype: x.typeName, location: loca, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }))
        this.props.appState.tableDataOne = devices;
        this.setState({
          data: this.props.appState.tableDataOne
        })
      }, (err) => {
        console.warn(err);
      })
    }
    if (sessionStorage.getItem('number')) {
      number = parseInt(sessionStorage.getItem('number'));
    } else {
      window.rpc.device.getCountByContainer({}, console.log).then((res) => {
        //  console.log(number);
        number = res;
      }, (err) => {
        console.warn(err);
      })
    }
  }
  handAll = () => {
    if (sessionStorage.getItem('number')) {
      number = parseInt(sessionStorage.getItem('number'));
    } else {
      window.rpc.device.getCountByContainer({}, console.log).then((res) => {
        console.log(number)
        number = res;
      }, (err) => {
        console.warn(err);
      })
    }
    window.rpc.device.getArrayBriefByCondContainer(null, null, 0, 10).then((result) => {
      let devices = [];
      result.forEach(function (x) {
        if (x.location) {
          loca = x.location.replace(reg, '-');
        } else {
          loca = '';
        }
        devices.push({ ...x, dtype: x.typeName, location: loca, key: x.id, rstate: x.dtype, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') })
      })
      this.props.appState.tableDataOne = devices;
    }, (err) => {
      console.warn(err);
    })
  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0]) };
    this.setState({ Selected });

  }
  handleStaff = () => {
    if (this.state.Selected.Id != null) {
      console.log(this.state.Selected.Id);
      browserHistory.push(`/equipment/editdevice/${this.state.Selected.Id}`);
    } else {
      message.info('请选择设备！');
    }
  }
  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id != null) {
      // console.log(this.state.Selected.Id);
      browserHistory.push(`/equipment/device/${this.state.Selected.Id}`);
    } else {
      message.info('请选择设备！');
    }
  }
  //是否删除
  remove = () => {
    if (this.state.Selected.Id != null) {
      window.rpc.device.removeById(this.state.Selected.Id).then((res) => {
        let types = res.map(x => ({ ...x, dtype: x.typeName, location: loca, key: x.id, rstate: x.dtype, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
        this.setState({ types });
        this.props.appState.tableDataOne = types;
        this.setState({
          data: this.props.appState.tableDataOne
        })
      }, (err) => {
        console.warn(err);
      })
      let pagen = 0;
      if (this.state.pagenum !== "") {
        pagen = this.state.pagenum
      }
      window.rpc.device.getArrayBriefByCondContainer(null, null, pagen, 10).then((result) => {
        console.log(result);
        let devices = [];

        result.forEach(function (x) {
          if (x.location) {
            loca = x.location.replace(reg, '-');
          } else {
            loca = '';
          }
          devices.push({ ...x, dtype: x.typeName, location: loca, key: x.id, rstate: x.dtype, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') })
          // console.log(devices);
        })
        console.log(devices);
        this.props.appState.tableDataOne = devices;
        this.setState({
          data: this.props.appState.tableDataOne
        })
        console.log(this.props.appState.tableDataOne);
      }, (err) => {
        console.warn(err);
      })
      //刷新页面

    } else {
      message.info('请选择设备！');
    }
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  maintain() {
    message.success('保养成功');
  }

  check() {
    message.success('检测成功');
  }
  onDelete = (key, index) => {
    window.rpc.device.removeById(Number(index)).then((res) => {
      
    }, (err) => {
      console.warn(err);
    })
    this.props.appState.tableDataOne.splice(key, 1);
  }
  cancel() {
    message.error('已取消');
  }
  handelClick(e) {
  }
  render() {
    const rowSelection = {
      onChange: this.onSelectChange,
    };
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      {
        title: '设备名称', dataIndex: 'name', key: 'name', render: (text, record) => (
          <span>
            <Link to={`/equipment/device/${record.key}`}>{text}</Link>
          </span>
        ),
      },

      {
        title: '设备类型', dataIndex: 'dtype', key: 'dtype', render: (text, record) => (
          <span>
            <Link to={`/equipment/typedetail/${record.key}`}>{text}</Link>
          </span>
        ),

      },
      { title: '安装日期', dataIndex: 'setupTime', key: 'setupTime' },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record, index) => {
          let strs = text.split("-");
          let valueN = [];
          let valueM = [];
          for (let value of strs) {
            valueN.push(parseInt(value.replace(/[^0-9]/ig, "")));
            valueM.push(value.replace(':', "").replace(/[\d]+/, ""));
          }
          if (valueN.length === 3) {
            return (
              <span>
                <Link to={`/org/area/${valueN[0]}`}>{valueM[0]}</Link>--
               <Link to={`/org/area/${valueN[1]}`}>{valueM[1]}</Link>--
               <Link to={`/org/area/${valueN[2]}`}>{valueM[2]}</Link>
              </span>
            )
          } else if (valueN.length === 2) {

            return (
              <span>
                <Link to={`/org/area/${valueN[0]}`}>{valueM[0]}</Link>--
                  <Link to={`/org/area/${valueN[1]}`}>{valueM[1]}</Link>
              </span>
            )
          } else if (valueN.length === 1) {
            return (
              <span>
                <Link to={`/org/area/${valueN[0]}`}>{valueM[0]}</Link>--
              </span>
            )
          } else {
            <span></span>
          }
        }
      },
      { title: '运行状态', dataIndex: 'rstate', key: 'rstate' },
      { title: '最后巡查日期', dataIndex: 'lastTime', key: 'lastTime' },
      { title: '最后巡查人', dataIndex: 'patrolId', key: 'patrolId' },
      {
        title: '操作', dataIndex: '', key: 'x', width: "170px", render: (text, record, index) => (
          <span>
            <Link to={`/equipment/device/${record.key}`}>查看</Link>
          </span>
        )
      },
    ];
    const data = [...this.props.appState.tableDataOne];
    const pagination = {
      total: number,
      showTotal: total => `共 ${number} 条`,
      pageSize: 10,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (page, pageSize) => {
        let pagenum = (parseInt(page) - 1) * 10;
        this.setState({
          pagenum
        })
        if (sessionStorage.getItem('equipment')) {
          window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
            return window.rpc.device.getArrayBriefByCondContainer(null, { floor: sessionStorage.getItem('newId') }, pagenum, 10).then(device => { return { device, rstate } });
          }).then((data) => {
            let result = data.device
            let devices;
            result.forEach(function (x) {
              if (x.location) {
                loca = x.location.replace(reg, '-');
              } else {
                loca = '';
              }
            })

            devices = result.map(x => ({ ...x, dtype: x.typeName, location: loca, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }))
            this.props.appState.tableDataOne = devices;
            this.setState({
              data: this.props.appState.tableDataOne
            })
          }, (err) => {
            console.warn(err);
          })
        } else {
          window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
            return window.rpc.device.getArrayBriefByCondContainer(null, null, pagenum, 10).then(device => { return { device, rstate } });
          }).then((data) => {
            let result = data.device
            number = result.length;
            let devices;
            result.forEach(function (x) {
              if (x.location) {
                loca = x.location.replace(reg, '-');
              } else {
                loca = '';
              }
            })

            devices = result.map(x => ({ ...x, dtype: x.typeName, location: loca, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }))

            console.log(devices);
            this.props.appState.tableDataOne = devices;
            this.setState({
              data: this.props.appState.tableDataOne
            })
            console.log(this.props.appState.tableDataOne);
          }, (err) => {
            console.warn(err);
          })
        }
      },
    };


    return (
      <div className="EquipManage" style={{ padding: '14px 0' }}>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0',marginTop:30 }}>
          <Col span={24}>
            <Table
              bordered
              columns={columns}
              dataSource={data}
              rowSelection={rowSelection}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class Addequip extends Component {
  render() {
    return (
      <EquipManageC appState={new appState()} />
    )
  }
}

export default Addequip;