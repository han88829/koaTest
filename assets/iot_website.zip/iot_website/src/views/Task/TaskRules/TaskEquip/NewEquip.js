import React, { Component } from 'react';
import { Button, Steps, Table, Input, Row, Select, Col, Modal, message, Form, TreeSelect } from 'antd';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import listStore from '../../listStore';
import moment from 'moment';
import '../Rules.css';

import edit0 from '../../../../assets/images/task/编辑0.png';
import edit1 from '../../../../assets/images/task/编辑1.png';
import equip0 from '../../../../assets/images/task/选择户籍0.png';
import equip1 from '../../../../assets/images/task/选择户籍1.png';
import people0 from '../../../../assets/images/task/选择人员0.png';
import people1 from '../../../../assets/images/task/选择人员1.png';
import generate0 from '../../../../assets/images/task/生成规则0.png';
import generate1 from '../../../../assets/images/task/生成规则1.png';

const Step = Steps.Step;
const { Option } = Select;
const { rStateList } = listStore;
const FormItem = Form.Item;
// const { RangePicker } = DatePicker;
//const { TabPane } = Tabs;

// 查类型
let dtypes = [{ name: '/' }];

// 查区域
let locations = [];
let locationName = [{ name: "/" }];
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      mData: [],
      selectId: [],
      selectIdOne: null,
      removeSelected: [],
      Value: null,
      data: [],
    })
  }
}

class AdvancedSearchForm extends React.Component {
  state = {
    data: [],
    dataT: [],
    types: [],
    safetyLevelList: [],
    dStateObj: {},
    watchLevelList: [],
  }
  componentWillMount() {
    window.rpc.device.types.getArray(0, 0).then((result) => {

      for (let value of result) {
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes', JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })
    // 查区域
    window.rpc.area.getMapIdNameByContainer(null, 0, 0).then((result) => {
      locationName = result;
      sessionStorage.setItem('locationName', JSON.stringify(locationName));
    }, (err) => {
      console.warn(err);
    })
  }
  componentDidMount() {
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    window.rpc.area.getArray(0, 0).then((res) => {
      let tableDate = [];
      res.forEach(function (x) {
        if (x.name != "") {
          tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
        }
      })
      loop(tableDate)
      this.setState({ data: tableDate });
    }, (err) => {
      console.warn(err);
    })
    window.rpc.owner.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = ['/'];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      loop(tableDate)
      this.setState({ types, dataT: tableDate });
    })
    window.rpc.alias.getValueByName('fire.safetyLevel').then((res) => {
      let arrFire = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrFire.push(values);
      }
      this.setState({
        safetyLevelList: arrFire
      });

    }, (err) => {
      console.warn(err);
    });
    // 单位状态
    window.rpc.alias.getValueByName('owner.state').then((res) => {
      this.setState({ dStateObj: res })
    }, (err) => {
      console.warn(err);
    });
    // 监管等级
    window.rpc.alias.getValueByName('fire.watchLevel').then((res) => {
      let arrWatch = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrWatch.push(values);
      }
      this.setState({
        watchLevelList: arrWatch,
      });

    }, (err) => {
      console.warn(err);
    });
  }
  handleSearch = (e) => {
    e.preventDefault();
    let dStateList = this.state.dStateObj;
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const Orgname = fieldsValue['Orgname'];
        const Orgtype = fieldsValue['Orgtype'];
        const safetyLevel = fieldsValue['safetyLevel'];
        const Orgstate = fieldsValue['Orgstate'];
        const Supervision = fieldsValue['Supervision'];
        let values = {};
        if (Orgname) {
          values = { ...values, Orgname };
        }
        if (Supervision) {
          values = { ...values, Supervision: fieldsValue['Supervision'].map(x => parseInt(x, 10)) }
        }
        if (Orgtype) {
          values = { ...values, Orgtype: fieldsValue['Orgtype'].map(x => parseInt(x, 10)) }
        }
        if (safetyLevel) {
          values = { ...values, safetyLevel: fieldsValue['safetyLevel'].map(x => parseInt(x, 10)) }
        }
        if (Orgstate) {
          values = { ...values, Orgstate: fieldsValue['Orgstate'].map(x => parseInt(x, 10)) }
        }
        // if (rangeValue) {
        //   values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        // }
        // console.log(values)
        window.rpc.owner.getId().then(dataId => {
          values = { ...values, deep: 999 };
          window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then((res) => {
            window.rpc.alias.getValueByName('fire.safetyLevel').then((data) => {
              window.rpc.owner.getArrayBriefByContainer(values, 0, 0).then((result) => {
                result = result.reverse();
                let orgs = result.map((x) => ({ ...x, id: x.id, key: x.id, Orgname: x.name, safetyLevel: data[x.safetyLevel], Orgtype: res[x.type] || "其他", safety: null, Orgstate: dStateList[x.state], Orgnum: x.number, Orglocation: x.address, contacts: x.parentId, legalPersonPhone: x.legalPersonPhone, legalPerson: x.legalPerson }));
                message.info(`共搜索到${orgs.length}条数据`);
                this.props.appState.tableData = orgs;
              }, (err) => {
                console.warn(err);
              })
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          });
        }, err => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    let OrgstateChildren = [];
    let safetyChildren = [];
    let SupervisionsChildren = [];
    let safet = this.state.safetyLevelList;
    let dStateObj = this.state.dStateObj;
    let safetySupervision = this.state.watchLevelList;

    for (let i = 1; i < safet.length; i++) {
      safetyChildren.push(<Option key={`${i}`}>{safet[i]}</Option>)
    }
    for (let i in dStateObj) {
      OrgstateChildren.push(<Option key={`${i}`}>{dStateObj[i]}</Option>)
    }
    for (let i = 1; i < safetySupervision.length + 1; i++) {
      SupervisionsChildren.push(<Option key={`${i}`}>{safetySupervision[i]}</Option>)
    }
    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={5} key={1}>
            <FormItem label={`单位名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={5} key={2}>
            <FormItem label={`单位类型`}>
              {getFieldDecorator(`type`)(
                <TreeSelect
                  style={{ height: 30, width: 180 }}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.dataT.filter(x => x.layer === 1)}
                  placeholder="请选择单位类型"
                  multiple
                />
              )}
            </FormItem>
          </Col>
          <Col span={5} key={4}>
            <FormItem label={`安全等级`}>
              {getFieldDecorator(`safetyLevel`)(
                <Select multiple style={{ width: 120 }} size="large" placeholder="请选择" >
                  {safetyChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          {/*<Col span={4} key={5}>
            <FormItem label={`监管等级`}>
              {getFieldDecorator(`Supervision`)(
                <Select multiple style={{ width: 120 }} size="large" placeholder="请选择" >
                  {SupervisionsChildren}
                </Select>
              )}
            </FormItem>
          </Col>*/}
          <Col span={5} key={6}>
            <FormItem label={`单位状态`}>
              {getFieldDecorator(`state`)(
                <Select multiple style={{ width: 120 }} size="large" placeholder="请选择">
                  {OrgstateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7} style={{ marginLeft: 20 }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
const PopoverPreserve = observer(class appState extends Component {
  constructor() {
    super();
    this.state = {
      data: [],
      selectId: [],
      dStateObj: {},
    }
  }
  componentDidMount() {
    //查类型区域

    window.rpc.device.types.getArray(0, 0).then((result) => {

      for (let value of result) {
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes', JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })
    // 查区域
    window.rpc.area.getMapIdNameByContainer(null, 0, 0).then((result) => {
      locationName = result;
      sessionStorage.setItem('locationName', JSON.stringify(locationName));
    }, (err) => {
      console.warn(err);
    })

    // 单位状态
    window.rpc.alias.getValueByName('owner.state').then((res) => {
      this.setState({ dStateObj: res })
    }, (err) => {
      console.warn(err);
    });
    window.rpc.owner.getId().then(dataId => {
      window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then((res) => {
        window.rpc.alias.getValueByName('fire.safetyLevel').then((data) => {
          window.rpc.owner.getArrayBriefByContainer({ deep: 999 }, 0, 0).then((result) => {
            let dStateList = this.state.dStateObj;
            result = result.reverse();
            let orgs = result.map((x) => ({ ...x, id: x.id, key: x.id, Orgname: x.name, safetyLevel: data[x.safetyLevel], Orgtype: res[x.type] || "其他", safety: null, Orgstate: dStateList[x.state], Orgnum: x.number, Orglocation: x.address, contacts: x.parentId, legalPersonPhone: x.legalPersonPhone, legalPerson: x.legalPerson }));
            this.props.appState.tableData = orgs;
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        })
      }, (err) => {
        console.warn(err);
      });
    }, err => {
      console.warn(err);
    })

  }
  state = { visible: false, selectedRowKeys: null, }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    this.setState({
      visible: false,
    });
    this.props.appState.selectId = this.state.Selected;
    window.rpc.owner.getId().then(dataId => {
      window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then((res) => {
        window.rpc.alias.getValueByName('fire.safetyLevel').then((data) => {
          window.rpc.owner.getArrayBriefByContainer({ deep: 999, id: [...this.props.appState.selectId] }, 0, 0).then((result) => {
            let dStateList = this.state.dStateObj;
            result = result.reverse();
            let orgs = result.map((x) => ({ ...x, id: x.id, key: x.id, Orgname: x.name, safetyLevel: data[x.safetyLevel], Orgtype: res[x.type] || "其他", safety: null, Orgstate: dStateList[x.state], Orgnum: x.number, Orglocation: x.address, contacts: x.parentId, legalPersonPhone: x.legalPersonPhone, legalPerson: x.legalPerson }));
            this.props.appState.mData = orgs;
            // 清楚选中状态
            setTimeout(() => {
              this.setState({
                selectedRowKeys: [],
              })
            }, 1000)
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        })
      }, (err) => {
        console.warn(err);
      });
    }, err => {
      console.warn(err);
    })
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    //console.log(Selected);
    this.setState({ Selected, selectedRowKeys });
  }
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }
  handelClick = (e) => {
    if (this.state.Selected.length !== 0 && this.state.Value) {
      let EquipSelected = this.state.Selected;
      sessionStorage.setItem('EquipPreserve', JSON.stringify(EquipSelected));
    }
  }
  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
        this.setState.Selected = selected;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.Selected = selected;
      },
    };
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '单位名称',
      dataIndex: 'Orgname',
      key: 'Orgname'
    }, {
      title: '安全等级',
      dataIndex: 'safetyLevel',
      key: 'safetyLevel',
    },
    { title: '建筑数目', dataIndex: 'floorCount', key: 'floorCount' },
    { title: '单位类型', dataIndex: 'Orgtype', key: 'Orgtype' },
    { title: '单位地址', dataIndex: 'Orglocation', key: 'Orglocation' },
    { title: '单位状态', dataIndex: 'Orgstate', key: 'Orgstate' },
    { title: '联系人', dataIndex: 'legalPerson', key: 'legalPerson' },
    { title: '联系电话', dataIndex: 'legalPersonPhone', key: 'legalPersonPhone' },
    ];

    const data = [...this.props.appState.tableData];
    return (
      <div>
        <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.showModal}>新增单位</Button>
        <Modal visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
          style={{ minWidth: 1300, minHeight: 700, marginLeft: 300, marginTop: '-70px' }}
          className="peopleModal"
        >
          <Row style={{ padding: '5px 0 0', }}>
            <WrappedAdvancedSearchForm appState={this.props.appState} />
            <Col span={24} style={{ marginTop: 10 }}>
              <Table
                bordered
                columns={columns}
                dataSource={data}
                rowSelection={rowSelection}
              />
            </Col>
          </Row>
        </Modal>
      </div>
    )
  }
})
const EquipPreserveMemberC = observer(class appState extends Component {
  constructor() {
    super();
    this.state = {
      display: "none",
      pagenum: "",
      Value: null,
      dStateObj: {},
      src0: edit0,
      src1: equip0,
      src2: people0,
      src3: generate0,
    }
  }
  componentWillMount() {

  }
  componentDidMount() {
    //查类型区域
    window.rpc.area.getArray(0, 0).then((result) => {
      for (let value of result) {
        locations[value.id] = value;
      }
      sessionStorage.setItem('locations', JSON.stringify(locations));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.device.types.getArray(0, 0).then((result) => {

      for (let value of result) {
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes', JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })
    // 查区域
    window.rpc.area.getMapIdNameByContainer(null, 0, 0).then((result) => {
      locationName = result;
      sessionStorage.setItem('locationName', JSON.stringify(locationName));
    }, (err) => {
      console.warn(err);
    })
    // 单位状态
    window.rpc.alias.getValueByName('owner.state').then((res) => {
      this.setState({ dStateObj: res })
    }, (err) => {
      console.warn(err);
    });
    let obje = JSON.parse(sessionStorage.getItem('rulesEquipObj')) || [];
    let datae = obje.resId || [];
    if (datae.length > 0) {
      window.rpc.owner.getId().then(dataId => {
        window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then((res) => {
          window.rpc.alias.getValueByName('fire.safetyLevel').then((data) => {
            window.rpc.owner.getArrayBriefByContainer({ deep: 999, id: datae }, 0, 0).then((result) => {
              let dStateList = this.state.dStateObj;
              result = result.reverse();
              let orgs = result.map((x) => ({ ...x, id: x.id, key: x.id, Orgname: x.name, safetyLevel: data[x.safetyLevel], Orgtype: res[x.type] || "其他", safety: null, Orgstate: dStateList[x.state], Orgnum: x.number, Orglocation: x.address, contacts: x.parentId, legalPersonPhone: x.legalPersonPhone, legalPerson: x.legalPerson }));
              this.props.appState.mData = orgs;
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        });
      }, err => {
        console.warn(err);
      })
    } else {
      this.props.appState.mData = [];
    }
  }
  state = {
    visible: false,
  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    this.props.appState.removeSelected = Selected;
    console.log(selectedRowKeys)
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }
  handleChange = (value) => {
    //console.log(`selected ${value}`);
    this.props.appState.Value = value;
    //console.log(this.props.appState.Value)
  }
  removeClick = (e) => {
    e.preventDefault();
    //console.log(this.state.Value)
    if (this.props.appState.Value) {
      if (this.props.appState.removeSelected.length !== 0) {
        let dataId = this.props.appState.selectId;
        let remove = this.props.appState.removeSelected;
        //在返回修改的时this.props.appState.selectId时初始值，所以无法进行删除操作，转而对本地存储数据进行操作
        if (dataId.length > 0) {
          //删除全部单位
          if (dataId.length == remove.length) {
            let obj1 = JSON.parse(sessionStorage.getItem('rulesEquipObj'));
            if (obj1.resId) {
              delete obj1.resId
            }
            this.props.appState.selectId = [];
            this.props.appState.mData = [];
            this.props.appState.removeSelected = [];
            message.info('请重新添加单位！')
          } else {
            //删除部分单位
            for (let i = 0; i < remove.length; i++) {
              dataId.splice(dataId.indexOf(remove[i]), 1)
            }
            this.props.appState.selectId = dataId;
            window.rpc.device.getArrayByContainer({ id: [...this.props.appState.selectId] }, 0, 0).then((result) => {
              let users = result.map((x) => ({ ...x, dtype: dtypes[x.dtype]['name'] || "/", location: locationName[x.location] || "/", key: x.id, rstate: rStateList[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
              this.props.appState.mData = users;
            }, (err) => {
              console.warn(err);
            })
          }
        } else {
          //下一步的返回修改操作
          let obje = JSON.parse(sessionStorage.getItem('rulesEquipObj')) || [];
          //console.log(obje.resId)
          let datae = obje.resId || [];
          //删除全部单位
          if (datae.length == remove.length) {
            let obj1 = JSON.parse(sessionStorage.getItem('rulesEquipObj'));
            if (obj1.resId) {
              delete obj1.resId
            }
            this.props.appState.selectId = [];
            this.props.appState.mData = [];
            this.props.appState.removeSelected = [];
            message.info('请重新添加单位！')
          } else {
            //删除部分单位
            for (let i = 0; i < remove.length; i++) {
              datae.splice(datae.indexOf(remove[i]), 1)
            }
            this.props.appState.selectId = datae;
            window.rpc.device.getArrayByContainer({ id: [...this.props.appState.selectId] }, 0, 0).then((result) => {
              let users = result.map((x) => ({ ...x, dtype: dtypes[x.dtype]['name'] || "/", location: locationName[x.location] || "/", key: x.id, rstate: rStateList[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
              this.props.appState.mData = users;
            }, (err) => {
              console.warn(err);
            })
          }
        }
      } else {
        message.info("请选择单位！");
        this.props.appState.selectId = [];
        this.props.appState.mData = [];
      }
    } else {
      message.info("请选择操作！");
    }
  }

  //提交添加数据
  handleSubmit = (e) => {
    let rulesObj1 = JSON.parse(sessionStorage.getItem('rulesEquipObj'));
    rulesObj1.resId ? rulesObj1.resId : rulesObj1.resId = [];
    if (this.props.appState.selectId.length !== 0) {
      e.preventDefault();
      let data = [...this.props.appState.selectId];
      let obj = { resId: data };
      let obj1 = JSON.parse(sessionStorage.getItem('rulesEquipObj'));
      delete obj1.resId;
      let obj2 = eval('(' + (JSON.stringify(obj) + JSON.stringify(obj1)).replace(/}{/, ',') + ')');
      sessionStorage.setItem('rulesEquipObj', JSON.stringify(obj2));
      message.info('添加单位成功！')
      browserHistory.push('/task/taskequip/people');
    } else if (rulesObj1.resId && rulesObj1.resId.length !== 0) {
      message.info('添加单位成功！')
      browserHistory.push('/task/taskequip/people');
    } else {
      this.props.appState.mData = [];
      message.info('请添加单位')
    }
  }
  render() {
    const data = [...this.props.appState.mData];
    const rowSelection = {
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.removeSelected = selected;
      },
    };
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '单位名称',
      dataIndex: 'Orgname',
      key: 'Orgname'
    }, {
      title: '安全等级',
      dataIndex: 'safetyLevel',
      key: 'safetyLevel',
    },
    { title: '建筑数目', dataIndex: 'floorCount', key: 'floorCount' },
    { title: '单位类型', dataIndex: 'Orgtype', key: 'Orgtype' },
    { title: '单位地址', dataIndex: 'Orglocation', key: 'Orglocation' },
    { title: '单位状态', dataIndex: 'Orgstate', key: 'Orgstate' },
    { title: '联系人', dataIndex: 'legalPerson', key: 'legalPerson' },
    { title: '联系电话', dataIndex: 'legalPersonPhone', key: 'legalPersonPhone' },
    ];
    return (
      <div>
        <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>新增规则</Link>
        </div><br />
        <div>
          <Steps current={1} style={{ width: '100%', margin: '0 auto', marginTop: 30 }} className="taskStep">
            <Step title="" />
            <Step title="" />
            <Step title="" />
            <Step title="" />
          </Steps>
        </div>
        {/*图片*/}
        <div className="BasisImg">
          <div></div>
          <ul>
            <li
              onMouseOver={() => {
                this.setState({ src0: edit1 });
              }}
              onMouseOut={() => {
                this.setState({ src0: edit0 });
              }}
            >
              <img src={this.state.src0} alt="" />
              <div>基本信息</div>
            </li>
            <li
              style={{ backgroundColor: "#ffffff" }}
              onMouseOver={() => {
                this.setState({ src1: equip1 });
              }}
              onMouseOut={() => {
                this.setState({ src1: equip0 });
              }}
            >
              <div className="BasisSan"></div>
              <img src={this.state.src1} alt="" />
              <div>添加单位</div>
            </li>
            <li
              onMouseOver={() => {
                this.setState({ src2: people1 });
              }}
              onMouseOut={() => {
                this.setState({ src2: people0 });
              }}
            >
              <img src={this.state.src2} alt="" />
              <div>添加人员</div>
            </li>
            <li
              onMouseOver={() => {
                this.setState({ src3: generate1 });
              }}
              onMouseOut={() => {
                this.setState({ src3: generate0 });
              }}
            >
              <img src={this.state.src3} alt="" />
              <div>生成规则</div>
            </li>
          </ul>
        </div>
        <div style={{ marginTop: 15 }} className="ConcenHistory">
          <div>
            <Row style={{ padding: '5px 0 15px' }}>
              <Col span={24}>
                <div style={{ float: 'left', marginRight: 4, marginTop: '-7px', width: "100%" }} className="TaskRules">
                  <PopoverPreserve appState={this.props.appState} />
                  <Button style={{ float: 'left', background: '#d9dee4', color: '#373e41', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.removeClick} >批量操作</Button>
                  <div style={{ marginLeft: 5, float: 'left', width: 110, height: 32, background: '#d9dee4' }} className='select-small'>
                    <Select style={{ width: 100 }} placeholder="更多操作" onChange={this.handleChange}>
                      <Option key={1}>删除</Option>
                    </Select>
                  </div>
                </div>
              </Col>
            </Row>
            <Row>
              <Col span={24}>
                <Table
                  bordered
                  columns={columns}
                  dataSource={data}
                  rowSelection={rowSelection}
                />
              </Col>
            </Row>
          </div>
        </div>
        <Row style={{ marginTop: 20, textAlign: 'left' }} className="ruleForm ">
          <Col span={24}>
            <div onClick={this.handleSubmit} className="new-button" style={{ display: `inline-block`, backgroundColor: '#00c1de', color: '#fff', fontSize: '0.875rem', marginLeft: 10, fontFamily: '微软雅黑', width: 75, height: 32, cursor: "pointer" }}>下一步</div>
            <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', marginLeft: 10, fontFamily: '微软雅黑', width: 75, height: 32 }}><Link to="/task/taskequip/basis">返回修改</Link></div>
          </Col>
        </Row>
      </div>
    );
  }
})


class Newpeople extends Component {
  render() {
    return (
      <EquipPreserveMemberC appState={new appState()} />
    )
  }
}
export default Newpeople;