import React from 'react';
import { Form, Input, Select, Button, DatePicker, Row, Col, Steps, Radio, message } from 'antd';
import { Link, browserHistory } from 'react-router';
import { observer } from 'mobx-react';
import moment from 'moment';
import '../Rules.css';

import name from '../../../../assets/images/task/name.png';
import time from '../../../../assets/images/task/time.png';
import report from '../../../../assets/images/task/report.png';
import type from '../../../../assets/images/task/type.png';
import types from '../../../../assets/images/task/types.png';
import task from '../../../../assets/images/task/task.png';
import time1 from '../../../../assets/images/task/time1.png';
import edit0 from '../../../../assets/images/task/编辑0.png';
import edit1 from '../../../../assets/images/task/编辑1.png';
import equip0 from '../../../../assets/images/task/选择户籍0.png';
import equip1 from '../../../../assets/images/task/选择户籍1.png';
import people0 from '../../../../assets/images/task/选择人员0.png';
import people1 from '../../../../assets/images/task/选择人员1.png';
import generate0 from '../../../../assets/images/task/生成规则0.png';
import generate1 from '../../../../assets/images/task/生成规则1.png';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const Option = Select.Option;
const { Step } = Steps;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

let config = {}, rules = [];
const Newbasis = observer(Form.create()(React.createClass({
  getInitialState: function () {
    return {
      number: null,
      data: [],
      src0: edit0,
      src1: equip0,
      src2: people0,
      src3: generate0,
    };
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let { name, auditType, TaskDate, cycle, reportId, taskType, workDay } = values;
        //console.log(TaskDate)
        let rulesObj = { name, taskType: parseInt(taskType, 10), workDay: parseInt(workDay, 10), auditType: parseInt(auditType, 10), beginTime: new Date(TaskDate[0].format('YYYY-MM-DD HH:mm:ss')), endTime: new Date(TaskDate[1].format('YYYY-MM-DD HH:mm:ss')), cycle: taskType == 1 ? '' : cycle, reportId: parseInt(reportId, 10) };
        //console.log(rulesObj)
        sessionStorage.setItem('rulesEquipObj', JSON.stringify(rulesObj));
        message.info('信息创建成功！')
        browserHistory.push('/task/taskequip/equip');
      } else {
        console.log(err)
      }
    });
  },
  //验证数字
  checkNumber(rule, value, callback) {
    var num = /^[0-9]*$/;
    if (num.test(value)) {
      callback();
    } else {
      callback('请输入数字');
    }
  },

  //审核选择
  onChange(value) {
    let objb = JSON.parse(sessionStorage.getItem('rulesEquipObj')) || [];
    if (value == 1) {
      document.getElementById("cycle").style.display = 'none';
      delete objb.cycle;
      rules = [{ required: false, message: '请输入天数!' },]
    } else {
      document.getElementById("cycle").style.display = 'block';
      rules = [
        { required: true, message: '请输入天数!' },
        { validator: this.checkNumber },
      ]
    }
  },
  componentWillMount() {
    //查报表
    window.rpc.report.template.getArrayBriefByContainer(null, 0, 0).then((result) => {
      let reportName = [{ name: '/' }];
      for (let value of result) {
        reportName[value.id] = value;
      }
      this.setState({ data: reportName });
    }, (err) => {
      console.warn(err);
    })
  },
  disabledStartDate(value){
    let date = new Date();
    let mm = date.getTime()-1000*60*60*24; 
    if(!value){
      return false;
    }
    return mm.valueOf() >=value.valueOf();
  },
  render() {
    let objb = JSON.parse(sessionStorage.getItem('rulesEquipObj')) || [];
    config = {
      initialValue: objb.cycle || '',
      rules: rules,
    }
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 3 },
      wrapperCol: { span: 8 },
    };
    const dateFormat = 'YYYY/MM/DD HH:mm:ss';
    // let reportName = JSON.parse(sessionStorage.getItem('reportName')) || [];
    let reportChildren = [];
    let reportName = this.state.data;
    for (let value of reportName) {
      if (value && value.id) {
        reportChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    return (
      <div style={{}}>
        <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>新增单位规则</Link>
        </div><br />
        <div>
          <Steps current={0} style={{ width: '100%', margin: '0 auto', marginTop: 30 }} className="taskStep">
            <Step title="" />
            <Step title="" />
            <Step title="" />
            <Step title="" />
          </Steps>
        </div>
        {/*图片*/}
        <div className="BasisImg">
          <div></div>
          <ul>
            <li
              style={{ backgroundColor: "#ffffff" }}
              onMouseOver={() => {
                this.setState({ src0: edit1 });
              }}
              onMouseOut={() => {
                this.setState({ src0: edit0 });
              }}
            >
              <div className="BasisSan"></div>
              <img src={this.state.src0} alt="" />
              <div>基本信息</div>
            </li>
            <li
              onMouseOver={() => {
                this.setState({ src1: equip1 });
              }}
              onMouseOut={() => {
                this.setState({ src1: equip0 });
              }}
            >
              <img src={this.state.src1} alt="" />
              <div>添加单位</div>
            </li>
            <li
              onMouseOver={() => {
                this.setState({ src2: people1 });
              }}
              onMouseOut={() => {
                this.setState({ src2: people0 });
              }}
            >
              <img src={this.state.src2} alt="" />
              <div>添加人员</div>
            </li>
            <li
              onMouseOver={() => {
                this.setState({ src3: generate1 });
              }}
              onMouseOut={() => {
                this.setState({ src3: generate0 });
              }}
            >
              <img src={this.state.src3} alt="" />
              <div>生成规则</div>
            </li>
          </ul>
        </div>
        <Form onSubmit={this.handleSubmit} className="ruleForm" style={{ marginTop: 26 }}>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={name} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="规则名称"
                hasFeedback
              >
                {getFieldDecorator('name', {
                  initialValue: objb.name || '',
                  rules: [{ required: true, message: '请输入任务标题!' }],
                })(
                  <Input />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={types} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="审核方式选择："
                hasFeedback
              >
                {getFieldDecorator('auditType', {
                  initialValue: objb.auditType ? String(objb.auditType) : '',
                  rules: [
                    { required: true, message: '请选择审核方式！' },
                  ],
                })(
                  <RadioGroup >
                    <RadioButton value="1" style={{ width: '15vh' }}>报表系统自动审核</RadioButton>
                    <RadioButton value="2" style={{ width: '15vh' }}>报表人工审核</RadioButton>
                  </RadioGroup>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={time} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="规则有效时间："
                hasFeedback
              >
                {getFieldDecorator('TaskDate', {
                  initialValue: objb.beginTime && objb.endTime ? [moment(objb.beginTime, dateFormat), moment(objb.endTime, dateFormat)] : '',
                  rules: [{ required: true, message: '请选择时间!' }],
                })(
                  <RangePicker
                    showTime
                    disabledDate={this.disabledStartDate}
                    format="YYYY-MM-DD HH:mm:ss"
                    placeholder={['开始时间', '截至时间']}
                  />
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={report} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="选择报表："
                hasFeedback
              >
                {getFieldDecorator('reportId', {
                  initialValue: objb.reportId ? String(objb.reportId) : '',
                  rules: [{ required: true, message: '请选择报表!' }],
                })(
                  <Select>
                    {reportChildren}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={type} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="任务类型："
                hasFeedback
              >
                {getFieldDecorator('taskType', {
                  initialValue: objb.taskType ? String(objb.taskType) : '',
                  rules: [{ required: true, message: '请选择任务类型!' }],
                })(
                  <Select onChange={this.onChange} id="select">
                    <Option value="1">抽检</Option>
                    <Option value="2">巡检</Option>
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ display: `${objb.taskType == 2 ? 'block' : 'none'}` }} id="cycle">
            <div style={{ float: "left", width: "2%" }}>
              <img src={task} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="检查频率（天/次）"
                hasFeedback
              >
                {getFieldDecorator('cycle', config)(
                  <Input />
                )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={time1} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="持续时间(天)："
                hasFeedback
              >
                {getFieldDecorator('workDay', {
                  initialValue: objb.workDay ? String(objb.workDay) : '',
                  rules: [
                    { required: true, message: '请输入持续时间！' },
                    { validator: this.checkNumber },
                  ],
                })(
                  <Input />
                  )}
              </FormItem>
            </div>
          </div>
          <Row style={{ marginTop: 20, textAlign: 'left' }}>
            <Col span={22}>
              <Button type="primary" htmlType="submit" style={{ backgroundColor: '#00c1de', borderColor: '#00c1de' }}>下一步</Button>
            </Col>
          </Row>
        </Form>
      </div>
    );
  },
})));

export default Newbasis;