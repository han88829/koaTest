import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Link, browserHistory } from 'react-router';
import { Row, Col, Button, Form, Table, } from 'antd';
import moment from 'moment';
import listStore from '../../listStore';

const FormItem = Form.Item;

const { levelList, genderList } = listStore;

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
    })
  }
}
const TaskRulePerformancePersonC = observer(class TaskRulePerformancePersonC extends Component {
  constructor() {
    super();
    this.state = {
      showStyle2: 'none',
      showStyle1: 'block',
    };
  }

  changeShow = () => {
    this.setState({
      showStyle2: 'block',
      showStyle1: 'none',
    });

  }

  //单位 建筑
  componentDidMount() {
    const id = parseInt(this.props.params.id, 10);
    //设备列表
    let values = { id: id };
    window.rpc.rules.user.getArrayBriefByContainer(values, 0, 0).then((result) => {
      let userData = result.map((x) => ({ ...x, key: x.id, name: x.name, number: x.number, gender: genderList[x.gender], level: levelList[x.level], mobile: x.mobile, email: x.email, groupName: x.groupName, ownerName: x.ownerName, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = userData;
    }, (err) => {
      console.warn(err);
    })
  }
  state = {
    selectedRowKeys: [],  // Check here to configure the default column
  };
  onSelectChange = (selectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    this.setState({ selectedRowKeys });
  }

  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };
    let hasSelected = 0;

    if (selectedRowKeys) {
      hasSelected = selectedRowKeys.length;
    }

    const dataSource = [...this.props.appState.tableData];
    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        //console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        //console.log('Current: ', current);
      },
    };
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '姓名', dataIndex: 'name', key: 'name' },
      { title: '工号', dataIndex: 'number', key: 'number' },
      { title: '性别', dataIndex: 'gender', key: 'gender' },
      { title: '等级', dataIndex: 'level', key: 'level' },
      { title: '手机', dataIndex: 'mobile', key: 'mobile' },
      { title: '电子邮件', dataIndex: 'email', key: 'email' },
      { title: '部门', dataIndex: 'groupName', key: 'groupName' },
      { title: '公司', dataIndex: 'ownerName', key: 'ownerName' },
      { title: '入职时间', dataIndex: 'createTime', key: 'createTime' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/memb/staff/detail/${record.key}`}>查看</Link>
          </span>
        )
      },
    ];
    return (
      <div className="EquipTaskRuleDetail" style={{ margin: 0, fontFamily: '苹方中等', height: '82vh' }}>
        <Row style={{ padding: '0 0 5px' }}>
          <Col span={6}>
            <FormItem style={{ paddingLeft: 20 }}>
              <span>已选择{hasSelected}项数据</span>
            </FormItem>
          </Col>
        </Row>
        <Row style={{ padding: '0 0 5px' }}>
          <Col span={24}>
            <Table
              bordered
              rowSelection={rowSelection}
              columns={columns}
              dataSource={dataSource}
              pagination={pagination}
            />
          </Col>
        </Row>
        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 10, display: this.state.showStyle1 }}>
          <Button type="primary" size="large" onClick={this.changeShow} style={{ float: 'left', marginRight: 10 }}>编辑</Button>
          <Button type="success" size="large" style={{ float: 'left' }}><Link to='/task/rule'>返回</Link></Button>
        </Row>

        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 10, display: this.state.showStyle2 }}>
          <Button type="primary" htmlType="submit" size="large" style={{ float: 'left', marginRight: 10 }}>保存</Button>
          <Button type="success" size="large" style={{ float: 'left' }}><Link to='/task/rule'>取消</Link></Button>
        </Row>
      </div>
    );
  }
})

class TaskRulePerformancePerson extends Component {
  render() {
    return (
      <TaskRulePerformancePersonC appState={new appState()} params={this.props.params} />
    )
  }
}

export default TaskRulePerformancePerson;