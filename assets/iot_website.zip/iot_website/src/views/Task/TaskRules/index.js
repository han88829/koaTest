/*
 * @Author: Han.beibei 
 * @Date: 2017-03-23 09:41:33 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-15 17:06:03
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message } from 'antd';
import moment from 'moment';
import listStore from '../listStore';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const { taskTypeList, auditTypeList, tStateList } = listStore;
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: [],
      selectIdOne: null,
      number: null,
    })
  }
}

// 取出报表名称
let reportName = [];

class AdvancedSearchForm extends React.Component {
  componentWillMount() {
    //查报表
    window.rpc.report.template.getArrayBriefByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        reportName[value.id] = value.name;
      }
    }, (err) => {
      console.warn(err);
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['endTime'];
        const name = fieldsValue['name'];
        const taskType = fieldsValue['taskType'];
        const state = fieldsValue['state'];
        const auditType = fieldsValue['auditType'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (taskType) {
          values = { ...values, taskType: fieldsValue['taskType'].map(x => parseInt(x, 10)) }
        }
        if (state) {
          values = { ...values, state: fieldsValue['state'].map(x => parseInt(x, 10)) }
        }
        if (auditType) {
          values = { ...values, auditType: fieldsValue['auditType'].map(x => parseInt(x, 10)) }
        }
        if (rangeValue && rangeValue.length > 0) {
          values = { ...values, endTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        values = { ...values, resType: 1 }
        window.rpc.rules.getArrayByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, key: x.id, reportId: reportName[x.reportId] || '/', cycle: x.taskType == 1 ? '/' : x.cycle, state: tStateList[x.state], auditType: auditTypeList[x.auditType], taskType: taskTypeList[x.taskType], beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
          this.props.appState.tableData = users;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let taskTypeChildren = [];
    let stateChildren = [];
    let auditTypeChildren = [];

    for (let i = 1; i < taskTypeList.length; i++) {
      taskTypeChildren.push(<Option key={`${i}`}>{taskTypeList[i]}</Option>)
    }
    for (let i = 1; i < tStateList.length; i++) {
      stateChildren.push(<Option key={`${i}`}>{tStateList[i]}</Option>)
    }
    for (let i = 1; i < auditTypeList.length; i++) {
      auditTypeChildren.push(<Option key={`${i}`}>{auditTypeList[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={3} key={3}>
            <FormItem label={`类型`}>
              {getFieldDecorator(`taskType`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {taskTypeChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={4}>
            <FormItem label={`状态`}>
              {getFieldDecorator(`state`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {stateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={5}>
            <FormItem label={`审核方式`}>
              {getFieldDecorator(`auditType`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {auditTypeChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={6} style={{ marginLeft: '-20px' }}>
            <FormItem label={`截止时间`}>
              {getFieldDecorator(`endTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

const StaffC = observer(class StaffC extends Component {
  componentDidMount() {
    window.rpc.rules.getArrayByContainer({ resType: 1 }, 0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, reportId: reportName[x.reportId] || '/', key: x.id, cycle: x.taskType == 1 ? '/' : x.cycle, state: tStateList[x.state], auditType: auditTypeList[x.auditType], taskType: taskTypeList[x.taskType], beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      this.props.appState.tableData = users;
    }, (err) => {
      console.warn(err);
    })
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
    selectedRowKeys: [],
    name: null,
    state: 1,
  };
  handleChange = (pagination, filters, sorter) => {
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }

  //更多操作选择
  handlemore = (value) => {
    this.props.appState.number = value;
  }
  //批量操作
  handleBatch = () => {
    if (this.props.appState.selectId.length !== 0) {
      if (this.props.appState.number) {
        //启用、停用、删除设置
        if (this.props.appState.number == 1) {
          let data = [...this.props.appState.selectId];
          window.rpc.rules.updateStateByArrayId(data, 1).then((res) => {
            if (res) {
              message.info('已启用！');
              //启用后清除复选框选中状态
              setTimeout(() => {
                this.setState({
                  selectedRowKeys: [],
                });
              }, 1000);
              window.rpc.rules.getArrayByContainer({ resType: 1 }, 0, 0).then((result) => {
                let users = result.map((x) => ({ ...x, key: x.id, reportId: reportName[x.reportId] || '/', cycle: x.taskType == 1 ? '/' : x.cycle, state: tStateList[x.state], auditType: auditTypeList[x.auditType], taskType: taskTypeList[x.taskType], beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
                this.props.appState.tableData = users;
              }, (err) => {
                console.warn(err);
              })
            } else {
              message.info('启用失败请联系管理员！');
              //启用后清除复选框选中状态
              setTimeout(() => {
                this.setState({
                  selectedRowKeys: [],
                });
              }, 1000);
            }
          }, (err) => {
            console.log(err);
          })
        } else if (this.props.appState.number == 2) {
          let data = [...this.props.appState.selectId];
          //console.log(data)
          window.rpc.rules.updateStateByArrayId(data, 2).then(() => {
            message.info('已停用！');
            //停用后清除复选框选中状态
            setTimeout(() => {
              this.setState({
                selectedRowKeys: [],
              });
            }, 1000);
            window.rpc.rules.getArrayByContainer({ resType: 1 }, 0, 0).then((result) => {
              let users = result.map((x) => ({ ...x, key: x.id, reportId: reportName[x.reportId] || '/', cycle: x.taskType == 1 ? '/' : x.cycle, state: tStateList[x.state], auditType: auditTypeList[x.auditType], taskType: taskTypeList[x.taskType], beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
              this.props.appState.tableData = users;
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.log(err);
          })
        } else if (this.props.appState.number == 3) {
          let data = [...this.props.appState.selectId];
          window.rpc.rules.removeByArrayId(data).then(() => {
            message.info('已删除！');
            window.rpc.rules.getArrayByContainer({ resType: 1 }, 0, 0).then((result) => {
              let users = result.map((x) => ({ ...x, key: x.id, reportId: reportName[x.reportId] || '/', cycle: x.taskType == 1 ? '/' : x.cycle, state: tStateList[x.state], auditType: auditTypeList[x.auditType], taskType: taskTypeList[x.taskType], beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
              this.props.appState.tableData = users;
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.log(err);
          })
        }
      } else {
        message.info('请选择操作！')
      }
    } else {
      message.info('请选择规则！')
    }
  }
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '规则名称',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '任务类型',
      dataIndex: 'taskType',
      key: 'taskType',
    },
    { title: '开始时间', dataIndex: 'beginTime', key: 'beginTime' },
    { title: '截止时间', dataIndex: 'endTime', key: 'endTime' },
    { title: '状态', dataIndex: 'state', key: 'state' },
    { title: '检查频率（天）', dataIndex: 'cycle', key: 'cycle' },
    { title: '审核方式', dataIndex: 'auditType', key: 'auditType' },
    { title: '选择报表', dataIndex: 'reportId', key: 'reportId' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/task/rule/detail/${record.key}`}>查看</Link>
          <span className="ant-divider" />
          <Link to={`/task/rule/detail/${record.key}`}>编辑</Link>
          <span className="ant-divider" />
          <Link to={``}
            onClick={() => {
              let id = record.id;
              let obj = { state: record.state === "已启用" ? 2 : 1 };
              window.rpc.rules.setInfoById(id, obj).then(() => {
                if (obj.state === 1) {
                  message.info('已启用！');
                } else {
                  message.info('已停用！');
                }
                window.rpc.rules.getArrayByContainer({ resType: 1 }, 0, 0).then((result) => {
                  let users = result.map((x) => ({ ...x, key: x.id, reportId: reportName[x.reportId] || '/', cycle: x.taskType == 1 ? '/' : x.cycle, state: tStateList[x.state], auditType: auditTypeList[x.auditType], taskType: taskTypeList[x.taskType], beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
                  this.props.appState.tableData = users;
                }, (err) => {
                  console.warn(err);
                })
              }, (err) => {
                console.log(err);
              })
            }}>
            {record.state === "已启用" ? "停用" : "启用"}
          </Link>
          <span className="ant-divider" />
          <Link to={``}
            onClick={() => {
              let id = record.id;
              window.rpc.rules.removeByArrayId([id]).then(() => {
                message.info('已删除！');
                window.rpc.rules.getArrayByContainer({ resType: 1 }, 0, 0).then((result) => {
                  let users = result.map((x) => ({ ...x, key: x.id, reportId: reportName[x.reportId] || '/', cycle: x.taskType == 1 ? '/' : x.cycle, state: tStateList[x.state], auditType: auditTypeList[x.auditType], taskType: taskTypeList[x.taskType], beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), endTime: moment(x.endTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
                  this.props.appState.tableData = users;
                }, (err) => {
                  console.warn(err);
                })
              }, (err) => {
                console.log(err);
              })
            }}>
            删除
          </Link>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];

    const pagination = {
      total: data.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };

    //表格选框设置
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        this.props.appState.selectId = selectedRowKeys;
        this.setState({ selectedRowKeys })
      },
      onSelect: (record, selected, selectedRows) => {

      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (
      <div className="ConcenHistory">
        <div style={{ height: 35, paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备任务规则</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }}><Link to="/task/basis">新增规则</Link></Button>
            <Button style={{ float: 'left', background: '#d9dee4', color: '#373e41', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.handleBatch} >批量操作</Button>
            <div style={{ marginLeft: 5, float: 'left', width: 110, height: 32, background: '#d9dee4' }} className='select-small'>
              <Select
                showSearch
                style={{ width: 100, height: 32, color: '#373e41', fontSize: '0.875rem', border: "none" }}
                id="select"
                placeholder="更多操作"
                optionFilterProp="children"
                onChange={this.handlemore}
                filterOption={(input, option) => option.props.value.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                <Option value="1">启用</Option>
                <Option value="2">停用</Option>
                <Option value="3">删除</Option>
              </Select>
            </div>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} style={{ width: '80%', textAlign: 'center' }} />
        <Row style={{ padding: '5px 0 0', marginTop: 10 }}>
          <Col span={24}>
            <Table
              bordered
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})

class TaskReport extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default TaskReport;