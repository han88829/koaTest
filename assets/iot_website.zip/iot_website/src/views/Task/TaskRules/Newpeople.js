import React, { Component } from 'react';
import { Button, Steps, Table, Input, Row, Select, Col, Modal, message, Form, DatePicker } from 'antd';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import listStore from '../listStore';
import moment from 'moment';
import './Rules.css';

import basis from '../../../assets/images/task/basis.png';
import end from '../../../assets/images/task/end.png';
import equip from '../../../assets/images/task/equip.png';
import people from '../../../assets/images/task/people.png';
import edit0 from '../../../assets/images/task/编辑0.png';
import edit1 from '../../../assets/images/task/编辑1.png';
import equip0 from '../../../assets/images/task/选择设备0.png';
import equip1 from '../../../assets/images/task/选择设备1.png';
import people0 from '../../../assets/images/task/选择人员0.png';
import people1 from '../../../assets/images/task/选择人员1.png';
import generate0 from '../../../assets/images/task/生成规则0.png';
import generate1 from '../../../assets/images/task/生成规则1.png';

const Step = Steps.Step;
const { Option } = Select;
const { genderList, levelList } = listStore;
const FormItem = Form.Item;
const { RangePicker } = DatePicker;
//const { TabPane } = Tabs;


//查部门 、 组织
let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      mData: [],
      selectId: [],
      selectIdOne: null,
      removeSelected: [],
      Value: null,
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupownerNames[value.id] = value;
      }
      sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
    }, (err) => {
      console.warn(err);
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const level = fieldsValue['level'];
        const groupId = fieldsValue['groupId'];
        const ownerId = fieldsValue['ownerId'];
        const gender = fieldsValue['gender'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (level) {
          values = { ...values, level: fieldsValue['level'].map(x => parseInt(x, 10)) }
        }
        if (groupId) {
          values = { ...values, groupId: fieldsValue['groupId'].map(x => parseInt(x, 10)) }
        }
        if (ownerId) {
          values = { ...values, ownerId: fieldsValue['ownerId'].map(x => parseInt(x, 10)) }
        }
        if (gender) {
          values = { ...values, gender: fieldsValue['gender'].map(x => parseInt(x, 10)) }
        }
        if (rangeValue && rangeValue.length > 0) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }

        window.rpc.user.getArrayByContainer(values, 0, 0).then((result) => {

          message.info(`共搜索到${result.length}条数据`);
          let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          this.props.appState.tableData = users;
          this.setState({ data: users });
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;

    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let levelChildren = [];
    let groupIdChildren = [];
    let ownerIdChildren = [];
    let genderChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={3} key={2}>
            <FormItem label={`性别`}>
              {getFieldDecorator(`gender`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {genderChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={3}>
            <FormItem label={`等级`}>
              {getFieldDecorator(`level`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={4}>
            <FormItem label={`部门`}>
              {getFieldDecorator(`groupId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {groupIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={3} key={5}>
            <FormItem label={`公司`}>
              {getFieldDecorator(`ownerId`)(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {ownerIdChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={5} key={6}>
            <FormItem label={`加入时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7} style={{ marginTop: 32, marginLeft: 20 }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
const PopoverPreserve = observer(class appState extends Component {
  constructor() {
    super();
    this.state = {
      data: [],
      selectId: []
    }
  }
  componentDidMount() {
    window.rpc.cache.group.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupNames[value.id] = value;
      }
      sessionStorage.setItem('groupNames', JSON.stringify(groupNames));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {
      for (let value of result) {
        groupownerNames[value.id] = value;
      }
      sessionStorage.setItem('groupownerNames', JSON.stringify(groupownerNames));
    }, (err) => {
      console.warn(err);
    })
    window.rpc.user.getArray(0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = users;

      this.setState({ data: users });

    }, (err) => {
      console.warn(err);
    })

  }
  state = { visible: false, selectedRowKeys: null }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    this.setState({
      visible: false,
    });
    this.props.appState.selectId = this.state.Selected;
    window.rpc.user.getArrayByContainer({ id: [...this.props.appState.selectId] }, 0, 0).then((result) => {
      let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.mData = users;
      // 清楚选中状态
      setTimeout(() => {
        this.setState({
          selectedRowKeys: [],
        })
      }, 1000)
    }, (err) => {
      console.warn(err);
    })

  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    this.setState({ Selected, selectedRowKeys });
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  handelClick = (e) => {
    if (this.state.Selected.length !== 0 && this.state.Value) {
      let EquipSelected = this.state.Selected;
      sessionStorage.setItem('EquipPreserve', JSON.stringify(EquipSelected));
    }

  }
  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
        this.setState.Selected = selected;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.Selected = selected;
      },
    };
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
      /*{
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/member/staff/detail/${record.key}`}>详情</Link>
            <span className="ant-divider" />
            <Link to={`/member/edit/staff/${record.key}`}>编辑</Link>
          </span>
        )
      },*/
    ];

    const data = [...this.props.appState.tableData];
    return (
      <div >
        <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.showModal}>新增人员</Button>
        <Modal visible={this.state.visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
          style={{ minWidth: 1300, minHeight: 700, marginLeft: 300, marginTop: '-70px' }}
          className="peopleModal"
        >
          <Row style={{ padding: '5px 0 0', }}>
            <WrappedAdvancedSearchForm appState={this.props.appState} />
            <Col span={24} style={{ marginTop: 30 }}>
              <Table
                bordered
                columns={columns}
                dataSource={data}
                rowSelection={rowSelection}
              />
            </Col>
          </Row>
        </Modal>
      </div>
    )
  }

})
const EquipPreserveMemberC = observer(class appState extends Component {
  constructor() {
    super();
    this.state = {
      display: "none",
      pagenum: "",
      Value: null,
      src0: edit0,
      src1: equip0,
      src2: people0,
      src3: generate0,
    }
  }
  componentWillMount() {

  }
  componentDidMount() {
    let obje = JSON.parse(sessionStorage.getItem('rulesObj')) || [];
    let datae = obje.userId || [];
    if (datae.length > 0) {
      window.rpc.user.getArrayByContainer({ id: datae }, 0, 0).then((result) => {
        let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
        this.props.appState.mData = users;
      }, (err) => {
        console.warn(err);
      })
    } else {
      this.props.appState.mData = [];
    }
  }
  state = {
    visible: false,
  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    this.props.appState.removeSelected = Selected;
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }
  handleChange = (value) => {
    this.props.appState.Value = value;
  }
  removeClick = (e) => {
    e.preventDefault();
    if (this.props.appState.Value) {
      if (this.props.appState.removeSelected.length !== 0) {
        let dataId = this.props.appState.selectId;
        let remove = this.props.appState.removeSelected;
        //在返回修改的时this.props.appState.selectId时初始值，所以无法进行删除操作，转而对本地存储数据进行操作
        if (dataId.length > 0) {
          if (dataId.length === remove.length) {
            this.props.appState.selectId = [];
            this.props.appState.mData = [];
            this.props.appState.removeSelected = [];
            message.info('请重新添加人员！')
          } else {
            for (let i = 0; i < remove.length; i++) {
              dataId.splice(dataId.indexOf(remove[i]), 1)
            }
            this.props.appState.selectId = dataId;
            window.rpc.user.getArrayByContainer({ id: [...this.props.appState.selectId] }, 0, 0).then((result) => {
              let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
              this.props.appState.mData = users;
            }, (err) => {
              console.warn(err);
            })
          }
        } else {
          //下一步的返回修改操作
          let obje = JSON.parse(sessionStorage.getItem('rulesObj')) || [];
          let datae = obje.userId || [];
          if (datae.length === remove.length) {
            this.props.appState.selectId = [];
            this.props.appState.mData = [];
            this.props.appState.removeSelected = [];
            message.info('请重新添加人员！')
          } else {
            for (let i = 0; i < remove.length; i++) {
              datae.splice(datae.indexOf(remove[i]), 1)
            }
            this.props.appState.selectId = datae;
            window.rpc.user.getArrayByContainer({ id: [...this.props.appState.selectId] }, 0, 0).then((result) => {
              let users = result.map((x) => ({ ...x, ownerId: groupownerNames[x.ownerId]['name'], level: levelList[x.level] || '/', groupId: groupNames[x.groupId]['name'], key: x.id, gender: genderList[x.gender] || '/', createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
              this.props.appState.mData = users;
            }, (err) => {
              console.warn(err);
            })
          }
        }
      } else {
        message.info("请选择人员！");
        this.props.appState.selectId = [];
        this.props.appState.mData = [];
      }
    } else {
      message.info("请选择操作！");
    }
  }

  //提交数据
  handleSubmit = (e) => {
    let rulesObjOne = JSON.parse(sessionStorage.getItem('rulesObj'));
    if (this.props.appState.selectId.length !== 0) {
      e.preventDefault();
      let data = [...this.props.appState.selectId];
      let obj = { userId: data }
      let obj1 = JSON.parse(sessionStorage.getItem('rulesObj'));
      delete obj1.userId;
      let obj2 = eval('(' + (JSON.stringify(obj) + JSON.stringify(obj1)).replace(/}{/, ',') + ')');
      sessionStorage.setItem('rulesObj', JSON.stringify(obj2));
      message.info('添加人员成功！')
      browserHistory.push('/task/generate');
    } else if (rulesObjOne.userId && rulesObjOne.userId.length !== 0) {
      message.info('添加人员成功！')
      browserHistory.push('/task/generate');
    } else {
      this.props.appState.mData = [];
      message.info('请添加人员')
    }
  }
  render() {
    const data = [...this.props.appState.mData];
    const rowSelection = {
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
        this.setState.removeSelected = selected;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        this.setState.removeSelected = selected;
      },
    };
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      render: text => <span>{text}</span>,
    }, {
      title: '姓名',
      dataIndex: 'name',
      key: 'name'
    }, {
      title: '工号',
      dataIndex: 'number',
      key: 'number',
    },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '等级', dataIndex: 'level', key: 'level' },
    { title: '手机', dataIndex: 'mobile', key: 'mobile' },
    { title: '电子邮件', dataIndex: 'email', key: 'email' },
    { title: '部门', dataIndex: 'groupId', key: 'groupId' },
    { title: '公司', dataIndex: 'ownerId', key: 'ownerId' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    ];
    return (
      <div style={{ marginTop: 15 }}>
        <div>
          <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>新增设备规则</Link>
          </div><br />
          <div>
            <Steps current={2} style={{ width: '100%', margin: '0 auto', marginTop: 30 }} className="taskStep">
              <Step title="" />
              <Step title="" />
              <Step title="" />
              <Step title="" />
            </Steps>
          </div>
          {/*图片*/}
          <div className="BasisImg">
            <div></div>
            <ul>
              <li
                onMouseOver={() => {
                  this.setState({ src0: edit1 });
                }}
                onMouseOut={() => {
                  this.setState({ src0: edit0 });
                }}
              >
                <img src={this.state.src0} alt="" />
                <div>基本信息</div>
              </li>
              <li
                onMouseOver={() => {
                  this.setState({ src1: equip1 });
                }}
                onMouseOut={() => {
                  this.setState({ src1: equip0 });
                }}
              >
                <img src={this.state.src1} alt="" />
                <div>添加设备</div>
              </li>
              <li
                style={{ backgroundColor: "#ffffff" }}
                onMouseOver={() => {
                  this.setState({ src2: people1 });
                }}
                onMouseOut={() => {
                  this.setState({ src2: people0 });
                }}
              >
                <div className="BasisSan"></div>
                <img src={this.state.src2} alt="" />
                <div>添加人员</div>
              </li>
              <li
                onMouseOver={() => {
                  this.setState({ src3: generate1 });
                }}
                onMouseOut={() => {
                  this.setState({ src3: generate0 });
                }}
              >
                <img src={this.state.src3} alt="" />
                <div>生成规则</div>
              </li>
            </ul>
          </div>
          <Row style={{ padding: '5px 0 15px', marginTop: 15 }}>
            <Col span={24}>
              <div style={{ float: 'left', marginRight: 4, marginTop: '-7px', width: "100%" }} className="TaskRules">
                <PopoverPreserve appState={this.props.appState} />
                <Button style={{ float: 'left', background: '#d9dee4', color: '#373e41', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.removeClick} >批量操作</Button>
                <div style={{ marginLeft: 5, float: 'left', width: 110, height: 32, background: '#d9dee4' }} className='select-small'>
                  <Select style={{ width: 100 }} placeholder="更多操作" onChange={this.handleChange}>
                    <Option key={1}>删除</Option>
                  </Select>
                </div>
              </div>
            </Col>
          </Row>
          <Row style={{ padding: '5px 0 0' }} className="ConcenHistory">
            <Col span={24}>
              <Table
                bordered
                columns={columns}
                dataSource={data}
                rowSelection={rowSelection}
              />
            </Col>
          </Row>
        </div>
        <Row style={{ marginTop: 20, textAlign: 'left' }}>
          <Col span={24}>
            <div onClick={this.handleSubmit} className="new-button" style={{ display: `inline-block`, backgroundColor: '#00c1de', color: '#fff', fontSize: '0.875rem', marginLeft: 10, fontFamily: '微软雅黑', width: 75, height: 32, cursor: "pointer" }}>下一步</div>
            <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', marginLeft: 10, width: 75, height: 32 }}><Link to="/task/equip/new">返回修改</Link></div>
          </Col>
        </Row>
      </div>
    );
  }
})


class Newpeople extends Component {
  render() {
    return (
      <EquipPreserveMemberC appState={new appState()} />
    )
  }
}
export default Newpeople;