import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Link, browserHistory } from 'react-router';
import { Tabs, Icon, Row, Col, DatePicker, Button, Form, Table, Card, message, Modal, Input, Radio, Select, Checkbox } from 'antd';
import moment from 'moment';
import TaskRulePerformancePerson from './containers/TaskRulePerformancePerson';
import listStore from '../listStore';

const { TabPane } = Tabs;
const { RangePicker } = DatePicker;
const Option = Select.Option;
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;

const { tStateList } = listStore;


// 设置message消息
message.config({
  top: 216,
  duration: 2
})


let config = {}, rules = [];
const EditRule = Form.create()(React.createClass({
  // constructor() {
  //     this.state = {
  //         showStyle2: "none",
  //         showStyle1: 'block',
  //     }
  // },

  getInitialState() {
    return {
      objb: {},
      showStyle2: 'none',
      showStyle1: 'block',
      reportName: []
    }
  },
  changeShow() {
    this.setState({
      showStyle2: 'block',
      showStyle1: 'none'
    });
  },
  componentWillMount() {
    const id = parseInt(this.props.params.id, 10);
    window.rpc.rules.getInfoById(id).then((result) => {
      this.setState({ objb: result });
    }, (err) => {
      console.warn(err);
    })
    //查报表
    window.rpc.report.template.getArrayBriefByContainer(null, 0, 0).then((result) => {
      let reportName = [];
      for (let value of result) {
        reportName[value.id] = value.name;
      }
      this.setState({ reportName });
    }, (err) => {
      console.warn(err);
    })
  },
  handleSubmit(e) {
    e.preventDefault();
    const id = parseInt(this.props.params.id, 10);
    //const id = 17;
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let { name, auditType, TaskDate, cycle, reportId, taskType, workDay } = values;
        let obj = { name, taskType: parseInt(taskType, 10), workDay: parseInt(workDay, 10), auditType: parseInt(auditType, 10), beginTime: new Date(TaskDate[0].format('YYYY-MM-DD HH:mm:ss')), lastTime: new Date(TaskDate[1].format('YYYY-MM-DD HH:mm:ss')), cycle: taskType == 1 ? '' : cycle, reportId: parseInt(reportId, 10) };
        window.rpc.rules.setInfoById(id, obj).then(() => {
          message.info('修改成功！');
          browserHistory.push('/task/rule');
        }, (err) => {
          console.log(err);
        })
      }
    });
  },
  //验证数字
  checkNumber(rule, value, callback) {
    //const form = this.props.form;
    var num = /^[0-9]*$/;
    if (num.test(value)) {
      callback();
    } else {
      callback('请输入数字');
    }
  },
  //审核选择
  onChangeTaskTypeType(value) {
    //console.log(value)
    if (value == 1) {
      document.getElementById("cycle").style.display = 'none';
      delete this.state.objb.cycle;
      rules = [{ required: false, message: '请输入天数!' },]
    } else {
      document.getElementById("cycle").style.display = 'block';
      rules = [
        { required: true, message: '请输入天数!' },
        { validator: this.checkNumber },
      ]
    }
  },
  render() {
    config = {
      initialValue: this.state.objb.cycle || '',
      rules: rules,
    }
    const dateFormat = 'YYYY/MM/DD HH:mm:ss';
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    let reportChildren = [];
    let reportName = this.state.reportName;
    for (let i in reportName) {
      reportChildren.push(<Option key={`${i}`}>{reportName[i]}</Option>)
    }
    return (
      <Form onSubmit={this.handleSubmit} style={{ height: '82vh' }}>
        <Row style={{ marginTop: 30 }}>
          <Col span={12} style={{ position: 'relative', marginLeft: '-25%', left: '50%' }}>
            <FormItem
              {...formItemLayout}
              label="规则名称"
              hasFeedback
            >
              {getFieldDecorator('name', {
                initialValue: this.state.objb.name || '',
                rules: [{ required: true, message: '请输入任务标题!' }],
              })(
                <Input />
                )}
            </FormItem>
          </Col>
        </Row>
        <Row >
          <Col span={12} style={{ position: 'relative', marginLeft: '-25%', left: '50%' }}>
            <FormItem
              {...formItemLayout}
              label="审核方式选择："
              hasFeedback
            >
              {getFieldDecorator('auditType', {
                initialValue: this.state.objb.auditType ? String(this.state.objb.auditType) : '',
                rules: [
                  { required: true, message: '请选择审核方式！' },
                ],
              })(
                <RadioGroup>
                  <RadioButton value="1">报表系统自动审核</RadioButton>
                  <RadioButton value="2">报表人工审核</RadioButton>
                </RadioGroup>
                )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12} style={{ position: 'relative', marginLeft: '-25%', left: '50%' }}>
            <FormItem
              {...formItemLayout}
              label="任务开始时间："
              hasFeedback
            >
              {getFieldDecorator('TaskDate', {
                initialValue: this.state.objb.beginTime && this.state.objb.lastTime ? [moment(this.state.objb.beginTime, dateFormat), moment(this.state.objb.lastTime, dateFormat)] : '',
                rules: [{ required: true, message: '请选择时间!' }],
              })(
                <RangePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['开始时间', '截至时间']}
                />
                )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12} style={{ position: 'relative', marginLeft: '-25%', left: '50%' }}>
            <FormItem
              {...formItemLayout}
              label="使用报表："
              hasFeedback
            >
              {getFieldDecorator('reportId', {
                initialValue: this.state.objb.reportId ? String(this.state.objb.reportId) : '',
                rules: [{ required: true, message: '请选择报表!' }],
              })(
                <Select>
                  {reportChildren}
                </Select>
                )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12} style={{ position: 'relative', marginLeft: '-25%', left: '50%' }}>
            <FormItem
              {...formItemLayout}
              label="任务类型："
              hasFeedback
            >
              {getFieldDecorator('taskType', {
                initialValue: this.state.objb.taskType ? String(this.state.objb.taskType) : '',
                rules: [{ required: true, message: '请选择任务类型!' }],
              })(
                <Select onChange={this.onChangeTaskTypeType} id="select">
                  <Option value="1">抽检</Option>
                  <Option value="2">巡检</Option>
                </Select>
                )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12} style={{ position: 'relative', marginLeft: '-25%', left: '50%', display: `${this.state.objb.taskType === 2 ? 'block' : 'none'}` }} id="cycle">
            <FormItem
              {...formItemLayout}
              label="检查频率（天/次）"
              hasFeedback
            >
              {getFieldDecorator('cycle', config)(
                <Input />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12} style={{ position: 'relative', marginLeft: '-25%', left: '50%' }}>
            <FormItem
              {...formItemLayout}
              label="持续时间："
              hasFeedback
            >
              {getFieldDecorator('workDay', {
                initialValue: this.state.objb.workDay ? String(this.state.objb.workDay) : '',
                rules: [
                  { required: true, message: '请输入持续时间！' },
                  { validator: this.checkNumber },
                ],
              })(
                <Input />
                )}
            </FormItem>
          </Col>
        </Row>


        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 10, display: this.state.showStyle1 }}>
          <Button type="primary" size="large" onClick={this.changeShow} style={{ float: 'left', marginRight: 10 }}>编辑</Button>
          <Button type="success" size="large" style={{ float: 'left' }}><Link to='/task/rule'>返回</Link></Button>
        </Row>

        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 10, display: this.state.showStyle2 }}>
          <Button type="primary" htmlType="submit" size="large" style={{ float: 'left', marginRight: 10 }}>保存</Button>
          <Button type="success" size="large" style={{ float: 'left' }}><Link to='/task/rule'>取消</Link></Button>
        </Row>
      </Form>


    );
  },
}));



// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
    })
  }
}

const TaskRuleDetailC = observer(class TaskRuleDetailC extends React.Component {
  constructor() {
    super();
    this.state = {
      showStyle2: 'none',
      showStyle1: 'block',
    };
  }

  changeShow = () => {
    this.setState({
      showStyle2: 'block',
      showStyle1: 'none',
    });
  }

  componentWillMount() {
  }

  componentDidMount() {
    const id = parseInt(this.props.params.id, 10);
    //设备列表
    let values = { 'id': id };
    window.rpc.rules.device.getArrayBriefByContainer(values, 0, 0).then((result) => {
      let deviceData = result.map((x) => ({ ...x, key: x.id, name: x.name, typeName: x.typeName, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), location: x.location, dstate: tStateList[x.dstate], patroTime: moment(x.patroTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), userName: x.userName, mobile: x.mobile }));
      this.props.appState.tableData = deviceData;
    }, (err) => {
      console.warn(err);
    })
  }
  state = {
    selectedRowKeys: [],  // Check here to configure the default column
  };

  onSelectChange = (selectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    this.setState({ selectedRowKeys });
  }

  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };

    let hasSelected = 0;

    if (selectedRowKeys) {
      hasSelected = selectedRowKeys.length;
    }

    const dataSource = [...this.props.appState.tableData];
    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '名称', dataIndex: 'name', key: 'name' },
      { title: '类型', dataIndex: 'typeName', key: 'typeName' },
      { title: '安装日期', dataIndex: 'setupTime', key: 'setupTime' },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record) => {
          let textArr = text.split(',');
          if (textArr[2]) {
            return (
              <span>
                <Link to={`/org/building/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link to={`/org/floor/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>--
                <Link to={`/org/areacontent/${textArr[2].split(':')[0]}`}>{textArr[2].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[1]) {
            return (
              <span>
                <Link to={`/org/building/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link to={`/org/floor/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[0]) {
            return (
              <span>
                <Link to={`/org/building/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>
              </span>
            )
          }
        }
      },
      { title: '状态', dataIndex: 'dstate', key: 'dstate' },
      { title: '最后巡查时间', dataIndex: 'patroTime', key: 'patroTime' },
      { title: '巡查人', dataIndex: 'userName', key: 'userName' },
      { title: '联系电话', dataIndex: 'mobile', key: 'mobile' },
      // {
      //   title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
      //     <span>
      //       <Link to={`/member/groupdetail/${record.key}`}>维护</Link>
      //       <span className="ant-divider" />
      //       <Link to={`/member/editgroup/${record.key}`}>更换</Link>
      //       <span className="ant-divider" />
      //       <Link to={`/member/invite/${record.key}`}>查看</Link>
      //     </span>
      //   )
      // },
    ];
    return (
      <div className="ConcenHistory">
        <div style={{ height: 35, paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/task/rule' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备任务规则</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }}><Link to="/task/basis">新增规则</Link></Button>
            <Button style={{ float: 'left', background: '#d9dee4', color: '#373e41', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.handleBatch} >批量操作</Button>
            <div style={{ marginLeft: 5, float: 'left', width: 110, height: 32, background: '#d9dee4' }} className='select-small'>
              <Select
                showSearch
                style={{ width: 100, height: 32, color: '#373e41', fontSize: '0.875rem' }}
                id="select"
                placeholder="更多操作"
                optionFilterProp="children"
                onChange={this.handlemore}
                filterOption={(input, option) => option.props.value.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                <Option value="1">启用</Option>
                <Option value="2">停用</Option>
                <Option value="3">删除</Option>
              </Select>
            </div>
          </div>
        </div>

        <div className="EquipTaskRuleDetail" style={{ margin: 0, fontFamily: '苹方中等', position: 'relative' }}>
          <Tabs defaultActiveKey="1">
            <TabPane tab={<span><Icon type="info-circle-o" />基础信息</span>} key="1">
              <EditRule params={this.props.params} />
            </TabPane>
            <TabPane tab={<span><Icon type="info-circle-o" />设备列表</span>} key="2" onClick={this.clearSelectNum}>
              <div style={{ height: '82vh' }}>
                <Row style={{ padding: '0 0 5px' }}>
                  <Col span={6} >
                    <FormItem style={{ paddingLeft: 20 }}>
                      <span>已选择{hasSelected}项数据</span>
                    </FormItem>
                  </Col>
                </Row>
                <Row style={{ padding: '0 0 5px' }}>
                  <Col span={24}>
                    <Table
                      bordered
                      rowSelection={rowSelection}
                      columns={columns}
                      dataSource={dataSource}
                      pagination={pagination}
                    />
                  </Col>
                </Row>
                <Row style={{ margin: '10px 0', position: 'absolute', bottom: 10, display: this.state.showStyle1 }}>

                  <Button type="primary" size="large" onClick={this.changeShow} style={{ float: 'left', marginRight: 10 }}>编辑</Button>
                  <Button type="success" size="large" style={{ float: 'left' }}><Link to='/task/rule'>返回</Link></Button>
                </Row>

                <Row style={{ margin: '10px 0', position: 'absolute', bottom: 10, display: this.state.showStyle2 }}>
                  <Button type="primary" htmlType="submit" size="large" style={{ float: 'left', marginRight: 10 }}>保存</Button>
                  <Button type="success" size="large" style={{ float: 'left' }}><Link to='/task/rule'>取消</Link></Button>
                </Row>
              </div>
            </TabPane>
            <TabPane tab={<span><Icon type="info-circle-o" />执行人员</span>} key="3" onClick={this.clearSelectNum}>
              <TaskRulePerformancePerson params={this.props.params} />
            </TabPane>
          </Tabs>
        </div>
      </div>
    );

  }
})

class RulesDetail extends Component {
  render() {
    return (
      <TaskRuleDetailC appState={new appState()} params={this.props.params} />
    )
  }
}

export default RulesDetail;
