import React from 'react';
import { Form, Row, Col, Steps, Radio, Switch, message } from 'antd';
import { Link, browserHistory } from 'react-router';
import './Rules.css';

import task from '../../../assets/images/task/task.png';
import types from '../../../assets/images/task/types.png';
import ok from '../../../assets/images/task/ok.png';
import edit0 from '../../../assets/images/task/编辑0.png';
import edit1 from '../../../assets/images/task/编辑1.png';
import equip0 from '../../../assets/images/task/选择设备0.png';
import equip1 from '../../../assets/images/task/选择设备1.png';
import people0 from '../../../assets/images/task/选择人员0.png';
import people1 from '../../../assets/images/task/选择人员1.png';
import generate0 from '../../../assets/images/task/生成规则0.png';
import generate1 from '../../../assets/images/task/生成规则1.png';

const FormItem = Form.Item;
const { Step } = Steps;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

const NewGenerate = Form.create()(React.createClass({
  getInitialState() {
    return {
      one: 'block',
      two: 'none',
      src0: edit0,
      src1: equip0,
      src2: people0,
      src3: generate0,
      state: 0,
    };
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let { stateS, allotType } = values;
        let obj = {};
        if (this.state.state) {
          if (stateS) {
            obj = { state: 1, allotType: parseInt(allotType, 10) }
          } else {
            obj = { state: 2, allotType: parseInt(allotType, 10) }
          }
        } else {
          obj = { state: 1, allotType: parseInt(allotType, 10) }
        }

        let obj1 = JSON.parse(sessionStorage.getItem('rulesObj'));
        let obj2 = eval('(' + (JSON.stringify(obj) + JSON.stringify(obj1)).replace(/}{/, ',') + ')');
        let { auditType, beginTime, cycle, name, endTime, reportId, resId, userId, state, workDay, taskType } = obj2;
        let obj3 = { auditType, taskType, workDay, state: parseInt(state, 10), beginTime: new Date(beginTime.replace('T', ' ').replace('.000Z', '')), cycle, name, endTime: new Date(endTime.replace('T', ' ').replace('.000Z', '')), reportId, resId, userId }
        window.rpc.rules.create(obj3).then((res) => {
          if (res) {
            message.info('创建成功！')
            browserHistory.push('/task/rule');
            sessionStorage.removeItem("rulesObj")
          } else {
            message.info('创建失败！')
          }

        }, (err) => {
          console.log(err);
        })
      }
    });
  },
  //审核选择
  onChange(e) {
    if (`${e.target.value}` === '1') {
      this.setState({
        one: 'block',
        two: 'none'
      })
    };
    if (`${e.target.value}` === '2') {
      this.setState({
        one: 'none',
        two: 'block'
      })
    }
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 3 },
      wrapperCol: { span: 8 },
    };

    return (
      <div>
        <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>新增设备规则</Link>
        </div><br />
        <div>
          <Steps current={3} style={{ width: '100%', margin: '0 auto', marginTop: 30 }} className="taskStep">
            <Step title="" />
            <Step title="" />
            <Step title="" />
            <Step title="" />
          </Steps>
        </div>
        {/*图片*/}
        <div className="BasisImg">
          <div></div>
          <ul>
            <li
              onMouseOver={() => {
                this.setState({ src0: edit1 });
              }}
              onMouseOut={() => {
                this.setState({ src0: edit0 });
              }}
            >
              <img src={this.state.src0} alt="" />
              <div>基本信息</div>
            </li>
            <li
              onMouseOver={() => {
                this.setState({ src1: equip1 });
              }}
              onMouseOut={() => {
                this.setState({ src1: equip0 });
              }}
            >
              <img src={this.state.src1} alt="" />
              <div>添加设备</div>
            </li>
            <li
              onMouseOver={() => {
                this.setState({ src2: people1 });
              }}
              onMouseOut={() => {
                this.setState({ src2: people0 });
              }}
            >
              <img src={this.state.src2} alt="" />
              <div>添加人员</div>
            </li>
            <li
              style={{ backgroundColor: "#ffffff" }}
              onMouseOver={() => {
                this.setState({ src3: generate1 });
              }}
              onMouseOut={() => {
                this.setState({ src3: generate0 });
              }}
            >
              <div className="BasisSan"></div>
              <img src={this.state.src3} alt="" />
              <div>生成规则</div>
            </li>
          </ul>
        </div>
        <Form onSubmit={this.handleSubmit} className="ruleForm" style={{ marginTop: 26 }}>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={types} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }} className="genterType">
              <FormItem
                {...formItemLayout}
                label="设备分配方式："
                hasFeedback
              >
                {getFieldDecorator('allotType', {
                  initialValue: '1',
                  rules: [
                    { required: true, message: '请选择分配方式！' },
                  ],
                })(
                  <RadioGroup onChange={this.onChange}>
                    <RadioButton value="1">共享</RadioButton>
                    <RadioButton value="2">独享</RadioButton>
                  </RadioGroup>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft" style={{ height: 60 }}>
            <div style={{ float: "left", width: "2%" }}>
              <img src={task} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }}>
              <FormItem
                {...formItemLayout}
                label="设备分配方式说明："
                hasFeedback
              >
                {getFieldDecorator('remark', {
                })(
                  <div>
                    <div style={{ display: `${this.state.one}` }}>此选项下所有人员共享所有设备，所有人一起巡检设备。系统不会将设备分配到个人；</div>
                    <div style={{ display: `${this.state.two}` }}>此选项下所有人员不能共享此设备，个人独自进行巡检设备。</div>
                  </div>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="ruleFormLeft">
            <div style={{ float: "left", width: "2%" }}>
              <img src={ok} alt="" />
            </div>
            <div style={{ float: "left", width: "90%" }} className="switch">
              <FormItem
                {...formItemLayout}
                label="是否启用："
              >
                {getFieldDecorator('stateS', {

                })(
                  <Switch onChange={() => { this.setState({ stat: 1 }); }} defaultChecked={true} checkedChildren={'开'} unCheckedChildren={'关'} />
                  )}
              </FormItem>
            </div>
          </div>
          <Row style={{ marginTop: 60, textAlign: 'left' }}>
            <Col span={22}>
              <div onClick={this.handleSubmit} className="new-button" style={{ display: `inline-block`, backgroundColor: '#00c1de', color: '#fff', fontSize: '0.875rem', marginLeft: 10, fontFamily: '微软雅黑', width: 75, height: 32, cursor: "pointer" }}>完成</div>
              <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', marginLeft: 10, fontFamily: '微软雅黑', width: 75, height: 32 }}><Link to="/task/people">返回修改</Link></div>

            </Col>
          </Row>
        </Form>
      </div>
    );
  },
}));

export default NewGenerate;