/*
 * @Author: lai.haibo 
 * @Date: 2017-04-18 17:03:13 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-07 17:16:48
 */

import React, { Component } from 'react';
import { Collapse, Input, Row, Col, Button, Radio, Checkbox } from 'antd';
import { observable, toJS } from 'mobx';
import { Link, browserHistory } from 'react-router';
import { observer } from 'mobx-react';
import './report.css';
import './modal.css';

const Panel = Collapse.Panel;

const radioStyle = {
  display: 'block',
  height: '32px',
  lineHeight: '32px'
};

class designState {
  @observable addItem = { title: '新项目', itemType: '2', checkType: '2', content: '新内容' };
  @observable addChooice = { title: '新选项', default: false };
  @observable panels = [];
  @observable newKey = 0;
  @observable defaultActiveKey = Array.from(new Array(100), (item, idx) => `${idx}`);
  @observable parentNode = '';
  @observable editItem = {};
  @observable editChooice = {};
  @observable title = '';
}


@observer
class DesingC extends Component {
  componentDidMount() {
    let id = parseInt(this.props.params.id, 10);

    const t = (id) => {
      return window.rpc.report.template.getInfoById(id);
    }

    const getInfo = async () => {
      try {
        const f = await t(id);
        this.props.designState.panels = JSON.parse(f.page);
        this.props.designState.title = f.name;
      } catch (err) {
        console.log(err);
      }
    }

    getInfo();
  }

  render() {
    function ge(panel, designState) {
      // console.info(panel);
      if (panel && panel.itemType === '1') {
        return (
          <Panel className={`Panel-Level${panel.level}`} header={panel.title} key={panel.key} style={{ padding: 0 }}>
            <Row gutter={16}>
              {/*<Col span={10}>
                <span style={{ marginRight: 6 }}>名称</span>
                <span><Input style={{ width: 'calc(100% - 30px)' }} placeholder="请输入项目名称" defaultValue={panel.title} disabled /></span>
              </Col>
              <Col span={6}>
                <span style={{ marginRight: 6 }}>项目类型</span>
                <span>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </span>
              </Col>
              <Col span={6}>
                <span style={{ marginRight: 6 }}>选项类型</span>
                <span>
                  <Select defaultValue={panel.checkType} style={{ width: 120 }} disabled>
                    <Option value="1">单选</Option>
                    <Option value="2">多选</Option>
                  </Select>
                </span>
              </Col>*/}
              <Col span={24}>
                {
                  panel.checkType === '1' ?
                    [...panel.chooiceItems].filter(x => x).map((chooiceItem, index) => (<Row key={`${index}`} style={{ marginTop: 8 }}><Col span={16}><Radio style={radioStyle} checked={chooiceItem.default} value={chooiceItem.key} disabled>{chooiceItem.title}</Radio></Col></Row>)) :
                    [...panel.chooiceItems].filter(x => x).map((chooiceItem, index) => (<Row key={`${index}`} style={{ marginTop: 8 }}><Col span={16}><Checkbox style={radioStyle} defaultChecked={chooiceItem.default} disabled>{chooiceItem.title}</Checkbox></Col></Row>))
                }
              </Col>
              {/*<Col span={24}>
                <AddChoiceModal designState={designState} addLevel={panel.addLevel} />
              </Col>*/}
            </Row>
          </Panel>
        );
      } else if (panel && panel.itemType === '2') {
        return (
          <Panel className={`Panel-Level${panel.level}`} header={panel.title} key={panel.key} style={{ padding: 0 }}>
            {/*<Row gutter={16}>
              <Col span={10}>
                <span style={{marginRight: 6}}>名称</span>
                <span><Input style={{ width: 'calc(100% - 30px)'}} placeholder="请输入项目名称" defaultValue={panel.title} disabled /></span>
              </Col>
              <Col span={6}>
                <span style={{marginRight: 6}}>项目类型</span>
                <span>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </span>
              </Col>
              <Col span={6}></Col>
            </Row>*/}
            <Collapse className="insideCollaspse" defaultActiveKey={[...designState.defaultActiveKey]} key={panel.key}>
              {panel.children.map(panel => ge(panel, designState))}
            </Collapse>
            {/*<Row gutter={16}>
              <Col span={24}>
                <AddItemModal designState={designState} addLevel={panel.addLevel} />
              </Col>
            </Row>*/}
          </Panel>
        );
      }
    }
    let panels = toJS(this.props.designState.panels);
    // console.info(panels);
    return (
      <div className="ReportDesign" style={{ padding: 0 }}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>任务报表</Link>
          </div>
        </div>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={2} style={{ height: '32px', lineHeight: '32px' }}>
            报表设计:
          </Col>
          <Col span={4}>
            <Input placeholder="请输入报表名称" value={this.props.designState.title} onChange={(e) => { this.props.designState.title = e.target.value }} disabled style={{ width: 288, height: 32 }} />
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={24}>
            <Collapse defaultActiveKey={[...this.props.designState.defaultActiveKey]} style={{ margin: '8px 0' }}>
              {panels.map(panel => ge(panel, this.props.designState))}
            </Collapse>
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0, textAlign: 'center' }}>
          {/*<Col span={24} style={{ margin: '24px 0 0'}}>
            <AddItemModal designState={this.props.designState} addLevel={[0]} />
          </Col>*/}
          <Col span={24} style={{ margin: '16px 0 0', textAlign: 'left' }}>
            <Button type="primary" onClick={() => browserHistory.push('/task/report')}>返回</Button>
          </Col>
        </Row>
      </div>
    )
  }
}

class Detail extends Component {
  render() {
    return (
      <DesingC designState={new designState()} params={this.props.params} />
    )
  }
}


export default Detail;