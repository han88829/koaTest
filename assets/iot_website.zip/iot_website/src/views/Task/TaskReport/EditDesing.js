/*
 * @Author: lai.haibo 
 * @Date: 2017-04-18 17:03:01 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-04-20 13:58:31
 */

import React, { Component } from 'react';
import { Collapse, Input, Row, Col, Button, Icon, Select, Radio, Modal, Switch, Checkbox, Cascader, message, Dropdown, Menu } from 'antd';
import { observable, toJS } from 'mobx';
import { Link, browserHistory } from 'react-router';
import { observer } from 'mobx-react';
import './report.css';
import './modal.css';

const Panel = Collapse.Panel;
// const RadioGroup = Radio.Group;
const Option = Select.Option;

const radioStyle = {
  display: 'block',
  height: '32px',
  lineHeight: '32px'
};

class designState {
  @observable addItem = {  title: '新项目', itemType:'2', checkType: '2',content: '新内容'};
  @observable addChooice = { title: '新选项', default: false };
  @observable panels = [];
  @observable newKey = 0;
  @observable defaultActiveKey = Array.from(new Array(100), (item, idx) => `${idx}`);
  @observable parentNode = '';
  @observable editItem = {};
  @observable editChooice = {};
  @observable title = '';
}

class AddItemModal extends Component {
  state = { 
    visible: false, 
    disabled: true,
    addItem:  { title: '新项目', itemType:'2', checkType: '2',content: '新内容' }
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleOkUp = (e) => {
    let panels = toJS(this.props.designState.panels);
    let addLevel = [...this.props.addLevel];
    let parentNode = this.props.designState.parentNode;
    if(parentNode) {
      let temp = parentNode.split('+');
      let last = temp.pop().split('-').map(num => parseInt(num, 10));
      addLevel = last;
    }
    let addLevelLen = addLevel.length;
    let newKey = this.props.designState.newKey + 1;
    
    let id = newKey;
    let key = `${newKey}`;
    this.props.designState.newKey = newKey;

    let addItem = {...this.props.designState.addItem, key, id, chooiceItems: [], default: [1], children:[]};

    switch (addLevelLen) {
      case 1:
        {
          let newAddLevel = [...addLevel, panels.length+1];
          panels.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 1});
          this.props.designState.panels = panels;
        }
        break;
      case 2:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children.length+1];
          panels[addLevel[1] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 2});
          this.props.designState.panels = panels;
        }
       break;
      case 3:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children.length+1];
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 3});
          this.props.designState.panels = panels;
        }
       break;
      case 4:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.length+1];
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 4});
          this.props.designState.panels = panels;
        }
       break;
      case 5:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.length+1];
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 5});
          this.props.designState.panels = panels;
        }
       break;
      case 6:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.length+1];
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 6});
          this.props.designState.panels = panels;
        }
       break;
      default:
          console.log('xixi');
        break;
    }
    this.props.designState.parentNode = '';
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  render() {
    const options = [
      {
        label: '根',
        value: '0',
        children: [...this.props.designState.panels]
      }
    ];
    return (
      <div>
        <Button type="dashed" onClick={this.showModal} style={{ width: '100%' }}>
          <Icon type="plus" /> 添加
        </Button>
        <Modal className="reportDesignModal"
          title="新建集合/项目" visible={this.state.visible}
          onCancel={this.handleCancel}
          onOk={this.handleOkUp}
        >
          <div className="modal-form">
            <div>
              <span>名称</span>
              <span>
                <Input placeholder="请输入项目名称" defaultValue={this.props.designState.addItem.title} onChange={(e) => {this.props.designState.addItem.title = e.target.value}} />
              </span>
            </div>
            <div>
              <span>项目类型</span>
              <span>
                <Select defaultValue={this.props.designState.addItem.itemType} style={{ width: 120 }} onChange={(value) => {
                  this.props.designState.addItem.itemType = value;
                  this.setState({
                    disabled: this.props.designState.addItem.itemType === '2'
                  })
                }}>
                  <Option value="2">集合</Option>
                  <Option value="1">项目</Option>
                </Select>
              </span>
            </div>
            <div>
              <span>选项类型</span>
              <span>
                <Select defaultValue={this.props.designState.addItem.checkType} style={{ width: 120 }} onChange={(value) => this.props.designState.addItem.checkType = value} disabled={this.props.designState.addItem.itemType === '2'}>
                  <Option value="1">单选</Option>
                  <Option value="2">多选</Option>
              </Select>
              </span>
            </div>
            <div>
              <span>选择父节点</span>
              <span>
                <Cascader options={options} onChange={(value) => {this.props.designState.parentNode = value.join('+')}} placeholder="请选择" changeOnSelect />
              </span>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}

class EditItemModal extends Component {
  state = { 
    visible: false, 
    deleteVisible: false,
    disabled: true,
    addItem:  { title: '新项目', itemType:'2', checkType: '2',content: '新内容' },
    self: {...this.props.self}
  }
  showModal = () => {
    console.info(this.state.self);
    this.props.designState.editItem = this.state.self;
    this.setState({
      visible: true,
    });
  }

  handleOkUp = (e) => {
    let self = {...this.props.self};
    let panels = toJS(this.props.designState.panels);
    let formerLevel = [...self.addLevel];
    let addLevel = [...this.props.addLevel];
    let addItem = toJS(this.props.designState.editItem);
    let parentNode = this.props.designState.parentNode;
    if(parentNode) {
      let temp = parentNode.split('+');
      let last = temp.pop().split('-').map(num => parseInt(num, 10));
      addLevel = last;
      let addLevelLen = addLevel.length;
      //删除原先所在位置
      switch (formerLevel.length) {
        case 2:
          {
            panels[formerLevel[1] - 1] = null;
            // this.props.designState.panels = panels;
          }
        break;
        case 3:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1] = null;
            // this.props.designState.panels = panels;
          }
        break;
        case 4:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1] = null;
            // this.props.designState.panels = panels;
          }
        break;
        case 5:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1] = null;
            // this.props.designState.panels = panels;
          }
        break;
        case 6:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1] = null;
            // this.props.designState.panels = panels;
          }
        break;
        case 7:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1].children[formerLevel[6] - 1] = null;
            // this.props.designState.panels = panels;
          }
        break;
        default:
            console.log('愣头青， 递归, 不存在的');
          break;
      }
      switch (addLevelLen) {
        case 1:
          {
            let newAddLevel = [...addLevel, panels.length+1];
            panels.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 1});
            this.props.designState.panels = panels;
          }
          break;
        case 2:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children.length+1];
            panels[addLevel[1] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 2});
            this.props.designState.panels = panels;
          }
        break;
        case 3:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children.length+1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 3});
            this.props.designState.panels = panels;
          }
        break;
        case 4:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.length+1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 4});
            this.props.designState.panels = panels;
          }
        break;
        case 5:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.length+1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 5});
            this.props.designState.panels = panels;
          }
        break;
        case 6:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.length+1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 6});
            this.props.designState.panels = panels;
          }
        break;
        default:
            console.log('xixi');
          break;
      }
    }else {
      // let addLevelLen = addLevel.length;
      //删除原先所在位置
      switch (formerLevel.length) {
        case 2:
          {
            panels[formerLevel[1] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
        break;
        case 3:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
        break;
        case 4:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
        break;
        case 5:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
        break;
        case 6:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
        break;
        case 7:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1].children[formerLevel[6] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
        break;
        default:
            console.log('愣头青， 递归, 不存在的');
          break;
      }
    }


    // //转移节点
    // switch (addLevelLen) {
    //   case 1:
    //     {
    //       let newAddLevel = [...addLevel, panels.length+1];
    //       panels.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 1});
    //       // this.props.designState.panels = panels;
    //     }
    //     break;
    //   case 2:
    //     {
    //       let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children.length+1];
    //       panels[addLevel[1] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 2});
    //       // this.props.designState.panels = panels;
    //     }
    //    break;
    //   case 3:
    //     {
    //       let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children.length+1];
    //       panels[addLevel[1] - 1].children[addLevel[2] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 3});
    //       // this.props.designState.panels = panels;
    //     }
    //    break;
    //   case 4:
    //     {
    //       let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.length+1];
    //       panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 4});
    //       // this.props.designState.panels = panels;
    //     }
    //    break;
    //   case 5:
    //     {
    //       let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.length+1];
    //       panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 5});
    //       // this.props.designState.panels = panels;
    //     }
    //    break;
    //   case 6:
    //     {
    //       let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.length+1];
    //       panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.push({ ...addItem, addLevel: newAddLevel,label: addItem.title, value: newAddLevel.join('-'), level: 6});
    //       // this.props.designState.panels = panels;
    //     }
    //    break;
    //   default:
    //       console.log('xixi');
    //     break;
    // }
    
    this.props.designState.panels = panels;
    this.props.designState.parentNode = '';

    this.setState({
      visible: false,
    });
  }

  handleDeleteUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let parentNode = this.props.designState.parentNode;
    if(parentNode) {
      let temp = parentNode.split('+');
      let last = temp.pop().split('-').map(num => parseInt(num, 10));
      addLevel = last;
    }
    let addLevelLen = addLevel.length;
    let newKey = this.props.designState.newKey + 1;
    this.props.designState.newKey = newKey;

    switch (addLevelLen) {
      case 2:
        {
          panels[addLevel[1] - 1] = null;
          this.props.designState.panels = panels;
        }
       break;
      case 3:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1] = null;
          this.props.designState.panels = panels;
        }
       break;
      case 4:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1] = null;
          this.props.designState.panels = panels;
        }
       break;
      case 5:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1] = null;
          this.props.designState.panels = panels;
        }
       break;
      case 6:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1] = null;
          this.props.designState.panels = panels;
        }
       break;
       case 7:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1] = null;
          this.props.designState.panels = panels;
        }
       break;
      default:
          console.log('愣头青， 递归, 不存在的');
        break;
    }
    this.props.designState.parentNode = '';
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
      deleteVisible: false
    });
  }

  handleMenuClick = (e) => {
    this.props.designState.editItem = this.state.self;
    console.log(toJS(this.props.designState.editItem));
    console.log([...this.props.addLevel]);
    if(e.key === '1') {
      this.setState({
        visible: true,
      });
    }else{
      this.setState({
        deleteVisible: true,
      });
    }
  }

  render() {
    const options = [
      {
        label: '根',
        value: '0',
        children: [...this.props.designState.panels]
      }
    ];

    const menu = (
      <Menu onClick={this.handleMenuClick}>
        <Menu.Item key="1">修改</Menu.Item>
        <Menu.Item key="2">删除</Menu.Item>
      </Menu>
    );
    return (
      <div>
        <Dropdown overlay={menu}>
          <Button style={{ marginLeft: 8 }}>
            编辑 <Icon type="down" />
          </Button>
        </Dropdown>
        <Modal className="reportDesignModal"
          title="编辑集合/项目" visible={this.state.visible}
          onOk={this.handleOkUp} onCancel={this.handleCancel}
        >
          <div className="modal-form">
            <div>
              <span>名称</span>
              <span>
                <Input placeholder="请输入项目名称" defaultValue={this.props.designState.editItem.title} onChange={(e) => {this.props.designState.editItem.title = e.target.value;console.log(this.props.designState.editItem)}} />
              </span>
            </div>
            <div>
              <span>项目类型</span>
              <span>
                <Select defaultValue={this.props.designState.editItem.itemType} style={{ width: 120 }} onChange={(value) => {
                this.props.designState.editItem.itemType = value;
                console.log(this.props.designState.editItem);
                this.setState({
                  disabled: this.props.designState.editItem.itemType === '2'
                })
                }}>
                  <Option value="2">集合</Option>
                  <Option value="1">项目</Option>
                </Select>
              </span>
            </div>
            <div>
              <span>选项类型</span>
              <span>
                <Select defaultValue={this.props.designState.editItem.checkType} style={{ width: 120 }} onChange={(value) => {this.props.designState.editItem.checkType = value;console.log(this.props.designState.editItem)}} disabled={this.props.designState.editItem.itemType === '2'}>
                  <Option value="1">单选</Option>
                  <Option value="2">多选</Option>
                </Select>
              </span>
            </div>
            <div>
              <span>选择父节点</span>
              <span>
                <Cascader options={options} onChange={(value) => {this.props.designState.parentNode = value.join('+');console.log(this.props.designState.editItem)}} placeholder="请选择" changeOnSelect />
              </span>
            </div>
          </div>
        </Modal>
        <Modal className="reportDesignModal-delete"
          title="删除集合/项目" visible={this.state.deleteVisible}
          onOk={this.handleDeleteUp} onCancel={this.handleCancel}
        >
          <p>确认删除该项？</p>
      </Modal>
    </div>
    );
  }
}

class AddChoiceModal extends Component {
  state = { visible: false }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleOkUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let addLevelLen = addLevel.length;
    let key = `${Math.round(new Date().getTime() * Math.random())}`;
    let addChooice = {...this.props.designState.addChooice, key};

    switch (addLevelLen) {
      case 2:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].checkType === '1'){
              panels[addLevel[1] - 1].chooiceItems = panels[addLevel[1] - 1].chooiceItems.map(chooiceItem => ({...chooiceItem, default: false}));
            }
          }

          panels[addLevel[1] - 1].chooiceItems.push({ ...addChooice});
          this.props.designState.panels = panels;
        }
       break;
      case 3:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.map(chooiceItem => ({...chooiceItem, default: false}));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.push({ ...addChooice});
          this.props.designState.panels = panels;
        }
       break;
      case 4:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.map(chooiceItem => ({...chooiceItem, default: false}));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.push({ ...addChooice});
          this.props.designState.panels = panels;
        }
       break;
      case 5:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.map(chooiceItem => ({...chooiceItem, default: false}));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.push({ ...addChooice});
          this.props.designState.panels = panels;
        }
       break;
      case 6:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.map(chooiceItem => ({...chooiceItem, default: false}));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.push({ ...addChooice});
          this.props.designState.panels = panels;
        }
       break;
       case 7:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.map(chooiceItem => ({...chooiceItem, default: false}));
            }
          }
          
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.push({ ...addChooice});
          this.props.designState.panels = panels;
        }
       break;
      default:
          console.log('xixi');
        break;
    }
    
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }
  
  render() {
    return (
      <div>
        <Button type="dashed" onClick={this.showModal} style={{ width: '100%' }}>
          <Icon type="plus" /> 添加
        </Button>
        <Modal className="reportDesignModal"
          title="新建选项" visible={this.state.visible}
          onOk={this.handleOkUp} onCancel={this.handleCancel}
        >
          <div className="modal-form-choice">
            <div>
              <span>选项内容</span>
              <span>
                <Input placeholder="请输入选项内容" defaultValue={this.props.designState.addChooice.title} onChange={(e) => {this.props.designState.addChooice.title = e.target.value}} />
              </span>
            </div>
            <div>
              <span>默认结果</span>
              <span>
                <Switch checkedChildren={'是'} unCheckedChildren={'否'} defaultChecked={this.props.designState.addChooice.default} onChange={(checked) => this.props.designState.addChooice.default = checked} />
              </span>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}

class EditChoiceModal extends Component {
  state = { visible: false, deleteVisible: false }
  showModal = () => {
    // console.info([...this.props.addLevel]);
    console.info(this.props.self);
    this.setState({
      visible: true,
    });
  }
  handleOkUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let addLevelLen = addLevel.length;
    let key = `${Math.round(new Date().getTime() * Math.random())}`;
    let addChooice = {...this.props.designState.addChooice, key};
    let self = this.props.self;
    // console.info(addChooice);

    switch (addLevelLen) {
      case 2:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].checkType === '1'){
              panels[addLevel[1] - 1].default = [panels[addLevel[1] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].default.push(panels[addLevel[1] - 1].chooiceItems.length + 1);
            }
          }
          panels[addLevel[1] - 1].chooiceItems[self]={ ...addChooice};
          this.props.designState.panels = panels;
        }
       break;
      case 3:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1);
            }
          }
          panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self]={ ...addChooice};
          this.props.designState.panels = panels;
        }
       break;
      case 4:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1);
            }
          }
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems[self]={ ...addChooice};
          this.props.designState.panels = panels;
        }
       break;
      case 5:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1);
            }
          }
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems[self]={ ...addChooice};
          this.props.designState.panels = panels;
        }
       break;
      case 6:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1);
            }
          }
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems[self]={ ...addChooice};
          this.props.designState.panels = panels;
        }
       break;
       case 7:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1);
            }
          }
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems[self]={ ...addChooice};
          this.props.designState.panels = panels;
        }
       break;
      default:
          console.log('xixi');
        break;
    }
    
    this.setState({
      visible: false,
    });
  }
  handleDeleteUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let addLevelLen = addLevel.length;
    let key = `key-${Math.round(new Date().getTime() * Math.random())}`;
    let addChooice = {...this.props.designState.addChooice, key};
    let self = this.props.self;
    // console.info(addChooice);

    switch (addLevelLen) {
      case 2:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].checkType === '1'){
              panels[addLevel[1] - 1].default = [panels[addLevel[1] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].default.push(panels[addLevel[1] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].chooiceItems[self] =null;
          this.props.designState.panels = panels;
        }
       break;
      case 3:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self] =null;
          this.props.designState.panels = panels;
        }
       break;
      case 4:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems[self] =null;
          this.props.designState.panels = panels;
        }
       break;
      case 5:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems[self] =null;
          this.props.designState.panels = panels;
        }
       break;
      case 6:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems[self] =null;
          this.props.designState.panels = panels;
        }
       break;
       case 7:
        {
          if(addChooice.default) {
            if(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].checkType === '1'){
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1];
            }else{
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems[self] =null;
          this.props.designState.panels = panels;
        }
       break;
      default:
          console.log('xixi');
        break;
    }
    
    this.setState({
      visible: false,
    });
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
      deleteVisible: false
    });
  }
  handleMenuClick = (e) => {
    console.log(e);
    if(e.key === '1') {
      console.info(this.props.self);
      this.setState({
        visible: true,
      });
    }else{
      this.setState({
        deleteVisible: true,
      });
    }
  }
  render() {
    const menu = (
      <Menu onClick={this.handleMenuClick}>
        <Menu.Item key="1">修改</Menu.Item>
        <Menu.Item key="2">删除</Menu.Item>
      </Menu>
    );
    return (
      <div style={{display:'inlineFlex'}}>
        <Dropdown overlay={menu}>
          <Button style={{ marginLeft: 8 }}>
            编辑 <Icon type="down" />
          </Button>
        </Dropdown>
        <Modal className="reportDesignModal"
          title="编辑选项" visible={this.state.visible}
          onOk={this.handleOkUp} onCancel={this.handleCancel}
        >
          <div className="modal-form-choice">
            <div>
              <span>选项内容</span>
              <span>
                <Input placeholder="请输入选项内容" defaultValue={this.props.designState.addChooice.title} onChange={(e) => {this.props.designState.addChooice.title = e.target.value}} />
              </span>
            </div>
            <div>
              <span>默认结果</span>
              <span>
                <Switch checkedChildren={'是'} unCheckedChildren={'否'} defaultChecked={this.props.designState.addChooice.default} onChange={(checked) => this.props.designState.addChooice.default = checked} />
              </span>
            </div>
          </div>
        </Modal>
        <Modal className="reportDesignModal-delete"
          title="删除选项" visible={this.state.deleteVisible}
          onOk={this.handleDeleteUp} onCancel={this.handleCancel}
        >
          <p>是否删除该选项？</p>
        </Modal>
      </div>
    );
  }
}


@observer
class DesingC extends Component {
  // 提交结果， 没问题
  componentDidMount() {
    let id = parseInt(this.props.params.id, 10);
    this.props.designState.reportId = id;
    const t = (id) => {
      return window.rpc.report.template.getInfoById(id);
    }

    const getInfo = async () => {
      try {
        const f = await t(id);
        // console.log(f);
        this.props.designState.panels = JSON.parse(f.page);
        this.props.designState.title = f.name;
      } catch (err) {
        console.log(err);
      }
    }

    getInfo();
  }

  onSubmit() {
    let page = toJS(this.props.designState.panels);
    let name = this.props.designState.title;
    let id = this.props.designState.reportId;
    // console.log({name,page: JSON.stringify(page)});
    // console.info(JSON.stringify(page));
    if(!name) {
      message.warning('请输入报名名称');
      return ;
    }
    if(!page.length) {
      message.warn('请设计报表');
      return ;
    }
    window.rpc.report.template.setInfoById(id, {name,page: JSON.stringify(page)}).then((res) =>{
      console.log(res);
      if(res) {
        message.success('保存成功');
        setTimeout(() => {
          browserHistory.push('/task/report');
        }, 1000);
      }else {
        message.success(`保存失败，错误：${res}`);
      }
    }, (err) => {
      message.error(`${err}`);
    })
  }

  render() {
    function ge(panel, designState) {
      // console.info(panel);
      if(panel && panel.itemType === '1') {
        return (
          <Panel className={`Panel-Level${panel.level}`} header={panel.title} key={panel.key} style={{ padding: 0 }}>
            <Row gutter={16}>
              <Col span={10}>
                <span style={{marginRight: 6}}>名称</span>
                <span><Input style={{ width: 'calc(100% - 30px)'}} placeholder="请输入项目名称" defaultValue={panel.title} disabled /></span>
              </Col>
              <Col span={6}>
                <span style={{marginRight: 6}}>项目类型</span>
                <span>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </span>
              </Col>
              <Col span={6}>
                <span style={{marginRight: 6}}>选项类型</span>
                <span>
                  <Select defaultValue={panel.checkType} style={{ width: 120 }} disabled>
                    <Option value="1">单选</Option>
                    <Option value="2">多选</Option>
                  </Select>
                </span>
              </Col>
              <Col className="operationGroup" span={2}>
                <EditItemModal designState={designState} addLevel={panel.addLevel} self={panel} />
              </Col>
            <Col span={24}>
              {
                panel.checkType === '1' ? 
                [...panel.chooiceItems].filter(x => x).map((chooiceItem,index) => (<Row key={`${index}`} style={{marginTop: 8}}><Col span={16}><Radio style={radioStyle} checked={chooiceItem.default} value={chooiceItem.key} disabled>{chooiceItem.title}</Radio></Col><Col className="operationGroup" span={8}><EditChoiceModal designState={designState} addLevel={panel.addLevel} self={index} /></Col></Row>)) : 
                [...panel.chooiceItems].filter(x => x).map((chooiceItem, index) => (<Row key={`${index}`} style={{marginTop: 8}}><Col span={16}><Checkbox style={radioStyle} defaultChecked={chooiceItem.default} disabled>{chooiceItem.title}</Checkbox></Col><Col className="operationGroup" span={8}><EditChoiceModal designState={designState} addLevel={panel.addLevel} self={index} /></Col></Row>))
              }
            </Col>
              <Col span={24}>
                <AddChoiceModal designState={designState} addLevel={panel.addLevel} />
              </Col>
            </Row>
          </Panel>
        );
      }else if( panel && panel.itemType === '2') {
        return (
          <Panel className={`Panel-Level${panel.level}`} header={panel.title} key={panel.key} style={{ padding: 0 }}>
            <Row gutter={16}>
              <Col span={10}>
                <span style={{marginRight: 6}}>名称</span>
                <span><Input style={{ width: 'calc(100% - 30px)'}} placeholder="请输入项目名称" defaultValue={panel.title} disabled /></span>
              </Col>
              <Col span={6}>
                <span style={{marginRight: 6}}>项目类型</span>
                <span>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </span>
              </Col>
              <Col span={6}></Col>
              <Col className="operationGroup" span={2}>
                <EditItemModal designState={designState} addLevel={panel.addLevel} self={panel} />
              </Col>
            </Row>
            <Collapse className="insideCollaspse" defaultActiveKey={[...designState.defaultActiveKey]} key={panel.key}>
              {panel.children.map(panel => ge(panel, designState))}
            </Collapse>
            <Row gutter={16}>
              <Col span={24}>
                <AddItemModal designState={designState} addLevel={panel.addLevel} />
              </Col>
            </Row>
          </Panel>
        );
      }
    }
    let panels = toJS(this.props.designState.panels);
    console.info(panels);
    return (
      <div className="ReportDesign" style={{ padding: 0 }}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>任务报表</Link>
          </div>
        </div>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={2} style={{ height: '32px', lineHeight: '32px' }}>
            报表设计:
          </Col>
          <Col span={4}>
            <Input placeholder="请输入报表名称" value={this.props.designState.title} onChange={(e) => {this.props.designState.title = e.target.value;console.log(this.props.designState.title)}} style={{ width:288,height:32 }} />
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={24}>
            <Collapse defaultActiveKey={[...this.props.designState.defaultActiveKey]} style={{ margin: '8px 0' }}>
              {panels.map(panel => ge(panel, this.props.designState))}
            </Collapse>
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0, textAlign: 'center' }}>
          <Col span={24} style={{ margin: '24px 0 0'}}>
            <AddItemModal designState={this.props.designState} addLevel={[0]} />
          </Col>
          <Col span={24} style={{ margin: '16px 0 0', textAlign: 'left' }}>
            <Button type="primary" onClick={this.onSubmit.bind(this)} style={{ backgroundColor: '#00c1de', borderColor: '#00c1de' }}>完成</Button>
            <Button onClick={() =>browserHistory.push('/task/report') } style={{marginLeft: 16}}>返回</Button>
          </Col>
        </Row>
      </div>
    )
  }
}

class EditDesing extends Component {
  render() {
    return (
      <DesingC designState={new designState()} params={this.props.params} />
    )
  }
}


export default EditDesing;