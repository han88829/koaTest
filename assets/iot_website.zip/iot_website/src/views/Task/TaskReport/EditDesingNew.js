/*
 * @Author: Han.beibei 
 * @Date: 2017-06-08 12:56:40 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-12 09:51:38
 */

import React, { Component } from 'react';
import { Collapse, Input, Row, Col, Button, Icon, Select, Radio, Modal, Switch, Checkbox, Cascader, message, Dropdown, Menu } from 'antd';
import { observable, toJS } from 'mobx';
import { Link, browserHistory } from 'react-router';
import { observer } from 'mobx-react';
import '../../Logined/Logined.css';

import edit from '../../../assets/images/task/eQjnbafzZLfqiiH_254330814.png';

const Panel = Collapse.Panel;
const Option = Select.Option;

const radioStyle = {
  display: 'block',
  height: '32px',
  lineHeight: '32px'
};

class designState {
  @observable addItem = { title: '新项目', itemType: '2', checkType: '2', content: '新内容', isImages: false };
  @observable addChooice = { title: '新选项', default: false };
  @observable panels = [];
  @observable newKey = 0;
  @observable defaultActiveKey = Array.from(new Array(100), (item, idx) => `${idx}`);
  @observable parentNode = '';
  @observable editItem = {};
  @observable editChooice = {};
  @observable title = '';
  @observable num = 1;
  @observable addChooiceTime = {};
  @observable displayF = 'none';
  @observable displayS = 'none';
  @observable editChooiceTime = {};
}
@observer
class AddItemModal extends Component {
  state = {
    visible: false,
    disabled: true,
    addItem: { title: '新项目', itemType: '2', checkType: '2', content: '新内容', isImages: false },
    checked: false,
    display: 'none'
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleOkUp = (e) => {
    let panels = toJS(this.props.designState.panels);
    let addLevel = [...this.props.addLevel];
    let parentNode = this.props.designState.parentNode;
    if (parentNode) {
      let temp = parentNode.split('+');
      let last = temp.pop().split('-').map(num => parseInt(num, 10));
      addLevel = last;
    }
    let addLevelLen = addLevel.length;
    // 重新添加newkey清空需重新赋值
    let newKey = this.props.designState.newKey ? this.props.designState.newKey + 1 : panels.length + 1;

    let id = newKey;
    let key = `${newKey}`;
    this.props.designState.newKey = newKey;

    let addItem = { ...this.props.designState.addItem, key, id, chooiceItems: [], default: [1], children: [] };

    switch (addLevelLen) {
      case 1:
        {
          let newAddLevel = [...addLevel, panels.length + 1];
          panels.push({ ...addItem, isImages: this.state.checked, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 1 });
          this.props.designState.panels = panels;
        }
        break;
      case 2:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children.length + 1];
          panels[addLevel[1] - 1].children.push({ ...addItem, isImages: this.state.checked, itemType: '1', addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 2 });
          this.props.designState.panels = panels;
        }
        break;
      case 3:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children.length + 1];
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 3 });
          this.props.designState.panels = panels;
        }
        break;
      case 4:
        {
          // let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.length + 1];
          // panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 4 });
          // this.props.designState.panels = panels;
          message.info("第三级为选项，添加项目请重新选择！")
          console.log(addLevelLen)
        }
        break;
      case 5:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.length + 1];
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 5 });
          this.props.designState.panels = panels;
          console.log(addLevelLen)
        }
        break;
      case 6:
        {
          let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.length + 1];
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 6 });
          this.props.designState.panels = panels;
          console.log(addLevelLen)
        }
        break;
      default:
        console.log('xixi');
        break;
    }
    this.props.designState.parentNode = '';
    this.setState({
      visible: false,
      display: 'none'
    });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  render() {
    const options = [
      {
        label: '根',
        value: '0',
        children: [...this.props.designState.panels]
      }
    ];
    return (
      // 集合项目添加新增
      <div style={{ marginTop: 10 }}>
        <div style={{ display: this.state.display, backgroundColor: '#f5f5f5', height: 35, width: '100%', textAlign: "left", paddingLeft: 20, lineHeight: "35px" }}>
          <span>名称：</span>
          <span style={{ marginLeft: 10 }}>
            <Input style={{ width: 150 }} placeholder="请输入项目名称" defaultValue={this.props.designState.addItem.title} onChange={(e) => { this.props.designState.addItem.title = e.target.value }} />
          </span>
          <span style={{ marginLeft: 10 }}>项目类型：</span>
          <span style={{ marginLeft: 1 }}>
            <Select
              defaultValue={this.props.designState.num === 2 ? "1" : '2'}
              value={this.props.designState.num === 2 ? '1' : this.props.designState.addItem.itemType}
              disabled={this.props.designState.num === 2 ? true : false} style={{ width: 120 }}
              onChange={(value) => {
                this.props.designState.addItem.itemType = value;
                this.setState({
                  disabled: this.props.designState.addItem.itemType === '2'
                })
              }}>
              <Option value="2">集合</Option>
              <Option value="1">项目</Option>
            </Select>
          </span>
          <span style={{ marginLeft: 10 }}>多媒体选择：</span>
          <span style={{ marginLeft: 1 }}>
            <Switch
              checkedChildren={'开'}
              unCheckedChildren={'关'}
              defaultChecked={this.props.designState.addItem.isImages}
              onChange={(checked) => {
                this.setState({ checked });
              }}
            />
          </span>
          <span style={{ marginLeft: 10 }}>选项类型：</span>
          <span style={{ marginLeft: 1 }}>
            <Select
              defaultValue={this.props.designState.addItem.checkType}
              style={{ width: 120 }}
              onChange={(value) => { this.props.designState.addItem.checkType = value }}
              disabled={this.props.designState.num === 2 ? false : this.props.designState.addItem.itemType === '2'}
            >
              <Option value="1">单选</Option>
              <Option value="2">多选</Option>
            </Select>
          </span>
          <span style={{ marginLeft: 10 }}>选择父节点：</span>
          <span style={{ marginLeft: 1 }}>
            <Cascader options={options} onChange={(value) => { this.props.designState.parentNode = value.join('+') }} placeholder="请选择" changeOnSelect />
          </span>
          <Button onClick={() => { this.setState({ display: "none" }); }} style={{ marginLeft: 20, backgroundColor: '#ccc', float: "right", color: '#fff', borderColor: '#ccc', height: 30, marginTop: 3, marginRight: 10 }}>取消</Button>
          <Button type="primary" onClick={this.handleOkUp} style={{ marginLeft: 20, backgroundColor: '#00c1de', borderColor: '#00c1de', float: "right", height: 30, marginTop: 3 }}>保存</Button>
        </div>
        <Button type="dashed"
          onClick={() => {
            this.setState({ display: 'block' });
            let addLevel = [...this.props.addLevel];
            if (addLevel.length === 1) {
              this.props.designState.num = 1;
            } else if (addLevel.length === 2) {
              this.props.designState.num = 2;
            }
          }}
          style={{ width: '100%' }}>
          <Icon type="plus" /> 添加
        </Button>
        {/*Pre-reserved, prudent modification*/}
        <Modal className="reportDesignModal"
          title="新建集合/项目" visible={this.state.visible}
          onCancel={this.handleCancel}
          onOk={this.handleOkUp}
        >
          <div className="modal-form">
            <div>
              <span>名称</span>
              <span>
                <Input placeholder="请输入项目名称" defaultValue={this.props.designState.addItem.title} onChange={(e) => { this.props.designState.addItem.title = e.target.value }} />
              </span>
            </div>
            <div>
              <span>项目类型</span>
              <span>
                <Select defaultValue={this.props.designState.num === 2 ? "1" : this.props.designState.addItem.itemType} disabled={this.props.designState.num === 2 ? true : false} style={{ width: 120 }} onChange={(value) => {
                  this.props.designState.addItem.itemType = value;
                  this.setState({
                    disabled: this.props.designState.addItem.itemType === '2'
                  })
                }}>
                  <Option value="2">集合</Option>
                  <Option value="1">项目</Option>
                </Select>
              </span>
              <span style={{ marginLeft: 80 }}>多媒体选择</span>
              <span>
                <Switch
                  checkedChildren={'开'}
                  unCheckedChildren={'关'}
                  defaultChecked={this.props.designState.addItem.isImages}
                  onChange={(checked) => {
                    this.setState({ checked });
                  }}
                />
              </span>
            </div>
            <div>
              <span>选项类型</span>
              <span>
                <Select defaultValue={this.props.designState.addItem.checkType} style={{ width: 120 }} onChange={(value) => this.props.designState.addItem.checkType = value} disabled={this.props.designState.addItem.itemType === '1' ? false : true}>
                  <Option value="1">单选</Option>
                  <Option value="2">多选</Option>
                </Select>
              </span>
            </div>
            <div>
              <span>选择父节点</span>
              <span>
                <Cascader options={options} onChange={(value) => { this.props.designState.parentNode = value.join('+') }} placeholder="请选择" changeOnSelect />
              </span>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}
@observer
class EditItemModal extends Component {
  state = {
    visible: false,
    deleteVisible: false,
    disabled: true,
    addItem: { title: '新项目', itemType: '2', checkType: '2', content: '新内容' },
    self: { ...this.props.self },
    display: 'none',
    num: 0,
    num1: 0,
    num2: 0,
    num3: 0
  }
  showModal = () => {
    // console.log(this.state.self);
    this.props.designState.editItem = this.state.self;
    this.setState({
      visible: true,
    });
  }

  handleOkUp = (e) => {
    let self = { ...this.props.self };
    let panels = toJS(this.props.designState.panels);
    let formerLevel = [...self.addLevel];
    let addLevel = [...this.props.addLevel];
    let addItem = toJS(this.props.designState.editItem);
    let parentNode = this.props.designState.parentNode;
    let editChooiceTime = toJS(this.props.designState.editChooiceTime)

    if (!this.state.num && !this.state.num1 && !this.state.num2) {
      console.log("没有修改内容！");
      this.setState({ display: 'none' });
      return
    }
    if (parentNode) {
      let temp = parentNode.split('+');
      let last = temp.pop().split('-').map(num => parseInt(num, 10));
      addLevel = last;
      let addLevelLen = addLevel.length;
      if (addLevelLen < 2) {
        this.props.designState.num = 1;
      }
      //删除原先所在位置
      switch (formerLevel.length) {
        case 2:
          {
            panels[formerLevel[1] - 1] = null;
            // this.props.designState.panels = panels;
            // console.log(formerLevel.length)
          }
          break;
        case 3:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1] = null;
            // this.props.designState.panels = panels;
            // console.log(formerLevel.length)
          }
          break;
        case 4:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1] = null;
            // this.props.designState.panels = panels;
            // console.log(formerLevel.length)
          }
          break;
        case 5:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1] = null;
            // this.props.designState.panels = panels;
          }
          break;
        case 6:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1] = null;
            // this.props.designState.panels = panels;
          }
          break;
        case 7:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1].children[formerLevel[6] - 1] = null;
            // this.props.designState.panels = panels;
          }
          break;
        default:
          console.log('愣头青， 递归, 不存在的');
          break;
      }
      switch (addLevelLen) {
        case 1:
          {
            let newAddLevel = [...addLevel, panels.length + 1];
            panels.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 1 });
            this.props.designState.panels = panels;
            console.log('If this section shows, check this code and configure it')
          }
          break;
        case 2:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children.length + 1];
            panels[addLevel[1] - 1].children.push({ ...addItem, itemType: '1', addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 2 });
            this.props.designState.panels = panels;
            console.log('If this section shows, check this code and configure it')
          }
          break;
        case 3:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children.length + 1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 3 });
            this.props.designState.panels = panels;
            console.log('If this section shows, check this code and configure it')
          }
          break;
        case 4:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.length + 1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 4 });
            this.props.designState.panels = panels;
            console.log('If this section shows, check this code and configure it')
          }
          break;
        case 5:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.length + 1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 5 });
            this.props.designState.panels = panels;
            console.log('If this section shows, check this code and configure it')
          }
          break;
        case 6:
          {
            let newAddLevel = [...addLevel, panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.length + 1];
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children.push({ ...addItem, addLevel: newAddLevel, label: addItem.title, value: newAddLevel.join('-'), level: 6 });
            this.props.designState.panels = panels;
            console.log('If this section shows, check this code and configure it')
          }
          break;
        default:
          console.log('xixi');
          break;
      }
    } else {
      // let addLevelLen = addLevel.length;
      //删除原先所在位置
      switch (formerLevel.length) {
        case 2:
          {
            addItem.children = panels[formerLevel[1] - 1].children;
            editChooiceTime.children = panels[formerLevel[1] - 1].children;
            panels[formerLevel[1] - 1] = editChooiceTime;
          }
          break;
        case 3:
          {
            addItem.chooiceItems = panels[formerLevel[1] - 1].children[formerLevel[2] - 1].chooiceItems;
            editChooiceTime.chooiceItems = panels[formerLevel[1] - 1].children[formerLevel[2] - 1].chooiceItems;
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1] = editChooiceTime;
          }
          break;
        case 4:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1] = addItem;
            //this.props.designState.panels = panels;
          }
          break;
        case 5:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
          break;
        case 6:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
          break;
        case 7:
          {
            panels[formerLevel[1] - 1].children[formerLevel[2] - 1].children[formerLevel[3] - 1].children[formerLevel[4] - 1].children[formerLevel[5] - 1].children[formerLevel[6] - 1] = addItem;
            // this.props.designState.panels = panels;
          }
          break;
        default:
          console.log('愣头青， 递归, 不存在的');
          break;
      }
    }

    this.props.designState.panels = panels;
    this.props.designState.parentNode = '';

    this.setState({
      visible: false,
      display: 'none'
    });
  }

  handleDeleteUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let parentNode = this.props.designState.parentNode;
    if (parentNode) {
      let temp = parentNode.split('+');
      let last = temp.pop().split('-').map(num => parseInt(num, 10));
      addLevel = last;
    }
    let addLevelLen = addLevel.length;
    if (addLevelLen < 2) {
      this.props.designState.num = 1;
    }
    let newKey = this.props.designState.newKey + 1;
    this.props.designState.newKey = newKey;

    switch (addLevelLen) {
      case 2:
        {
          panels[addLevel[1] - 1] = null;
          this.props.designState.panels = panels;
          // console.log(addLevelLen)
        }
        break;
      case 3:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1] = null;
          this.props.designState.panels = panels;
          // console.log(addLevelLen)
        }
        break;
      case 4:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1] = null;
          this.props.designState.panels = panels;
        }
        break;
      case 5:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1] = null;
          this.props.designState.panels = panels;
        }
        break;
      case 6:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1] = null;
          this.props.designState.panels = panels;
        }
        break;
      case 7:
        {
          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1] = null;
          this.props.designState.panels = panels;
        }
        break;
      default:
        console.log('愣头青， 递归, 不存在的');
        break;
    }
    this.props.designState.parentNode = '';
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
      deleteVisible: false
    });
  }

  handleMenuClick = (e) => {
    this.props.designState.editItem = this.state.self;
    if (e.key === '1') {
      this.setState({
        // visible: true,
        display: 'block',
        num: 0,
        num1: 0,
        num2: 0
      });

      // 获取当前节点的数据进行显示
      let self = { ...this.props.self };
      let panels = toJS(this.props.designState.panels);
      let formerLevel = [...self.addLevel];
      // let addLevel = [...this.props.addLevel];
      // let addItem = toJS(this.props.designState.editItem);
      // let parentNode = this.props.designState.parentNode;
      switch (formerLevel.length) {
        case 2:
          {
            this.props.designState.editChooiceTime = panels[formerLevel[1] - 1];
            console.log(toJS(this.props.designState.editChooiceTime))
          }
          break;
        case 3:
          {
            this.props.designState.editChooiceTime = panels[formerLevel[1] - 1].children[formerLevel[2] - 1];
            console.log(toJS(this.props.designState.editChooiceTime))
          }
          break;
        default:
          break;
      }
    } else {
      this.setState({
        deleteVisible: true,
      });
    }
  }

  render() {
    const options = [
      {
        label: '根',
        value: '0',
        children: [...this.props.designState.panels]
      }
    ];

    const menu = (
      <Menu onClick={this.handleMenuClick}>
        <Menu.Item key="1">修改</Menu.Item>
        <Menu.Item key="2">删除</Menu.Item>
      </Menu>
    );

    return (
      <div onClick={(e) => { e.stopPropagation(); }}>
        <span style={{ display: this.state.display === 'none' ? "block" : 'none' }}>
          <Dropdown overlay={menu} >
            <Button style={{ marginLeft: 8, border: "none", backgroundColor: "#f5f5f5" }}>
              <img src={edit} alt="编辑" /> <Icon type="down" />
            </Button>
          </Dropdown>
        </span>

        <span style={{ display: this.state.display }}>
          <span>名称：</span>
          <span style={{ marginLeft: 1 }}>
            <Input style={{ width: 150 }} placeholder="请输入项目名称" value={this.props.designState.editChooiceTime.title} onChange={(e) => { this.props.designState.editChooiceTime.title = e.target.value; this.props.designState.editItem.title = e.target.value; this.setState({ num: 1 }); }} />
          </span>
          <span style={{ marginLeft: 15 }}>项目类型：</span>
          <span style={{ marginLeft: 1 }}>
            <Select
              defaultValue={this.props.designState.editChooiceTime.itemType}
              disabled={this.props.designState.editChooiceTime.itemType === '1'}
              style={{ width: 120 }}
              value={this.props.designState.editChooiceTime.itemType}
              onChange={(value) => {
                this.props.designState.editItem.itemType = value;
                this.props.designState.editChooiceTime.itemType = value;
                this.setState({
                  disabled: this.props.designState.editItem.itemType === '2'
                })
              }}>
              <Option value="2">集合</Option>
              <Option value="1">项目</Option>
            </Select>
          </span>
          <span style={{ marginLeft: 10 }}>多媒体选择：</span>
          <span style={{ marginLeft: 1 }}>
            <Switch
              checkedChildren={'开'}
              unCheckedChildren={'关'}
              defaultChecked={this.props.designState.editChooiceTime.isImages}
              checked={this.props.designState.editChooiceTime.isImages}
              onChange={(checked) => {
                this.props.designState.editItem.isImages = checked;
                this.props.designState.editChooiceTime.isImages = checked;
                this.setState({ num1: 1 });
              }}
            />
          </span>
          <span style={{ marginLeft: 15 }}>选项类型：</span>
          <span style={{ marginLeft: 1 }}>
            <Select
              defaultValue={this.props.designState.editChooiceTime.checkType}
              value={this.props.designState.editChooiceTime.checkType}
              style={{ width: 120 }}
              onChange={(value) => {
                this.props.designState.editItem.checkType = value;
                this.props.designState.editChooiceTime.checkType = value;
                this.setState({ num2: 1 });
              }}
              disabled={this.props.designState.editItem.itemType === '2'}
            >
              <Option value="1">单选</Option>
              <Option value="2">多选</Option>
            </Select>
          </span>
          <span style={{ marginLeft: 15 }}>选择父节点：</span>
          <span style={{ marginLeft: 1 }}>
            <Cascader options={options} onChange={(value) => { this.props.designState.parentNode = value.join('+'); }} placeholder="请选择" changeOnSelect />
          </span>
          <Button onClick={() => { this.setState({ display: "none", num: 0, num1: 0, num2: 0 }); }} style={{ marginLeft: 20, backgroundColor: '#ccc', float: "right", color: '#fff', borderColor: '#ccc', height: 30, marginTop: 3 }}>取消</Button>
          <Button type="primary" onClick={this.handleOkUp} style={{ marginLeft: 20, backgroundColor: '#00c1de', borderColor: '#00c1de', float: "right", height: 30, marginTop: 3 }}>保存</Button>
        </span>
        {/*Pre-reserved, prudent modification*/}
        <Modal className="reportDesignModal"
          title="编辑集合/项目" visible={this.state.visible}
          onOk={this.handleOkUp} onCancel={this.handleCancel}
        >
          <div className="modal-form">
            <div>
              <span>名称</span>
              <span>
                <Input placeholder="请输入项目名称" defaultValue={this.props.designState.editItem.title} onChange={(e) => { this.props.designState.editItem.title = e.target.value; console.log(this.props.designState.editItem) }} />
              </span>
            </div>
            <div>
              <span>项目类型</span>
              <span>
                <Select
                  defaultValue={this.props.designState.editItem.itemType}
                  disabled={this.props.designState.editItem.itemType === '1'}
                  style={{ width: 120 }}
                  onChange={(value) => {
                    this.props.designState.editItem.itemType = value;
                    console.log(this.props.designState.editItem);
                    this.setState({
                      disabled: this.props.designState.editItem.itemType === '2'
                    })
                  }}>
                  <Option value="2">集合</Option>
                  <Option value="1">项目</Option>
                </Select>
              </span>
              <span style={{ marginLeft: 80 }}>多媒体选择</span>
              <span>
                <Switch
                  checkedChildren={'开'}
                  unCheckedChildren={'关'}
                  defaultChecked={this.props.designState.editItem.isImages}
                  onChange={(checked) => {
                    this.props.designState.editItem.isImages = checked;
                  }}
                />
              </span>
            </div>
            <div>
              <span>选项类型</span>
              <span>
                <Select defaultValue={this.props.designState.editItem.checkType} style={{ width: 120 }} onChange={(value) => { this.props.designState.editItem.checkType = value; console.log(this.props.designState.editItem) }} disabled={this.props.designState.editItem.itemType === '2'}>
                  <Option value="1">单选</Option>
                  <Option value="2">多选</Option>
                </Select>
              </span>
            </div>
            <div>
              <span>选择父节点</span>
              <span>
                <Cascader options={options} onChange={(value) => { this.props.designState.parentNode = value.join('+'); console.log(this.props.designState.editItem) }} placeholder="请选择" changeOnSelect />
              </span>
            </div>
          </div>
        </Modal>
        <Modal className="reportDesignModal-delete"
          title="删除集合/项目" visible={this.state.deleteVisible}
          onOk={this.handleDeleteUp} onCancel={this.handleCancel}
        >
          <p>确认删除该项？</p>
        </Modal>
      </div>
    );
  }
}
@observer
class AddChoiceModal extends Component {
  state = { visible: false, addChooice: true, display: 'none' }
  showModal = () => {
    // console.log(this.props.designState.addChooice.default)
    let addChooice = toJS(this.props.designState.addChooice.default)
    this.setState({
      visible: true,
      addChooice
    });
  }

  handleOkUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let addLevelLen = addLevel.length;
    let key = `${Math.round(new Date().getTime() * Math.random())}`;
    let addChooice = { ...this.props.designState.addChooice, key };
    if (addLevelLen < 2) {
      this.props.designState.num = 1;
    }
    switch (addLevelLen) {
      case 2:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].checkType === '1') {
              panels[addLevel[1] - 1].chooiceItems = panels[addLevel[1] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
            }
          }

          panels[addLevel[1] - 1].chooiceItems.push({ ...addChooice });
          this.props.designState.panels = panels;
          // console.log(panels)
          // console.log(addLevelLen)
        }
        break;
      case 3:
        {
          let len = panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length;
          for (let i = 0; i < len; i++) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[i] == null) {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.splice(i, 1)
            }
          }
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.push({ ...addChooice });
          this.props.designState.panels = panels;
          // console.log(panels)
          // console.log(addLevelLen)
        }
        break;
      case 4:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.push({ ...addChooice });
          this.props.designState.panels = panels;
        }
        break;
      case 5:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.push({ ...addChooice });
          this.props.designState.panels = panels;
        }
        break;
      case 6:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.push({ ...addChooice });
          this.props.designState.panels = panels;
        }
        break;
      case 7:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.push({ ...addChooice });
          this.props.designState.panels = panels;
        }
        break;
      default:
        console.log('xixi');
        break;
    }


    this.setState({
      visible: false,
      display: 'none'
    });
    // console.log(panels)
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  render() {
    // console.log(this.props.designState.addChooice.default)
    return (
      <div style={{ marginTop: 10 }}>
        <div style={{ display: this.state.display, backgroundColor: '#f5f5f5', height: 35, width: '100%', textAlign: "left", paddingLeft: 20, lineHeight: "35px" }}>
          <span>选项内容：</span>
          <span style={{ marginLeft: 1 }}>
            <Input style={{ width: 150 }} placeholder="请输入选项内容" value={this.props.designState.addChooice.title} defaultValue={this.props.designState.addChooice.title} onChange={(e) => { this.props.designState.addChooice.title = e.target.value }} />
          </span>
          <span style={{ marginLeft: 10 }}>默认结果：</span>
          <span style={{ marginLeft: 1 }}>
            <Switch checkedChildren={'是'} unCheckedChildren={'否'} checked={this.props.designState.addChooice.default} onChange={(checked) => { this.props.designState.addChooice.default = checked }} />
          </span>
          <Button onClick={() => { this.setState({ display: "none" }); }} style={{ marginLeft: 20, backgroundColor: '#ccc', float: "right", color: '#fff', borderColor: '#ccc', height: 30, marginTop: 3, marginRight: 10 }}>取消</Button>
          <Button type="primary" onClick={this.handleOkUp} style={{ marginLeft: 20, backgroundColor: '#00c1de', borderColor: '#00c1de', float: "right", height: 30, marginTop: 3 }}>保存</Button>

        </div>
        <Button type="dashed" onClick={() => { this.setState({ display: 'block' }); }} style={{ width: '100%' }}>
          <Icon type="plus" /> 添加
        </Button>
        {/*Pre-reserved, prudent modification*/}
        <Modal className="reportDesignModal"
          title="新建选项"
          visible={this.state.visible}
          onOk={this.handleOkUp}
          onCancel={this.handleCancel}
        >
          <div className="modal-form-choice" onMouseOver={() => { console.log(this.props.designState.addChooice.title) }}>
            <div>
              <span>选项内容</span>
              <span>
                <Input placeholder="请输入选项内容" value={this.props.designState.addChooice.title} defaultValue={this.props.designState.addChooice.title} onChange={(e) => { this.props.designState.addChooice.title = e.target.value }} />
              </span>
            </div>
            <div>
              <span>默认结果</span>
              <span>
                <Switch checkedChildren={'是'} unCheckedChildren={'否'} defaultChecked={false} onChange={(checked) => { this.props.designState.addChooice.default = checked }} />
              </span>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}
@observer
class EditChoiceModal extends Component {
  state = { visible: false, deleteVisible: false, display: "none", title: null, addChooice: {}, num: 0, num1: 0, default: false, }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  componentDidMount() {

  }

  handleOkUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let addLevelLen = addLevel.length;
    if (addLevelLen < 2) {
      this.props.designState.num = 1;
    }
    let key = `${Math.round(new Date().getTime() * Math.random())}`;
    let addChooice = { ...this.props.designState.addChooice, key };
    // console.log(addChooice)
    let self = this.props.self;
    // console.info(addChooice);
    if (this.state.num || this.state.num1) {
      switch (addLevelLen) {
        case 2:
          {
            if (addChooice.default) {
              if (panels[addLevel[1] - 1].checkType === '1') {
                panels[addLevel[1] - 1].default = [panels[addLevel[1] - 1].chooiceItems.length + 1];
                panels[addLevel[1] - 1].chooiceItems = panels[addLevel[1] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
              } else {
                panels[addLevel[1] - 1].default.push(panels[addLevel[1] - 1].chooiceItems.length + 1);
              }
            }
            panels[addLevel[1] - 1].chooiceItems[self] = { ...addChooice };
            if (!this.state.num) {
              panels[addLevel[1] - 1].chooiceItems[self].title = this.props.designState.addChooiceTime.title;
            }
            if (!this.state.num1) {
              panels[addLevel[1] - 1].chooiceItems[self].default = this.props.designState.addChooiceTime.default;
            }
            this.props.designState.panels = panels;
            // console.log(toJS(this.props.designState.panels))
          }
          break;
        case 3:
          {
            if (addChooice.default) {
              if (panels[addLevel[1] - 1].children[addLevel[2] - 1].checkType === '1') {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1];
                panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems = panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.map(chooiceItem => ({ ...chooiceItem, default: false }));
              } else {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1);
              }
            }
            panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self] = { ...addChooice };
            if (!this.state.num) {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self].title = this.props.designState.addChooiceTime.title;
            }
            if (!this.state.num1) {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self].default = this.props.designState.addChooiceTime.default;
            }
            this.props.designState.panels = panels;
            // console.log(toJS(this.props.designState.panels))
          }
          break;
        case 4:
          {
            if (addChooice.default) {
              if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].checkType === '1') {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1];
              } else {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1);
              }
            }
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems[self] = { ...addChooice };
            this.props.designState.panels = panels;
            // console.log(addLevelLen)
          }
          break;
        case 5:
          {
            if (addChooice.default) {
              if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].checkType === '1') {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1];
              } else {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1);
              }
            }
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems[self] = { ...addChooice };
            this.props.designState.panels = panels;
          }
          break;
        case 6:
          {
            if (addChooice.default) {
              if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].checkType === '1') {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1];
              } else {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1);
              }
            }
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems[self] = { ...addChooice };
            this.props.designState.panels = panels;
          }
          break;
        case 7:
          {
            if (addChooice.default) {
              if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].checkType === '1') {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1];
              } else {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1);
              }
            }
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems[self] = { ...addChooice };
            this.props.designState.panels = panels;
          }
          break;
        default:
          console.log('xixi');
          break;
      }
    } else {
      console.log('没有修改任何内容！')
    }

    this.setState({
      visible: false,
      display: "none",
      num: 0
    });
  }
  handleDeleteUp = (e) => {
    let panels = [...this.props.designState.panels];
    let addLevel = [...this.props.addLevel];
    let addLevelLen = addLevel.length;
    if (addLevelLen < 2) {
      this.props.designState.num = 1;
    }
    let key = `key-${Math.round(new Date().getTime() * Math.random())}`;
    let addChooice = { ...this.props.designState.addChooice, key };
    let self = this.props.self;
    // console.log(addLevelLen);
    // console.log(self)

    switch (addLevelLen) {
      case 2:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].checkType === '1') {
              panels[addLevel[1] - 1].default = [panels[addLevel[1] - 1].chooiceItems.length + 1];
            } else {
              panels[addLevel[1] - 1].default.push(panels[addLevel[1] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].chooiceItems[self] = null;
          this.props.designState.panels = panels;
          // console.log(addLevelLen)
        }
        break;
      case 3:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1];
            } else {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length + 1);
            }
          }
          let len = panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length;
          for (let i = 0; i < len; i++) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[i] === null) {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.splice(i, 1)
            }
          }
          // let num = len - panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems.length;
          panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self] = null;
          this.props.designState.panels = panels;
          // console.log(addLevelLen)
        }
        break;
      case 4:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1];
            } else {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems[self] = null;
          this.props.designState.panels = panels;
        }
        break;
      case 5:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1];
            } else {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].chooiceItems[self] = null;
          this.props.designState.panels = panels;
        }
        break;
      case 6:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1];
            } else {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].chooiceItems[self] = null;
          this.props.designState.panels = panels;
        }
        break;
      case 7:
        {
          if (addChooice.default) {
            if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].checkType === '1') {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1];
            } else {
              panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems.length + 1);
            }
          }

          panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].children[addLevel[4] - 1].children[addLevel[5] - 1].children[addLevel[6] - 1].chooiceItems[self] = null;
          this.props.designState.panels = panels;
        }
        break;
      default:
        console.log('xixi');
        break;
    }

    this.setState({
      visible: false,
      deleteVisible: false
    });
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
      deleteVisible: false
    });
  }
  handleMenuClick = (e) => {
    if (e.key === '1') {
      this.setState({
        // visible: true,
        display: "block"
      });
      let panels = [...this.props.designState.panels];
      let addLevel = [...this.props.addLevel];
      let addLevelLen = addLevel.length;
      let key = `key-${Math.round(new Date().getTime() * Math.random())}`;
      let addChooice = { ...this.props.designState.addChooice, key };
      let self = this.props.self;
      switch (addLevelLen) {
        case 2:
          {
            this.props.designState.addChooiceTime = panels[addLevel[1] - 1].chooiceItems[self];
            // Stores raw data for canceling recovery
            this.setState({ title: panels[addLevel[1] - 1].chooiceItems[self].title, default: panels[addLevel[1] - 1].chooiceItems[self].default });
            // console.log(this.props.designState.addChooiceTime)
          }
          break;
        case 3:
          {
            this.props.designState.addChooiceTime = panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self];
            // Stores raw data for canceling recovery
            this.setState({ title: panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self].title, default: panels[addLevel[1] - 1].children[addLevel[2] - 1].chooiceItems[self].default });
            // console.log(this.props.designState.addChooiceTime)
          }
          break;
        case 4:
          {
            if (addChooice.default) {
              if (panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].checkType === '1') {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default = [panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1];
              } else {
                panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].default.push(panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems.length + 1);
              }
            }
            panels[addLevel[1] - 1].children[addLevel[2] - 1].children[addLevel[3] - 1].chooiceItems[self] = { ...addChooice };
            this.props.designState.panels = panels;
          }
          break;
        default:
          console.log('xixi');
          break;
      }
    } else {
      this.setState({
        deleteVisible: true,
      });
    }
  }
  render() {
    const menu = (
      <Menu onClick={this.handleMenuClick}>
        <Menu.Item key="1">修改</Menu.Item>
        <Menu.Item key="2">删除</Menu.Item>
      </Menu>
    );
    return (
      // 修改自动更新，获取title初始值，取消赋值
      <div style={{ display: 'inlineFlex' }}>
        <span style={{ display: this.state.display === 'none' ? 'block' : "none" }}>
          <Dropdown overlay={menu}>
            <Button style={{ marginLeft: 8, border: "none", backgroundColor: "#f5f5f5" }}>
              <img src={edit} alt="编辑" /> <Icon type="down" />
            </Button>
          </Dropdown>
        </span>

        <span style={{ display: this.state.display }}>
          <span>选项内容：</span>
          <span style={{ marginLeft: 15 }}>
            <Input style={{ width: 150 }} placeholder="请输入选项内容" value={this.props.designState.addChooiceTime.title} onChange={(e) => { this.props.designState.addChooiceTime.title = e.target.value; this.props.designState.addChooice.title = e.target.value; this.setState({ num: 1 }); console.log(this.props.designState.addChooiceTime.title) }} />
          </span>
          <span style={{ marginLeft: 15 }}>默认结果：</span>
          <span style={{ marginLeft: 15 }}>
            <Switch checkedChildren={'是'} unCheckedChildren={'否'} checked={this.props.designState.addChooiceTime.default} onChange={(checked) => { this.props.designState.addChooiceTime.default = checked; this.props.designState.addChooice.default = checked; this.setState({ num1: 1 }); }} />
          </span>
          <Button onClick={() => { this.setState({ display: "none" }); this.props.designState.addChooiceTime.title = this.state.title; this.props.designState.addChooiceTime.default = this.state.default; }} style={{ marginLeft: 20, marginRight: 10, backgroundColor: '#ccc', float: "right", color: '#fff', borderColor: '#ccc', height: 30, marginTop: 1 }}>取消</Button>
          <Button type="primary" onClick={this.handleOkUp} style={{ marginLeft: 20, backgroundColor: '#00c1de', borderColor: '#00c1de', float: "right", height: 30, marginTop: 1 }}>保存</Button>
        </span>
        {/*Pre-reserved, prudent modification*/}
        <Modal className="reportDesignModal"
          title="编辑选项" visible={this.state.visible}
          onOk={this.handleOkUp} onCancel={this.handleCancel}
        >
          <div className="modal-form-choice">
            <div>
              <span>选项内容</span>
              <span>
                <Input style={{ width: 150 }} placeholder="请输入选项内容" defaultValue={this.props.designState.addChooice.title} onChange={(e) => { this.props.designState.addChooice.title = e.target.value }} />
              </span>
            </div>
            <div>
              <span>默认结果</span>
              <span>
                <Switch checkedChildren={'是'} unCheckedChildren={'否'} defaultChecked={this.props.designState.addChooice.default} onChange={(checked) => this.props.designState.addChooice.default = checked} />
              </span>
            </div>
          </div>
        </Modal>
        <Modal className="reportDesignModal-delete"
          title="删除选项" visible={this.state.deleteVisible}
          onOk={this.handleDeleteUp} onCancel={this.handleCancel}
        >
          <p>是否删除该选项？</p>
        </Modal>
      </div>
    );
  }
}


@observer
class DesingC extends Component {
  // 提交结果， 没问题
  componentDidMount() {
    let id = parseInt(this.props.params.id, 10);
    this.props.designState.reportId = id;
    const t = (id) => {
      return window.rpc.report.template.getInfoById(id);
    }

    const getInfo = async () => {
      try {
        const f = await t(id);
        this.props.designState.panels = JSON.parse(f.page);
        this.props.designState.title = f.name;
      } catch (err) {
        console.log(err);
      }
    }

    getInfo();
  }

  onSubmit() {
    let page = toJS(this.props.designState.panels);
    let name = this.props.designState.title;
    let id = this.props.designState.reportId;
    if (!name) {
      message.warning('请输入报名名称');
      return;
    }
    if (page.length < 1) {
      message.warn('请设计报表');
      return;
    }
    window.rpc.report.template.setInfoById(id, { name, page: JSON.stringify(page) }).then((res) => {
      if (res) {
        message.success('保存成功');
        browserHistory.push('/task/report');
      } else {
        message.success(`保存失败，错误：${res}`);
      }
    }, (err) => {
      message.error(`${err}`);
    })
  }

  render() {
    function ge(panel, designState) {
      if (panel && panel.itemType === '1') {
        return (
          <Panel className={`Panel-Level${panel.level}`} header={<div><span>{panel.title}</span><span style={{ float: "right", marginRight: 20, lineHeight: "35px" }}><EditItemModal designState={designState} addLevel={panel.addLevel} self={panel} /></span></div>} key={panel.key} style={{ padding: 0 }}>
            <Row gutter={16}>
              {/*Pre-reserved, prudent modification*/}
              {/*<Col span={10}>
                <span style={{ marginRight: 6 }}>名称</span>
                <span><Input style={{ width: 'calc(100% - 30px)' }} placeholder="请输入项目名称" defaultValue={panel.title} disabled /></span>
              </Col>
              <Col span={6}>
                <span style={{ marginRight: 6 }}>项目类型</span>
                <span>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </span>
              </Col>
              <Col span={6}>
                <span style={{ marginRight: 6 }}>选项类型</span>
                <span>
                  <Select defaultValue={panel.checkType} style={{ width: 120 }} disabled>
                    <Option value="1">单选</Option>
                    <Option value="2">多选</Option>
                  </Select>
                </span>
              </Col>*/}
              {/*<Col className="operationGroup" span={2} style={{position:"absolute",top:0,right:50}}>
                <EditItemModal designState={designState} addLevel={panel.addLevel} self={panel} />
              </Col>*/}
              <Col span={24}>
                {
                  panel.checkType === '1' ?
                    [...panel.chooiceItems].filter(x => x).map((chooiceItem, index) => (<Row key={`${index}`} style={{ marginTop: 8 }}><Col span={10}><Radio style={radioStyle} checked={chooiceItem.default} value={chooiceItem.key} disabled>{chooiceItem.title}</Radio></Col><Col className="operationGroup" span={14}><EditChoiceModal designState={designState} addLevel={panel.addLevel} self={index} /></Col></Row>)) :
                    [...panel.chooiceItems].filter(x => x).map((chooiceItem, index) => (<Row key={`${index}`} style={{ marginTop: 8 }}><Col span={10}><Checkbox style={radioStyle} checked={chooiceItem.default} disabled>{chooiceItem.title}</Checkbox></Col><Col className="operationGroup" span={14}><EditChoiceModal designState={designState} addLevel={panel.addLevel} self={index} /></Col></Row>))
                }
              </Col>
              <Col span={24}>
                <AddChoiceModal designState={designState} addLevel={panel.addLevel} />
              </Col>
            </Row>
          </Panel>
        );
      } else if (panel && panel.itemType === '2') {
        return (
          <Panel className={`Panel-Level${panel.level}`} header={<div><span>{panel.title}</span><span style={{ float: "right", marginRight: 20, lineHeight: "35px" }}><EditItemModal designState={designState} addLevel={panel.addLevel} self={panel} /></span></div>} key={panel.key} style={{ padding: 0 }}>
            {/*Pre-reserved, prudent modification*/}
            {/*<Row gutter={16}>
              <Col span={10}>
                <span style={{ marginRight: 6 }}>名称</span>
                <span><Input style={{ width: 'calc(100% - 30px)' }} placeholder="请输入项目名称" defaultValue={panel.title} disabled /></span>
              </Col>
              <Col span={6}>
                <span style={{ marginRight: 6 }}>项目类型</span>
                <span>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </span>
              </Col>
              <Col span={6}></Col>
              <Col className="operationGroup" span={2}>
                <EditItemModal designState={designState} addLevel={panel.addLevel} self={panel} />
              </Col>
            </Row>*/}
            <Collapse className="insideCollaspse" defaultActiveKey={[...designState.defaultActiveKey]} key={panel.key}>
              {panel.children.map(panel => ge(panel, designState))}
            </Collapse>
            <Row gutter={16}>
              <Col span={24}>
                <AddItemModal designState={designState} addLevel={panel.addLevel} />
              </Col>
            </Row>
          </Panel>
        );
      }
    }
    let panels = toJS(this.props.designState.panels);
    return (
      <div className="ReportDesign" style={{ padding: 0 }}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>任务报表</Link>
          </div>
        </div>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={2} style={{ height: '32px', lineHeight: '32px' }}>
            报表设计:
          </Col>
          <Col span={4}>
            <Input placeholder="请输入报表名称" value={this.props.designState.title} onChange={(e) => { this.props.designState.title = e.target.value }} style={{ width: 288, height: 32 }} />
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={24}>
            <Collapse defaultActiveKey={[...this.props.designState.defaultActiveKey]} style={{ margin: '8px 0' }}>
              {panels.map(panel => ge(panel, this.props.designState))}
            </Collapse>
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0, textAlign: 'center' }}>
          <Col span={24} style={{ margin: '24px 0 0' }}>
            <AddItemModal designState={this.props.designState} addLevel={[0]} />
          </Col>
          <Col span={24} style={{ margin: '16px 0 0', textAlign: 'left' }}>
            <Button type="primary" onClick={this.onSubmit.bind(this)} style={{ backgroundColor: '#00c1de', borderColor: '#00c1de' }}>完成</Button>
            <Button onClick={() => { browserHistory.push('/task/report') }} style={{ marginLeft: 20, backgroundColor: '#ccc', color: '#fff', borderColor: '#ccc' }}>取消</Button>
          </Col>
        </Row>
      </div >
    )
  }
}

class EditDesingNew extends Component {
  render() {
    return (
      <DesingC designState={new designState()} params={this.props.params} />
    )
  }
}

export default EditDesingNew;