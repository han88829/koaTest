/*
 * @Author: lai.haibo 
 * @Date: 2017-03-24 11:15:25 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-08 12:55:36
 */

import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Popconfirm } from 'antd';
import moment from 'moment';
import listStore from '../listStore';
import './report.css';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const { genderList, levelList } = listStore;
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      select: [],
      selectIdOne: null,
      number: null,
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
  }
  componentDidUpdate(prevProps, prevState) {
  }

  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['createTime'];
        const rangeValueLast = fieldsValue['lastTime'];
        const name = fieldsValue['name'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (rangeValue) {
          values = { ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        if (rangeValueLast) {
          values = { ...values, lastTime: [new Date(rangeValueLast[0].format('YYYY-MM-DD')), new Date(rangeValueLast[1].format('YYYY-MM-DD'))] }
        }

        window.rpc.report.template.getArrayBriefByContainer(values, 0, 0).then((res) => {
          message.info(`共搜索到${res.length}条数据`);
          this.props.appState.tableData = res.map(report => ({ ...report, key: report.id, lastUserName: report.lastUserName ? report.lastUserName : report.userName, createTime: moment(report.createTime).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(report.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let groupownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let groupNames = JSON.parse(sessionStorage.getItem('groupNames')) || [];
    let levelChildren = [];
    let groupIdChildren = [];
    let ownerIdChildren = [];
    let genderChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of groupownerNames) {
      if (value && value.id) {
        ownerIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of groupNames) {
      if (value && value.id) {
        groupIdChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < genderList.length; i++) {
      genderChildren.push(<Option key={`${i}`}>{genderList[i]}</Option>)
    }

    return (
      <Form layout='inline' style={{ margin: 0 }}>
        <Row gutter={16}>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={7} key={2}>
            <FormItem label={`创建日期`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={7} key={3}>
            <FormItem label={`最后操作日期`}>
              {getFieldDecorator(`lastTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={2} key={7}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);


const TaskRulesC = observer(class TaskRulesC extends Component {
  componentDidMount() {
    const getInfo = () => {
      return window.rpc.report.template.getArrayBriefByContainer({}, 0, 0);
    }

    const init = async () => {
      try {
        const result = await getInfo();
        this.props.appState.tableData = result.map(report => ({ ...report, key: report.id, lastUserName: report.lastUserName ? report.lastUserName : report.userName, createTime: moment(report.createTime).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(report.lastTime).format('YYYY-MM-DD HH:mm:ss') }));

      } catch (err) {
        console.log(err);
      }
    }

    init();
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {

    });
  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
  };
  handleChange = (pagination, filters, sorter) => {
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }
  //更多操作选择
  handlemore = (value) => {
    this.props.appState.number = value;
  }
  //批量操作
  handleBatch = () => {
    if (this.props.appState.select.length !== 0) {
      if (this.props.appState.number) {
        let data = [...this.props.appState.select];
        window.rpc.report.template.removeByArrayId(data).then((res) => {
          message.success('批量删除成功');
          window.rpc.report.template.getArrayBriefByContainer({}, 0, 0).then((res) => {
            this.props.appState.tableData = res.map(report => ({ ...report, key: report.id, lastUserName: report.lastUserName ? report.lastUserName : report.userName, createTime: moment(report.createTime).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(report.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
          })
        }, (err) => {
          console.log(err);
        })
      } else {
        message.info("请选择操作！")
      }
    } else {
      message.info("请选择报表！")
    }
  }
  deleteReport = (id) => {
    window.rpc.report.template.removeById(id).then((res) => {
      message.success('删除成功');
      window.rpc.report.template.getArrayBriefByContainer({}, 0, 0).then((res) => {
        this.props.appState.tableData = res.map(report => ({ ...report, key: report.id, lastUserName: report.lastUserName ? report.lastUserName : report.userName, createTime: moment(report.createTime).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(report.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
      })
    }, (err) => {
      console.log(err);
    })
  }
  confirm = (id) => {
    this.deleteReport(id);
  }

  cancel() {
    message.error('已取消');
  }
  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '编号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '名称',
      dataIndex: 'name',
      key: 'name'
    },
    { title: '创建日期', dataIndex: 'createTime', key: 'createTime' },
    { title: '创建者', dataIndex: 'userName', key: 'userName' },
    { title: '最后操作日期', dataIndex: 'lastTime', key: 'lastTime' },
    { title: '最后操作者', dataIndex: 'lastUserName', key: 'lastUserName' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/task/report/info/${record.id}`}>查看</Link>
          <span className="ant-divider" />
          <Link to={`/task/report/edit/${record.id}`}>编辑</Link>
          <span className="ant-divider" />
          <Popconfirm title="确认删除此任务报表模板?" onConfirm={() => this.confirm(record.id)} onCancel={this.cancel} okText="是" cancelText="否">
            <a href="#">删除</a>
          </Popconfirm>
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];
    const pagination = {
      total: data.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        // console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        // console.log('Current: ', current);
      },
    };

    //表格单选框设置
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        this.props.appState.select = selectedRowKeys;
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
        this.props.appState.selectIdOne = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (

      <div className="ConcenHistory" style={{ padding: 0 }}>
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>任务报表</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={() => browserHistory.push(`/task/design`)}>新增报表</Button>
            <Button style={{ float: 'left', background: '#d9dee4', color: '#373e41', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.handleBatch} >批量操作</Button>
            <div style={{ marginLeft: 5, float: 'left', width: 110, height: 32, background: '#d9dee4' }} className='select-small'>
              <Select
                showSearch
                style={{ width: 100, height: 32, color: '#373e41', fontSize: '0.875rem' }}
                id="select"
                placeholder="更多操作"

                optionFilterProp="children"
                onChange={this.handlemore}
                filterOption={(input, option) => option.props.value.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                {/*<Option value="1">启用</Option>
                <Option value="2">停用</Option>*/}
                <Option value="3">删除</Option>
              </Select>
            </div>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0', marginTop: 10 }}>
          <Col span={24}>
            <Table
              bordered
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class TaskReport extends Component {
  render() {
    return (
      <TaskRulesC appState={new appState()} />
    )
  }
}

export default TaskReport;