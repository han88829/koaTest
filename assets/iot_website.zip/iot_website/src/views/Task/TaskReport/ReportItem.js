import React, { Component } from 'react';
import { Menu, Dropdown, Button, Icon, message } from 'antd';
import './reportItem.css';

function handleButtonClick(e) {
  message.info('Click on left button.');
  console.log('click left button', e);
}

function handleMenuClick(e) {
  message.info('Click on menu item.');
  console.log('click', e);
}

const menu = (
  <Menu onClick={handleMenuClick}>
    <Menu.Item key="1">编辑</Menu.Item>
    <Menu.Item key="2">删除</Menu.Item>
  </Menu>
);

class ReportItem extends Component {
  state = { ...this.props.panel, bodyshow: true }
  
  componentWillMount() {
    console.log(this.props.panel,this.props.designState)
  }

  closeBody() {
    console.log(this.state.bodyshow);
    // this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))
    // this.setState(prevState => ({bodyshow:!prevState.bodyshow}));
  }
  
  render() {
    return (
      <div className="ReportItem">
        <div className="ReportItem-title">
          <div className="ReportItem-title-show" onClick={this.state.closeBody}>
            <span>项目名称：{this.state.title}</span>
            <span>
              <Dropdown overlay={menu}>
                <Button>
                  Button <Icon type="down" />
                </Button>
              </Dropdown>
            </span>
          </div>
          <div className="ReportItem-title-edit"></div>
        </div>
        <div className="ReportItem-body" style={{ display: this.state.bodyshow ? 'block' : 'none' }}>
          <div className="ReportItem-body-show"></div>
          <div className="ReportItem-body-edit"></div>
        </div>
      </div>
    );
  }
}

export default ReportItem;