import React, { Component } from 'react';
import { Collapse, Input, Row, Col, Button, Select, Radio, Checkbox } from 'antd';
import { observable, toJS } from 'mobx';
import { observer } from 'mobx-react';
import { Link, browserHistory } from 'react-router';
import './report.css';

const Panel = Collapse.Panel;
const RadioGroup = Radio.Group;
const Option = Select.Option;
// const CheckboxGroup = Checkbox.Group;

function callback(key) {
  // console.log(new Date().getTime());
}

const radioStyle = {
  display: 'block',
  height: '32px',
  lineHeight: '32px',
};

class designState {
  @observable addItem = {  title: '新项目', itemType:'2', checkType: '2',content: '新内容'};
  @observable addChooice = { title: '新选项', default: false };
  @observable panels = [];
  @observable newKey = 0;
  @observable defaultActiveKey = Array.from(new Array(100), (item, idx) => `${idx}`);
  @observable parentNode = '';
  @observable editItem = {};
  @observable editChooice = {};
  @observable title = '';
}


@observer
class DesingC extends Component {
  // constructor(props) {
  //   super(props);
  //   const panels = [
  //     { title: '项目1', content: '内容1', key: '1' },
  //     { title: '项目2', content: '内容2', key: '2' }
  //   ];
  //   this.state = {
  //     panels
  //   };
  // };
  componentWillMount() {
    // console.info(this.props.designState)

    const t = () => {
      return new Promise((reslove, reject) => {
        setTimeout(() => {
          reslove('xixi');
        }, 2000);
      })
    }

    const test = async () => {
      const f = await t();
      console.log(f);
      console.log(new Date().getTime());
    }

    test();
  };

  componentDidMount() {
    let id = parseInt(this.props.params.id, 10);

    const t = (id) => {
      return window.rpc.report.template.getInfoById(id);
    }

    const getInfo = async () => {
      try {
        const f = await t(id);
        this.props.designState.panels = JSON.parse(f.page);
        this.props.designState.title = f.name;
      } catch (err) {
        console.log(err);
      }
    }

    getInfo();
  }
  
  onSubmit() {
    let page = toJS(this.props.designState.panels);
    let name = this.props.designState.title;
    // console.log({name,page: JSON.stringify(page)});
    // console.info(JSON.stringify(page));
    window.rpc.report.template.create({name,page: JSON.stringify(page)}).then((res) =>{
      console.log(res);
    }, (err) => {
      console.log(err);
    })
  }
  render() {
    // function handleMenuClick(e) {
    //   console.log('click', e);
    // }

    function ge(panel, designState) {
      // console.info(panel.items ? panel.items.length : 0);
      if(panel.itemType === '1') {
        // console.log(panel);
        return (
          <Panel className={`Panel-Level${panel.level}`} header={panel.title} key={panel.key} style={{ padding: 0 }}>
            <Row gutter={16} style={{padding: 16}}>
              <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>名称:</Col>
              <Col span={4}><Input placeholder="请输入项目名称" defaultValue={panel.title} disabled /></Col>
              <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>项目类型:</Col>
              <Col span={4}>
                <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                  <Option value="1">项目</Option>
                  <Option value="2">集合</Option>
                </Select>
              </Col>
              {panel.itemType === '1' ? <div>
                <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>选项类型:</Col>
                  <Col span={4}>
                    <Select defaultValue={panel.checkType} style={{ width: 120 }} disabled>
                      <Option value="1">单选</Option>
                      <Option value="2">多选</Option>
                    </Select>
                  </Col>
                </div> : ''}
            </Row>
            <div className="chooiceItems" style={{marginTop: 12}}>
              {do {
                if(panel.chooiceItems.length !== 0 ) { 
                  panel.checkType === '1' ? 
                  <RadioGroup style={{ display: 'block' }}>{[...panel.chooiceItems].filter(x => x).map((chooiceItem,index) => (<Row><Col span={16}><Radio key={`key-${Math.round(new Date().getTime() * Math.random())}-${index}`} style={radioStyle} checked={chooiceItem.default} value={chooiceItem.key} disabled>{chooiceItem.title}</Radio></Col></Row>))}</RadioGroup> : 
                  <div>{[...panel.chooiceItems].filter(x => x).map((chooiceItem, index) => (<Row><Col span={16}><Checkbox style={radioStyle} key={`key-${Math.round(new Date().getTime() * Math.random())}-${index}`} defaultChecked={chooiceItem.default} disabled>{chooiceItem.title}</Checkbox></Col></Row>))}</div>
                }
              }}
            </div>
          </Panel>
        );
      }else if(panel.itemType === '2') {
        if(panel.children.length === 0) {
          return (
            <Panel className={`Panel-Level${panel.level}`} header={panel.title} key={panel.key} style={{padding: 0}}>
              <Row gutter={16} style={{padding: 16}}>
                <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>名称:</Col>
                <Col span={4}><Input placeholder="请输入项目名称" defaultValue={panel.title} disabled /></Col>
                <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>项目类型:</Col>
                <Col span={4}>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </Col>
                {panel.itemType === '1' ? <div>
                  <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>选项类型:</Col>
                    <Col span={4}>
                      <Select defaultValue={panel.checkType} style={{ width: 120 }} disabled>
                        <Option value="1">单选</Option>
                        <Option value="2">多选</Option>
                      </Select>
                    </Col>
                  </div> : ''}
              </Row>
            </Panel>
          );
        }else {
          return (
            <Panel className={`Panel-Level${panel.level}`} header={panel.title} key={panel.key} style={{padding: 0}}>
              <Row gutter={16}>
                <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>名称:</Col>
                <Col span={4}><Input placeholder="请输入项目名称" defaultValue={panel.title} disabled /></Col>
                <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>项目类型:</Col>
                <Col span={4}>
                  <Select defaultValue={panel.itemType} style={{ width: 120 }} disabled>
                    <Option value="1">项目</Option>
                    <Option value="2">集合</Option>
                  </Select>
                </Col>
                {panel.itemType === '1' ? <div>
                  <Col span={2} style={{ height: '28px', lineHeight: '28px' }}>选项类型:</Col>
                    <Col span={4}>
                      <Select defaultValue={panel.checkType} style={{ width: 120 }} disabled>
                        <Option value="1">单选</Option>
                        <Option value="2">多选</Option>
                      </Select>
                    </Col>
                  </div> : ''}
              </Row>
              <Collapse defaultActiveKey={[...designState.defaultActiveKey]} key={panel.key} style={{ margin: 8 }}>
                {[...panel.children].map(panel => ge({...panel}, designState))}
              </Collapse>
            </Panel>
          );
        }
      }
    }

    let panels = [...this.props.designState.panels];
    // console.log([...this.props.designState.panels].map(panel => panel.key));
  

    return (
      <div className="ReportDesign" style={{ padding: 0 }}>
        <div style={{ fontSize: '0.75em', height: 35, paddingBottom: '1.125em', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>任务报表</Link>
          </div>
        </div>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={2} style={{ height: '32px', lineHeight: '32px' }}>
            报表设计:
          </Col>
          <Col span={4}>
            <Input placeholder="请输入报表名称" value={this.props.designState.title} onChange={(e) => {this.props.designState.title = e.target.value}} disabled style={{ width:288,height:32 }} />
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0 }}>
          <Col span={24}>
            <Collapse bordered={false} defaultActiveKey={[...this.props.designState.defaultActiveKey]} onChange={callback} style={{ margin: '8px 0' }}>
              {panels.map(panel => ge({...panel}, this.props.designState))}
            </Collapse>
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: 0, textAlign: 'center' }}>
          <Col span={24} style={{ margin: '16px 0 0', textAlign: 'left' }}>
            <Button type="primary" onClick={() =>browserHistory.push('/task/report') }>返回</Button>
          </Col>
        </Row>
      </div>
    )
  }
}

class Detail extends Component {
  render() {
    return (
      <DesingC designState={new designState()} params={this.props.params} />
    )
  }
}


export default Detail;