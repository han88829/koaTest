const listOrgStore = {
  dStateList: ['未知', '合格', '不合格'],
  rStateList: ['/','未知', '合格', '不合格'],
  networkModeList: ['/','网关', '4G', 'GSM'],
  patrolTypeList: ['/','巡查', '保养', '检测'],
  patrolStateList: ['/','巡查', '保养', '检测'],
  warningType: ['/','烟感','测温设备','灭火器'],
  resultsType: ['/','测试','已修复','已报警'],
  armtypeList: ['/','测试','火情','短路'],
  ResultState:['/','已处理','误报'],
  sexList: ['/','男','女'],
}

export default listBuildStore;