import React, { Component } from 'react';
import { Tabs,Menu, Icon,Card,Row, Col, Button, Table} from 'antd';
import { Link } from 'react-router';

import "./containers/Building.css";
import BuildPhoteOne from '../../../assets/images/build/u630.jpg'
import BuildTree from './containers/BuildTree';
import BuildAlarm from './containers/BuildAlarm';
import Buildinspection from './containers/Buildinspection';

const TabPane = Tabs.TabPane;

function callback(key) {
  console.log(key);
}

class BuildMapMonitore extends Component {
  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
    // point.lng
    // point.lat
  }
  componentWillMount() {
    
     
  }
  
  componentDidMount() {
    function init() {
      var map = new window.BMap.Map("allmap");            // 创建Map实例
      var point = new window.BMap.Point(121.63049, 29.993947); // 创建点坐标
      map.centerAndZoom(point,14);                 
      map.enableScrollWheelZoom();                 //启用滚轮放大缩小

      var top_left_control = new window.BMap.ScaleControl({anchor: 'BMAP_ANCHOR_TOP_LEFT'});// 左上角，添加比例尺
	    var top_left_navigation = new window.BMap.NavigationControl();  //左上角，添加默认缩放平移控件
	    // var top_right_navigation = new window.BMap.NavigationControl({anchor: 'BMAP_ANCHOR_TOP_RIGHT', type: 'BMAP_NAVIGATION_CONTROL_SMALL'}); //右上角，仅包含平移和缩放按钮
      
            //添加控件和比例尺
      function add_control(){
        map.addControl(top_left_control);        
        map.addControl(top_left_navigation);     
        // map.addControl(top_right_navigation);    
      }
      

      var marker = new window.BMap.Marker(new window.BMap.Point(121.63049, 29.993947));
      map.addOverlay(marker);

      add_control();
    }

    setTimeout(() => {
      init();
    }, 1000)
  }
  render() {
    return (
      <div className="BuildMapMonitore">
        <div id="allmap" style={{width: '100%', height: '72vh', overflow: 'hidden', margin:'0'}}></div>
      </div>
    );
  }
}



class BulidBase extends Component {
  render() {
    const Floordata = [{key: 1, id: 1, Floornum: '一楼', Floortype: '圆顶咖啡',Floorarea: 2,},
      {key: 2, id: 2, Floornum: '二楼', Floortype: '圆顶咖啡', Floorarea: 2,},
      {key: 3, id: 3, Floornum: '二楼', Floortype: '圆顶咖啡', Floorarea: 2,}];
      const FloorInformation = [
        { title: '序号', dataIndex: 'id', key: 'id' },
        { title: '楼层', dataIndex: 'Floornum', key: 'Floornum' },
        { title: '所属建筑', dataIndex: 'Floortype', key: 'Floortype' },
        { title: '区域数', dataIndex: 'Floorarea', key: 'Floorarea' },
        { title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
            <span>
              <Link to={`/org/floor/:id`}>详情</Link>
              <span className="ant-divider" />
              <Link to={`/org/editfloor/:id`}>修改</Link>
            </span>
          )},
      ];
      const pagination = {
      // total: this.props.equipTaskState.tableData.length,
        total: Floordata.length,
        showTotal: total => `共 ${total} 条`,
        showSizeChanger: true,
        showQuickJumper: true,
        onShowSizeChange: (current, pageSize) => {
          console.log('Current: ', current, '; PageSize: ', pageSize);
        },
        onChange: (current) => {
          console.log('Current: ', current);
        },
      };
    return (
      <div className="EquipStatistics">
        <Tabs defaultActiveKey="1">
          <TabPane tab={<span><Icon type="info-circle-o" />基础信息</span>} key="1"> 
             <div className="buildCard"  style={{height:'78vh' }}>
               <Card bodyStyle={{fontsize: 12,color: '#666666'}} bordered={false}>
                <Row style={{ padding: '0 0 5px' ,fontsize: '12px',}}>
                  <Col span={12}>建筑物名称：</Col>
                  <Col span={12}>建造日期： </Col>
                </Row>
                <Row style={{ padding: '5px 0 5px' }}>
                  <Col span={12}>建筑物类型： </Col>
                  <Col span={12}>火灾危险性： </Col>
                </Row>
                <Row style={{ padding: '5px 0 5px' }}>
                  <Col span={12}>使用性质： </Col>
                  <Col span={12}>构造类型： </Col>
                </Row>
                <Row style={{ padding: '5px 0 0' }}>
                  <Col span={12}>耐火等级： </Col>                 
                </Row>             
               </Card>   
              <br/>
              <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} />
              <br/>
              <Card bodyStyle={{fontsize: 16,color: '#666666'}} bordered={false}>
                <Row style={{ padding: '0 0 5px' ,fontsize: '16px',}}>
                  <Col span={12}>建筑物高度（米）：</Col>
                  <Col span={12}>占地面积（平方米）： </Col>
                </Row>
                <Row style={{ padding: '0 0 5px' }}>
                  <Col span={12}>建筑物面积（平方米）：</Col>
                  <Col span={12}>标准层面积（平方米）： </Col>         
                </Row>                  
              </Card>
              <br/>
              <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} />
              <br/>
              <Card bodyStyle={{fontsize: 16,color: '#666666'}} bordered={false}>
                <Row style={{ padding: '0 0 5px' ,fontsize: '16px',}}>
                  <Col span={12}>地上层数：</Col>
                  <Col span={12}>地上面积（平方米）： </Col>
                </Row>
                <Row style={{ padding: '5px 0 5px' }}>
                   <Col span={12}>地下层数：</Col>
                   <Col span={12}>地下面积（平方米）： </Col>
                </Row>
                <Row style={{ padding: '5px 0 0' }}>
                   <Col span={12}>避难层数量：</Col>
                   <Col span={12}>避难层总面积（平方米）： </Col>
                 </Row>
              </Card> 
              <br/>
              <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} />
              <br/>
              <Card bodyStyle={{fontsize: 16,color: '#666666'}} bordered={false}>
                <Row style={{ padding: '0 0 5px' ,fontsize: '16px',}}>
                  <Col span={12}>消防电梯总量：</Col>
                  <Col span={12}>电梯容纳总量： </Col>
                </Row>
                <Row style={{ padding: '0 0 5px' }}>
                  <Col span={12}>最大容纳人数： </Col>
                  <Col span={12}>日常工作时间： </Col>
                </Row>                   
               </Card>  
               <br/>
               <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} />
               <br/>
               <Card bodyStyle={{fontsize: 16,color: '#666666'}} bordered={false}>
                <Row style={{ padding: '5px 0 0' ,fontsize: '16px',}}>
                  <Col span={12}>备注：</Col>
                </Row>             
               </Card>
               <br/>
               <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} />
               <br/>
               
               <div>
                 <Row style={{padding: '10px 0 0px',marginTop:20}}>
                 <Col span={9} style={{textAlign:'left'}}>
                   <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to="/org/bding/manage">返回</Link></Button>
                 </Col>
               </Row>     
             </div>                                                   
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />楼层</span>} key="2">  
            <Row style={{ padding: '2px 0 15px' }}>
              <Col span={24}>
                <Table
                  className="table-equipTask"
                  columns={FloorInformation}
                  dataSource={Floordata}
                  pagination={pagination}
                  bordered
                />
              </Col>
              <Col span={6}  style={{marginTop:'-45px', marginLeft:'7%'}}>
                    <Button type="primary"><Link to="/org/newfloor">新增楼层</Link></Button>
              </Col>
            </Row>     
          </TabPane>
        </Tabs>
      </div>
    );
  }
}

const BuildTabs = () => (
    <BulidBase />
)
  

class Building extends Component {
  render() {
    return (
      <div className="Building">
        <BuildTabs />
      </div>
    )
  }
}

export default Building;