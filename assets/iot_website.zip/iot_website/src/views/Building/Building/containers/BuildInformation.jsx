import React, { Component } from 'react';
import {Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Popconfirm} from 'antd';
import './Building.css';



export default BulidInformation;