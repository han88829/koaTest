import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Popconfirm } from 'antd';
import moment from 'moment';
import './Building.css';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

message.config({
  top: 216,
  duration: 2
})

class appState {
  constructor(){
    extendObservable(this,{
      tableData:[],
      timer:0,
      trick:action(function(){
        setInterval(() => {
        this.timer += 1;
         }, 1000)
        })
  })
 }
}


class AdvancedSearchForm extends React.Component {

  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const values = {
          ...fieldsValue,
          'dtype': parseInt(fieldsValue['dtype'], 10),
          'dstate': parseInt(fieldsValue['dstate'], 10),
          'location': parseInt(fieldsValue['location'], 10),
          'setupTime': [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))]
          // 'setupTime': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
        }
        console.log('Received values of form: ', values);

        window.rpc.device.getArrayByContainer(values,0,0).then((result) =>{
          console.log(result);
          message.info(`共搜索到${result.length}条数据`);
          let devices = result.map((x) => ({...x, key: x.id, setupTime: '2017-2-21', sign: `*&^%$#@!`, lastPatrolDate: '2016-09-26 08:50:08'}));
          this.props.appState.tableData = devices;
        }, (err) => {
          console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      });
    } catch(e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form inline style={{ margin: 0 }}>
        <Row>
          <Col span={6} key={5}>
            <FormItem label={`巡查时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker
                ranges={{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }}
                />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

// @observer
// class EquipManageC extends Component {
  const EquipManageC=observer(class appState extends React.Component {
  componentDidMount() {
    window.rpc.device.getArray(0,0).then((result) =>{
      console.log(result);
      let devices = result.map((x) => ({...x, key: x.id, setupTime: '2016-09-26', sign: `!@#$%^&*`, lastPatrolDate: '2016-09-26 08:50:08'}));
      this.props.appState.tableData = devices;
    }, (err) => {
      console.warn(err);
    })
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }

  add() {
    this.props.appState.tableData.push({ key: 4, sign: '#', id: 4, name: '烟感1', type:'测温探测器', installDate: '2015-09-26 08:50:08', address: 'Sidney No. 1 Lake Park', condition: '维修中', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is Joe Black, I am 32 years old, living in Sidney No. 1 Lake Park.' })
  }

  maintain() {
    message.success('保养成功');
  }

  check() {
    message.success('检测成功');
  }

  cancel() {
    message.error('已取消');
  }

  render() {
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '巡查时间', dataIndex: 'name', key: 'name' },
      { title: '巡查结果', dataIndex: 'dtype', key: 'dtype' },
      { title: '巡查人', dataIndex: 'setupTime', key: 'setupTime' },
      { title: '巡查报表', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/equipment/device/${record.key}`}>查看报表</Link>        
          </span>
        )
      },
    ];

    const data = [...this.props.appState.tableData];

    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    return (
      <div className="EquipManage">
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={data}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class BuildAlarm extends Component {
  render() {
    return (
      <EquipManageC appState={new appState()} />
    )
  }
}

export default BuildAlarm;