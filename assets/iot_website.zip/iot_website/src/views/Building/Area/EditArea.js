/**by songmogu   2017-3-18 */

import React, { Component } from 'react';
import { Input, Button, Form, Select, DatePicker, InputNumber,Icon } from 'antd';
import { Link } from 'react-router';
import moment from 'moment';
import $ from 'jquery';

import build from '../../../assets/images/build/build.png';
import Area from '../../../assets/images/build/Area.png';
import bDate from '../../../assets/images/build/bDate.png';
import bArea  from '../../../assets/images/build/bArea.png';
import bd from '../../../assets/images/build/bd.png';
import bHeight from '../../../assets/images/build/bHeight.png';
import build_remark from '../../../assets/images/build/build-remark.png';
import build_time from '../../../assets/images/build/build-time.png';
import fireEleNum from '../../../assets/images/build/fireEleNum.png';

import maxTotleNum from '../../../assets/images/build/maxTotleNum.png';
import nature from '../../../assets/images/build/nature.png';
import refugeFloor_totalArea from '../../../assets/images/build/refugeFloor-totalArea.png';
import refugeFloor_number from '../../../assets/images/build/refugeFloor-number.png';

import safety from '../../../assets/images/build/safety.png';
import standardFloorArea from '../../../assets/images/build/standardFloorArea.png';
import subType from '../../../assets/images/build/subType.png';

import totalElevator from '../../../assets/images/build/totalElevator.png';


import underArea from '../../../assets/images/build/underArea.png';

import underNumber from '../../../assets/images/build/underNumber.png';
import upDown from '../../../assets/images/build/upDown.png';
import upperNumber from '../../../assets/images/build/upperNumber.png';
import workMen from '../../../assets/images/build/workMen.png';

import workPersonDay from '../../../assets/images/build/workPersonDay.png';
import fireLevel from '../../../assets/images/build/fireLevel.png';
import floorArea from '../../../assets/images/build/floorArea.png';

const FormItem = Form.Item;
//const RangePicker = DatePicker.RangePicker;
const Option = Select.Option;

const format = 'YYYY-MM-DD';

class EditArea  extends Component {
  render() {
    return (
      <div className="EditBuilding">
         <BuildingEdit  />
      </div>
    )
  }
}

const BuildingEdit = Form.create()(React.createClass({
   getInitialState() {
    return {
     name:'',
     buildId:'',
     buildingType:[],
     fireDanger:[],
    };
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
        let imgUrl=$("#seeImgArea").attr('href');
        const value = { ...values,type:51,mapUrl:imgUrl,extend:{elevatornum:values.elevatornum,elevator:values.elevator,nature:values.nature, everyday:values.everyday}};
        let Id=this.state.buildId;
        console.log(values);
        window.rpc.area.getInfoById(Id).then((dres) => {
           console.log(dres);
           let parentId=dres.parentId;
          window.rpc.area.setInfoById(Id,value).then((res) => { 
          console.log(res);
          //console.log(res.parentId);
          //let Id=res.parentId;
          
          if(res){
            window.location.href=`/org/floor/${parentId}`;
            // window.location.href=`/org/bding/manage`;
          }
        },(err) =>{
          console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
            window.location.href=`/org/bding/manage`;
        });  
         })
       

      }
    });
  },
   componentWillMount(){
     window.rpc.area.types.getInfoById(51).then((result)=>{
       console.log(result.name);
       this.setState({name:result.name})
     },(err) =>{
       console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
     });
     window.rpc.area.types.getArrayIdNameByContainer(null,0,0).then((res) => {
       console.log(res);
       let buildingType=res.map((x)=>({...x}));
       this.setState({
         buildingType
       }) 
     },(err) =>{
        console.warn(err);
     });
      window.rpc.alias.getValueByName('area.fireDanger').then((res) => {
        let arr=['/'];
         for(let key in res){
            let values=`${res[key]}`
            arr.push(values);
         }
       //  console.log(arr);
      let fireDanger=arr;
       this.setState({
         fireDanger
       }) 
     },(err) =>{
        console.warn(err);
     });
     var id = window.location.href;
     var index = id.lastIndexOf("\/");
     id = Number(id.substring(index + 1, id.length));
     this.setState({buildId:id});
     //let id=this.props.params;
      // window.rpc.area.getInfoById(id).then((res)=>{
      //   console.log(res);
      // })
      window.rpc.area.getInfoById(id).then((res)=>{
         console.log(res);
         let asc=res.mapUrl;
         $("#seeImgArea").attr({"href":asc});
         this.props.form.setFieldsValue({
           name: res.name,
           //type:this.state.name
           subtype:`${res.subtype}`,
           buildTime: moment(res.buildTime, format),
           fireLevel:`${res.fireLevel}`,
           face:res.face,
           hight:res.hight,
           nature:res.extend.nature||'',
           elevatornum:res.extend.elevatornum||'',
           elevator:res.extend.elevator||'',
           everyday:res.extend.everyday||''
          });
      },(err) =>{
        console.warn(err);
      })
   },
   componentDidMount(){
        
      let Id=this.state.buildId;
      //  window.rpc.upload.images.getAreaUniqueConfigById(Id).then((res) => {
        window.rpc.upload.images.getDefaultConfig().then((res) => {
        console.info(res);
        let { domain, uptoken } = res;
        //var uploader =
        window.Qiniu.uploader({
          runtimes: 'html5,flash,html4',    //上传模式,依次退化
          browse_button: 'pickfilesArea',       //上传选择的点选按钮，**必需**
          // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
          uptoken : uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
          //unique_names: false, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
          //save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
          domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
          // domain: `http://omdwajej6.bkt.clouddn.com/`,
          get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
          // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
          max_file_size: '100mb',           //最大文件体积限制
          unique_names: true,
          multi_selection: false,
          // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
          max_retries: 3,                   //上传失败最大重试次数
          // dragdrop: true,                   //开启可拖曳上传
          // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
          chunk_size: '4mb',                //分块上传时，每片的体积
          auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
          init: {
            'FilesAdded': function (up, files) {
             //plupload.each(files, function (file) {
             // 文件添加进队列后,处理相关的事情
             //});
             },
             'BeforeUpload': function (up, file) {
             // 每个文件上传前,处理相关的事情
             },
            'UploadProgress': function (up, file) {
             // 每个文件上传时,处理相关的事情
            },
            'FileUploaded': function (up, file, info) {
              //console.log(info);
                let domain = up.getOption('domain');
                let res = JSON.parse(info);
                var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
                console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
               // this.props.appState.imgLink=sourceLink;
                var asc=sourceLink;
                $("#seeImgArea").attr({"href":asc});
                alert('传图成功');
            },
            'Error': function (up, err, errTip) {
            //上传出错时,处理相关的事情
             alert('传图失败');
            },
            'UploadComplete': function () {
            //队列文件处理完毕后,处理相关的事情
            },
            'Key': function (up, file) {
              // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
              // 该配置必须要在 unique_names: false , save_key: false 时才生效
              // str=window.location.href;
             // let str = window.location.href;
             // var index = str.lastIndexOf("\/");
             var key = ``;
            //  str = parseInt( str.substring(index + 1, str.length),10);
              //var key = `owner-${str}`;
             // var key = `area-${str}`;
              //console.log(key);
              // do something with key here
              return key
          }
        }
      });
     },(err) =>{
        console.warn(err);
     })    
     
  },

  normFile(e) {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  },
  render() {
    const { getFieldDecorator } = this.props.form;
 //此处为楼，type=50  得到类型值 disabled
   //let buildingType=this.state.buildingType;

  // let buildingTypeLists=[];
    
    // for (let value of buildingType) {
    //   if (value && value.id) {
    //   buildingTypeLists.push(<Option key={`${value.id}`}>{value.name}</Option>);
    //   }
    // }
    //  <Select placeholder="" size="small" style={{ width: 180 }} >{buildingTypeLists} </Select>
    //console.log(this.state.name);
   let name=this.state.name;
   let buildingTypeLists=[];
    //buildingTypeLists.push(<Option key={50}>{this.state.name}</Option>);
    let  fireDanger=this.state.fireDanger;

    let  fireDangerLists=[];
    
    for (let i=1;i<fireDanger.length+1;i++) {   
       fireDangerLists.push(<Option key={`${i}`}>{fireDanger[i]}</Option>)
    }

    let buildingType=this.state.buildingType;
    for (let value of buildingType) {
      if (value && value.id) {
        buildingTypeLists.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    return (
       <div  className="EditOrg EditArea" style={{ background: '#fff'}}>
            <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',paddingTop:'1.125rem',color:'#333',borderBottom:'1px solid #ddd',fontSize:'0.75em',fontFamily:'苹方中等',}}>
              <div style={{float:'left',width:135,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
                 <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>
                   <Link to={`/org/bding/manage`} style={{color:'#373e41'}} >建筑信息</Link><span style={{padding:'0 4px'}}>/</span>
                   <Link to={`org/floor/${this.state.id}`}  style={{color:'#373e41'}} >楼层信息</Link></span>
              </div>
              <div  style={{float:'left',width:80,height:32,marginRight:4}}>
                <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="">修改楼层</Link></Button>
              </div>
              
            </div>
         <Form onSubmit={this.handleSubmit} style={{ fontSize: '12px', marginTop: -4, paddingTop: 20,overflow: 'auto' }}>
            <div style={{textAlign:'left',borderBottom:'1px solid #eee',marginBottom:'24px'}}>
              <p  style={{color:'#373d41',fontsize: '0.75rem',fontFamily:'苹方中等',padding:'8px 0 28px 10px',}}>楼层信息</p>
            </div> 
            <div style={{fontsize:'0.75rem',color: '#373e41'}}> 
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{float:'left',marginRight:50,height:32,lineHeight:'32px'}}>
                    <img src={build} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>楼层名：</span>
                  </div>
                  <FormItem
                    style={{float:'left'}}
                    hasFeedback
                  >
                    {getFieldDecorator('name', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input placeholder="请输入内容!" />
                    )}
                  </FormItem>
              </div>
                <div className="Row-info-right clearfix" >
                <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                  <img src={safety} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span>火灾危险性：</span>
                </div>
                <FormItem
                 style={{float:'left'}}
                 hasFeedback
                >
                    {getFieldDecorator('fireDanger', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Select placeholder="请选择" style={{width:'162px'}}  >
                       {fireDangerLists}
                     </Select>
                    )}
                </FormItem>
               </div>
             </div>
           
          <div className="Row-info">
            <div className="Row-info-left clearfix">
              <div style={{float:'left',marginRight:36,height:32,lineHeight:'32px'}}>
                <img src={nature} style={{padding:'0 15px 0 12px'}} alt=""/>
                <span>使用性质：</span>
              </div>
              <FormItem
                style={{float:'left'}}
                hasFeedback
              >
                   {getFieldDecorator('Fuse', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input placeholder="请输入内容!" />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{float:'left',marginRight:24,height:32,lineHeight:'32px'}}>
                    <img src={subType} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>结构类型：</span>
                 </div>
                 <FormItem
                     style={{float:'left'}}
                     hasFeedback
                  >
                    {getFieldDecorator('subtype', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                     <Select placeholder="请选择" style={{ width: 162 }}>
                        {buildingTypeLists}
                     </Select>
                    )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{float:'left',marginRight:36,height:32,lineHeight:'32px'}}>
                    <img src={fireLevel} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>耐火等级：</span>
                  </div>
                  <FormItem
                    style={{float:'left'}}
                    hasFeedback
                  >
                    {getFieldDecorator('FireLevel', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input style={{ width: 162 }} placeholder="请输入" />
                    )}
                  </FormItem>
                </div> 
                <div className="Row-info-right clearfix" >
                {
                <div >  
                 <div className="col-md-12">
                  <div style={{overflow:'hidden'}}>
                     <div id="container"  style={{position: 'relative',float:'left',width:162,height:32,marginRight:6}}>
                       <Button id="pickfilesArea"   onClick={this.uploadButton} style={{position: 'relative',float:'left',width:162,height:32,borderRadius:0}} > 
                         <span>上传楼层图片</span>
                       </Button>
                     </div>
                     <a id="seeImgArea" style={{display:'none',float:'right',height:30,width:30,marginLeft:10, borderRadius:'100%',background:'#fff',border:'1px solid #ccc'}}><Icon type="upload"  style={{marginLeft:7}}/></a>  
                 </div>
                </div>
               </div>
              }
              
                </div>            
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix" >
                <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                  <img src={fireEleNum} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span>消防电梯数量：</span>
                </div>
                <FormItem
                  style={{float:'left'}}
                  hasFeedback//extend:{elevatornum:values.elevatornum, everyday:values.everyday,type:51,parentId:this.state.buildId}
                >
                    {getFieldDecorator('elevator', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type='middle' placeholder='请输入消防电梯数量'  style={{width:309}} />
                    )}
                 </FormItem>
             </div>
             <div className="Row-info-right clearfix" >
               <div style={{float:'left',marginRight:14,height:32,lineHeight:'32px'}}>
                 <img src={Area} style={{padding:'0 15px 0 12px'}} alt=""/>
                 <span>占地面积（平方米）：</span>
               </div>
               <FormItem
                 style={{float:'left'}}
                 hasFeedback
               >
                  {getFieldDecorator('face', {
                    initialValue:'',
                    rules: [{ type:'string', required: true, message: '请输入内容!' }],
                  })(
                    <Input type='middle' placeholder='请输入占地面积'  style={{width:309}}  />
                  )}
                  </FormItem>
                </div>
              </div>
              <div  className="Row-info">
                <div className="Row-info-left clearfix">
                <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                  <img src={totalElevator} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span>电梯容纳总量：</span>
                </div>
                <FormItem
                  style={{float:'left'}}
                  hasFeedback
                >
                    {getFieldDecorator('elevatornum', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input  placeholder='请输入占地面积'  style={{width:309}}  />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix">
                 <div style={{float:'left',marginRight:24,height:32,lineHeight:'32px'}}>
                   <img src={workPersonDay} style={{padding:'0 15px 0 12px'}} alt=""/>
                   <span>日常工作时间人数：</span>
                 </div>
                 <FormItem
                   style={{float:'left'}}
                   hasFeedback
                  >
                    {getFieldDecorator('everyday', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input placeholder='请输入日常工作时间人数'  style={{width:309}}  />
                    )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix" >
                  <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                    <img src={maxTotleNum} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>最大容纳人数：</span>
                  </div>
                  <FormItem
                      style={{float:'left'}}
                      hasFeedback
                  >
                    {getFieldDecorator('galleryful', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input  placeholder='请输入占地面积'  style={{width:309}}  />
                    )}
                  </FormItem>
               </div>
             
              </div>  
              <div className="Row-info" style={{background:'#f8fbfb',padding:'4px 0',height:100,}}>
                <div style={{float:'left',marginRight:12,height:92,lineHeight:'92px',padding:'4px 0'}}>
                  <img src={build_remark} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span style={{marginRight:24}}>备注：</span>
                </div>
                <FormItem
                  style={{float:'left',height:92}}
                  hasFeedback
                > 
                  {getFieldDecorator('remark', {
                 
                   })(
                    <Input type="textarea" size="large" placeholder="备注" style={{ width: 600, height: 92 }} />
                   )}
                </FormItem>
              </div>
              <div style={{ position: 'absolute', bottom:80, fontFamily:'苹方中等',fontsize:'0.75em'}} className="search-btn">
                {/*<FormItem>*/}
                  <Button type="primary" htmlType="submit" size="large" style={{borderColor: 'transparent'}} >保存</Button>
                  {/*<Button  style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑',marginLeft:'10px'}}><Link to={`/org/floor/${this.state.buildId}`}>返回</Link></Button>*/}
                  <div className="new-button" style={{display:`inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑',marginLeft:10, fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to={`/org/floor/${this.state.buildId}`}>返回</Link></div>
                {/*</FormItem>*/}
             </div>
          </div>  
        </Form>
      </div>
   );
  },
}));

export default EditArea;