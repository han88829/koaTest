import React, { Component } from 'react';
import { Input, Button, Form, TreeSelect, Select, DatePicker, Row, Col, InputNumber,Upload,Icon} from 'antd';
import { Link } from 'react-router';
//import { observable } from 'mobx';
//import { observer } from 'mobx-react';
 import $ from 'jquery';
 import message from 'message';

const FormItem = Form.Item;
const RangePicker = DatePicker.RangePicker;
const Option = Select.Option;


const info = function () {
  message.info('This is a normal message');
};
class  NewFloor extends Component {
  render() {
    return (
      <div className="NewBuilding">
        <FloorNew />
      </div>
    )
  }
}


const FloorNew = Form.create()(React.createClass({
   getInitialState() {
    return {
     imgLink:'',
     createValue:null,
     buildingType:[],
     createId:null
    };
  },
   componentWillMount(){
      window.rpc.area.types.getArrayIdNameByContainer(null,0,0).then((res) => {
       console.log(res);
      let buildingType=res.map((x)=>({...x}));
      this.setState({
        buildingType
      }) 
    },(err) =>{
        console.warn(err);
      })
   },
  componentDidMount() {
  
  },
  uploadButton(){
       // console.log(11111);
       console.log(this.state.createId);
       let createId=this.state.createId;
       // window.rpc.upload.images.getAreaUniqueConfigById(createId).then((res) => {
        window.rpc.upload.images.getDefaultConfig().then((res) => {
        console.info(res);
        let { domain, uptoken } = res;
          var uploader = window.Qiniu.uploader({
          runtimes: 'html5,flash,html4',    //上传模式,依次退化
          browse_button: 'pickfiles1',       //上传选择的点选按钮，**必需**
          // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
          uptoken : uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
          //unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
           //save_key: true,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
          domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
         // domain: `http://omdwajej6.bkt.clouddn.com/`,
          get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
          // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
          max_file_size: '100mb',           //最大文件体积限制
          unique_names: true,
          multi_selection: false,
          // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
          max_retries: 3,                   //上传失败最大重试次数
          // dragdrop: true,                   //开启可拖曳上传
          // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
          chunk_size: '4mb',                //分块上传时，每片的体积
          auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
          init: {
          'FilesAdded': function (up, files) {
            //plupload.each(files, function (file) {
            // 文件添加进队列后,处理相关的事情
            //});
          },
          'BeforeUpload': function (up, file) {
            // 每个文件上传前,处理相关的事情
          },
          'UploadProgress': function (up, file) {
            // 每个文件上传时,处理相关的事情
          },
          'FileUploaded': function (up, file, info) {
             let domain = up.getOption('domain');
             let res = JSON.parse(info);
             var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
             console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
             // this.props.appState.imgLink=sourceLink;
             var asc=sourceLink;
             let btn= $("#seeImg").attr({"href":asc});
           },
           'Error': function (up, err, errTip) {
            //上传出错时,处理相关的事情
           },
           'UploadComplete': function () {
            //队列文件处理完毕后,处理相关的事情
           },
           'Key': function (up, file) {
            // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
            // 该配置必须要在 unique_names: false , save_key: false 时才生效
            var key = "";
            // do something with key here
            return key
          }
        }
      });
    },(err) =>{
        console.warn(err);
    })    
  },
 handleClickButton(){
   //setInfo 上传图片
   let createId=this.state.createId;
   let value=this.state.createValue;
   let imgUrl=$("#seeImg").attr('href');
   let values = {...value,mapUrl:imgUrl};
   console.log(values);
   window.rpc.area.setInfoById(createId,values).then((res) => {
   console.log(res);
     if(res){
     window.location.href='/org/buildingManage';
     }
   },(err) =>{
     console.warn(err);
   });

// let imgUrl='baidu'
// let Object={name:"科技创业大厦",number:null,ownerId:1,parentId:0,point:null,remark:null,subtype:102,type:50,x:121.618835,y:29.92071}
//  let value = { ...Object, img:imgUrl};
//  console.log(value);
 },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form:', values);
        const value = { ...values,type:51}//buildTime:new Date(values.buildTime.format('YYYY-MM-DD')),
        console.log(value);
        this.setState({ createValue:value});
        window.rpc.area.create(value).then((res) => {
          console.log(res);
          let createId=res;
          if(createId){
            this.setState({createId:res});
            console.log(this.state.createId);
            //qi(res);
            //qi(id){}
          }   
        },(err)=>{
          console.log(err);
        })
      } else {
       // console.log('Received values of form: ', values.builtdate._d);
      }
    });
  },
  normFile(e) {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 },
    };

    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    const rangeConfig = {
      rules: [{ type: 'array', required: true, message: 'Please select time!' }],
    };
 //此处为楼，type=51  得到类型值 disabled
   let buildingType=this.state.buildingType;

   let buildingTypeLists=[];
    
    for (let value of buildingType) {
      if (value && value.id) {
      buildingTypeLists.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
   // console.log( buildingTypeLists);
    return (
        <div className="NewFloor" style={{ background: '#fff', paddingBottom: 100 }}>
          <Form onSubmit={this.handleSubmit} style={{ fontSize: '12px', marginTop: -4, paddingTop: 30, height: 550, overflow: 'auto' }} >
             <Row>
                <Col span={6}>
                  <FormItem
                    {...formItemLayout}
                    label="楼层名："
                    hasFeedback
                  >
                    {getFieldDecorator('name', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
                <Col span={10}>
                  <FormItem
                    {...formItemLayout}
                    label="火灾危险性："
                    hasFeedback
                  >
                    {getFieldDecorator('Frisk', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
              </Row>
              <Row>
            <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="上传建筑物照片"
              extra=""
            >
             {
               <div>  
                <div className="col-md-12">
                  <Row>
                   <Col span={8}>
                     <div id="container" style={{position: 'relative'}}>
                       <Button id="pickfiles1"  onClick={this.uploadButton} style={{width:100}}> 
                         <span>选择文件</span>
                       </Button>
                     </div>
                   </Col>
                   <Col span={14}>
                     <a id="seeImg" style={{display:'inline-block',height:30,width:30,marginLeft:10, borderRadius:'100%',background:'#fff',border:'1px solid #ccc'}}><Icon type="upload"  style={{marginLeft:7}}/></a>
                     <a id="up" onClick={this.handleClickButton} style={{display:'inline-block',height:30,width:80,marginLeft:10, borderRadius:'10px',background:'#fff',border:'1px solid #ccc'}}><Icon type="upload"  style={{marginLeft:20}}/>提交</a> 
                   </Col>
                 </Row>
                </div>
              </div>
            }
            </FormItem>
          </Col>
          </Row>
              <Row>
                <Col span={6}>
                  <FormItem
                    {...formItemLayout}
                    label="使用性质："
                    hasFeedback
                  >
                    {getFieldDecorator('Fuse', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
                <Col span={10}>
                  <FormItem
                    {...formItemLayout}
                    label="结构类型："
                    hasFeedback
                  >
                    {getFieldDecorator('subtype', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={6}>
                  <FormItem
                    {...formItemLayout}
                    label="耐火等级："
                    hasFeedback
                  >
                    {getFieldDecorator('FireLevel', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
               
              </Row>
              <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} /><br />
              
              <Row>
                <Col span={6}>
                  <FormItem
                    {...formItemLayout}
                    label="消防电梯数量："
                    hasFeedback
                  >
                    {getFieldDecorator('Felevator', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
                <Col span={10}>
                  <FormItem
                    {...formItemLayout}
                    label="占地面积（平方米）："
                    hasFeedback
                  >
                    {getFieldDecorator('face', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={6}>
                  <FormItem
                    {...formItemLayout}
                    label="电梯容纳总量："
                    hasFeedback
                  >
                    {getFieldDecorator('Etotal', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
              </Row>
              <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} /><br />

              <Row>
                <Col span={6}>
                  <FormItem
                    {...formItemLayout}
                    label="最大容纳人数："
                    hasFeedback
                  >
                    {getFieldDecorator('galleryful', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
                <Col span={10}>
                  <FormItem
                    {...formItemLayout}
                    label="日常工作时间人数："
                    hasFeedback
                  >
                    {getFieldDecorator('Fday', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={1} />
                    )}
                  </FormItem>
                </Col>
              </Row>
              <hr style={{border:'none',height:'1px',color:'#EEE',background:'#DDD'}} /><br />
              
              <Row>
                <Col span={6}>
                  <FormItem
                    {...formItemLayout}
                    label="备注："
                    hasFeedback
                  >
                    {getFieldDecorator('remark', {
                      initialValue:'',
                      rules: [{ type:'string', required: true, message: '请输入内容!' }],
                    })(
                      <Input type="textarea" rows={3} />
                    )}
                  </FormItem>
                </Col>
              </Row>
              <Row style={{marginTop:'30px'}}>
                <Col span={6}>
                  <FormItem {...tailFormItemLayout}>
                    <Button type="primary" htmlType="submit" size="large">新增</Button>
                  </FormItem>
              </Col>
              <Col span={6}>
                  <FormItem {...tailFormItemLayout}>
                    <Button type="success" style={{marginLeft:'100%'}}><Link to="/org/floor/:id">返回</Link></Button>
                  </FormItem>
              </Col>
              </Row>
          </Form>
      </div>
    );
  },
}));

export default NewFloor;