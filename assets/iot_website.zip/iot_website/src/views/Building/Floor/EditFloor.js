import React from 'react';
import { Form, Input, Cascader, Select, Button, DatePicker, Row, Col, Tabs, Icon, Table } from 'antd';
import { Link } from 'react-router';
//import { observable, action } from 'mobx';
//import moment from 'moment';
const FormItem = Form.Item;
const Option = Select.Option;
const { RangePicker } = DatePicker;
const { TabPane } = Tabs;

const EditFloor = Form.create()(React.createClass({
  componentWillMount(){
    window.rpc.area.getInfoById(this.props.params.id).then((res)=>{
      console.log(res)
    },(err) =>{
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
        window.rpc.area.setInfoById(this.props.params.id, values).then((res) => {
          console.log(res)
        },(err) =>{
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
      }
    });
  },

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    
    const Floordata = [{ key: 1, id: 1, Floornum: '一楼', Floortype: '圆顶咖啡', Floorarea: 2, },
    { key: 2, id: 2, Floornum: '二楼', Floortype: '圆顶咖啡', Floorarea: 2, },
    { key: 3, id: 3, Floornum: '二楼', Floortype: '圆顶咖啡', Floorarea: 2, }];
    const FloorInformation = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '楼层', dataIndex: 'Floornum', key: 'Floornum' },
      { title: '所属建筑', dataIndex: 'Floortype', key: 'Floortype' },
      { title: '区域数', dataIndex: 'Floorarea', key: 'Floorarea' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={``}>详情</Link>
            <span className="ant-divider" />
            <Link to={``}>修改</Link>
          </span>
        )
      },
    ];
    return (
      <div>
        <Form onSubmit={this.handleSubmit}>
          <Row>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="楼层名："
                hasFeedback
              >
                {getFieldDecorator('Fname', {
                  initialValue: '一楼',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="火灾危险性："
                hasFeedback
              >
                {getFieldDecorator('Frisk', {
                  initialValue: '非常危险',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="使用性质："
                hasFeedback
              >
                {getFieldDecorator('Fuse', {
                  initialValue: '办公',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="结构类型："
                hasFeedback
              >
                {getFieldDecorator('Fstructure', {
                  initialValue: '结构一',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="耐火等级："
                hasFeedback
              >
                {getFieldDecorator('Frefractory', {
                  initialValue: '一级',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="占地面积（平方米）："
                hasFeedback
              >
                {getFieldDecorator('Farea', {
                  initialValue: '200',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} /><br />

          <Row>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="消防电梯数量："
                hasFeedback
              >
                {getFieldDecorator('Felevator', {
                  initialValue: '10',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="占地面积（平方米）："
                hasFeedback
              >
                {getFieldDecorator('Earea', {
                  initialValue: '200',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="电梯容纳总量："
                hasFeedback
              >
                {getFieldDecorator('Etotal', {
                  initialValue: '100人',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} /><br />

          <Row>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="最大容纳人数："
                hasFeedback
              >
                {getFieldDecorator('Ftotal', {
                  initialValue: '200人',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="日常工作时间人数："
                hasFeedback
              >
                {getFieldDecorator('Fday', {
                  initialValue: '200人',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={1} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} /><br />

          <Row>
            <Col span={6}>
              <FormItem
                {...formItemLayout}
                label="备注："
                hasFeedback
              >
                {getFieldDecorator('Fnote', {
                  initialValue: '100人',
                  rules: [{ type: 'string', required: true, message: '请输入内容!' }],
                })(
                  <Input type="textarea" rows={3} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <Row style={{ marginTop: '30px' }}>
            <Col span={6}>
              <FormItem {...tailFormItemLayout}>
                <Button type="primary" htmlType="submit" size="large">确定修改</Button>
              </FormItem>
            </Col>
            <Col span={6}>
              <FormItem {...tailFormItemLayout}>
                <Button type="success"><Link to="/org/floor/:id">返回</Link></Button>
              </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
    );
  },
}));

export default EditFloor;