/*
 * @Author:szj 
 * @Date: 2017-03-27 17:15:44 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 12:45:59
 */
/*
 * @Author: songmogu 
 * @Date: 2017-03-21 13:53:06 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-03-27 17:15:20
 */


import React, { Component } from 'react';
import { Form, Input, Icon, Select, Row, Col, Button, DatePicker, InputNumber, message } from 'antd';
import { Link, browserHistory } from 'react-router';
import $ from 'jquery';

import build from '../../../assets/images/build/build.png';
import Area from '../../../assets/images/build/Area.png';
import bDate from '../../../assets/images/build/bDate.png';
import bArea  from '../../../assets/images/build/bArea.png';
import bd from '../../../assets/images/build/bd.png';
import bHeight from '../../../assets/images/build/bHeight.png';
import build_remark from '../../../assets/images/build/build-remark.png';
import build_time from '../../../assets/images/build/build-time.png';
import fireEleNum from '../../../assets/images/build/fireEleNum.png';

import maxTotleNum from '../../../assets/images/build/maxTotleNum.png';
import nature from '../../../assets/images/build/nature.png';
import refugeFloor_totalArea from '../../../assets/images/build/refugeFloor-totalArea.png';
import refugeFloor_number from '../../../assets/images/build/refugeFloor-number.png';

import safety from '../../../assets/images/build/safety.png';
import standardFloorArea from '../../../assets/images/build/standardFloorArea.png';
import subType from '../../../assets/images/build/subType.png';
import totalElevator from '../../../assets/images/build/totalElevator.png';
import underArea from '../../../assets/images/build/underArea.png';

import underNumber from '../../../assets/images/build/underNumber.png';
import upDown from '../../../assets/images/build/upDown.png';
import upperNumber from '../../../assets/images/build/upperNumber.png';
import workMen from '../../../assets/images/build/workMen.png';
import workPersonDay from '../../../assets/images/build/workPersonDay.png';
import fireLevel from '../../../assets/images/build/fireLevel.png';
import floorArea from '../../../assets/images/build/floorArea.png';

import './areacontent.css';
const FormItem = Form.Item;
const Option = Select.Option;

const WrappedRegistrationForm = Form.create()(React.createClass({
    getInitialState() {
        return {
            imgLink: '',
            createValue: null,
            buildingType: [],
            OrgsType: [],
            id: null,
            parent: "",
            grandId:"",
            fireDanger:""
        };
    },
    componentWillMount() {

    window.rpc.area.types.getArrayIdNameByContainer(null,0,0).then((res) => {
       console.log(res);
       let buildingType=res.map((x)=>({...x}));
       this.setState({
         buildingType
       }) 
     },(err) =>{
        console.warn(err);
     });
      window.rpc.alias.getValueByName('area.fireDanger').then((res) => {
        let arr=['/'];
         for(let key in res){
            let values=`${res[key]}`
            arr.push(values);
         }
       //  console.log(arr);
      let fireDanger=arr;
       this.setState({
         fireDanger
       }) 
     },(err) =>{
        console.warn(err);
     });
        window.rpc.area.getInfoById(this.props.props.params.id).then(result => {
            console.log(result.parentId )
            this.setState({ parent: result.parentId })
              window.rpc.area.getInfoById(result.parentId).then(res => {
                 this.setState({grandId: res.parentId })
              })
            this.props.form.setFieldsValue({
                name: result.name,
                //fireDanger: result.fireDanger,
                nature: result.extend.nature,
                subtype: `${result.subtype}`,
                face: result.face,
                elevatornum: result.extend.elevatornum,
                galleryful: result.galleryful,
                remark: result.remark,
                //fireLevel:`${result.fireLevel}`,
                fireDanger: `${result.fireDanger}`,
                fireLevel:result.fireLevel,
                elevator: result.extend.elevator,
                everyday: result.extend.everyday
            });
        })
    },

    handleSubmit(e) {
        e.preventDefault();
        let text = '';
        if (sessionStorage.getItem('arr')){
            const arr = JSON.parse(sessionStorage.getItem('arr'))
            arr.map(x => {
                text += `${x.x},${x.y};`
            })
        }
       console.log(text)
        this.props.form.validateFieldsAndScroll((err, values) => {
            if (!err) {
                const value1 = { ...values, type: 52, mapPoint: text, parentId: Number(this.state.parent), extend: { nature: values.nature, elevator: values.elevator, elevatornum: values.elevatornum, everyday: values.everyday } }
                delete value1.nature; delete value1.elevator; delete value1.elevatornum; delete value1.everyday;
                console.log(value1)
                window.rpc.area.setInfoById(this.props.props.params.id, value1).then(id => {
                    //rpc.upload.images.GetOwnerUniqueConfigById(id)
                    console.log(id);
                    if (id) {
                        this.setState({ id });
                        message.info('修改成功');
                        sessionStorage.removeItem('arr')
                        browserHistory.push(`/org/area/cont/${this.state.parent}`)
                    }
                },err=>{
                    console.warn(err);
                    console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
                })

            } else {
                // console.log('Received values of form: ', values.builtdate._d);
            }
        });
    },
    render() {
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {
            labelCol: { span: 3 },
            wrapperCol: { span: 14 },
        };
        const config = {
            rules: [{ type: 'object', required: true, message: 'Please select time!' }],
        };

        let buildingTypeLists=[];
    //buildingTypeLists.push(<Option key={50}>{this.state.name}</Option>);
    let  fireDanger=this.state.fireDanger;

    let  fireDangerLists=[];
    
    for (let i=1;i<fireDanger.length+1;i++) {   
       fireDangerLists.push(<Option key={`${i}`}>{fireDanger[i]}</Option>)
    }

    let buildingType=this.state.buildingType;
    for (let value of buildingType) {
      if (value && value.id) {
        buildingTypeLists.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
     // console.log(fireDangerLists);
     // console.log(buildingTypeLists);
        //let Orgtypes = JSON.parse(sessionStorage.getItem('Orgtypes'))||[];
        let Orgtypes = this.state.OrgsType;
        let OrgtypeChildren = [];
        //如果有数据就存储到子数组中
        for (let value of Orgtypes) {
            if (value && value.id) {
                OrgtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>);
            }
        }
        return (
            <div style={{ background: '#fff' }} className="EditOrg">
         
              <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',paddingTop:'1.125rem',color:'#333',borderBottom:'1px solid #ddd',fontSize:'0.75rem',fontFamily:'苹方中等',}}>
                <div style={{float:'left',width:195,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
                  <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}> 
                    <Link to={`/org/bding/manage`} style={{color:'#373e41'}} >建筑信息</Link><span style={{padding:'0 4px'}}>/</span>
                    <Link to={`/org/floor/${this.state.grandId}`}  style={{color:'#373e41'}} >楼层信息</Link><span style={{padding:'0 4px'}}>/</span>
                    <Link to={`/org/area/cont/${this.state.parent}`} style={{color:'#373e41'}} >区域信息</Link>
                  </span>
                </div>
                <div  style={{float:'left',width:80,height:32,marginRight:4}}>
                  <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="">修改区域</Link></Button>
                </div>
              </div>
                <Form className="EditOrg " onSubmit={this.handleSubmit} style={{ marginTop: -4, overflow: 'auto', overflow: 'auto' }}>
                    <div span={2} style={{ textAlign: 'left' }}>
                        <p style={{ color: '#373d41', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '28px 0 28px 10px' }}>基础信息</p>
                    </div>
                    <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                        <div className="Row-info">
                            <div className="Row-info-left clearfix">
                                <div style={{ float: 'left', marginRight: 26, height: 32, lineHeight: '32px' }}>
                                    <img src={build} style={{ padding: '0 15px 0 12px', float: 'left' }} alt="" />
                                    <span style={{ float: 'left' }}>区域名：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('name', {
                                        rules: [{
                                            required: true, message: '请输入区域名',
                                        }],
                                    })(
                                        <Input style={{ width: '400px', float: "left" }} />
                                    )}
                                </FormItem>
                                <Button style={{ float: 'left', marginLeft: 30 }}><Link to={`/org/areat/image/${this.props.props.params.id}/52`}>区域划分</Link></Button>
                            </div>
                            <div className="Row-info-right clearfix" >
                                <div style={{ float: 'left', marginRight: 48, height: 32, lineHeight: '32px' }}>
                                    <img src={safety} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>火灾危险性：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('fireDanger', {
                                        rules: [
                                            { required: true, message: '请选择火灾危险性' },
                                        ],
                                    })(
                                        <Select placeholder="请选择火灾危险性" style={{ width: '162px' }} >
                                          {fireDangerLists}
                                        </Select>
                                   )}
                                </FormItem>
                            </div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left clearfix" >
                                <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                                    <img src={nature} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>使用性质：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('nature', {
                                        rules: [
                                            { required: true, message: '请选择使用性质' },
                                        ],
                                    })(
                                        <Input  placeholder="请选择使用性质" />
                                        )}
                                </FormItem>
                            </div>
                            <div className="Row-info-right clearfix" >
                                <div style={{ float: 'left', marginRight: 60, height: 32, lineHeight: '32px' }}>
                                    <img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>结构类型：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('subtype', {
                                        rules: [
                                            { required: true, message: '请选择结构类型' },
                                        ],
                                    })(
                                        <Select placeholder="请选择结构类型" style={{ width: '162px' }} >
                                          {buildingTypeLists}
                                        </Select>
                                    )}
                                </FormItem>
                            </div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left clearfix" >
                                <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                                    <img src={fireLevel} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>耐火等级：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('fireLevel', {
                                        rules: [
                                            { required: true, message: '请选择耐火等级' },
                                        ],
                                    })(
                                        <Input style={{ width: 180 }} placeholder="请输入" />
                                    )}
                                </FormItem>
                            </div>
                            <div className="Row-info-left clearfix">
                                <div style={{ float: 'left', marginRight: 60, height: 32, lineHeight: '32px' }}>
                                    <img src={Area} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>占地面积：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('face', {
                                        rules: [{
                                            required: true, message: '请输入占地面积',
                                        }],
                                    })(
                                        <Input style={{ width: '400px' }} placeholder='请输入占地面积' />
                                   )}
                                </FormItem>
                            </div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left clearfix">
                                <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                                    <img src={fireEleNum} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>消防电梯数量：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('elevator', {
                                        rules: [{
                                            required: true, message: '请输入消防电梯数量',
                                        }],
                                    })(
                                        <Input style={{ width: '400px' }} placeholder='请输入消防电梯数量' />
                                    )}
                                </FormItem>
                            </div>
                            <div className="Row-info-right clearfix" >
                                <div style={{ float: 'left', marginRight: 36, height: 32, lineHeight: '32px' }}>
                                    <img src={totalElevator} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>电梯容纳总量：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('elevatornum', {
                                        rules: [{
                                            required: true, message: '请输入电梯容纳总量',
                                        }],
                                    })(
                                        <Input style={{ width: '400px' }} placeholder='请输入' />
                                    )}
                                </FormItem>
                            </div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left clearfix">
                                <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                                    <img src={maxTotleNum} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>最大容纳人数：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('galleryful', {
                                        rules: [{
                                            required: true, message: '请输入最大容纳人数',
                                        }],
                                    })(
                                        <Input style={{ width: '400px' }} placeholder='请输入' />
                                    )}
                                </FormItem>
                            </div>
                            <div className="Row-info-left clearfix">
                                <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                                    <img src={workPersonDay} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>日常工作时间人数：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('everyday', {
                                        rules: [{
                                            required: true, message: '请输入日常工作时间人数',
                                        }],
                                    })(
                                        <Input style={{ width: '400px' }} placeholder='请输入' />
                                    )}
                                </FormItem>
                            </div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left clearfix">
                                <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                                    <img src={build_remark} style={{ padding: '0 15px 0 12px' }} alt="" />
                                    <span>备注：</span>
                                </div>
                                <FormItem
                                    style={{ float: 'left' }}
                                    hasFeedback
                                >
                                    {getFieldDecorator('remark')(
                                        <Input style={{ width: '400px' }} placeholder='请输入备注' />
                                    )}
                                </FormItem>

                            </div>
                        </div>
                        <div style={{ margin: '10px 0', position: 'absolute',bottom:80 }} className="search-btn">
                            <FormItem>
                                <Button  htmlType="submit" size="large" style={{ color: '#fff', fontFamily: '微软雅黑', fontSize: '14px', borderRadius: 0, width:60}}>修改</Button>
                                {/*<Button  style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius:0, marginLeft: '10px',width:60 }}><Link to={`/org/area/cont/${this.state.parent}`}>返回</Link></Button>*/}
                                 <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to={`/org/area/cont/${this.state.parent}`}>返回</Link></span>
                            </FormItem>
                        </div>
                    </div>
                </Form>
            </div>
        );
    }
})
)

class EditAreaContent extends Component {
    render() {
        return (
            <div className="EditAreaContent">
                <WrappedRegistrationForm props={this.props} />
            </div>
        )
    }
}

export default EditAreaContent;