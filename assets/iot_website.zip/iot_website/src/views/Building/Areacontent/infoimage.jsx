import React, { Component } from 'react';
import { Button } from 'antd';
import { Link } from 'react-router';

class AreaInfoImage extends Component {
    state = {
        image: "",
        Id:""
    }
    componentWillMount() {
        console.log(this.props.params.id);
        let id=parseInt(this.props.params.id,10);
        window.rpc.area.getInfoById(id).then(info => {
            console.log(info.parentId)
            this.setState({Id:info.parentId})
            return window.rpc.area.getInfoById(info.parentId)
        }).then(res => {
            console.log(res.mapUrl);
            this.setState({
                image: res.mapUrl
            })
        })
    }
    componentDidMount() {
        let id=this.props.params.id;
        let arr2 = [];
        var Canvas = document.getElementsByTagName('canvas')[0];
        var myCanvas = Canvas.getContext('2d');
        let arrcon = JSON.parse(sessionStorage.getItem(`arr${id}`));
        console.log(arrcon);
        arrcon.forEach((x) => {
            //arr2.push({ x: x.split(',')[0], y: x.split(',')[1] })
            arr2.push({ x: x.x, y: x.y})
        })
        myCanvas.beginPath();
        myCanvas.moveTo(arr2[0].x, arr2[0].y);
        myCanvas.strokeStyle = 'red';
        arr2.map(x => { myCanvas.lineTo(x.x, x.y); })
        myCanvas.lineWidth = 2;
        myCanvas.stroke();
        myCanvas.closePath();
    }
    render() {
        
        return (
            <div className="areaContent" style={{ position: "relative" }}>
                <div style={{ width: 40, height: 40, fontSize: 30, position:'fixed',right:0,top:50,zIndex: 99999, color: "white", borderRadius: "0 0 0 80%", background: "#cccccc", cursor: "pointer", padding: "0 0 30px 15px" }} className="open">
                    <Link to={`/org/areat/info/${this.props.params.id}`}>X</Link>
                </div>
                <canvas width="1600" height="800" style={{ position: "absolute", left: 0, top: 0, zIndex: 9 }}></canvas>
                <p style={{ width: 1600, height: 800, position: "absolute", left: 0, top: 0 }}><img src={this.state.image} alt="" style={{ width: "100%", height: "100%" }} /></p>
                <div style={{position:"absolute",top:803,background:'#ccc'}}><Button style={{background:'#ccc'}}><Link style={{color:'#fff'}} to={`/org/areat/info/${this.props.params.id}`}>返回</Link></Button></div>
            </div>
        )
    }
}

export default AreaInfoImage;
