/*
 * @Author: szj
 * @Date: 2017-04-06 14:01:51 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 11:34:52
 */

import React, { Component } from 'react';
// import { BaiduMap } from 'react-baidu-map';
import { observer } from 'mobx-react';
import { extendObservable, action } from 'mobx';
import { Link } from 'react-router';
import { notification, Icon , Row, Col, DatePicker, Button, Radio, Card, Form, message } from 'antd';
import { browserHistory } from 'react-router';
import moment from 'moment';
import echarts from 'echarts';
//import './equipMapMonitore.css';
import QuitScreen from '../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../assets/images/application/shut-o.png';
import UnAlarm from '../../../assets/images/application/探测.png';
import Alarm from '../../../assets/images/application/探测.png';
import Watch from '../../../assets/images/application/监控.png';
import Remind from '../../../assets/images/application/提醒.png';
import Delete from '../../../assets/images/application/删除.png';
import Up from '../../../assets/images/application/up.png';
import Down from '../../../assets/images/application/down.png';
import $ from 'jquery';
import ico_image from '../../../assets/images/monitoring/全屏-icon.png';

const FormItem = Form.Item;
const { RangePicker } = DatePicker;

let arrFlag = 0;
const openNotification = (data) => {
  notification.open({
    message: data,
    icon: <Icon type="smile-circle" style={{ color: '#108ee9' }} />,
    placement: 'bottomRight',
    duration: 30,
    onClose: function () {

    }
  });
};
function createMarkup() {
  return { __html: 'First &middot; Second' };
}


class deviceState {
  // @observable me = {};
  // @observable patrolData = [{key: 1, value: 5, name: '任务完成数', selected: true },{key: 2, value: 2, name: '任务逾期数' }];
  // @observable patrolData3 = [[51, 43,54,55,58,41,43],[31,24,55,38,41,43,45],[41,34,12,28,41,43,25]];
  // @observable periods = [];
  // @observable periodsTime = [];
  // @observable periodsScore = [];

  constructor() {
    extendObservable(this, {
        me: {},
        patrolData: [{key: 1, value: 5, name: '任务完成数', selected: true },{key: 2, value: 2, name: '任务逾期数' }],
        patrolData3: [[51, 43,54,55,58,41,43],[31,24,55,38,41,43,45],[41,34,12,28,41,43,25]],
        periods: [],
        periodsTime: [],
        periodsScore: [],
        addPatrolUp: action(function(time = 'month') {
          switch (time) {
            case 'month':
              {
                this.periods = [moment().format('YYYY-MM')];
                this.periodsTime = [1];
                this.periodsScore = [100];
              }
              break;
            case 'quater':
              {
                // console.log();
                let arr = [];
                for(let i = 0; i < 3; i++){
                  arr.unshift(moment().subtract(i, 'month').format('YYYY-MM'))
                }
                this.periods = arr;
                this.periodsTime = [30,29,1];
                this.periodsScore = [100,99,98];
              }
              break;
            case 'year':
              {
                let arr = [];
                for(let i = 0; i < 12; i++){
                  arr.unshift(moment().subtract(i, 'month').format('YYYY-MM'))
                }
                this.periods = arr;
                this.periodsTime = [30,28,26,25,28,30,29,26,25,28,29,1];
                this.periodsScore = [100,99,96,54,88,60,11,66,88,77,88];
              }
              break;
            default:
              {
                console.log('haha!');
              }
              break;
          }

          let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
              
          myChartOne.setOption({
            title : {
              text: '出勤次数',
              textStyle: {
                font: '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {
              trigger: 'axis'
            },
            color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
            legend: {
              orient: 'horizontal',
              x: 'right',
              data:['出勤次数']
            },
            calculable : true,
            xAxis : [
              {
                type : 'category',
                /**此处应该是从外面传来的参数，最近7天 */
                data : [...this.periods]
              }
            ],
            yAxis : [
              {
                type : 'value',
                splitLine: {
                  show: false
                },
              }
            ],
            series : [
              {
                name:'出勤次数',
                type:'bar',
                barWidth: 15,
                /** 从后台拿数据*/
                data:[...this.periodsTime],
              }
            ]
          });

          let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));

          if( time === 'month'){
            myChartTwo.setOption({
              title: {
                text: '任务完成率' ,
                textStyle: {
                  font: '14px 微软雅黑 Light',               
                  color: "#666666"
                }
              },
              tooltip: {},
              color: ['#74cb62', '#32b3f2', '#8387c3'],
              series: [{
                name:'任务完成率',
                type:'pie',
                selectedMode: 'single',
                radius: ['0', '48%'],
                center: ['50%', '52%'],
                data: [...this.patrolData],
                itemStyle: {
                  emphasis: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                  },
                  normal: {
                    label: {
                      show: true,
                      //position:'inside',
                      formatter: '{b} \n\n {c}个 \n\n({d}%)',
                      textStyle : {
                        fontSize : '14',
                        fontFamily:'幼圆',
                        fontWeight:'bold'
                      }
                    }
                  }
                      /*labelLine: { show: true }*/
                },
              }]
            });
          }else {
            myChartTwo.setOption({
              title: {
                text: '任务完成率',
                textStyle: {
                  font:  '14px 微软雅黑 Light',               
                  color: "#666666"
                }
              },
              tooltip: {
                trigger: 'axis'
              },
              color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
              legend: {
                orient: 'horizontal',
                x: 'right',
                right: '50px',
                data: ['任务完成率']
              },
              /**网格 */
              grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
              },
              xAxis: {
                type: 'category',//category  种类
                boundaryGap: false,
                /*设置此处横的网格线不显示*/ 
                splitLine: {
                  show: false
                },
                data: [...this.periods]
              },
              yAxis: {
                type: 'value',
                splitLine: {
                  show: false
                },
              },
              series: [
                {
                  name:'任务完成率',
                  type:'line',
                  data:[...this.periodsTime]
                }
              ]
            });
          }

          let myChartThree = echarts.init(document.getElementById('DeviceTypeMountEcharts03'));
          myChartThree.setOption({
            title : {
              text: '得分',
              textStyle: {
                font: '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {
              trigger: 'axis'
            },
            color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
            legend: {
              orient: 'horizontal',
              x: 'right',
              data:['得分']
            },
            calculable : true,
            xAxis : [
              {
                type : 'category',
                /**此处应该是从外面传来的参数，最近7天 */
                data : [...this.periods]
              }
            ],
            yAxis : [
              {
                type : 'value',
                splitLine: {
                  show: false
                },
              }
            ],
            series : [
              {
                name:'得分',
                type:'bar',
                barWidth: 15,
                /** 从后台拿数据*/
                data:[...this.periodsScore],
              }
            ]
          });
        })
    })
  }
}

const TrendSearchFormUp = Form.create()(React.createClass({
  handleSearch(e) {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['field-5'];
        // const values = {
        //   'field-5': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
        // }
        // console.log('Received values of form: ', values);
        const start = moment(rangeValue[0].format('YYYY-MM-DD'));
        const end = moment(rangeValue[1].format('YYYY-MM-DD'));
        const diff = end.diff(start, 'month') + 1;

        let arr = [];
        let arrTime = [];
        let arrScore = [];
        for(let i = 0; i < diff; i++){
          arr.unshift(moment(rangeValue[1].format('YYYY-MM-DD')).subtract(i, 'month').format('YYYY-MM'));
          arrTime.unshift(Math.floor(Math.random() * 30));
          arrScore.unshift(Math.floor(Math.random() * 100));
        }

        this.props.deviceState.periods = arr;
        this.props.deviceState.periodsTime = arrTime;
        this.props.deviceState.periodsScore = arrScore;

        let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
            
        myChartOne.setOption({
          title : {
            text: '出勤次数',
            textStyle: {
              font: '14px 微软雅黑 Light',               
              color: "#666666"
            }
          },
          tooltip: {
            trigger: 'axis'
          },
          color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
          legend: {
            orient: 'horizontal',
            x: 'right',
            data:['出勤次数']
          },
          calculable : true,
          xAxis : [
            {
              type : 'category',
              /**此处应该是从外面传来的参数，最近7天 */
              data : [...this.props.deviceState.periods]
            }
          ],
          yAxis : [
            {
              type : 'value',
              splitLine: {
                show: false
              },
            }
          ],
          series : [
            {
              name:'出勤次数',
              type:'bar',
              barWidth: 15,
              /** 从后台拿数据*/
              data:[...this.props.deviceState.periodsTime],
            }
          ]
        });

        let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));

        if( diff === 1 ){
          myChartTwo.setOption({
            title: {
              text: '任务完成率' ,
              textStyle: {
                font: '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {},
            color: ['#74cb62', '#32b3f2', '#8387c3'],
            series: [{
              name:'任务完成率',
              type:'pie',
              selectedMode: 'single',
              radius: ['0', '48%'],
              center: ['50%', '52%'],
              data: [...this.props.deviceState.patrolData],
              itemStyle: {
                emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                },
                normal: {
                  label: {
                    show: true,
                    //position:'inside',
                    formatter: '{b} \n\n {c}个 \n\n({d}%)',
                    textStyle : {
                      fontSize : '14',
                      fontFamily:'幼圆',
                      fontWeight:'bold'
                    }
                  }
                }
                    /*labelLine: { show: true }*/
              },
            }]
          });
        }else {
          myChartTwo.setOption({
            title: {
              text: '任务完成率',
              textStyle: {
                font:  '14px 微软雅黑 Light',               
                color: "#666666"
              }
            },
            tooltip: {
              trigger: 'axis'
            },
            color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
            legend: {
              orient: 'horizontal',
              x: 'right',
              right: '50px',
              data: ['任务完成率']
            },
            /**网格 */
            grid: {
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true
            },
            xAxis: {
              type: 'category',//category  种类
              boundaryGap: false,
              /*设置此处横的网格线不显示*/ 
              splitLine: {
                show: false
              },
              data: [...this.props.deviceState.periods]
            },
            yAxis: {
              type: 'value',
              splitLine: {
                show: false
              },
            },
            series: [
              {
                name:'任务完成率',
                type:'line',
                data:[...this.props.deviceState.periodsTime]
              }
            ]
          });
        }

        let myChartThree = echarts.init(document.getElementById('DeviceTypeMountEcharts03'));
        myChartThree.setOption({
          title : {
            text: '得分',
            textStyle: {
              font: '14px 微软雅黑 Light',               
              color: "#666666"
            }
          },
          tooltip: {
            trigger: 'axis'
          },
          color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
          legend: {
            orient: 'horizontal',
            x: 'right',
            data:['得分']
          },
          calculable : true,
          xAxis : [
            {
              type : 'category',
              /**此处应该是从外面传来的参数，最近7天 */
              data : [...this.props.deviceState.periods]
            }
          ],
          yAxis : [
            {
              type : 'value',
              splitLine: {
                show: false
              },
            }
          ],
          series : [
            {
              name:'得分',
              type:'bar',
              barWidth: 15,
              /** 从后台拿数据*/
              data:[...this.props.deviceState.periodsScore],
            }
          ]
        });
      });
      message.info('已更新');
    }catch(e) {
      console.log(e)
    }
  },
	onChange(e) {
    const time = e.target.value;
		this.props.deviceState.addPatrolUp(time);
	},
  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0,padding:'15px 0px'}}>
        <Row>
					<Col span={6} key={2}>
						<FormItem>
              <Radio.Group onChange={this.onChange} defaultValue="month">
                <Radio.Button value="month">月</Radio.Button>
                <Radio.Button value="quater">季</Radio.Button>
                <Radio.Button value="year">年</Radio.Button>
              </Radio.Group>
						</FormItem>
					</Col>
          <Col span={14} key={5}>
            <FormItem label={`时间`}>
              {getFieldDecorator(`field-5`)(
                <RangePicker style={{width:300}} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6} style={{float:'right',marginRight:'18px'}}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
               
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}));

// @observer
const DeviceTrendC = observer(class DeviceTrendC extends Component {
	constructor() {
		super();
		this.state = {
			size: 'default'
		};
	}

	componentDidMount(){
    //const id = this.props.params.id||1;
    //const id = 1;
    let str = window.location.href;
    var index = str.lastIndexOf("\/");
    var id = parseInt( str.substring(index + 1, str.length),10);
     const ghost = () => {
        //console.log(id);
        return  window.rpc.user.getArrayByCond({id},0,0)
      }
      const ghosts = async() => {
        const result = await ghost();
        //报警初始数据
        console.log(result);
         const me = {...result[0], attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: result[0].id};
        // console.log(me);
        this.props.deviceState.me = me;
      }
      ghosts();
      
  //  window.rpc.user.getArrayByCond({id},0,0).then((result) => {
  //    console.log(result);
  //     const me = {...result[0], attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: result[0].id};
  //     // console.log(me);
  //     this.props.deviceState.me = me;
  //   }, (err) => {
  //     console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
  //   });
  
		/*图表一*/
		let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
		myChartOne.setOption({
			title : {
				text: '出勤次数',
				textStyle: {
					font: '14px 微软雅黑 Light',               
					color: "#666666"
				}
			},
			tooltip : {
				trigger: 'axis'
			},
			color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
			legend: {
			orient: 'horizontal',
				x: 'right',
				data:['出勤次数']
			},
			calculable : true,
			xAxis : [
				{
					type : 'category',
					/**此处应该是从外面传来的参数，最近7天 */
					data : ['2017-03']
				}
			],
			yAxis : [{
					type : 'value',
					splitLine: {
						show: false
					},
				}
			],
			series : [
				{
					name:'出勤次数',
					type:'bar',
					barWidth: 15,
					/** 从后台拿数据*/
					data:[...this.props.deviceState.patrolData3[0]],
				}
			]
		});

    /*图表二*/
		let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));
		myChartTwo.setOption({
			title: {
				text: '任务完成率' ,
				textStyle: {
					font: '14px 微软雅黑 Light',               
					color: "#666666"
				}
			},
			tooltip: {},
			color: ['#74cb62', '#32b3f2', '#8387c3'],
			series: [{
				name:'任务完成率',
				type:'pie',
				selectedMode: 'single',
				radius: ['0', '48%'],
				center: ['50%', '52%'],
				data: [...this.props.deviceState.patrolData],
				itemStyle: {
					emphasis: {
						shadowBlur: 10,
						shadowOffsetX: 0,
						shadowColor: 'rgba(0, 0, 0, 0.5)'
					},
					normal: {
						label: {
							show: true,
							//position:'inside',
							formatter: '{b} \n\n {c}个 \n\n({d}%)',
							textStyle : {
								fontSize : '14',
								fontFamily:'幼圆',
								fontWeight:'bold'
							}
						}
					}
							/*labelLine: { show: true }*/
				},
			}]
		});

    /*图表三*/
		let myChartThree = echarts.init(document.getElementById('DeviceTypeMountEcharts03'));
    myChartThree.setOption({
			title : {
				text: '得分',
				textStyle: {
					font: '14px 微软雅黑 Light',               
					color: "#666666"
				}
			},
			tooltip : {
				trigger: 'axis'
			},
			color: ['#2db7f5','#7dc856','#808bc6','#f8cb44'],
			legend: {
			orient: 'horizontal',
				x: 'right',
				data:['得分']
			},
			calculable : true,
			xAxis : [
				{
					type : 'category',
					/**此处应该是从外面传来的参数，最近7天 */
					data : ['2017-03']
				}
			],
			yAxis : [{
					type : 'value',
					splitLine: {
						show: false
					},
				}
			],
			series : [
				{
					name:'得分',
					type:'bar',
					barWidth: 15,
					/** 从后台拿数据*/
					data:[...this.props.deviceState.patrolData3[0]],
				}
			]
		});
  }

	render() {
    let me = {...this.props.deviceState.me};
		return (
			<div className="DeviceTrend" style={{padding:'0 12px'}}>
        <div style={{ fontSize: '0.75rem', height: 35,lineHeight:'35px',paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid'}}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/prfrm' style={{ padding: '2px 12px 2px 10px', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0',marginTop:'10px' }}>绩效详情</Link>
          </div>
        </div>
        <Row style={{ padding: '8px 0' }} gutter={16}>
          <Col>
            姓名：{me.name}
          </Col>
        </Row>
				<TrendSearchFormUp deviceState={this.props.deviceState}  />
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<Col span={11} style={{ padding: '-2px'}}>
						<Card style={{ margin: '0 10px 0 12px'}}>
						  <div id="DeviceTypeMountEcharts01" style={{ height: '36vh', width: '100%' }}></div>
						</Card>
					</Col>
         
					<Col span={12}>
						<Card>
							<div id="DeviceTypeMountEcharts02" style={{ height: '36vh', width: '100%'}}></div>
						</Card>
					</Col>
        </Row>
        <Row style={{ padding: '5px 0' }} gutter={16}>
           <Col span={1} style={{ padding: '-2px'}}></Col>
					<Col span={22}>
						<Card style={{ margin: '0 10px 0 20px'}}>
						<div id="DeviceTypeMountEcharts03" style={{ height: '42vh', width: '100%'}}></div>
						</Card>
					</Col>
				</Row>
			</div>
		);
	}
})

class MemberECharts extends Component {
  componentDidMount() {
  }
  render() {
    return (
      <div className="PerformanceDetail" style={{ padding: 0 }}>
        <DeviceTrendC deviceState={new deviceState()} params={this.props.params} />
      </div>
    );
  }
}

class TrackHistory extends Component {
  constructor() {
    super();
    this.state = {
      arr: [],
      display: 0,
      param: []
    }
  }
  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
    // point.lng
    // point.lat
  }
  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
     // script.src="http://api.map.baidu.com/api?v=1.5&ak=YWdGplhYjUGQ3GtpKNeuTM2S"
     //script.src = "http://api.map.baidu.com/api?v=1.4";
      document.body.appendChild(script);
    }
    loadJScript();
  }

  componentDidMount() {
 
    function init() {
      
     //随机数生成
    function getRandom(n){
			return Math.floor(Math.random()*n+1)
		}

		//在轨迹点上创建图标，并添加点击事件，显示轨迹点信息。points,数组。
		function addMarker(points){
			var pointsLen = points.length;
			if(pointsLen == 0){
				return;
			}
			var myIcon = new window.BMap.Icon(`${Alarm}`, new window.BMap.Size(25.6,25.6), {
				offset: new window.BMap.Size(5, 5) 
        
			});

			// 创建标注对象并添加到地图   
			for(var i = 0;i <pointsLen;i++){
				var point = new window.BMap.Point(points[i].lng,points[i].lat);
				var marker = new window.BMap.Marker(point, {icon: myIcon});
        //无真实数据，暂不显示
				//map.addOverlay(marker); 
      
        	(function() {
					var thePoint = points[i];
					marker.addEventListener("click",function(){
           // console.log(i);
					  window.location.href=`/task/report/info/${i+1}`
					});
			})();
			}
		}    

		//添加线
		function addLine(points){

			var linePoints = [],pointsLen = points.length,i,polyline;
			if(pointsLen == 0){
				return;
			}
			// 创建标注对象并添加到地图   
			for(i = 0;i <pointsLen;i++){
				linePoints.push(new window.BMap.Point(points[i].lng,points[i].lat));
			}

			polyline = new window.BMap.Polyline(linePoints, {strokeColor:"red", strokeWeight:2, strokeOpacity:0.5});   //创建折线
		   //	map.addOverlay(polyline);   //增加折线
       //无数据，暂不显示轨迹折线
      
		}
    var Num=1;
		//随机生成新的点，加入到轨迹中。
		function dynamicLine(){
			var lng = 121.618835+Math.random()*0.0004;
			var lat = 29.920698+Math.random()*0.0003;
			var id = getRandom(100);
			var point = {"lng":lng,"lat":lat,"status":1,"id":id}
			var makerPoints = [];
			var newLinePoints = [];
			var len;

			makerPoints.push(point);			
			addMarker(makerPoints);//增加对应该的轨迹点
			points.push(point);
			bPoints.push(new window.BMap.Point(lng,lat));
			len = points.length;
			newLinePoints = points.slice(len-2, len);//最后两个点用来画线。
      //地图坐标 的数组point
			addLine(newLinePoints);//增加轨迹线
			setZoom(bPoints);
	   	//	setTimeout(dynamicLine, 3000);
      if(Num<3){
          setTimeout(dynamicLine, 3000); 
      }
      Num++;
		}

		//根据点信息实时更新地图显示范围，让轨迹完整显示。设置新的中心点和显示级别. 
		//更新。设置不是每次增加点都重新设置显示范围。因为有可能会想放大了看。
		function setZoom(bPoints){
			var view = map.getViewport(eval(bPoints));
			if(map.oldView != JSON.stringify(view)){
				var mapZoom = view.zoom; 
				var centerPoint = view.center; 
				map.centerAndZoom(centerPoint,mapZoom);
				map.oldView = JSON.stringify(view);
			}

		}
    	//数据准备,
    var points = [];//原始点信息数组
		 var bPoints = [];//百度化坐标数组。用于更新显示范围。
     var map = new window.BMap.Map("container");            // 创建Map实例
      var point = new window.BMap.Point(121.618835, 29.920698); // 创建点坐标
      map.centerAndZoom(point,18);                 
      map.enableScrollWheelZoom(); 
     //最先调用的函数 
     setTimeout(dynamicLine, 1000);  
      //   window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
      //   console.log(res);
      //   newId = '';
      //   res.map((x) => {
      //     alarm(Alarm)
      //     mouseoverTxt = x.name;
      //     var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
      //     var content = x.name;
      //     var obj = x;
      //     newId = x.id;
      //     param = { 'floor': newId };
      //     map.addOverlay(maker)// 将标注添加到地图中
      //     addClickHandler(content, param, newId, obj, maker);//生成点处
      //   })
      // },(err) =>{
      //   console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      // })
  //     function addClickHandler(content, param, newId, obj, marker) {
  //       // console.log(param);
  //       //console.log(param+'~~'+content+'~~'+newId) ;   
  //       marker.addEventListener("click", function (e) {
  //         createDom(newId);
  //         console.log('dislpay:none');
  //         //  CardDisplay();
  //       function createDom(newId){
  //         console.log(newId);
  //         window.rpc.user.getInfoById(1).then((res) => {
  //           console.log(res);
  //           let obj1={
  //             name:res.name,
  //             num:res.number,
  //             email:res.email,//加密处理
  //             groupId:res.ownerId,//在请求
  //             number:""
  //           }
  //        },(err) =>{
  //           console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
  //         });
  //     }
  //  })
  // }
 }
    setTimeout(() => {
      init();
    }, 1000)
} 
  render() {
    //console.log(arrFlag);
    return (
     <div style={{position:'relative',width:'100%',height:'100%'}}>
        <div style={{ position: 'absolute', right: 0, top: 0, zIndex: 999, display: this.state.isShow }} >
          <span className="new-button" style={{display:'inline-block', background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden',padding:'0 5px'  }}><img src={QuitScreen} alt="" style={{ marginTop: 8, marginRight: 2, float: 'left' }} /><Link to='/safecenter' style={{ color: '#fff' }}>退出全屏</Link></span>
          <span className="new-button" style={{display:'inline-block', marginLeft:12,background: 'rgba(55, 61, 65,.8)', overflow: 'hidden',width:102,padding:'0 5px' }}><img src={Close} alt="" style={{ marginTop: 8, marginRight: 2,marginLeft:2, float: 'left' }} /><Link to='/apply/duty' style={{ color: '#fff' }}>返回执勤页面</Link></span>
        </div>
        <div style={{width:'40%',height:'100%',position:'absolute',backgroundColor:"#fff",zIndex:"9"}}>
           <MemberECharts />
        </div>        
       <div id="container" style={{width:'100%',height:'100%'}}></div>    
     </div>
    );
  }
}

export default TrackHistory;