/*
 * @Author: lai.haibo 
 * @Date: 2017-04-20 09:06:42 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 11:35:20
 */

import React, { Component } from 'react';
import './equipCenter.css';
import { Link, browserHistory } from 'react-router';

// import { BaiduMap } from 'react-baidu-map';
import { notification, Icon, Row, Col, Card, Button } from 'antd';
import UnAlarm from '../../../assets/images/equipment/unalarm.png';
import Alarm from '../../../assets/images/equipment/1.png';
import Music from '../../../assets/6709.mp3';
var audio;
const openNotification = (data) => {
  notification.open({
    message: data,
    icon: <Icon type="smile-circle" style={{ color: '#108ee9' }} />,
    placement: 'bottomRight',
    duration: 30,
    onClose:function(){
      audio.pause();
    }
  });
};

class EquipCenter extends Component {
  state = {
    allDeviceCount: 0,
    commonDeviceCount: 0,
    erroeDeviceCount: 0,
    alarmCount: {
      1: 0,
      2: 0,
      3: 0
    },
    patrolCount: {
      1: 0,
      2: 0,
      3: 0
    }
  }
  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
    // point.lng
    // point.lat
  }
  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    // console.log(document.getElementById('equipCenterMap'))
    loadJScript();
  }

  componentDidMount() {
    // const getAllDevice = () => {
    //   return window.rpc.device.getArray(0, 0);
    // }

    const getAllDeviceCount = () => {
      return window.rpc.device.getCount();
    }

    const getCommonDeviceCount = () => {
      return window.rpc.device.getCountByCond({rstate: 1});
    }

    const getErroeDeviceCount = () => {
      return window.rpc.device.getCountByCond({rstate: 2});
    }

    // const getArea = () => {
    //   return window.rpc.area.getArray(0, 0);
    // }

    const getAlarm = () => {
      return window.rpc.device.alarm.getFieldCountByContainer(null, 'type');
    }

    const getPatrol = () => {
      return window.rpc.device.patrol.getFieldCountByContainer(null, 'type');
    }

    const initC = async () => {
      try {
        // const allDevice = await getAllDevice();
        const commonDeviceCount = await getCommonDeviceCount();
        const allDeviceCount = await getAllDeviceCount();
        const erroeDeviceCount = await getErroeDeviceCount();
        // const area = await getArea();

        const alarmCount = await getAlarm();
        const patrolCount = await getPatrol();
        
        this.setState({ allDeviceCount, commonDeviceCount, erroeDeviceCount });
        this.setState({ alarmCount });
        this.setState({ patrolCount });
      } catch (err) {
        console.log(err);
      }
    }

    initC();

    function init() {
      let newId = [], param = '';
      function callBack(data) {
        // console.log(data);
        sessionStorage.setItem('flag', 1)
        audio = new Audio(Music);
        audio.loop='loop';
        audio.play();
        newId = [];
        window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
          res.forEach(function (value) {
            data.forEach(function (x) {
              if (value.id === x.floor) {
                openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
                alarm(Alarm);
                mouseoverTxt = x.locationName.slice(0, x.locationName.indexOf(','));
                var maker = new ComplexCustomOverlay(new window.BMap.Point(x.floorX, x.floorY), value.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  id: newId
                };
                map.addOverlay(maker)// 将标注添加到地图中
                addClickHandler(content, param, newId, obj, maker);
              }
            })
          })
        },(err) =>{
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
      }
      window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
      window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);

      var map = new window.BMap.Map("equipCenterMap");
      var point = new window.BMap.Point(121.618835,
        29.920698);
      map.centerAndZoom(new window.BMap.Point(116.3964, 39.9093), 15);
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';

      function setPlace() {
        map.clearOverlays();    //清除地图上所有覆盖物
        function myFun() {
          var pp = local.getResults().getPoi(0).point;    //获取第一个智能搜索的结果
          map.centerAndZoom(pp, 18);
          map.addOverlay(new window.BMap.Marker(pp));    //添加标注
        }
        var local = new window.BMap.LocalSearch(map, { //智能搜索
          onSearchComplete: myFun
        });
        local.search(myValue);
      }

      // function myFun(result) {
      //   var cityName = result.name;
      //   map.setCenter(cityName);
      // }
      // var myCity = new window.BMap.LocalCity();
      // myCity.get(myFun);
      map.centerAndZoom(point, 12);
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
      // 编写自定义函数,创建标注
      map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 11);
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);
      function G(id) {
        return document.getElementById(id);
      }
      //map.centerAndZoom("宁波", 12);                   // 初始化地图,设置城市和地图级别。
        map.centerAndZoom(point, 18);
        map.addControl(new  window.BMap.MapTypeControl({mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP]}));        
      var ac = new window.BMap.Autocomplete(    //建立一个自动完成的对象
        {
          "input": "suggestId"
          , "location": map
        });

      ac.addEventListener("onhighlight", function (e) {  //鼠标放在下拉列表上的事件
        var str = "";
        var _value = e.fromitem.value;
        var value = "";
        if (e.fromitem.index > -1) {
          value = _value.province + _value.city + _value.district + _value.street + _value.business;
        }
        str = "FromItem<br />index = " + e.fromitem.index + "<br />value = " + value;

        value = "";
        if (e.toitem.index > -1) {
          _value = e.toitem.value;
          value = _value.province + _value.city + _value.district + _value.street + _value.business;
        }
        str += "<br />ToItem<br />index = " + e.toitem.index + "<br />value = " + value;
        G("searchResultPanel").innerHTML = str;
      });

      var myValue;
      ac.addEventListener("onconfirm", function (e) {    //鼠标点击下拉列表后的事件
        var _value = e.item.value;
        myValue = _value.province + _value.city + _value.district + _value.street + _value.business;
        G("searchResultPanel").innerHTML = "onconfirm<br />index = " + e.item.index + "<br />myValue = " + myValue;

        setPlace();
      });
      // map.centerAndZoom(new window.BMap.Point(116.417854, 39.921988), 15);
      // var data_info = [[116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
      // [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
      // [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
      // ];
      var opts = {
        width: 100,     // 信息窗口宽度
        height: 50,     // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true//设置允许信息窗发送短息
      };
      function alarm(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          div.appendChild(p);
          span.appendChild(document.createTextNode(this._text));
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
        // console.log(res)
        newId = '';
        res.map((x) => {
          alarm(UnAlarm)
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          map.addOverlay(maker)// 将标注添加到地图中
          addClickHandler(content, param, newId, obj, maker);
        })
      },(err) =>{
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })

      function addClickHandler(content, param, newId, obj, marker) {

        marker.addEventListener("click", function (e) {
          sessionStorage.setItem('newId',newId)
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            window.location.href = '/equip';
          },(err) =>{
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
        }
        );
      }
      function openInfo(content, e) {
        var p = e.target;
        var point = new window.BMap.Point(p.getPosition().lng, p.getPosition().lat);
        var infoWindow = new window.BMap.InfoWindow(content, opts);  // 创建信息窗口对象 
        map.openInfoWindow(infoWindow, point); //开启信息窗口
      }
    }
    setTimeout(() => {
      init();
    }, 1000)
  }
  render() {
    return (
      <div className="EquipCenter">
        <div className="banner" style={{height:100,lineHeight:"100px",backgroundColor:'#f9f9fa',position:"relative"}}>
          <p style={{fontSize:'1.5rem',fontFamily:'微软雅黑 regular'}}>设备统一管理</p>
          <div className="backToBack" onClick={() => browserHistory.push('/safecenter') }>
          </div>
        </div>
        <div style={{fontSize:"0.875em",color:'#3333d41',fontFamily:'苹方中等 Sansation Regula'}}>
          <p style={{margin:'18px 0 18px',padding:'2px  0 2px 10px',borderLeft:'2px solid #0099cc',}}>设备统一</p>
          <p style={{height:38,lineHeight:'38px',border:'1px solid #ccc',paddingLeft:'10px'}}>设备总数<span><Link to="/equip/manage">{this.state.allDeviceCount}</Link></span>个，设备正常<span><Link to="/equip/manage/ok">{this.state.commonDeviceCount}</Link></span>个，设备异常<span><Link to="/equip/manage/error">{this.state.erroeDeviceCount}</Link></span>个</p>
        </div>
        <Row gutter={16}>
          <Col span={18}>
            <div style={{fontSize:"0.875em",color:'#3333d41',fontFamily:'苹方中等 Sansation Regula'}}>
              <p style={{margin:'18px 0 18px',padding:'2px  0 2px 10px',borderLeft:'2px solid #0099cc',}}>设备概况</p>
            </div>
            <div id="equipCenterMap" style={{ height: '987px' }}></div>
          </Col>
          <Col span={6}>
            <div style={{fontSize:"0.875em",color:'#3333d41',fontFamily:'苹方中等 Sansation Regula'}}>
              <p style={{margin:'18px 0 18px',padding:'2px  0 2px 10px'}}>报警概况</p>
            </div>
            <Card className="equipFire" style={{ height:146 }}><div><p>火警</p><p>{this.state.alarmCount[1] || 0}</p><p><Button type="primary" ghost onClick={() => browserHistory.push(`/equip/warning/1`)}>立即查看</Button></p></div></Card>
            <Card className="equipEvent" style={{ height:146 }}><div><p>事件</p><p>{this.state.alarmCount[2] || 0}</p><p><Button onClick={() => browserHistory.push(`/equip/warning/2`)}>立即查看</Button></p></div></Card>
            <Card className="equipError" style={{ height:146 }}><div><p>异常</p><p>{this.state.alarmCount[3] || 0}</p><p><Button onClick={() => browserHistory.push(`/equip/warning/3`)}>立即查看</Button></p></div></Card>
            <div style={{fontSize:"0.875em",color:'#3333d41',fontFamily:'苹方中等 Sansation Regula'}}>
              <p style={{margin:'18px 0 18px',padding:'2px  0 2px 10px'}}>维护概况</p>
            </div>
            <Card className="equipPatril" style={{ height:146 }}><div><p>巡查</p><p>{this.state.patrolCount[1] || 0}</p><p><Button onClick={() => browserHistory.push(`/equip/preserve/1`)}>立即查看</Button></p></div></Card>
            <Card className="equipMaintain" style={{ height:146 }}><div><p>保养</p><p>{this.state.patrolCount[2] || 0}</p><p><Button onClick={() => browserHistory.push(`/equip/preserve/2`)}>立即查看</Button></p></div></Card>
            <Card className="equipTest" style={{ height:146 }}><div><p>检测</p><p>{this.state.patrolCount[3] || 0}</p><p><Button onClick={() => browserHistory.push(`/equip/preserve/3`)}>立即查看</Button></p></div></Card>
          </Col>
        </Row>
      </div>
    );
  }
}


export default EquipCenter;