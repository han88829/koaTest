import React, { Component } from 'react';
import { Row, Col, Card, Layout } from 'antd';
import AlarmConcenBasicMes from '../AlarmSix/AlarmConcenBasicMes';
import AlarmConcenRoute from '../AlarmSix/AlarmConcenRoute';
import AlarmConcenResources from '../AlarmSix/AlarmConcenResources';

class ALarmOne extends Component {
  render() {
    return (
      <Row gutter={8} >
        <Col span={24} style={{ display: 'calc(100vh - 90px)'}}>
          <Row gutter={8} style={{ height: 'calc(100vh - 90px)', color: '#FFF' }}>
            <Col span={20} style={{ height: 'calc(33vh - 43px)', width: '100%',  }}>
              <Card style={{ height: 'calc(33vh - 43px)', padding: '0', position: 'relative' }} >
                {/*<span onClick={() => browserHistory.push(`/apply/alarmbasicmes/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>*/}
                <span style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>
                <AlarmConcenBasicMes params={this.props.params} id={this.props.id} />
              </Card>
            </Col>
            <Col span={20} style={{ height: 'calc(33vh - 43px)', width: '100%', marginTop: 24,  }}>
              <Card style={{ height: 'calc(33vh - 43px)', padding: '0', position: 'relative' }} >
                {/*<span onClick={() => browserHistory.push(`/apply/alarmroute/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>*/}
                <span  style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>
                <AlarmConcenRoute />
              </Card>
            </Col>
            <Col span={20} style={{ height: 'calc(33vh - 43px)', width: '100%', marginTop: 24, }}>
              <Card style={{ height: 'calc(33vh - 43px)', padding: '0', position: 'relative' }} >
                {/*<span onClick={() => browserHistory.push(`/apply/alarmsources/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>*/}
                <span  style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>
                <AlarmConcenResources params={this.props.params} mesid={this.props.id} />
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    )
  }
}

export default ALarmOne;