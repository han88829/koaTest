import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Link, browserHistory } from 'react-router';
import { Input, Progress, Icon, Modal, Button } from 'antd';
import moment from 'moment';
import echarts from 'echarts';
import BuildImg from './BuildImg';
import './EquipRight.css';
import WarningDeviceList  from '../AlarmSix/InfoDisplay/WarningDeviceList';
import FalseWarningList  from '../AlarmSix/InfoDisplay/FalseWarningList';
import DeviceList  from '../AlarmSix/InfoDisplay/DeviceList';
import MalfunctionList  from '../AlarmSix/InfoDisplay/MalfunctionList';
import imgOne from '../../../../assets/images/apply/设备总数.png';
import imgTwo from '../../../../assets/images/apply/故障数目.png';
import imgalarm from '../../../../assets/images/apply/alarm.png';
import imgL from '../../../../assets/images/apply/故障率-o.png';
import imgT from '../../../../assets/images/apply/设备总数-o.png';
import imgN from '../../../../assets/images/apply/故障数目-0.png';
import closeBtn from '../../../../assets/images/apply/收缩.png';

import fireSum from '../../../../assets/images/apply/报警-(6).png';
import errorSum from '../../../../assets/images/apply/误报.png';
import fireRate from '../../../../assets/images/apply/火警.png';
import QuitScreen from '../../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../../assets/images/application/shut-o.png';

import sbTong from '../../../../assets/images/apply/equip/设备统计.png';
import qushi from '../../../../assets/images/apply/equip/趋势分析.png';
import baojing from '../../../../assets/images/apply/equip/报警统计.png';
import jingqing from '../../../../assets/images/apply/equip/警情分析.png';
import jichu from '../../../../assets/images/apply/equip/基础信息.png';
import xiaofang from '../../../../assets/images/apply/equip/消防信息.png';
import jianzhu from '../../../../assets/images/apply/equip/建筑物参数.png';
import pingmian from '../../../../assets/images/apply/equip/楼层平面图.png';

class appState {
  constructor() {
    extendObservable(this, {
      newId: JSON.parse(sessionStorage.getItem('newId'), 10) || null,
    })
  }
}
const EquipRight = observer(class appState extends React.Component {
  state = {

    warningInfo:'none',
    deviceInfo:'none',
    malDeviceInfo:'none',
    FalseWarningInfo:'none',
    deviceSum: 1,
    deviceError: 1,
    lastDeviceError: 1,
    building: this.props.building,
    fire: true,
    basic: true,
    count: true,
    count2: true,
    build: true,
    picture: true,
    anylize: true,
    anylize2: true,
    toFSum: 0,
    toFErr: 0,
    toFRate: 0,
    toFRateToLast: 0,
    toFRateUp: true,
    visible: false,
    new_pingmiantu: false,
    mapPoints: [],
    mapPointsIcon: [],
    types: []
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    this.setState({
      visible: false,
    });
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  handlePoints(id) {

  }

  componentWillReceiveProps(nextProps) {
    this.setState({ building: nextProps.building })
    this.setState({ building: nextProps.building });
    let id = this.props.id;
    let myChartTwo = echarts.init(document.getElementById('right_anylize'));

    myChartTwo.setOption({
      tooltip: {
        trigger: 'axis',
      },
      backgroundColor: '#9fb1d0',
      legend: {
        data: ['故障', '报警'],
        x: 'left'
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      toolbox: {
        feature: {
          saveAsImage: {}
        }
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['4.1', '4.2', '4.3', '4.4', '4.5', '4.6', '4.7']
      },
      yAxis: {
        type: 'value'
      },
      series: [
        {
          name: '故障',
          type: 'line',
          stack: '总量',
          data: [120, 132, 101, 134, 90, 230, 210]
        },
        {
          name: '报警',
          type: 'line',
          stack: '总量',
          data: [220, 182, 191, 234, 290, 330, 310]
        }
      ]
    });

  }
  //componentWillReceiveProps(){
  componentDidMount() {
    setTimeout(() => {
      let id = this.props.id;

      const getDeviceSum = () => {
        return window.rpc.device.getArray(0, 0);
      }

      const getDeviceErrorbyPeriods = (obj) => {
        return window.rpc.device.getCountByContainer(obj);

      }

      window.rpc.device.types.getArray(0, 0).then((res) => {
        let types = {};
        for (let value of res) {
          types[value.id] = value.name
        }
        this.setState({ types });
      });

      const getFirebyPeriods = (obj) => {
        return window.rpc.device.alarm.getCountFieldByContainer(obj, 'type')
      }

      let today = parseInt(moment().days(), 10);
      let lastWeek = [new Date(moment().subtract(today + 7, 'days').format('YYYY-MM-DD')), new Date(moment().subtract(today + 1, 'days').format('YYYY-MM-DD'))]
      let toWeek = [new Date(moment().subtract(today - 1, 'days').format('YYYY-MM-DD')), new Date()]

      const setSum = async () => {
        try {

          let sum = await getDeviceSum();
          let lastErr = await getDeviceErrorbyPeriods({ rstate: 2, createTime: lastWeek });
          let toErr = await getDeviceErrorbyPeriods({ rstate: 2, createTime: toWeek });
          this.setState({
            deviceSum: sum.length,
            lastDeviceError: lastErr,
            deviceError: toErr
          })

        } catch (error) {
          console.warn(error);
        }
      }

      const setFire = async () => {
        try {
          let lastErr = await getFirebyPeriods({ alarm: { lastTime: lastWeek } });
          let toErr = await getFirebyPeriods({ alarm: { lastTime: toWeek } });
          let toFire = toErr[1] ? toErr[1] : 0;
          let toFireErr = toErr[2] ? toErr[2] : 0;
          let toFireTest = toErr[3] ? toErr[3] : 0;
          let laFire = lastErr[1] ? lastErr[1] : 1;
          let toSum = toFire + toFireErr + toFireTest;

          this.setState({
            toFSum: toSum,
            toFErr: toFireErr,
            toFRate: toSum === 0 ? 0 : (toFire / toSum),
            toFRateToLast: (toFire - laFire) / laFire,
            toFRateUp: laFire > toFire ? false : true
          })
        } catch (error) {
          console.warn(error);
        }
      }

      setSum();
      setFire();

      // 报警
      let flag = 1, switcs = null;
      const before = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate() - 6);
      const now = moment(new Date()).format('YYYY-MM-DD')
      let number = [];
      window.rpc.alias.getValueByName('device.alarm.type').then(result => {
        return window.rpc.device.alarm.getTrendCountTypeByContainer({ createTime: [new Date(before), new Date(now)] }, 'date').then(data => { return { result, data } })
      }).then(ress => {
        const data = ress.result;
        const res = ress.data;
        const dataYarr = [], arr = [], nameArr = [], dates = [], tableDate = [], dataArr = [], nameTable = [];
        for (let i in res) {
          nameArr.push(res[i])
        }

        for (let i = 6; i >= 0; i--) {
          (function () {
            dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() + 1).toString().length === 1 ? '0' + (new Date().getMonth() + 1) : (new Date().getMonth() + 1)}-${((new Date().getDate() - i).toString().length === 1 ? '0' + (new Date().getDate() - i) : (new Date().getDate() - i))}`)
          })(i)
        }

        for (let j in data) {
          nameTable.push(data[j])
          dataArr.forEach((x, i) => {
            dataYarr.push([x, data[j]]);
          })
        }

        for (let i in res) {
          for (let j in data) {
            for (let z in res[i]) {
              if (z == j) arr.push({ name: i, value: res[i] })
              else arr.push({ name: j, value: { [j]: 0 } })
              tableDate.push({ name: data[i], data: [] })
            }
          }
        }


        if (arr.length > 0) {
          dataYarr.forEach((x, index) => {
            arr.forEach((y, i) => {
              if (y.name === x[0]) {
                for (let z in y.value) {
                  if (data[z] === x[1]) {
                    dataYarr[index].push(y.value[z])
                    break;
                  } else {
                    dataYarr[index].push(0)
                    break;
                  }
                }
              } else {
                if (switcs !== index) {
                  flag = 1;
                  dataYarr[index].push(0);
                } else {
                  flag = 0;
                }
                switcs = index;
              }
            })
          })
        } else {
          dataYarr.forEach((y, i) => {
            dataYarr[i].push(0);
          })
        }

        //时间组成方法
        let nDtate = [];

        dataYarr.forEach((x, i) => {
          if (x.length > 3) {
            if (x[2] > 0) {
              x.splice(3, 1)
            } else {
              x.splice(2, 1)
            }
          }
          var type = x[1];
          x[1] = x[2];
          x[2] = type;
          nDtate.push(x[1])
        })


        let num = 0, valuename = 0;

        for (var i = 0; i < nameTable.length; i++) {
          for (var j = valuename * 7; j < nDtate.length; j++) {
            num += nDtate[j];
            if (j % 7 === 0 && j !== 0) {
              number.push({ key: i, value: num, name: nameTable[i] })
              num = 0;
              valuename++;
              break;
            } else if (j === (parseInt(nDtate.length) - 1)) {
              number.push({ key: i, value: num, name: nameTable[parseInt(nameTable.length) - 1] })
            }
          }
        }
        //console.log(dataYarr)
        let myChart2 = echarts.init(document.getElementById('right_fire_any'));

        myChart2.setOption({
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'line',
              lineStyle: {
                color: 'rgba(0,0,0,0.2)',
                width: 1,
                type: 'solid'
              }
            }
          },

          legend: {
            data: nameArr
          },

          singleAxis: {
            top: 50,
            bottom: 50,
            axisTick: {},
            axisLabel: {},
            type: 'time',
            axisPointer: {
              animation: true,
              label: {
                show: true
              }
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed',
                opacity: 0.2
              }
            }
          },
          backgroundColor: '#9fb1d0',
          series: [
            {
              type: 'themeRiver',
              itemStyle: {
                emphasis: {
                  shadowBlur: 20,
                  shadowColor: 'rgba(0, 0, 0, 0.8)'
                }
              },
              data: dataYarr
            }
          ]
        });
      })
    }, 500)

  }
  hrefDeviceWarning() {
    //setState 关于警情的显示隐藏
    this.setState({ warningInfo: 'block' });
  }


  render() {
    let types = this.state.types;
    return (
      <div className="EquipRight" style={{ backgroundColor: "#060514" }}>
        <div className="right-search">
          <Input placeholder="搜索" value={this.props.id} style={{ display: 'none' }} />
        </div>
        <div style={{ display: this.state.warningInfo, position: 'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff' }}>
          <div className="pingmiantu-top" style={{ float: 'right' }}>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState({ warningInfo: 'none' })}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <WarningDeviceList />
        </div>
        <div style={{display:this.state.deviceInfo,position:'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff'}}>
          <div className="pingmiantu-top" style={{float:'right'}}>
              <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState({ deviceInfo:'none'})}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <DeviceList  />
        </div>
       
         <div style={{ display: this.state.FalseWarningInfo , position: 'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff' }}>
          <div className="pingmiantu-top" style={{ float: 'right' }}>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState({ FalseWarningInfo: 'none' })}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          < FalseWarningList  />
        </div>
       <div style={{display:this.state.malDeviceInfo,position:'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff'}}>
          <div className="pingmiantu-top" style={{float:'right'}}>
              <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState({ malDeviceInfo:'none'})}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <MalfunctionList id={3} />
        </div>
        <div className="right-count" style={{ height: this.state.count ? 250 : 24 }}>
          <div className="right-anylize-one" style={{ color: '#9acad1', fontSize: `14px` }}>
            <span>
              <img src={sbTong} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left" }}>设备统计</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ count: !prevState.count }))}>
              <img src={closeBtn} alt="close" />
            </span>
          </div>
          <div className="right-countOne" style={{ display: this.state.count ? 'block' : 'none' }}>
            <div className="countOne">
              <img src={imgT} alt="" />
            </div>

            <div className="countTwo" >设备总数（个）: <p style={{ color: '#00c1d1' }}><Link to=""  onClick={() => this.setState({deviceInfo:'block'})} style={{ color: '#00c1d1', fontFamily: "Sansation-Regular" }}>{this.state.deviceSum}</Link></p></div>

          </div>
          <div className="right-countTwo" style={{ display: this.state.count ? 'block' : 'none' }}>
            <div className="countOne">
              <img src={imgN} alt="" />
            </div>
            <div className="countTwo">故障数目（个）:<p style={{ color: '#00c1d1' }}><Link to="" onClick={() => this.setState({malDeviceInfo:'block'})} style={{ color: '#00c1d1', fontFamily: "Sansation-Regular" }}>{this.state.deviceError}</Link></p></div>
          </div>
          <div className="right-countThree" style={{ display: this.state.count ? 'block' : 'none' }}>
            <div className="countOne">
              <img src={imgL} alt="" />
            </div>
            <div className="countTwo" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div style={{ color: '#00c1d1' }}>
                故障率:<p style={{ color: '#00c1d1', fontFamily: "Sansation-Regular" }}> {Math.floor(parseFloat(this.state.deviceError / this.state.deviceSum * 100))} %</p>
              </div>
              <div>
                <Icon type={this.state.lastDeviceError > this.state.deviceError ? "caret-up" : 'caret-down'} style={{ marginRight: 6, fontSize: 12, transform: 'scale(0.75)' }} /><span style={{ color: '#00c1d1', marginRight: 24, fontFamily: "Sansation-Regular" }}>{Math.floor(parseFloat((this.state.deviceError - this.state.lastDeviceError) / (this.state.lastDeviceError === 0 ? 1 : this.state.lastDeviceError) * 100))}%</span><span>同比上周</span>
              </div>
            </div>
            <div className="countThree">
              <div className="count3progress">
                <div className="count3progress-w" style={{ width: Math.floor(parseFloat(this.state.deviceError / this.state.deviceSum) * 276) > 27 ? Math.floor(parseFloat(this.state.deviceError / this.state.deviceSum) * 276) : 27 }}><span style={{ marginRight: 3 }}>{Math.floor(parseFloat(this.state.deviceError / this.state.deviceSum * 100))}%</span></div>
              </div>
            </div>
          </div>
        </div>
        <div className="right-anylize">
          <div className="right-anylize-one" style={{ color: '#9acad1', fontSize: `14px` }}>
            <span>
              <img src={qushi} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left" }}>趋势分析</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ anylize: !prevState.anylize }))}><img src={closeBtn} alt="close" />
            </span>
          </div>
          <div id="right_anylize" style={{ height: 292, width: '99.9%', display: this.state.anylize ? 'block' : 'none' }}></div>
        </div>
        <div className="right-count" style={{ height: this.state.count2 ? 250 : 24 }}>
          <div className="right-anylize-one" style={{ color: '#9acad1', fontSize: `14px` }}>
            <span>
              <img src={baojing} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left" }}>报警统计</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ count2: !prevState.count2 }))}><img src={closeBtn} alt="close" />
            </span>
          </div>
          <div className="right-countOne" style={{ display: this.state.count2 ? 'block' : 'none' }}>
            <div className="countOne">
              <img src={fireSum} alt="" />
            </div>
            <div className="countTwo" >报警总数（个）: <p style={{ color: '#00c1d1' }}><Link to="" onClick={() => this.setState({ warningInfo: 'block' })} style={{ color: '#00c1d1', fontFamily: "Sansation-Regular" }}>{this.state.toFSum}</Link></p></div>
          </div>
          <div className="right-countTwo" style={{ display: this.state.count2 ? 'block' : 'none' }}>
            <div className="countOne">
              <img src={errorSum} alt="" />
            </div>

            <div className="countTwo">误报数目（个）:<p style={{ color: '#999' }}><Link to=""  onClick={() => this.setState({ FalseWarningInfo:'block'})}>{this.state.toFErr}</Link></p></div>

          </div>
          <div className="right-countThree" style={{ display: this.state.count2 ? 'block' : 'none' }}>
            <div className="countOne">
              <img src={fireRate} alt="" />
            </div>
            <div className="countTwo" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                火警率:<p style={{ color: '#00c1d1', fontFamily: "Sansation-Regular" }}> {Math.floor(parseFloat(this.state.toFRate * 100))} %</p>
              </div>
              <div>
                <Icon type={this.state.toFRateUp ? "caret-up" : 'caret-down'} style={{ marginRight: 6, fontSize: 12, transform: 'scale(0.75)' }} /><span style={{ color: '#00c1d1', fontFamily: "Sansation-Regular", marginRight: 24 }}>{Math.floor(parseFloat(this.state.toFRateToLast))}%</span><span>同比上周</span>
              </div>
            </div>
            <div className="countThree">
              <div className="count3progress">
                <div className="count3progress-w" style={{ width: Math.floor(parseFloat(this.state.toFRate) * 276) > 27 ? Math.floor(parseFloat(this.state.toFRate) * 276) : 27 }}><span style={{ marginRight: 3 }}>{Math.floor(parseFloat(this.state.toFRate * 100))}%</span></div>
              </div>
            </div>
          </div>
        </div>
        <div className="right-anylize">
          <div className="right-anylize-one" style={{ color: '#9acad1', fontSize: `14px` }}>
            <span>
              <img src={jingqing} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left" }}>警情分析</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ anylize2: !prevState.anylize2 }))}><img src={closeBtn} alt="close" />
            </span>
          </div>
          <div id="right_fire_any" style={{ height: 292, width: '99.9%', display: this.state.anylize2 ? 'block' : 'none' }}></div>
        </div>
        <div className="right-basic" style={{ color: '#00c1d1', display: this.state.building.name ? 'block' : 'none' }}>
          <div className="right-anylize-one" style={{ color: '#9acad1', fontSize: `14px` }}>
            <span>
              <img src={jichu} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left" }}>基础信息</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ basic: !prevState.basic }))}>
              <img src={closeBtn} alt="close" />
            </span>
          </div>
          <div className="right-basic-one" style={{ display: this.state.basic ? 'block' : 'none' }}>
            <div><img src="" alt="" />建筑物名称：{this.state.building.name}</div>
            <div>结构类型：{this.state.building.type}</div>
            <div>建筑日期：{this.state.building.buildTime}</div>
            <div>耐火等级：{this.state.building.fireLevel}</div>
            <div>建筑物类型：{this.state.building.extend.subtype}</div>
            <div>火灾危险性：{this.state.building.fireDanger}</div>
            <div>使用性质：{this.state.building.extend.usetype}</div>
          </div>
        </div>
        <div className="right-fire" style={{ color: '#00c1d1', marginTop: 15, display: this.state.building.name ? 'block' : 'none' }}>
          <div className="right-anylize-one" style={{ color: '#9acad1', fontSize: `14px` }}>
            <span>
              <img src={xiaofang} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left" }}>消防信息</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ fire: !prevState.fire }))}>
              <img src={closeBtn} alt="close" />
            </span>
          </div>
          <div className="right-fire-one" style={{ display: this.state.fire ? 'block' : 'none' }}>
            <div>消防电梯数量：</div>
            <div>电梯容量：</div>
            <div>最大容纳人数：{this.state.building.galleryful}</div>
            <div>日常工作人数：</div>
          </div>
        </div>
        <div className="right-build" style={{ color: '#00c1d1', display: this.state.building.name ? 'block' : 'none' }}>
          <div className="right-anylize-one" style={{ color: '#9acad1', fontSize: `14px` }}>
            <span>
              <img src={jianzhu} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left" }}>建筑物参数</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ build: !prevState.build }))}><img src={closeBtn} alt="close" />
            </span>
          </div>
          <div className="right-build-one" style={{ display: this.state.build ? 'block' : 'none' }}>
            <div>建筑物高度（米）：{this.state.building.extend.height}</div>
            <div>地上层数：{this.state.building.extend.overgroundfloor}</div>
            <div>占地面积（平方米）：{this.state.building.extend.overgroundarea}</div>
            <div>地上面积（平方米）：{this.state.building.extend.overgroundarea}</div>
            <div>建筑物面积（平方米）：{this.state.building.extend.rangebuild}</div>
            <div>地下层数：{this.state.building.extend.undergroundfloor}</div>
            <div>标准层面积（平方米）：{this.state.building.extend.rangebase}</div>
            <div>地下面积（平方米）：{this.state.building.extend.overgroundarea}</div>
            <div>避难层数量：{this.state.building.extend.refugestoreyfloor}</div>
            <div>避难层总面积（平方米）:{this.state.building.extend.refugestoreyarea}</div>
          </div>
        </div>
        <div className="right-picture" style={{ display: this.state.building.name ? 'block' : 'none' }}>
          <div className="right-anylize-one">
            <span>
              <img src={pingmian} alt="" style={{ height: 18, float: "left" }} />
              <span style={{ marginLeft: 10, marginTop: "-3px", float: "left", color: '#9acad1', }}>平面图</span>
            </span>
            <span className="close-btn" onClick={() => this.setState((prevState) => ({ picture: !prevState.picture }))}>
              <img src={closeBtn} alt="close" />
            </span>
          </div>
          <div className="right-picture-one" style={{ display: this.state.picture ? 'block' : 'none' }}>
            <img id="img" src={this.state.building.mapUrl} alt="right-pic" onClick={() => {
              window.rpc.device.getArrayByCond({ floor: this.state.building.id }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                this.setState({ mapPoints, mapPointsIcon });
              });
              this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))
            }} />
            <div className="new_pingmiantu" style={{ display: this.state.new_pingmiantu ? 'flex' : 'none', position: 'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff' }}>
              <div className="pingmiantu-top">
                <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>
                <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
              </div>
              <div className="pingmiantu-left">
                <img id="img2" src={this.state.building.mapUrl} alt="right-pic" />
                {this.state.mapPoints.map((point, index) => (
                  <div key={index} className={`map-point map-point-${point.dtype}`} style={{ position: 'absolute', height: 20, width: 20, top: `${point.mapY}px`, left: `${point.mapX}px` }}></div>
                ))}
              </div>
              <div className="pingmiantu-right">
                <div className="pingmiantu-oprate" title="正常" onClick={() => {
                  window.rpc.device.getArrayByCond({ floor: this.state.building.id, rstate: 1 }, 0, 0).then((res) => {
                    let mapPoints = res.filter(point => point.mapX);
                    this.setState({ mapPoints });
                  });
                }}><i className="iconfont-lszp">&#xe62a;</i></div>
                <div className="pingmiantu-oprate" title="异常" onClick={() => {
                  window.rpc.device.getArrayByCond({ floor: this.state.building.id, rstate: 2 }, 0, 0).then((res) => {
                    let mapPoints = res.filter(point => point.mapX);
                    this.setState({ mapPoints });
                  });
                }}><i className="iconfont-lszp">&#xe7e6;</i></div>
                <div className="pingmiantu-oprate" title="离线" onClick={() => {

                  window.rpc.device.getArrayByCond({ floor: this.state.building.id, rstate: 3 }, 0, 0).then((res) => {
                    let mapPoints = res.filter(point => point.mapX);
                    this.setState({ mapPoints });
                  });
                }}><i className="iconfont-lszp">&#xe613;</i></div>
                {this.state.mapPointsIcon.map((point, index) => (
                  <div key={index} className={`pingmiantu-oprate pingmiantu-oprate-${point}`} title={types[point]} onClick={() => {

                    window.rpc.device.getArrayByCond({ floor: this.state.building.id, dtype: point }, 0, 0).then((res) => {
                      let mapPoints = res.filter(point => point.mapX);
                      this.setState({ mapPoints });
                    });
                  }}></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
})

export default EquipRight;