/*
 * @Author: szj
 * @Date: 2017-05-02 16:33:29 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-22 15:20:19
 */

import React, {
  Component
} from 'react';
import {
  notification,
  Icon,
  message,
  Button,
  Select
} from 'antd';
import {
  Link,
  browserHistory
} from 'react-router';
import {
  extendObservable
} from 'mobx';
import {
  observer
} from 'mobx-react';

import UnAlarm from '../../../../assets/images/application/fire-plug.png';
import Alarm from '../../../../assets/images/application/hot.png';
import QuitScreen from '../../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../../assets/images/application/shut-o.png';
import Music from '../../../../assets/6709.mp3';
import $ from 'jquery';
import './AlarmLeft.css';
import red from '../../../../assets/images/application/warningInstance_red.png';
import blue from '../../../../assets/images/application/warningInstance_blue.png';

import fixLeft from '../../../../assets/images/apply/fix-left.png';
import allBlue from '../../../../assets/images/apply/all-blue.png';
import allGay from '../../../../assets/images/apply/all-gay.png';
import car from '../../../../assets/images/apply/car.png';
import close from '../../../../assets/images/apply/close.png';
import deleteAlarm from '../../../../assets/images/apply/deleteAlarm.png';
import deviceBuild from '../../../../assets/images/apply/buildName.png';
import deviceState from '../../../../assets/images/apply/deviceState.png';

import home from '../../../../assets/images/apply/home.png';
import map_pic from '../../../../assets/images/apply/map.png';
import nomalBlue from '../../../../assets/images/apply/nomal-blue.png';
import nomalGay from '../../../../assets/images/apply/nomal-gay.png';
import alarm from '../../../../assets/images/apply/alarm.png';


import title from '../../../../assets/images/apply/title.png';
import unusual from '../../../../assets/images/apply/unusual.png';
import unusualGay from '../../../../assets/images/apply/unusual-gay.png';

import upDown from '../../../../assets/images/apply/upDown.png';
import alarmTop from '../../../../assets/images/apply/alarmTop.png';

const Option = Select.Option;

var audio;
let getidList = []; //floorid
let firstFloorid = null;
message.config({
  bottom: 20,
  duration: 10
})
const openNotification = (data) => {
  notification.open({
    message: data,
    icon: < Icon type="smile-circle"
      style={
        {
          color: '#108ee9'
        }
      }
    />,
    placement: 'bottomRight',
    duration: 30,
    onClose: function () {
      audio.pause();
    }
  });
};
const quitAudio = (flag) => {
  audio.pause();
}
class AlarmLeftState {
  constructor() {
    extendObservable(this, {
      distortId: 12,
      objAlarm: {},
      alarmId: null,
      data: []
    })
  }
}
const AlarmLeftC = observer(class AlarmLeftState extends React.Component {
  //class AlarmLeft extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'none',
      mapZoomLevel: '13',
      deviceId: {
        // areaId:null
      }
      , arr: [],
      data: [],
    };
  }
  componentWillMount() {
    //console.log(this.state.SixD);

  }

  componentDidMount() {

    let that = this;
    //console.log(this.props);
    function callBack(data) {
      //console.log(1233333333333333333);
      //console.log(data);
      if (typeof data == 'number') {

      } else {
        $('.AlarmAlert').css({
          display: 'block',
          opacity: 1
        })
        sessionStorage.removeItem('alarmInfo');
        //sessionStorage.removeItem("rulesObj")
        sessionStorage.setItem('flag', 1)
        //audio = new Audio(Music);
        audio = document.getElementById("audio");
        //audio.loop = 'loop';
        audio.play();
        // $(window).css({
        //   boxShadow: '0 0 5px red'
        // })
        // let newId = [];
        //console.log(data);
        //console.log( that.props);
        let dataArr = [];
        data = data.map((x) => {
          //let local=x.location;
          //console.log(x.locationName)
          let strs = `${x.locationName}`.split(",");
          let buildLocal = '', local = '', areaId = null;
          if (strs[2]) {
            buildLocal = strs[0];
            local = strs[0] + `-` + strs[1] + '-' + strs[2];

          } else if (strs[1]) {
            buildLocal = `${strs[0]}`;
            local = `${strs[0]}-${strs[1]}`;
          } else if (strs[0]) {
            buildLocal = `${strs[0]}`;
            local = `${strs[0]}`;

          }
          x = { ...x, buildLocal: buildLocal, locationName: local };
          //console.log(x);
          dataArr.push(x);
        });
        //console.log(dataArr)
        that.props.AlarmLeftState.data = dataArr;
        //this.setState({data:dataArr})
        sessionStorage.setItem('alarmInfo', JSON.stringify(dataArr));



        //localStorage删除指定键对应的值

        //sessionStorage.setItem('AlarmLeftData', data);
        //console.log( that.props.AlarmLeftState.data);
        window.rpc.area.getArrayDeviceCountByContainer({ deep: 3 }, 0, 0).then((res) => {
          res.forEach(function (values) {
            data.forEach(function (x) {
              if (values.id === x.floor) {
                openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
                //console.log(x.location, x.floor);
                getidList.push(values.id);
                $('.AlarmAlert').css({
                  display: 'block',
                  opacity: 1
                })
                if (getidList.length === 1) {
                  //console.log(getidList);
                  //   $('.AlarmMesCard').css({
                  //        display:'block',
                  //        opacity:1
                  //  });
                  //  $('.AlarmAlert').css({
                  //    display:'block',
                  //    opacity:1
                  // })
                  // $('.fixAlarmDeviceAll').css({
                  //   display:'block'
                  // })
                }
              }
            })
          })
          if (getidList.length >= 1) {
            //showAlarmMes(getidList);

          }

        }, (err) => {
          console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
        })
      }
    }
    window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
    window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);
    //showAlarmMes();
  }
  onChangeAlarmState = (stateName) => {
    // this.setState(stateName)
    // this.setState({ id: stateName.sixId });
    // let id = stateName.sixId;
    //console.log(stateName);
    if (stateName.alarmId) {
      this.props.onClicked({
        alarmId: stateName.alarmId
      });
    }
    if (stateName.deviceId) {
      this.setState({
        deviceId: {
          areaId: null
        }
      })
    }

  }
  //点击处警传数据
  handlePopupClick = (index) => {
    let data = [...this.props.AlarmLeftState.data];
    this.props.AlarmLeftState.objAlarm = data[index];
  }
  //点辅助信息传id
  handleWatchClick = (index) => {
    let data = [...this.props.AlarmLeftState.data];
    //console.log(index);
    let floorId = data[index].floor;
    //console.log(this.props.onClicked);
    this.props.onClicked({
      SixD: 'block',
      sixId: floorId
    });
    $('.AlarmMesCard').css({
      opacity: 0,
      display: `none`
    });
    $('.openAlarmDeviceAll').css({
      display: 'block'
    });
    $('.fixAlarmDeviceAll').css({
      display: 'none'
    });

  }
  fixDutyInfo = () => {
    $('.AlarmAlert').css({
      display: 'none',
      opacity: 0
    })
  }
  allInfoFix = () => {
    $('.AlarmMesCard').css({
      opacity: 0,
      display: `none`
    });
    $('.openAlarmDeviceAll').css({
      display: 'block'
    });
    $('.fixAlarmDeviceAll').css({
      display: 'none'
    });
  }
  openAlarmDeviceInfo = () => {
    // console.log(12334)
    $('.AlarmMesCard').css({
      left: 0,
      opacity: 1,
      display: `block`
    });
    $('#openAlarmDeviceAll').css({
      //  display: 'none'
    });
    // console.log(this.props.AlarmLeftState.data)
  }
  render() {
    //console.log(this.props)
    //关闭左侧报警设备列表
    $('#openAlarmDeviceAll').click((e) => {
      //console.log(111);
      let arrAlarm = [...this.props.AlarmLeftState.data];
      //console.log(arrAlarm);
      if (arrAlarm.length == 0) {
        //console.log(222);
        var data = JSON.parse(sessionStorage.getItem('alarmInfo'));
        //console.log(data);
        this.props.AlarmLeftState.data = data;
      }

      e.stopPropagation();
      $('.AlarmMesCard').css({
        left: 0,
        opacity: 1,
        display: `block`
      });
      $('.fixAlarmDeviceAll').css({
        display: 'block'
      });
      $('#openAlarmDeviceAll').css({
        //display: 'none'
      });
    });
    let data = [...this.props.AlarmLeftState.data];


    //console.log(data)
    return (
      <div className="AlarmLeft" style={{ height: "100%" }}>
        <div><img src={fixLeft} className="openAlarmDeviceAll" onClick={this.openAlarmDeviceInfo} style={{ position: 'absolute', left: 2, top: '300px', height: 200, width: 12, display: 'none' }} id="openAlarmDeviceAll" /></div>
        <div style={{ zIndex: 99, boxShadow: `0 0 2px #00c1de`, textAlign: 'left', direction: 'rtl', unicodeBidi: 'bidi-override', background: '#293d51', position: 'absolute', top: 40, left: 0, transition: "all 0.5s", opacity: 1, fontFamily: "PingFang-SC-Medium", color: "#00c1de", fontSize: 12, maxHeight: '85vh', overflowY: 'auto', overflowX: 'hidden', }}>
          <div className='AlarmMesCard' style={{ zIndex: 99, width: 340, background: '#293d51', display: 'block', transition: "all 0.5s", opacity: 1, fontFamily: "MicrosoftYaHei", color: "#00c1de", overflowY: 'auto', overflowX: 'hidden', border: this.props.AlarmLeftState.data.length ? '8px solid rgba(25,34,52,1)' : 'transparent' }}>
            <img src={close} className="fixAlarmDeviceAll" style={{ position: 'fixed', left: 344, top: 60, zIndex: 99999999999, display: 'none' }} id="fixAlarmDeviceAll" onClick={this.allInfoFix} />
            {this.props.AlarmLeftState.data.map((point, index) => (
              <div key={index + 1} className="alarmDeviceInfo" style={{ paddingTop: '10px', paddingLeft: 12, overflow: 'hidden', width: 340, position: 'relative', fontSize: '0.75rem', height: 110, borderBottom: '1px solid rgba(25,34,52,0.8)' }}>
                <span style={{ float: 'left', margin: ' 0px 8px 0px 16px' }} className="deletes"><a href="javascript:;" >
                  <img src={deviceBuild} alt="" /></a>
                </span>
                <div style={{ float: 'left', width: '80%' }}>
                  <h3 style={{ fontFamily: '微软雅黑', color: '#00c1de', marginBottom: 10, fontWeight: 400, fontSise: 12 }}>建筑物名称：{point.buildLocal || ''}</h3>
                  <div style={{ lineHeight: '20px' }}>
                    <p>报警设备:{point.name || "无"}</p>
                    <p style={{ marginBottom: 5 }}><span>报警位置:{point.locationName || "无"}</span></p>
                  </div>
                  <a href="javascript:;" onClick={() => this.handlePopupClick(index)} style={{ display: 'block', textAlign: 'center', width: 60, height: 24, lineHeight: '24px', fontSize: 12, fontFamily: 'MicrosoftYaHei', color: '#00c1de', textalign: 'center', lineheight: 24, position: 'absolute', right: 68, bottom: 0, background: '#060514' }} className="popup" >
                    处警
                </a>
                  <a href="javascript:;" onClick={() => this.handleWatchClick(index)} style={{ display: 'block', textAlign: 'center', width: 60, height: 24, lineHeight: '24px', fontSize: 12, fontFamily: 'MicrosoftYaHei', color: '#00c1de', textalign: 'center', lineheight: 24, position: 'absolute', right: 0, bottom: 0, background: '#060514' }} className="popup" >
                    辅助信息
                </a>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className='AlarmAlert'
          style={{ zIndex: 99, width: 444, position: 'fixed', height: '180px', left: '50%', top: '300px', marginLeft: '-222px', transition: "all 0.5s", opacity: 1, fontFamily: "PingFang-SC-Medium", color: "#333744", fontSize: 14, background: "#fff", opacity: 0, display: 'none' }}>
          <div style={{ position: 'relative' }}>
            <div className="DclearFix DutyInfo" style={{ width: '100%', height: 43, lineHeight: 43, fontSize: 18, background: '#b22222 url(${alarmTop}) no-repeat 0 0' }}>
              <img src={alarm} alt="" style={{ width: 40, height: 40, float: 'left', marginLeft: 8 }} />
              <span style={{ float: 'left', marginleft: 15 }}>设备预警</span>
              <img src={close} id="deviceAlarmFix" className="deviceAlarmFix" alt="" onClick={this.fixDutyInfo} style={{ position: 'absolute', top: 12, right: 12, cursor: 'pointer' }} />
            </div>
            <div className="everyData DclearFix" style={{ width: '100%', height: 136 }} >
              <div style={{ position: 'absolute', bottom: 12, width: '100%' }}>
                <div style={{ width: '65%', border: '1px solid #ccc', float: 'left', marginLeft: 12, padding: 2 }}>
                  <img src={car} alt="" />
                </div>
                <div style={{ width: '24%', marginRight: 15, float: 'right' }} >
                  <img src={deleteAlarm} className="deviceAlarmFix" id="quitAlarmAudio" alt="" style={{ cursor: 'pointer' }} onClick={this.fixDutyInfo} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          <audio id="audio" src={Music} loop="loop"></audio>
        </div>
        {/*<div className='AlarmAlertTwo' style={{ zIndex: 99, width: 600, position: 'absolute', height: '180px', left: '40%', top: '400px', marginLeft: '-222px', transition: "all 0.5s", fontFamily: "PingFang-SC-Medium", color: "#333744", fontSize: 14, background: "#fff", opacity: 0, display: 'none' }}>
        </div>*/}
        <div className='AlarmAlertThree' style={{ width: 400, height: 'auto' }}>
          <AlertThree id={this.state.deviceId} onChildClicked={this.onChangeAlarmState.bind(this)} AlarmLeftState={this.props.AlarmLeftState} />
        </div>
      </div>

    );
  }
})
const AlertThree = observer(class AlarmLeftState extends React.Component {
  //class AlertThree extends Component {
  state = {
    deviceName: '',
    local: '',
    areaId: null,
    alarmId: '',
    //flag:1,
    oldId: '',
    alarmValue: '',
    leftToId: null
  }
  handleChange = (value) => {
    //console.log(`selected ${value}`);
    this.setState({
      alarmValue: parseInt(value, 10)
    })
  }

  render() {
    //console.log(this.props)
    let objAlarm = { ...this.props.AlarmLeftState.objAlarm };

    // if (this.props.id.areaId&&this.state.leftToId!=this.props.id.deviceId) {
    if (objAlarm.floor) {
      let local = objAlarm.locationName;
      objAlarm = { ...objAlarm, locationName: objAlarm.locationName.replace("-", ",") };
      //console.log(objAlarm);
      //console.log(this.props.id);
      // this.setState({leftToId:data.id})
      $('.AlertThree').css({
        display: 'block',
        opacity: 1
      });
      //this.setState({areaId:this.props.id.areaId});
    }

    $('#AlarmTwoLevel').eq(0).click((e) => {
      //console.log(e);
      e.stopPropagation();
      if (this.state.alarmValue == 1) {

        let Id = parseInt(objAlarm.id, 10);
        //console.log(Id);
        window.rpc.device.alarm.setStateTypeById(Id, 0, 3).then(data => {
          // console.log(data);
          if (data == true) {
            // this.props.onChildClicked({
            //    alarmId: this.props.id.areaId
            // });
            this.props.AlarmLeftState.alarmId = objAlarm.floor
            message.info("已成功处理报警");
          }
        }, error => {
          //console.log(error);
        });
        $('.AlertThree').css({
          opacity: 0,
          display: 'none'
        });
      } else {
        //message.info("请处理警情");
      }

      $('.AlertThree').css({
        opacity: 0,
        display: 'none'
      });

    });

    //放入弹出相应图标的alarm值
    $('.deviceAlarmFixTwo').click((e) => {
      //console.log(111);
      e.stopPropagation();
      $('.AlertThree').css({
        opacity: 0,
        display: 'none'
      });
    });

    $('#dealwithResult').each((i) => {
      $('#dealwithResult').eq(i).change((e) => {
        //console.log("Click Event!");
        //console.log(e);
      })
    })

    return (
      <div className="AlertThree" style={{ height: '180px', display: 'none', zIndex: 99, width: 600, position: 'fixed', height: '180px', left: '40%', top: '400px', marginLeft: '-222px', transition: "all 0.5s", fontFamily: "PingFang-SC-Medium", color: "#333744", fontSize: 14, background: "#fff", opacity: 0, display: 'none' }}  >
        <div style={{ position: 'relative' }}>
          <div className="DclearFix DutyInfo" style={{ width: '100%', height: 43, lineHeight: '43px', fontSize: 18, background: '#e5e5e5' }}>
            <span style={{ float: 'left', marginLeft: 18 }}>设备处警</span>
            <img src={close} className="deviceAlarmFixTwo" alt="" style={{ position: 'absolute', top: 12, right: 12, cursor: 'pointer' }} />
          </div>
          <div className="everyData DclearFix" style={{ width: '100%', height: 136, overflow: 'hidden' }} >
            <div style={{ float: 'left', width: '100px' }}>
              <img src={alarm} alt="" style={{ width: 40, height: 40, float: 'left', margin: '16px 24px' }} />
            </div>
            <div style={{ float: 'left', width: '480px', marginLeft: 20, margintop: 24 }}>
              <p>报警设备：{objAlarm.name || null}</p>
              <p>报警地点：{objAlarm.locationName || ''}</p>
              <div>处理结果：
                <Select id="dealwithResult" placeholder="请选择" onChange={this.handleChange} style={{ width: 180 }}>
                  <Option key={1}>误报</Option>
                  <Option key={2}>火警</Option>
                </Select>
              </div>
            </div>
            <div style={{ position: 'absolute', bottom: 12, width: '100%' }}>
              <div style={{ marginRight: 15, float: 'right' }}>
                <span className="AlarmTwoLevel" id="AlarmTwoLevel" style={{ display: 'inline-block', width: 58, height: 32, lineHeight: '32px', boxShadow: '0 0 1px #ccc', textAlign: 'center', color: '#fff', background: 'red', fontSize: 12, cursor: 'pointer' }} >确认</span>
                <span className="deviceAlarmFixTwo" style={{ marginLeft: 8, display: 'inline-block', width: 58, height: 32, lineHeight: '32px', boxShadow: '0 0 1px #ccc', textAlign: 'center', color: '#333744', background: '#f7f7f7', fontSize: 12, border: '1px solid #e5e5e5', cursor: 'pointer' }}>取消</span>
              </div>
              <div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
})

class AlarmLeft extends Component {
  render() {
    return (
      <AlarmLeftC AlarmLeftState={new AlarmLeftState()} onClicked={this.props.onClicked} />
    )
  }
}
export default AlarmLeft;