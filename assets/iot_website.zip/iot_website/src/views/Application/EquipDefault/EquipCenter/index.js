/*
 * @Author: lai.haibo 
 * @Date: 2017-04-22 14:06:29 
<<<<<<< HEAD
<<<<<<< HEAD
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-04-23 14:59:14
=======
<<<<<<< HEAD
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-04-24 16:25:57
=======
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-04-24 20:00:32
>>>>>>> 476437d5bceaeb169d3881125929f9c9ce4ca17b
>>>>>>> 70936d80bf062c253204643bd01c4b75e36f47e5
=======
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 12:40:37
>>>>>>> be3bb926ccf3c72d209b4bb975aab789c47925ef
 */

import React, {
  Component
} from 'react';
import {
  extendObservable
} from 'mobx';
import {
  observer
} from 'mobx-react';
import {
  Link,
  browserHistory
} from 'react-router';
import moment from 'moment';
import EquipRight from './EquipRight';
import AlarmLeft from './AlarmLeft';
import AlarmSix from '../AlarmSix';
import AlarmOne from '../EquipCenter/AlarmOne';
import AlarmConcenBasicMes from '../AlarmSix/AlarmConcenBasicMes';
import AlarmConcenRoute from '../AlarmSix/AlarmConcenRoute';
import AlarmConcenResources from '../AlarmSix/AlarmConcenResources';
import AlarmRealTimeMonitor from '../AlarmSix/AlarmRealTimeMonitor';
import AlarmConcenEquipment from '../AlarmSix/AlarmConcenEquipment';
import AlarmConcenFloor from '../AlarmSix/AlarmConcenFloor';
import $ from 'jquery';
//AlarmLeft
//import './equipDefault.css';
// import { BaiduMap } from 'react-baidu-map';
import {
  notification,
  Icon,
  Row,
  Col,
  Card,
  Button,
  Dropdown,
  Menu
} from 'antd';
import UnAlarm from '../../../../assets/images/apply/green.png';
import yellow from '../../../../assets/images/apply/yellow.png';
import Alarm from '../../../../assets/images/apply/red.png';

import Music from '../../../../assets/6709.mp3';


var audio;
const openNotification = (data) => {
  notification.open({
    message: data,
    icon: < Icon type = "smile-circle"
    style = {
      {
        color: '#108ee9'
      }
    }
    />,
    placement: 'bottomRight',
    duration: 30,
    onClose: function () {
      audio.pause();
    }
  });
};
class EquipDefaultState {
  constructor() {
    extendObservable(this, {
      buildId: [],
      idbul: 1,
      sixAlarm: {},
      building: {}
    })
  }
}
//class EquipDefaultC extends Component {
const EquipDefaultC = observer(class EquipDefaultState extends React.Component {
  state = {
    deviceId:null,
    id: null,
    map:{x:'',y:''},
    display: "block",
    SixD: "none",
    sixId: null,
    allDeviceCount: 0,
    commonDeviceCount: 0,
    erroeDeviceCount: 0,
    alarmCount: {
      1: 0,
      2: 0,
      3: 0
    },
    patrolCount: {
      1: 0,
      2: 0,
      3: 0
    },
    building: {
      name: '',
      buildTime: '',
      createTime: '',
      fireDanger: '',
      fireLevel: '',
      galleryful: '',
      mapUrl: '',
      extend: {
        height: '',
        overgroundarea: '',
        overgroundfloor: '',
        rangebase: '',
        rangebuild: '',
        refugestoreyarea: '',
        refugestoreyfloor: '',
        subtype: '',
        undergroundarea: '',
        undergroundfloor: '',
        usetype: ''
      }
    },
    offer: true,
    widthA: "30%",
    widthB: "30%",
    heightA: "30%",
    heightB: "30%",
    heightC: "30%",
    heightD: "30%",
    heightE: "30%",
    heightF: "30%",

  }

  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
    // point.lng
    // point.lat
  }
  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    // console.log(document.getElementById('equipCenterMap'))
    loadJScript();
  }

  componentDidMount() {
    // const getAllDevice = () => {
    //   return window.rpc.device.getArray(0, 0);
    // }

    const getAllDeviceCount = () => {
      return window.rpc.device.getCount();
    }

    const getCommonDeviceCount = () => {
      return window.rpc.device.getCountByCond({
        rstate: 1
      });
    }

    const getErroeDeviceCount = () => {
      return window.rpc.device.getCountByCond({
        rstate: 2
      });
    }

    // const getArea = () => {
    //   return window.rpc.area.getArray(0, 0);
    // }

    const getAlarm = () => {
      return window.rpc.device.alarm.getFieldCountByContainer(null, 'type');
    }

    const getPatrol = () => {
      return window.rpc.device.patrol.getFieldCountByContainer(null, 'type');
    }

    const initC = async() => {
      try {
        // const allDevice = await getAllDevice();
        const commonDeviceCount = await getCommonDeviceCount();
        const allDeviceCount = await getAllDeviceCount();
        const erroeDeviceCount = await getErroeDeviceCount();
        // const area = await getArea();

        const alarmCount = await getAlarm();
        const patrolCount = await getPatrol();

        this.setState({
          allDeviceCount,
          commonDeviceCount,
          erroeDeviceCount
        });
        this.setState({
          alarmCount
        });
        this.setState({
          patrolCount
        });
      } catch (err) {
        console.log(err);
      }
    }

    initC();

    let setSSSSS = (obj) => {
      console.log(this.state.building);
      console.log(obj);
      let building = { ...obj,
        buildTime: moment(obj.buildTime).format("YYYY年MM月DD日")
      };
      this.setState({
        building
      });
    }

    function init() {
      let newId = [],
        param = '';

      function callBack(data) {
        // console.log(data);
        sessionStorage.setItem('flag', 1)
        //audio = new Audio(Music);
        //audio.loop = 'loop';
        // audio.play();
        newId = [];
        let rstate = this.props.appState.id
        window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
          console.log(res);
          res.forEach(function (value) {
            data.forEach(function (x) {
              if (value.id === x.floor) {
                openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
                alarm(Alarm);
                console.info(value)
                mouseoverTxt = x.locationName.slice(0, x.locationName.indexOf(','));
                var maker = new ComplexCustomOverlay(new window.BMap.Point(x.floorX, x.floorY), value.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  id: newId
                };
                map.addOverlay(maker) // 将标注添加到地图中
                addClickHandler(content, param, newId, obj, maker);
              }
            })
          })
        }, (err) => {
          console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }
      window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
      window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);

      var map = new window.BMap.Map("equipDefaultMap");
      var point = new window.BMap.Point(121.618835,
        29.920698);
      map.centerAndZoom(new window.BMap.Point(116.3964, 39.9094), 17);
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';

      function setPlace() {
        map.clearOverlays(); //清除地图上所有覆盖物
        function myFun() {
          var pp = local.getResults().getPoi(0).point; //获取第一个智能搜索的结果
          map.centerAndZoom(pp, 18);
          map.addOverlay(new window.BMap.Marker(pp)); //添加标注
        }
        var local = new window.BMap.LocalSearch(map, { //智能搜索
          onSearchComplete: myFun
        });
        local.search(myValue);
      }

      // function myFun(result) {
      //   var cityName = result.name;
      //   map.setCenter(cityName);
      // }
      // var myCity = new window.BMap.LocalCity();
      // myCity.get(myFun);
      map.centerAndZoom(point, 17);
      map.enableScrollWheelZoom(); //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom(); //启用地图惯性拖拽，默认禁用
      // 编写自定义函数,创建标注
      map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 11);
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);

      function G(id) {
        return document.getElementById(id);
      }
      map.centerAndZoom("宁波", 12); // 初始化地图,设置城市和地图级别。
      var ac = new window.BMap.Autocomplete( //建立一个自动完成的对象
        {
          "input": "suggestId",
          "location": map
        });

      // ac.addEventListener("onhighlight", function (e) {  //鼠标放在下拉列表上的事件
      //   var str = "";
      //   var _value = e.fromitem.value;
      //   var value = "";
      //   if (e.fromitem.index > -1) {
      //     value = _value.province + _value.city + _value.district + _value.street + _value.business;
      //   }
      //   str = "FromItem<br />index = " + e.fromitem.index + "<br />value = " + value;

      //   value = "";
      //   if (e.toitem.index > -1) {
      //     _value = e.toitem.value;
      //     value = _value.province + _value.city + _value.district + _value.street + _value.business;
      //   }
      //   str += "<br />ToItem<br />index = " + e.toitem.index + "<br />value = " + value;
      //   G("searchResultPanel").innerHTML = str;
      // });

      var myValue;
      ac.addEventListener("onconfirm", function (e) { //鼠标点击下拉列表后的事件
        var _value = e.item.value;
        myValue = _value.province + _value.city + _value.district + _value.street + _value.business;
        G("searchResultPanel").innerHTML = "onconfirm<br />index = " + e.item.index + "<br />myValue = " + myValue;

        setPlace();
      });
      map.centerAndZoom(new window.BMap.Point(116.417854, 39.921988), 15);
      var data_info = [
        [116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
        [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
        [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
      ];
      var opts = {
        width: 100, // 信息窗口宽度
        height: 50, // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true //设置允许信息窗发送短息
      };

      function alarm(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          div.appendChild(p);
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
        console.log(res);
        let idState3 = res.map(x => x.id);
        console.log(idState3);
        newId = '';
        //res.
        res.map((x) => {
          alarm(UnAlarm)
          mouseoverTxt = x.name;

          console.info(x);
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = {
            'floor': newId
          };
          map.addOverlay(maker) // 将标注添加到地图中
          addClickHandler(content, param, newId, obj, maker);

        })
        window.rpc.area.getArrayDeviceCountByContainer({
          device: {
            dstate: 1
          }
        }, 0, 0).then((res) => {
          console.log(res);
          let idState3 = res.map(x => x.id);
          console.log(idState3);
          newId = '';
          //res.
          res.map((x) => {
            alarm(UnAlarm)
            mouseoverTxt = x.name;
            var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = {
              'floor': newId
            };
            map.addOverlay(maker) // 将标注添加到地图中
            addClickHandler(content, param, newId, obj, maker);

          })
          window.rpc.area.getArrayDeviceCountByContainer({
            device: {
              dstate: 3
            }
          }, 0, 0).then((result) => {
            console.log(result);
            let idState2 = result.map(x => x.id);
            console.log(idState2);
            result.map((x) => {
              alarm(Alarm);
              mouseoverTxt = x.name;
              console.info(x);
              var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.addOverlay(maker) // 将标注添加到地图中
              addClickHandler(content, param, newId, obj, maker);
            })
          }, (err) => {
            console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
          });

        }, (err) => {
          console.warn(err);
        });
      }, (err) => {
        console.warn(err);
      });

      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }


      const buildingInfo = async(newId) => {
        const building = await getBuilding(newId);
        // console.log(building);
        setSSSSS(building);
      }

      function addClickHandler(content, param, newId, obj, marker) {
        // console.log(marker+newId);
        marker.addEventListener("click", function (e) {
          // setSSSSS();
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          // window.rpc.area.getInfoById(newId).then(res => {
          //   console.table('building:',this.state.building);
          //   let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
          //   // document.getElementById("img").src = res.mapUrl;
          //   setSSSSS(building);
          //   // setSSSSS();
          // });
          this.setState({
            id: newId
          })
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            // window.location.href = '/equip';
            // this.props.id=newId;
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        });
      }

      function openInfo(content, e) {
        var p = e.target;
        var point = new window.BMap.Point(p.getPosition().lng, p.getPosition().lat);
        var infoWindow = new window.BMap.InfoWindow(content, opts); // 创建信息窗口对象 
        map.openInfoWindow(infoWindow, point); //开启信息窗口
      }
    }
    setTimeout(() => {
      init();
    }, 1000)
  }
  //点击左部，更换地图
    handleLeftClick = (e) => {}
 

  handleK = () => {
    if (this.state.display === "block") {
      this.setState({
        display: "none"
      });
    } else {
      this.setState({
        display: "block"
      });
    }
  }
  handleCan = () => {
    this.setState({
      SixD: "none"
    });
  }
  onChangeState = (stateName) => {
    this.setState(stateName)
    this.setState({
      id: stateName.sixId
    });
    console.log(stateName);
    let areaId=stateName.areaId;
   
    var x='',y='';
    window.rpc.area.getInfoById(areaId).then((data)=>{
      console.log(data);
      x=data.x;
      y=data.y;
      //this.setState({map:{x:data.x,y:data.y}});
    });
  

     handleLeftClick(areaId);
   function handleLeftClick(areaId){
     
    // const getAllDevice = () => {
    //   return window.rpc.device.getArray(0, 0);
    // }
    //console.log(e);
    const getAllDeviceCount = () => {
      return window.rpc.device.getCount();
    }

    const getCommonDeviceCount = () => {
      return window.rpc.device.getCountByCond({
        rstate: 1
      });
    }

    const getErroeDeviceCount = () => {
      return window.rpc.device.getCountByCond({
        rstate: 2
      });
    }

    // const getArea = () => {
    //   return window.rpc.area.getArray(0, 0);
    // }

    const getAlarm = () => {
      return window.rpc.device.alarm.getFieldCountByContainer(null, 'type');
    }

    const getPatrol = () => {
      return window.rpc.device.patrol.getFieldCountByContainer(null, 'type');
    }

   

    let setSSSSS = (obj) => {
      console.log(this.state.building);
      console.log(obj);
      let building = { ...obj,
        buildTime: moment(obj.buildTime).format("YYYY年MM月DD日")
      };
      this.setState({
        building
      });
    }

  $(function init() {
      let newId = [],
        param = '';

     

      var map = new window.BMap.Map("equipDefaultMap");
    
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';
      //  var point = new window.BMap.Point(121.618835, 29.920698);
      //map.centerAndZoom(point, 18);
         //   map.centerAndZoom(new window.BMap.Point(116.417854, 39.921988), 18);
      map.enableScrollWheelZoom(); //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom(); //启用地图惯性拖拽，默认禁用
      // 编写自定义函数,创建标注
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);

      function G(id) {
        return document.getElementById(id);
      }
      //map.centerAndZoom("宁波", 12); // 初始化地图,设置城市和地图级别。
      window.rpc.area.getInfoById(areaId).then((res)=>{
         map.centerAndZoom(new window.BMap.Point(res.x, res.y), 18);   
      });
     
      var data_info = [
        [116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
        [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
        [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
      ];
      var opts = {
        width: 100, // 信息窗口宽度
        height: 50, // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true //设置允许信息窗发送短息
      };

      function alarm(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          div.appendChild(p);
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
        console.log(res);
        let idState3 = res.map(x => x.id);
        console.log(idState3);
        newId = '';
        //res.
        res.map((x) => {
          alarm(UnAlarm)
          mouseoverTxt = x.name;

          console.info(x);
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = {
            'floor': newId
          };
          map.addOverlay(maker) // 将标注添加到地图中
          addClickHandler(content, param, newId, obj, maker);

        })
        window.rpc.area.getArrayDeviceCountByContainer({
          device: {
            dstate: 1
          }
        }, 0, 0).then((res) => {
          console.log(res);
          let idState3 = res.map(x => x.id);
          console.log(idState3);
          newId = '';
          //res.
          res.map((x) => {
            alarm(UnAlarm)
            mouseoverTxt = x.name;
            var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = {
              'floor': newId
            };
            map.addOverlay(maker) // 将标注添加到地图中
            addClickHandler(content, param, newId, obj, maker);

          })
          window.rpc.area.getArrayDeviceCountByContainer({
            device: {
              dstate: 3
            }
          }, 0, 0).then((result) => {
            console.log(result);
            let idState2 = result.map(x => x.id);
            console.log(idState2);
            result.map((x) => {
              //测试
             // map.centerAndZoom(new window.BMap.Point(x.x, x.y), 18);
              alarm(Alarm);
              mouseoverTxt = x.name;
              console.info(x);
              var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.addOverlay(maker) // 将标注添加到地图中
              addClickHandler(content, param, newId, obj, maker);
            })
          }, (err) => {
            console.warn(err);
          });

        }, (err) => {
          console.warn(err);
        });
      }, (err) => {
        console.warn(err);
      });

      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }


      const buildingInfo = async(newId) => {
        const building = await getBuilding(newId);
        // console.log(building);
        setSSSSS(building);
      }

      function addClickHandler(content, param, newId, obj, marker) {
        // console.log(marker+newId);
        marker.addEventListener("click", function (e) {
          // setSSSSS();
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          // window.rpc.area.getInfoById(newId).then(res => {
          //   console.table('building:',this.state.building);
          //   let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
          //   // document.getElementById("img").src = res.mapUrl;
          //   setSSSSS(building);
          //   // setSSSSS();
          // });
          this.setState({
            id: newId
          })
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            // window.location.href = '/equip';
            // this.props.id=newId;
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        });
      }

      function openInfo(content, e) {
        var p = e.target;
        var point = new window.BMap.Point(p.getPosition().lng, p.getPosition().lat);
        var infoWindow = new window.BMap.InfoWindow(content, opts); // 创建信息窗口对象 
        map.openInfoWindow(infoWindow, point); //开启信息窗口
      }
    })
   
     // init();
    
   }
  }
 onChangeMapState = (stateId) => {
   console.log(stateId);
    this.setState({
      deviceId: stateId.deviceId
    });
    //handleLeftClick( stateId.deviceId);
  }

  // handleLeftClickJudge=(flag)=>{
  //      if(flag==1){
  //        handleLeftClick()
  //      }
  // }
  // 六屏
  handleA = () => {
    this.setState({
      offer: false,
      widthA: "100%",
      widthB: 0,
      heightA: "100%",
      heightB: 0,
      heightC: 0,
      heightD: 0,
      heightE: 0,
      heightF: 0,
    });
  }
  handleB = () => {
    this.setState({
      offer: false,
      widthA: "100%",
      widthB: 0,
      heightA: 0,
      heightB: "95%",
      heightC: 0,
      heightD: 0,
      heightE: 0,
      heightF: 0,
    });
  }
  handleC = () => {
    this.setState({
      offer: false,
      widthA: "100%",
      widthB: 0,
      heightA: 0,
      heightB: 0,
      heightC: "95%",
      heightD: 0,
      heightE: 0,
      heightF: 0,
    });
  }
  handleD = () => {
    this.setState({
      offer: false,
      widthA: 0,
      widthB: "100%",
      heightA: 0,
      heightB: 0,
      heightC: 0,
      heightD: "95%",
      heightE: 0,
      heightF: 0,
    });
  }
  handleE = () => {
    this.setState({
      offer: false,
      widthA: 0,
      widthB: "100%",
      heightA: 0,
      heightB: 0,
      heightC: 0,
      heightD: 0,
      heightE: "95%",
      heightF: 0,
    });
  }
  handleF = () => {
    this.setState({
      offer: false,
      widthA: 0,
      widthB: "100%",
      heightA: 0,
      heightB: 0,
      heightC: 0,
      heightD: 0,
      heightE: 0,
      heightF: "95%",
    });
  }
  handleTrue = () => {
    this.setState({
      offer: true,
      widthA: "30%",
      widthB: "30%",
      heightA: "30%",
      heightB: "30%",
      heightC: "30%",
      heightD: "30%",
      heightE: "30%",
      heightF: "30%",
    });
  }
  render() {
      function handleMenuClick(e) {
      console.log('click', e.key);
    }
    const menu = (
      <Menu onClick={handleMenuClick}>
        <Menu.Item key="1">正常</Menu.Item>
        <Menu.Item key="2">异常</Menu.Item>
        <Menu.Item key="3">全部</Menu.Item>
      </Menu>
    );
    return (
      <div className="EquipDefault">
        <div id="equipDefaultMap" style={{ height: '100vh' }}></div>

        <div className="banner">
          <div className="banner-left">
            <Button.Group>
              <Button>
                <Link to='/back' style={{ color: '#333' }}>首页</Link>
              </Button>
              <Button onClick={() => console.info(this.state.building)}>
                地图
              </Button>
              <Dropdown overlay={menu}>
                <Button>
                  设备状态 <Icon type="down" />
                </Button>
              </Dropdown>
            </Button.Group>
            <div onClick={this.handleLeftClick}>
              <AlarmLeft onClicked={this.onChangeState.bind(this)} />
            </div>
          </div>
          <div className="banner-middle"><span>设备管理地图</span></div>
          <div className="banner-right">
            <Button.Group size="large">
              <Button type="primary"  onClick={this.handleLeftClick}>
                设备统计
              </Button>
              <Button type="primary" onClick={this.handleK}>
                <Icon type={this.state.display === "block" ? "left" : "down"} />
              </Button>
              <Button type="primary">
                <Icon type="search" />搜索
              </Button>
            </Button.Group>
          </div>
        </div>
        <div className="" style={{ overflowY: "auto", display: this.state.display }}>
          <EquipRight  building={this.state.building}  />
          {/*<AlarmSix params={this.props.params} />*/}
        </div>
        {/*<div style={{ display: this.state.SixD, width: "98%", height: "100%", position: "absolute", top: 0, left: 10, zIndex: 99 }}>
          <div style={{ position: "relative" }}>
            <AlarmSix params={this.props.params} id={this.state.id} />
            <div className="sixAlarm" style={{ position: "absolute", bottom: 10, right: 10, }} onClick={this.handleCan}>关闭辅助</div>
          </div>
        </div>*/}
        <div style={{ display: this.state.SixD, width: this.state.widthA, height: "100%", position: "absolute", top: 0, left: 0, zIndex: 99, background: "white" }}>
          <div style={{ position: "relative", height: "100%" }}>
            <div style={{ height: this.state.heightA, width: "100%", overflow: "hidden", position: 'relative' }}>
              <span onClick={this.state.offer ? this.handleA : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 10, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenBasicMes id={this.state.id} />
            </div>
            <div style={{ height: this.state.heightB, width: "100%", marginTop: 10, overflow: "hidden", position: 'relative' }}>
              <span onClick={this.state.offer ? this.handleB : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 10, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenRoute mesid={this.state.id} />
            </div>
            <div style={{ height: this.state.heightC, width: "100%", marginTop: 10, overflow: "hidden", position: 'relative' }}>
              <span onClick={this.state.offer ? this.handleC : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 10, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenResources mesid={this.state.id} />
            </div>
            <div className="sixAlarm" style={{ position: "absolute", bottom: 10, right: 10, display: this.state.offer ? "block" : "none" }} onClick={this.handleCan}>关闭辅助</div>
          </div>
        </div>
        <div style={{ display: this.state.SixD, width: this.state.widthB, height: "100%", position: "absolute", top: 0, right: 0, zIndex: 99, background: "white" }}>
          <div style={{ position: "relative", height: "100%" }}>
            <div style={{ height: this.state.heightD, width: "100%", overflow: "hidden", position: 'relative' }}>
              <span onClick={this.state.offer ? this.handleD : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 10, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmRealTimeMonitor mesid={this.state.id} />
            </div>
            <div style={{ height: this.state.heightE, width: "100%", marginTop: 10, overflow: "hidden", position: 'relative' }}>
              <span onClick={this.state.offer ? this.handleE : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 10, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenFloor mesid={this.state.id} />
            </div>
            <div style={{ height: this.state.heightF, width: "100%", marginTop: 10, overflow: "hidden", position: 'relative' }}>
              <span onClick={this.state.offer ? this.handleF : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 10, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenEquipment mesid={this.state.id} />
            </div>
            <div className="sixAlarm" style={{ position: "absolute", bottom: 10, right: 10, display: this.state.offer ? "block" : "none" }} onClick={this.handleCan}>关闭辅助</div>
          </div>
        </div>
      </div>
    )
  }
})
class EquipCenter extends Component {
  render() {
    return (
      <EquipDefaultC EquipDefaultState={new EquipDefaultState()} />
    )
  }
}

export default EquipCenter;