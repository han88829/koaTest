﻿import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Table, Select, Modal, Row, Col, Input, Button, message, Form, Popconfirm, DatePicker, TreeSelect } from 'antd';
import moment from 'moment';
import './alarmRealTimeMonitor.css';

import Duosxt_pic from '../../../../../assets/images/application/duosxt.png';

const FormItem = Form.Item;
const Option = Select.Option;

var Num = '', ownerChildren = [];
const RangePicker = DatePicker.RangePicker;

class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
    })
  }
}

class BrandSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [],
      value: undefined
    }
  }
  componentWillMount() {
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    window.rpc.area.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        if (x.name !== "") {
          tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
        }
      })
      loop(tableDate)
      this.setState({ types, data: tableDate });
    }, (err) => {

    })
    window.rpc.owner.getArray(0, 0).then((res) => {
      res.forEach(function (x) {
        if (x.id && x.name !== '') {
          ownerChildren.push({ ...x, key: x.id })
        }
      })
      sessionStorage.setItem('owner', JSON.stringify(ownerChildren))
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const ownerId = fieldsValue['orgs'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['state'];
        let values = { dtype: 56 };

        if (name) {
          values = { ...values, name: name };
        }
        if (ownerId) {
          values = { ...values, ownerId: parseInt(ownerId, 10) }
        }
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        if (location) {
          values = { ...values, location: location }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }

        window.rpc.device.getArrayCameraByContainer(values, 0, 0).then((result) => {
          let type = result.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          Num = type.length;
          this.props.appState.tableData = type;
          message.info(`共搜索到${type.length}条数据`);
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    let data = JSON.parse(sessionStorage.getItem('owner')) || [];

    let dataChildren = [];

    data.forEach(function (value) {
      if (value.id && value.name) {
        dataChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    })

    return (
      < Form layout="inline" style={{ margin: "12px 0" }}>
        <Row>
          <Col span={5} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 190 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={5} key={2}>
            <FormItem label={`所属户籍`}>
              {getFieldDecorator(`orgs`)(
                <Select style={{ width: 190 }} placeholder="请选择">
                  {dataChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={5} key={3}>
            <FormItem label={`所属建筑`}>
              {getFieldDecorator(`location`)(
                <TreeSelect
                  style={{ width: 190 }}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.data.filter(x => x.layer === 1)}
                  placeholder="请选择建筑"
                  treeDefaultExpandAll
                  multiple
                />
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`安装时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{ width: 200 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form >
    );
  }
}

const BrandNameAdvancedSearchForm = Form.create()(BrandSearchForm);

const EquipBrandManageC = observer(class appState extends React.Component {
  constructor() {
    super();
    this.state = {
      Selected: {
        Id: null
      },
      data: [],
      pageSize: 10
    }
  }
  componentWillMount() {
    window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, 0, 0).then((res) => {
      let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerName: x.ownerName }));
      Num = type.length;
      this.props.appState.tableData = type;
      this.setState({
        data: this.props.appState.tableData
      })
    }, (err) => {
      console.warn(err);
    })
  }

  componentDidMount() {
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) }
    this.setState({ Selected });
  }
  handleStaff = () => {
    if (this.state.Selected.Id != null) {
      browserHistory.push(`/moni/manage/edit/${this.state.Selected.Id}`);
    } else {
      message.info('请选择建筑！');
    }
  }
  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id != null) {
      browserHistory.push(`/moni/manage/info/${this.state.Selected.Id}`);
    } else {
      message.info('请选择建筑！');
    }
  }
  handleStaffRemove = () => {
    if (this.state.Selected.Id != null) {
      window.rpc.brand.removeById(this.state.Selected.Id).then((res) => {
        let types = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark }));
        this.setState({ types });
        this.props.appState.tableData = types;
      }, (err) => {
        console.warn(err);
      })
    } else {
      message.info('请选择建筑！');
    }
  }
  //是否删除
  remove = () => {
    console.log(this.state.Selected.Id)
    if (this.state.Selected.Id != null) {
      window.rpc.device.removeById(this.state.Selected.Id).then((res) => {
      }, (err) => {
        console.warn(err);
      })
      window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, 0, 0).then((res) => {
        let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerId: x.ownerName }));
        Num = type.length;
        this.props.appState.tableData = type;
        this.setState({
          data: this.props.appState.tableData
        })
      }, (err) => {
        console.warn(err);
      })
      //刷新页面
    } else {
      message.info('请选择建筑！');
    }
  }
  onDelete = (key, index) => {
    window.rpc.device.removeById(index).then((res) => {
      console.log(res)
    }, (err) => {
      console.warn(err);
    })
    this.props.appState.tableData.splice(key, 1);
  }
  cancel() {
    message.error('已取消');
  }
  render() {
    const data = [...this.props.appState.tableData];
    const pagination = {
      total: Num,
      showTotal: total => `共 ${Num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        let pagenum = (parseInt(current, 10) - 1) * pageSize;
        window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, pagenum, pageSize).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, name: x.name, remark: x.remark }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      },
      onChange: (page, PageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * this.state.pageSize;
        window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, pagenum, this.state.pageSize).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, name: x.name, remark: x.remark }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      },
    };

    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
      },
    };

    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '摄像头名称', dataIndex: 'name', key: 'name', render: (text, record) => (<Link to={`/moni/manage/edit/${record.id}`}>{text}</Link>) },
      { title: '所属户籍', dataIndex: 'ownerName', key: 'ownerId', render: (text, record) => (<Link to={`/org/orgs/info/${record.ownerId}`}>{text}</Link>) },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: ((text, record) => {
          let strs = text.split("-");
          let valueN = [];
          let valueM = [];
          for (let value of strs) {
            valueN.push(parseInt(value.replace(/[^0-9]/ig, "")));
            valueM.push(value.replace(':', "").replace(/[\d]+/, ""));
          }
          return (
            <span>
              <Link to={`/org/floor/${valueN[0]}`}>{text.replace(/\:/ig, "").replace(/[\d]+/ig, "").replace(/\,/ig, "-")}</Link>
            </span>
          )
        })
      },
      { title: '安装时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '备注', dataIndex: 'remark', key: 'remark' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record, index) => (
          <div>
            <span>
              <Link to={`/moni/manage/info/${record.key}`}>查看更多</Link>
              <span className="ant-divider" />
              <Link to={`/moni/manage/edit/${record.key}`}>编辑</Link>
              <span className="ant-divider" />
              <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(index, record.key)}>
                <a href="#">删除</a>
              </Popconfirm>
            </span>
          </div>
        )
      },
    ];

    return (
      <div className="typeManage">
        {/*<div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>监控管理</Link>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={() => { browserHistory.push("/moni/manage/new") }} >新增摄像头</Button>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#d9dee4', color: '#000', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaff}><Link to="">编辑摄像头</Link></Button>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#d9dee4', color: '#000', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaffOne}><Link to="">摄像头详情</Link></Button>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Popconfirm title="确认删除?" onConfirm={this.remove} onCancel={this.cancel} okText="确定" cancelText="取消">
              <Button type="" style={{ background: '#d9dee4', color: '#000', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="">摄像头删除</Link></Button>
            </Popconfirm>
          </div>
        </div>*/}
        <BrandNameAdvancedSearchForm appState={this.props.appState} />
        <Row>
          <Col span={24}>
            <Table
              columns={columns}
              rowSelection={rowSelection}
              bordered
              dataSource={data}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    )
  }
})

var MyVedio = React.createClass({
  getInitialState: function () {
    return {
      MonitData: [],
      mData: [],
      nameData: [],
      location: null,
      brandId: null,
      networkMode: null,
      number: 0,
      visible: false,
    }
  },
  componentWillMount() {

  },
  componentDidMount() {
    let mesid = 1027;
    var SSOcxs = document.getElementById("div_boxs");

    window.rpc.device.getArrayCameraByContainer({ id: mesid }, 0, 0).then((res) => {
      let nameData = { key: res[0].id, ownerName: res[0].ownerName, name: res[0].name, location: res[0].location, };
      let loca = res[0].location;
      let location = loca.replace(/\:/ig, "").replace(/[\d]+/ig, "").replace(/\,/ig, "-");
      this.setState({ nameData, location });
    }, (err) => {
      console.warn(err);
    })
    window.rpc.device.getInfoById(mesid).then((result) => {
      window.rpc.public.tool.replaceNslookup(result.networkUrl).then((res) => {
        SSOcxs.innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
      <param name='mrl' value=${res} />
      <param name='volume' value='50' />
      <param name='autoplay' value='true' />
      <param name='loop' value='false' />
      <param name='fullscreen' value='false' />
      <param name='controls' value='true' />
      </object>`
      }, (err) => {
        console.error(err);
      })
    }, (err) => {
      console.warn(err);
    })
  },
  showModal() {
    this.setState({
      visible: true,
    });
  },
  handleOk(e) {
    let mesid = this.props.appState.selectId;
    var SSOcxs = document.getElementById("div_boxs");
    window.rpc.device.getArrayCameraByContainer({ id: mesid }, 0, 0).then((res) => {
      let nameData = { key: res[0].id, ownerName: res[0].ownerName, name: res[0].name, location: res[0].location, };
      let loca = res[0].location;
      let location = loca.replace(/\:/ig, "").replace(/[\d]+/ig, "").replace(/\,/ig, "-");
      this.setState({ nameData, location });
    }, (err) => {
      console.warn(err);
    })
    window.rpc.device.getInfoById(mesid).then((result) => {
      window.rpc.public.tool.replaceNslookup(result.networkUrl).then((res) => {
        SSOcxs.innerHTML = `<object type='application/x-vlc-plugin' pluginspage="http://www.videolan.org/" id='vlc' events='false' width="100%" height="100%" codebase="http://downloads.videolan.org/pub/videolan/vlc-webplugins/2.0.6/npapi-vlc-2.0.6.tar.xz">
      <param name='mrl' value=${res} />
      <param name='volume' value='50' />
      <param name='autoplay' value='true' />
      <param name='loop' value='false' />
      <param name='fullscreen' value='false' />
      <param name='controls' value='true' />
      </object>`
      }, (err) => {
        console.error(err);
      })
    }, (err) => {
      console.warn(err);
    })
    this.setState({
      visible: false,
    });
  },
  handleCancel(e) {
    this.setState({
      visible: false,
    });
  },
  render() {
    return (
      <div className="" style={{ backgroundColor: "white", zIndex: 1, position: "absolute", width: "100%", height: "100%", top: 0, left: 0, }} onMouseEnter={this.state.number ? "" : this.StartPlay}>
        <div style={{ width: "100%", height: "100%", background: "none", float: "left", border: "1px solid white" }}>
          <div style={{ width: "100%", height: 30, background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 12, position: "relative" }}>
            摄像头名称：{this.state.nameData ? this.state.nameData.name : "一号摄像头"}&nbsp;-->&nbsp;安装位置： {this.state.nameData ? this.state.nameData.ownerName : "国家科技园"}
            <span style={{ position: "absolute", right: 20, marginTop: 4 }}><Link to="" title="退出全屏"></Link> </span>
          </div>
          <div style={{ width: "100%", height: "80%", background: "black" }}>
            <div style={{ width: "100%", height: "100%" }} id="div_boxs"></div>
          </div>
          <div style={{ width: "100%", height: 50, background: "#333" }}>
            <img style={{ float: 'left', marginTop: 3, marginLeft: 5,cursor:"pointer" }} src={Duosxt_pic} alt="多屏监控" onClick={this.showModal} />
            <Modal
              visible={this.state.visible}
              onOk={this.handleOk}
              onCancel={this.handleCancel}
              className="sixModal"
            >
              <EquipBrandManageC appState={this.props.appState} />
            </Modal>
          </div>
        </div>
      </div>
    )
  }
});

class AlarmRealTimeMonitor extends Component {
  render() {
    return (
      <div>
        <MyVedio params={this.props.params} appState={new appState()} />
      </div>
    )
  }
}
export default AlarmRealTimeMonitor;