/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-22 10:04:20
 */

import React, { Component } from 'react';
import { Form, Button, Row, Col, message } from 'antd';
import concentFloor_pic from '../../../../assets/images/concentrate/cjzongpingtu.png';
import Alarm from '../../../../assets/images/application/hot.png';
import { Link } from 'react-router';
import moment from 'moment';

class AlarmConcenEquipment extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'block',
      devices: [],
    };
  }
  componentWillReceiveProps() {
    //查设备相关图片和坐标
    let mesid = parseInt(this.props.mesid, 10) || 1;//楼id
    let locationId = 1;//取到设备坐标
    window.rpc.area.getInfoById(mesid).then((areaData) => {
      locationId = areaData.location;
      return window.rpc.device.getInfoById(locationId).then((data) => {
        return { data, mapUrl: areaData.mapUrl };
      }).then((res) => {
        const result = res.data;
        const devices = { ...result, mapX: result.mapX ? result.mapX + "%" : "50%", mapY: result.mapY ? result.mapY + "%" : "30%", mapUrl: res.mapUrl };
        this.setState({ devices });
      }, (err) => {
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    })
  }

  render() {
    return (
      <div className="AlarmConcenEquipment" style={{ fontSize: 14, fontFamily: '苹方中等', padding: '12px', height: '100%',boxShadow:'0 0 20px rgb(0, 193, 222)' }}>
        <div style={{ width: "100%", marginBottom: 12, overflow: 'hidden' }}>
          <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 3 }}></span>
          <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left' }}>设备位置图</span>
        </div>
        <Row style={{ textAlign: 'center', height: '90%' }}>
          <div style={{ position: 'relative', width: '100%', height: '100%' }}>
            <img src={this.state.devices.mapUrl} alt="设备位置总平图" style={{ width: '100%', height: '100%' }} />
            <img id="locationMark" src={Alarm} alt="设备位置" style={{ position: 'absolute', left: this.state.devices.mapX, top: this.state.devices.mapY }} />
          </div>
        </Row>
      </div >
    );
  }
}


export default AlarmConcenEquipment;