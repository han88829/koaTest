import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, TreeSelect , Tabs, Icon} from 'antd';
//import './equipWarning.css';
import listStore from '../../../../Equipment/listStore';
import WarnInfo from './WarnInfo';
import moment from 'moment';
import Close from '../../../../../assets/images/application/shut-o.png';
const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const { TabPane } = Tabs;
message.config({
  top: 216,
  duration: 2
})

//结构出参量表
//const { warningType, resultsType } = listStore;
class appState {
  constructor() {
    extendObservable(this, {
      timer: 0,
      tableData: null,
      add() {
        this.tableData.push({ key: 4, id: 4, sign: '$', name: 'John Brown', dtype: '烟感', warningDate: '2016-09-26 08:50:08', installDate: '2015-09-26 08:50:08', address: 'New York No. 1 Lake Park', condition: '正常', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is John Brown, I am 32 years old, living in New York No. 1 Lake Park.' })
      }
    })
  }
}
class AdvancedSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      types: [],
      data: [],
      builldNames: [],
       warningType:[]
    }
  }
  componentWillMount = () => {
     window.rpc.alias.getValueByName('device.dstate').then((res) => {
      let arrWatch = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrWatch.push(values);
      }
      let  warningType = arrWatch;
      this.setState({
        warningType
      });
    }, (err) => {
      console.warn(err);
    });
     window.rpc.owner.getId().then(data => {
    //     data=parseInt(data||10)
      window.rpc.area.getArrayBriefByContainer({ownerId: 1, type: 50 },0,0).then(res => {
        let builldNames = res.map(x => ({ ...x }));
        this.setState({ builldNames });
      }, err => {
        console.warn(err)
      })
     }, err => {
       console.warn(err)
     })
    function pushChildren(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp)
      }
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = pushChildren(tableDate);
      this.setState({ data: tableDate });
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const setupTime = fieldsValue['setupTime']||null;
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        ///const lastPatrolDate = fieldsValue['lastPatrolDate'];
        const dstate = fieldsValue['dstate'];
        const location = fieldsValue['location'];
        let values = {dstate:3};
        if (name) {
          values = { ...values, name }
        }
        // if (lastPatrolDate) {
        //   values = { ...values, state: fieldsValue['lastPatrolDate'].map(x => parseInt(x, 10)) }
        // }
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => parseInt(x, 10)) }
        }
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        if(setupTime){
             if (setupTime[0]) {
           ////console.log(setupTime);
           values = { ...values, createTime: [new Date(setupTime[0].format('YYY-MM-DD')), new Date(setupTime[1].format('YYY-MM-DD'))] }
         }
        }
        
        if (location) {
          values = { ...values,floor: fieldsValue['location'].map(x => parseInt(x, 10)) };
        }

        window.rpc.device.getCountByContainer(values).then(res => {
          number = res;
        },err=>{
          console.warn(err)
        })
    // window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
      //window.rpc.alias.getValueByName('device.patrol.state').then(res => {
       window.rpc.alias.getValueByName('device.dstate').then((info) => {
          window.rpc.device.getArrayBriefByCondContainer(null, values, 0, 10).then(data => {             
        let devices = data.map(x => ({ ...x, dtype: x.typeName,
           location: x.location, key: x.id, dstate:info[x.dstate]||'', setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'),
           lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
               this.props.appState.tableData = devices;
               //this.setState({tableData:devices})
          },(err) => {
            console.warn(err);
          })
        },(err) => {
            console.warn(err);
      })
    });
    
    } catch (e) {
      console.warn(e);
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let fildes = this.state.builldNames||[];//JSON.parse(sessionStorage.getItem('locations')) || [];
    let warningType=this.state.warningType||[];
    let dtypeChildren = [];
    let fildeChildren = [];
    let waringstateChildren = [];
    let destateChildren = [];
    //整组拉所有数据 //console.log(dtypes);
    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of fildes) {
      if (value && value.id && value.type === 50) {
        fildeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let i = 1; i < warningType.length; i++) {
      waringstateChildren.push(<Option key={`${i}`}>{warningType[i]}</Option>)
    }
    // for (let i = 1; i < resultsType.length; i++) {
    //   destateChildren.push(<Option key={`${i}`}>{resultsType[i]}</Option>)
    // }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row style={{ margin: '15px 0 15px', height: '32px', lineHight: '32px' }}>
       
              <Col span={4} key={1}>
                <FormItem label={`设备名称`}>
                  {getFieldDecorator(`name`)(
                    <Input style={{ width: 140, height: 30 }} placeholder="请输入名称" />
                  )}
                </FormItem>
              </Col>
              <Col span={4} key={2}>
                <FormItem label={`设备类型`}>
                  {getFieldDecorator(`dtype`)(
                    <TreeSelect
                      style={{ width: 140 }}
                      dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                      treeData={this.state.data.filter(x => x.layer === 1)}
                      placeholder="请选择类型"
                      multiple
                    />
                  )}
                </FormItem>
              </Col>
              <Col span={4} key={3}>
                <FormItem label={`设备状态`}>
                  {getFieldDecorator(`dstate`)(
                    <Select multiple style={{ width: 140 }} placeholder="请选择">
                      {waringstateChildren}
                    </Select>
                  )}
                </FormItem>
              </Col>
      
              <Col span={4} key={4}>
                <FormItem label={`所属建筑`}>
                  {getFieldDecorator(`location`)(
                    <Select multiple style={{ width: 150 }} placeholder="请选择">
                      {fildeChildren}
                    </Select>
                  )}
                </FormItem>
              </Col>
              <Col span={6} key={5}>
                <FormItem label={`时间`}>
                  {getFieldDecorator(`setupTime`)(
                    <RangePicker style={{ width: 220 }} />
                  )}
                </FormItem>
              </Col>
              <Col span={1} key={6} className="search-btn" >
                <FormItem style={{ float: 'right', marginRight: '10px' }}>
                  <Button
                    type="primary"
                    onClick={this.handleSearch}
                    style={{ height: '32px', width: '80px', padding: 0, margin: 0, fontSize: '0.75rem' }}
                  >
                    搜索
              </Button>
              </FormItem>
        
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

let number = 0;
const EquipWarningC = observer(class appState extends React.Component {
    state={
        tableData:[],
        flag:1,
        warnInfoId:null
    }
  componentDidMount() {
    // let type = this.props.params;
    // let obj = {};
    // switch (type.type) {
    //   case '1':
    //     obj = { rstate: 1 }
    //     break;
    //   case '2':
    //     obj = { rstate: 2 }
    //     break;
    //   case '3':
    //     obj = { rstate: 3 }
    //     break;
    //   default:
    //     obj = {}
    //     break;
    // }
    let obj = { rstate: 2 };
    
      window.rpc.device.getCountByContainer({dstate:3}).then(res => {
          number = res;
        },err=>{
          console.warn(err)
        })
    // window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
      //window.rpc.alias.getValueByName('device.patrol.state').then(res => {
       window.rpc.alias.getValueByName('device.dstate').then((info) => {
          window.rpc.device.getArrayBriefByCondContainer(null, {dstate:3}, 0, 10).then(data => {
               //console.log(data);
              //  let devices =data.map((x) => ({ ...x, dtype: x.typeName, state: res[x.state]||'',
              //  rstate: warningType[x.rstate]||'', location: x.location, key: x.id, rstate:info[x.rstate]||'', 
              //  setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), 
              //  lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
               
        let devices = data.map(x => ({ ...x, dtype: x.typeName,
           location: x.location, key: x.id, dstate:info[x.dstate]||'', setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'),
           lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
               this.props.appState.tableData = devices;
               this.setState({tableData:devices})
          },(err) => {
            console.warn(err);
          })
        },(err) => {
            console.warn(err);
      })
    //  }, (err) => {
    //         console.warn(err);
    //  })
    //   }, (err) => {
    //         console.warn(err);
    //  })
    // },5000)
 
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) };
    this.setState({ Selected });
  }

  //详情跳转
  handleStaffOne = () => {
    //console.log(this.state.Selected.Id)
   if(this.state.Selected){
     if (this.state.Selected.Id) {
       //browserHistory.push(`/equip/device/info/${this.state.Selected.Id}`);
       this.setState({warnInfoId:this.state.Selected.Id})
     }else {
       message.info('请选择设备！');
     } 
    }else {
      message.info('请选择设备！');
    }
  }
 handleStaffLine = (index) => {
    console.log(index); //deviceId get
      this.setState({warnInfoId:index});
 }

 
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  add() {
    this.props.appState.tableData.push({ key: 4, id: 4, sign: '$', name: 'John Brown', dtype: '烟感', warningDate: '2016-09-26 08:50:08', installDate: '2015-09-26 08:50:08', address: 'New York No. 1 Lake Park', condition: '正常', lastPatrolDate: '2016-09-26 08:50:08', lastPatrolman: '王小明', description: 'My name is John Brown, I am 32 years old, living in New York No. 1 Lake Park.' })
  }

  maintain() {
    message.success('保养成功');
  }

  check() {
    message.success('检测成功');
  }

  render() {
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };
      const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      {
        title: '设备名称', dataIndex: 'name', key: 'name', render: (text, record) => (
          <span>
            <Link to={`/equip/device/info/${record.key}`} style={{ color: '#0099cc' }}>{text}</Link>
          </span>
        ),
      },

      {
        title: '设备类型', dataIndex: 'dtype', key: 'dtype', render: (text, record) => (
          <span>
            <Link to={`/equip/type/${record.key}`} style={{ color: '#0099cc' }}>{text}</Link>
          </span>
        ),

      },
      { title: '安装日期', dataIndex: 'setupTime', key: 'setupTime' },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record, index) => {
          let textArr = text.split(',');
          if (textArr[2]) {
            return (
              <span>
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>--
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/area/cont/${textArr[2].split(':')[0]}`}>{textArr[2].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[1]) {
            return (
              <span>
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[0]) {
            return (
              <span>
                <Link style={{ color: 'rgb(0, 153, 204)' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>
              </span>
            )
          }

        }
      },
      { title: '运行状态', dataIndex: 'dstate', key: 'dstate' },
      { title: '最后巡查日期', dataIndex: 'lastTime', key: 'lastTime' },
      { title: '最后巡查人', dataIndex: 'userName', key: 'userName' },
      {
        title: '操作', dataIndex: '', key: 'x', width: "170px", render: (text, record, index) => (
          <span>
            <Link to={``} onClick={()=>this.handleStaffLine(record.id)} style={{ color: '#0099cc' }}>查看</Link>
        </span>
         
        )
      },
    ];
    let dataA =null;
    if(this.props.appState.tableData){
       dataA=[...this.props.appState.tableData];
    }else{
      dataA =null;
    }
     let data=this.state.tableData;

    const pagination = {
      total: number,
      showTotal: total => `共 ${number} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
        const pageNum = (parseInt(current, 10) - 1) * 10

       window.rpc.alias.getValueByName('device.dstate').then((info) => {
        window.rpc.device.getArrayBriefByCondContainer(null,{dstate:3},  pageNum, 10).then(data => {
           let devices = data.map(x => ({ ...x, dtype: x.typeName,
           location: x.location, key: x.id, dstate:info[x.dstate]||'', setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'),
           lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
               this.props.appState.tableData = devices;
               this.setState({tableData:devices})
          },(err) => {
            console.warn(err);
          })
        },(err) => {
            console.warn(err);
        })
      },
    };
    return (
      <div className="EquipManage OrgManage" style={{ padding: 20 }}>

           <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
            <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
             <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备管理</Link>
           </div>
           <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
             <Button type="" style={{ background: '#536679', padding: '0 15px', height: '32px', borderRadius: 0, color: '#fff' }} onClick={this.handleStaffOne}>详情查看</Button>
           </div>
         </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={dataA?dataA:data}
              pagination={pagination}
              rowSelection={rowSelection}
            />
          </Col>
         </Row>
          <div style={{display:this.state.warnInfoId?'block':'none',position:'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff'}}>
           <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' ,padding:'20px 0 20px 20px'}}>
             <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
                <Link to=''  onClick={() => this.setState({warnInfoId:null})} style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备管理</Link>
             </div>
            <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
               <Button type="" style={{ background: '#536679', padding: '0 15px', height: '32px', borderRadius: 0, color: '#fff' }} >详情查看</Button>
            </div>
            <div className="" style={{float:'right', position:'absolute' ,top:0,right:2}}>
               <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState({warnInfoId:null})}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}></span></Button>
            </div>
         </div>
         
           <WarnInfo mesid={this.state.warnInfoId} />
            <div style={{ color: '#fff', fontSize: '0.875rem', position:'absolute' ,bottom:50,left:20}}>
              <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState({warnInfoId:null})}><span style={{ color: '#fff' }}>取消</span></Button>
            </div>
         </div>
      </div>
    );
  }
})

class MalfunctionList  extends Component {
  render() {
    return (
      <EquipWarningC appState={new appState()}  />
    )
  }
}

//export default WarningDeviceList;
export default MalfunctionList;