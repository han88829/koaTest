import React, { Component } from 'react';
// import { BaiduMap } from 'react-baidu-map';
import { notification, Icon, message, Button } from 'antd';
import { Link, browserHistory } from 'react-router';
import './alarmequipMapMonitore.css';
import UnAlarm from '../../../../../assets/images/application/fire-plug.png';
import Alarm from '../../../../../assets/images/application/hot.png';
import QuitScreen from '../../../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../../../assets/images/application/shut-o.png';
import Music from '../../../../../assets/6709.mp3';
import $ from 'jquery';
import red from '../../../../../assets/images/application/warningInstance_red.png';
import blue from '../../../../../assets/images/application/warningInstance_blue.png';


var audio;
let getidList = [];//floorid
let firstFloorid = null;

const openNotification = (data) => {
  notification.open({
    message: data,
    icon: <Icon type="smile-circle" style={{ color: '#108ee9' }} />,
    placement: 'bottomRight',
    duration: 30,
    onClose: function () {
      audio.pause();
    }
  });
};

class AlarmEquipMapMonitore extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'none',
      MMAP: false
    };
  }
  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    console.log(document.getElementById('resourcesMap'))
    loadJScript();
  }
  componentDidMount() {
    const that = this;
    // const type = parseInt(this.props.params.type, 10);
    // if (type) {
    //   this.setState({
    //     isShow: 'block',
    //   });
    // } else {
    //   this.setState({
    //     isShow: 'none',
    //   });
    // }
    function init() {
      let newId = [], param = '', makerList = [{ name: '/' }];
      const showAlarmMes = (floorsArr) => {
        const ghost = () => {
          return window.rpc.device.alarm.getArrayBriefByContainer({ floor: floorsArr, alarm: { state: 1 } }, 0, 10, console.log, console.error)
        }
        let newDivs = "";
        const ghosts = async () => {
          const res = await ghost();
          // const deviceName = await gho();
          res.map((x, index) => {
            console.log(index);
            if (index === 0) {
              firstFloorid = x.id;
            }
            newDivs += `<div style=" margin-top:10px;padding: 16px 10px 20px;overflow: hidden;width: 100%;position: relative;" class="cards">
                <span style="float: left;margin: 0px 8px 0px 16px;" class="deletes"><a href="javascript:;" ><img src=${red} alt="" /></a> </span>
                <div style="float: left;width:80%;">
                <h3 style="font-family:'微软雅黑';color: rgb(0, 193, 222);margin-bottom: 18px;font-weight:100;">警情通知</h3>     
                <div>
                  <p style="margin-bottom: 6px;"><span>报警位置:${x.location || "无"}</span></p>
                  <p>报警设备:${x.deviceName || "无"}</p>
                </div>   
                <a href="javascript:;" style="display: block;width: 45px;height: 24px;font-size: 12px;font-family: PingFang-SC-Medium;color: rgb(255, 255, 255);text-align: center;line-height: 24px;position: absolute;right: 10px;bottom: 0px;background: #00c1de;" class="watch" data-id=${x.id}>查看</a>
                </div>
              </div>`

          })
          //var arr = [1, 2, 3]
          // document.getElementsByClassName('AlarmMesCard')[0].innerHTML = newDivs
          // $('.watch').each((i) => {
          //   $('.watch').eq(i).click((e) => {
          //     e.stopPropagation()
          //     console.log($('.watch').eq(i).attr('data-id'))
          //     // that.setState({
          //     //   display: 1
          //     // })
          //     firstFloorid = null;
          //     var floorId = $('.watch').eq(i).attr('data-id');
          //     browserHistory.push(`/apply/alarmcentral/${floorId}`);
          //   })

          // })

          $('.cards').eq(0).css('background', '#f6f6f6')
          $('.cards').eq(0).find('img').attr('src', `${blue}`)
          $('.cards').eq(0).find('.watch').css({ background: '#fff', border: "1px solid #00c1de", color: "#00c1de", webkitBoxSizing: 'border-box' })
          $('.cards').each((i) => {
            $('.cards').eq(i).hover((e) => {
              e.stopPropagation()
              if (i !== 0) {
                $('.cards').eq(0).css('background', '#fff')
                $('.cards').eq(0).find('img').attr('src', `${red}`)
                $('.cards').eq(0).find('.watch').css({ background: '#00c1de', border: "none", color: "#fff" })
              }
              $('.cards').eq(i).css('background', '#f6f6f6')
              $('.cards').eq(i).find('img').attr('src', `${blue}`)
              $('.cards').eq(i).find('.watch').css({ background: '#fff', border: "1px solid #00c1de", color: "#00c1de", webkitBoxSizing: 'border-box' })

            }, (e) => {
              e.stopPropagation();
              $('#alarmallmap').hover((e) => {
                e.stopPropagation();
                $('.cards').eq(0).css('background', '#f6f6f6')
                $('.cards').eq(0).find('img').attr('src', `${blue}`)
                $('.cards').eq(0).find('.watch').css({ background: '#fff', border: "1px solid #00c1de", color: "#00c1de", webkitBoxSizing: 'border-box' })
              })

              $('.cards').eq(i).css('background', '#fff')
              $('.cards').eq(i).find('img').attr('src', `${red}`)
              $('.cards').eq(i).find('.watch').css({ background: '#00c1de', border: "none", color: "#fff" })

            })
          })
        }

        //  $('.AlarmMesCard').mouseout(() => {
        //           $('.cards').eq(0).css('background', '#f6f6f6')
        //           $('.cards').eq(0).find('img').attr('src', `${blue}`)
        //           $('.cards').eq(0).find('.watch').css({ background: '#fff', border: "1px solid #00c1de", color: "#00c1de", webkitBoxSizing: 'border-box' })
        //         })

        ghosts();
        document.body.onclick = () => {
          $('.AlarmMesCard').animate({ left: -360, opacity: 0 })
        }
        document.getElementsByClassName('AlarmMesCard')[0].style.left = '0';
        document.getElementsByClassName('AlarmMesCard')[0].style.opacity = '1';
      }
      function callBack(data) {
        sessionStorage.setItem('flag', 1)
        audio = new Audio(Music);
        audio.loop = 'loop';
        audio.play();
        newId = [];
        window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
          res.forEach(function (values) {
            data.forEach(function (x) {
              if (values.id === x.floor) {
                console.log(x.location, x.floor);
                openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
                alarm(Alarm);
                mouseoverTxt = x.locationName.slice(0, x.locationName.indexOf(','));
                var maker = new ComplexCustomOverlay(new window.BMap.Point(x.floorX, x.floorY), values.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  id: newId
                };
                getidList.push(values.id);
                //console.log(getidList);

                if (getidList.length === 1) {
                 //browserHistory.push(`/apply/alarmcentral/${getidList[0]}`)
                  getidList = [];
                }

                // console.log(values.id);
                // console.log(makerList, makerList[values.id]);
                map.addOverlay(maker)// 将标注添加到地图中
                map.removeOverlay(makerList[values.id]);//移除之前标注
                //addClickHandler(content, param, newId, obj, maker);
              }
            })
          })
          if (getidList.length >= 1) {

            showAlarmMes(getidList);
          }

        }, (err) => {
          console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }
      window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
      window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);

      var map = new window.BMap.Map("alarmallmap");
      var point = new window.BMap.Point(121.618835,
        29.920698);
      map.centerAndZoom(new window.BMap.Point(116.3964, 39.9093), 15);
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';

      map.centerAndZoom(point, 12);
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
      //console.log(map.getZoom())
      // map.zoomend(
      //   console.log("地图缩放级别"+map.getZoom(),"地图中心"+map.getCenter())
      // )
      // 编写自定义函数,创建标注
      //map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 11);
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);
      function G(id) {
        return document.getElementById(id);
      }
      map.centerAndZoom("宁波市梦幻乐园", 13);                   // 初始化地图,设置城市和地图级别。
      //sessionStorage.setItem("MAP",JSON.stringfy(map.getCenter()))
      //map.centerAndZoom(new window.BMap.Point(116.417854, 39.921988), 15);
      var data_info = [[116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
      [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
      [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
      ];
      var opts = {
        width: 100,     // 信息窗口宽度
        height: 50,     // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true//设置允许信息窗发送短息
      };
      function alarm(src) {
        //console.log(src);
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");

          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          div.appendChild(p);
          span.appendChild(document.createTextNode(this._text));
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
        //console.log(res)
        newId = '';
        res.map((x) => {
          alarm(UnAlarm)
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          map.addOverlay(maker)// 将标注添加到地图中
          //console.log(newId);
          makerList[newId] = maker;
          // addClickHandler(content, param, newId, obj, maker);
        })
      }, (err) => {
        console.warn(err);
      })

      function openInfo(content, e) {
        var p = e.target;
        var point = new window.BMap.Point(p.getPosition().lng, p.getPosition().lat);
        var infoWindow = new window.BMap.InfoWindow(content, opts);  // 创建信息窗口对象 
        map.openInfoWindow(infoWindow, point); //开启信息窗口
      }

    }

    setTimeout(() => {
      init();
    }, 1000)

  }

  render() {
    //打开六屏页面
    function openAlarmCentralize() {
      if (firstFloorid !== null) {
        //browserHistory.push(`/apply/alarmcentral/${getidList[0]}/${locationidList[0]}`);
        browserHistory.push(`/apply/equip/six/alarm/${firstFloorid}`);
      } else {

        browserHistory.push(`/apply/equip/six/alarm/1`);
        message.info("目前没有火警,请确认！")
      }
    }
    return (
      <div className="AlarmEquipMapMonitore" style={{ height: "100%" }}>
        <div style={{ position: 'absolute', right: 0, top: 0, zIndex: 999, display: this.state.isShow }}>
          <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><Link to='/safecenter' style={{ color: '#fff' }}>退出全屏</Link></Button>
          <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={openAlarmCentralize}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
        </div>
        <div className='AlarmMesCard' style={{ zIndex: 99, width: 360, position: 'absolute', left: -360, top: 0, transition: "all 0.5s", opacity: 1, fontFamily: "PingFang-SC-Medium", color: "#333744", fontSize: 14, height: '100%', background: "#fff" }}>
        </div>
        <div id="alarmallmap" style={{ height: "100%" }}></div>
      </div>
    );
  }
}

export default AlarmEquipMapMonitore;