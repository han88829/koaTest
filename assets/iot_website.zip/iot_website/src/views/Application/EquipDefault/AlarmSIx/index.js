import React, { Component } from 'react';
import { Row, Col, Card, Layout } from 'antd';
//import { browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';

import AlarmConcenRoute from './AlarmConcenRoute';//最近警力
import AlarmConcenFloor from './AlarmConcenFloor';//建筑物平面图
import AlarmConcenBasicMes from './AlarmConcenBasicMes';//基础信息
import AlarmConcenResources from './AlarmConcenResources';//资源分布
import AlarmConcenEquipment from './AlarmConcenEquipment';//设备位置图
import AlarmRealTimeMonitor from './AlarmRealTimeMonitor';//实时监控
import AlarmEquipMapMonitore from './AlarmEquipMapMonitore';//园区地图监控
//import applicationDown_pic from '../../../../assets/images/application/down.png';
import './alarmcentralize.css';

const { Content } = Layout;


// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      id: null,
    })
  }
}

const StaffC = observer(class StaffC extends Component {

  state = {
    isShowmes: 'none',
    ALarmHead: "block",
    CenterA: "block",
    CenterB: "block",
    CenterC: "block",
    CenterD: "block",
    CenterE: "block",
    CenterF: "block",
    CenterG: "block",
    CenterH: "block",
    ColA: 7,
    ColB: 6,
    ColC: 6,
    ColD: 6,
    ColE: 10,
    ColF: 7,
    ColG: 6,
    ColH: 6,
    ColI: 6,
    ColJ: 12,
    heightA: 'calc(33vh - 43px)',
    heightB: 'calc(33vh - 35px)',
    heightC: 'calc(100vh - 90px)',
    offer: true,
    heightD: "100%",
    appState: {},
    id: 2,
  }
  componentDidMount() {
    // if(this.props.id){
    //   this.setState({id:this.props.id});
    // }else{
    //   this.setState({id:1});
    // }
  }
  isShowMes = (mark) => {
    if (mark) {
      this.setState({
        isShowmes: 'block',
      });
    } else {
      this.setState({
        isShowmes: 'none',
      });
    }
  }

  handleTrue = () => {
    this.setState({
      ALarmHead: "block", CenterA: "block", CenterB: "block", CenterC: "block", CenterD: "block", CenterE: "block", CenterF: "block", CenterG: "block", CenterH: "block", ColA: 7,
      ColB: 6, ColC: 6, ColD: 6, ColE: 10, ColF: 7, ColG: 6, ColH: 6, ColI: 6, heightA: 'calc(33vh - 43px)', heightB: 'calc(33vh - 35px)', heightC: 'calc(100vh - 90px)', offer: true,
    });
  }
  handleA = () => {
    this.setState({ heightD: "800px", offer: false, ALarmHead: "none", CenterA: "block", CenterB: "none", CenterC: "none", CenterD: "none", CenterE: "none", CenterF: "none", CenterG: "none", ColA: 24, ColB: 24, heightA: '800px', });
  }
  handleB = () => {
    this.setState({ heightD: "800px", offer: false, ALarmHead: "none", CenterA: "none", CenterB: "block", CenterC: "none", CenterD: "none", CenterE: "none", CenterF: "none", CenterG: "none", ColA: 24, ColC: 24, heightA: '800px', });
  }
  handleC = () => {
    this.setState({ heightD: "800px", offer: false, ALarmHead: "none", CenterA: "none", CenterB: "none", CenterC: "block", CenterD: "none", CenterE: "none", CenterF: "none", CenterG: "none", ColA: 24, ColD: 24, heightA: '800px', });
  }
  handleD = () => {
    this.setState({ heightD: "800px", offer: false, ALarmHead: "none", CenterH: "none", CenterA: "none", CenterB: "none", CenterC: "none", CenterD: "block", CenterE: "none", CenterF: "none", CenterG: "none", ColE: 24, ColJ: 24, heightA: '0px', });
  }
  handleE = () => {
    this.setState({ heightD: "800px", offer: false, ALarmHead: "none", CenterH: "none", CenterA: "none", CenterB: "none", CenterC: "none", CenterD: "none", CenterE: "block", CenterF: "none", CenterG: "none", ColF: 24, ColG: 24, heightA: '800px', });
  }
  handleF = () => {
    this.setState({ heightD: "800px", offer: false, ALarmHead: "none", CenterH: "none", CenterA: "none", CenterB: "none", CenterC: "none", CenterD: "none", CenterE: "none", CenterF: "block", CenterG: "none", ColF: 24, ColH: 24, heightB: '800px', });
  }
  handleG = () => {
    this.setState({ heightD: "800px", offer: false, ALarmHead: "none", CenterH: "none", CenterA: "none", CenterB: "none", CenterC: "none", CenterD: "none", CenterE: "none", CenterF: "none", CenterG: "block", ColF: 24, ColI: 24, heightB: '800px', });
  }

  render() {
    this.props.appState.id = this.props.id;
    // let mesid = this.props.id || 1;
    // let id = parseInt(this.props.id, 10)

    return (
      <div style={{ background: "none" }} >
        <Layout className="ConcenHandle" style={{}}>
          {/*<Header style={{ display: this.state.ALarmHead }}>
            <div className="ConcenHandle-header">
              <dl className="ConcenHandle-chooseicon" onMouseOver={(mark) => this.isShowMes(1)} onMouseOut={(mark) => this.isShowMes(0)} onClick={() => browserHistory.push(`/apply/equip`)}>
                <dt className="choosepic">
                  <img src={applicationDown_pic} alt="隐藏页面" style={{ paddingTop: 16 }} />
                </dt>
                <dd style={{ width: 108, height: 20, position: 'absolute', top: 37, right: 30, border: '1px solid #666', paddingTop: 9, display: this.state.isShowmes }}>
                  隐藏页面
                </dd>
              </dl>
              <div style={{ height: 66, overflow: 'hidden' }}>
                <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 25 }}></span>
                <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left', marginTop: 33 }}>辅助信息</span>
              </div>
            </div>
          </Header>*/}
          <Content style={{ textAlign: 'center', height: this.state.heightD }}>
            <div style={{ padding: '5px 15px 0', height: this.state.heightC }}>
              <Row gutter={8} style={{ opacity: 100 }}>
                <Col span={this.state.ColA} style={{ display: this.state.CenterH }}>
                  <Row gutter={8} style={{ height: 'calc(100vh - 90px)', color: '#FFF' }}>
                    <Col span={this.state.ColB} style={{ height: this.state.heightA, width: '100%', display: this.state.CenterA }}>
                      <Card style={{ height: this.state.heightA, padding: '0', position: 'relative' }} >
                        {/*<span onClick={() => browserHistory.push(`/apply/alarmbasicmes/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>*/}
                        <span onClick={this.state.offer ? this.handleA : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
                        <AlarmConcenBasicMes params={this.props.params} id={this.props.id} />
                      </Card>
                    </Col>
                    <Col span={this.state.ColC} style={{ height: this.state.heightA, width: '100%', marginTop: 24, display: this.state.CenterB }}>
                      <Card style={{ height: this.state.heightA, padding: '0', position: 'relative' }} >
                        {/*<span onClick={() => browserHistory.push(`/apply/alarmroute/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>*/}
                        <span onClick={this.state.offer ? this.handleB : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
                        <AlarmConcenRoute />
                      </Card>
                    </Col>
                    <Col span={this.state.ColD} style={{ height: this.state.heightA, width: '100%', marginTop: 24, display: this.state.CenterC }}>
                      <Card style={{ height: this.state.heightA, padding: '0', position: 'relative' }} >
                        {/*<span onClick={() => browserHistory.push(`/apply/alarmsources/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>*/}
                        <span onClick={this.state.offer ? this.handleC : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
                        <AlarmConcenResources params={this.props.params} mesid={this.props.id} />
                      </Card>
                    </Col>
                  </Row>
                </Col>

                {/*中间大地图*/}
                <Col span={this.state.ColE} style={{ display: this.state.CenterD, opacity: 0 }}>
                  <Row gutter={8} style={{ height: 'calc(100vh - 80px)', color: '#FFF' }}>
                    <Col span={this.state.ColJ} style={{ height: 'calc(99vh - 80px)', width: '100%' }}>
                      <Card style={{ height: 'calc(99vh - 80px)', padding: '0', position: 'relative' }} >
                        <span onClick={this.state.offer ? this.handleD : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
                        <AlarmEquipMapMonitore />
                      </Card>
                    </Col>
                  </Row>
                </Col>

                <Col span={this.state.ColF} >
                  <Row gutter={8} style={{ height: 'calc(100vh - 80px)', color: '#FFF' }}>
                    <Col span={this.state.ColG} style={{ height: this.state.heightA, width: '100%', display: this.state.CenterE, overflowY: "auto" }}>
                      <Card style={{ height: this.state.heightA, padding: '0', position: 'relative' }} >
                        {/*<span onClick={() => browserHistory.push(`/apply/alarmtime/screens/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>*/}
                        <span onClick={this.state.offer ? this.handleE : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
                        <AlarmRealTimeMonitor params={this.props.params} mesid={this.props.id} />
                      </Card>
                    </Col>
                    <Col span={this.state.ColH} style={{ height: this.state.heightB, width: '100%', marginTop: 16, display: this.state.CenterF }}>
                      <Card style={{ height: this.state.heightB, padding: '0', position: 'relative' }} >
                        {/*<span onClick={() => browserHistory.push(`/apply/alarmfloor/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>点击全屏</span>*/}
                        <span onClick={this.state.offer ? this.handleF : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
                        <AlarmConcenFloor params={this.props.params} mesid={this.props.id} />
                      </Card>
                    </Col>
                    <Col span={this.state.ColI} style={{ height: this.state.heightB, width: '100%', marginTop: 16, display: this.state.CenterG }}>
                      <Card style={{ height: this.state.heightB, padding: '0', position: 'relative' }} >
                        {/*<span onClick={() => browserHistory.push(`/apply/alarmequip/${mesid}/${this.props.params.type = 1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>*/}
                        <span onClick={this.state.offer ? this.handleG : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer' }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
                        <AlarmConcenEquipment params={this.props.params} mesid={this.props.id} />
                      </Card>
                    </Col>
                  </Row>
                </Col>
              </Row>
            </div>
          </Content>
        </Layout>
      </div>

    );
  }
})


class AlarmCentralize extends Component {
  render() {
    return (
      <StaffC appState={new appState()} params={this.props.params} id={this.props.id} />
    )
  }
}
export default AlarmCentralize;