/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: mikey.zhaopeng
<<<<<<< HEAD
 * @Last Modified time: 2017-03-28 15:48:59
=======
 * @Last Modified time: 2017-06-13 11:32:40
>>>>>>> 84a9beca2f3f38cc1a9532537d5e40984652240a
 */

import React, { Component } from 'react';
import { Input, Row, Col, Button } from 'antd';
import { Link } from 'react-router';
import UnAlarm from '../../../assets/images/equipment/unalarm.png';
import Alarm from '../../../assets/images/equipment/1.png';
import Water from '../../../assets/images/concentrate/water.png';

class AlarmConcenResources extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'none'
    };
  }

  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    console.log(document.getElementById('resourcesMap'))
    loadJScript();
  }
  componentDidMount() {
    const type = parseInt(this.props.params.type, 10);
    console.log(type, this.props);
    if (type) {
      this.setState({
        isShow: 'block',
      });
    }
    function init() {
      // 定义组件内的变量
      let newId = [], param = '', mountText = '', mouseoverTxt = '';
      // 初始化地图
      var map = new window.BMap.Map("resourcesMap");
      var point = new window.BMap.Point(121.618835,
        29.920698);
      map.centerAndZoom(point, 12);
      map.addControl(new  window.BMap.MapTypeControl({mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP]}));        
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用

      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);

      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }

      //报警功能
      function alarm(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          div.appendChild(p);
          span.appendChild(document.createTextNode(this._text));
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }

      //添加地点
      window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
        console.log(res)
        newId = '';
        res.map((x, index) => {
          if (index === 0) {
            alarm(Alarm)
            mouseoverTxt = x.name;
            let maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
            let content = x.name;
            let obj = x;
            newId = x.id;
            console.log(newId)
            param = { 'floor': newId };
            map.addOverlay(maker)// 将标注添加到地图中
            map.centerAndZoom(maker, 25);
           // map.addControl(new  window.BMap.MapTypeControl({mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP]}));        
 
            // addClickHandler(content, param, newId, obj, maker);
          } else {
            let pt = new window.BMap.Point(x.x, x.y);
            let myIcon = new window.BMap.Icon(Water, new window.BMap.Size(32, 32));
            let marker2 = new window.BMap.Marker(pt, { icon: myIcon });  // 创建标注
            map.addOverlay(marker2);
          }

        })

        // var p1 = new window.BMap.Point(res[0].x, res[0].y);
        // var p2 = new window.BMap.Point(res[res.length - 1].x, res[res.length - 1].y);
        // var p3 = new window.BMap.Point(121.694413, 29.965648);
        // var driving = new window.BMap.DrivingRoute(map, {renderOptions:{map: map, autoViewport: true}});
        // var walking = new window.BMap.WalkingRoute(map, {renderOptions:{map: map, autoViewport: true}});
        // driving.search(p3, p2);
      }, (err) => {
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    }
    setTimeout(() => {
      init();
    }, 1000)
  }
  render() {
    //let id = this.props.params.id;
let mesid = parseInt(this.props.params.mesid, 10)||1;
    let backTo = '/apply/alarmcentral/'+ mesid;
    //console.log(this.state.isShow);
    return (

      <div className="AlarmConcenResources left-border" style={{ fontSize: 14, fontFamily: '苹方中等', padding: '12px', height: '100%' }}>
        <div style={{ width: "100%", marginBottom: 12, overflow: 'hidden' }}>
          <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 3 }}></span>
          <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left' }}>资源分布</span>
        </div>
        <div id="resourcesMap" style={{ height: '90%', width: '100%' }}></div>
        <Row style={{ margin: '0', display: this.state.isShow }}>

          <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginTop: 20 }}><Link to={backTo}>返回</Link></Button>

        </Row>
      </div>
    );
  }
}

export default AlarmConcenResources;