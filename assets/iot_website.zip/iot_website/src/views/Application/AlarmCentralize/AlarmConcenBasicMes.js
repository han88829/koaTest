/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:29 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 11:31:08
 */


import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { Link } from 'react-router';
import { observer } from 'mobx-react';
import { Tabs, Icon, Row, Col, DatePicker, Button, Form, Table, Card, message, Modal } from 'antd';
import moment from 'moment';
import star from '../../../assets/images/equipment/设备名称.png';
import er from '../../../assets/images/equipment/设备二维码.png';
import time from '../../../assets/images/equipment/安装时间.png';
import state from '../../../assets/images/equipment/布设状态.png';
import model from '../../../assets/images/equipment/采集模块.png';
import create from '../../../assets/images/equipment/创立时间.png';
import unit from '../../../assets/images/equipment/单位.png';
import address from '../../../assets/images/equipment/地址.png';
import type from '../../../assets/images/equipment/检测类型.png';
import dtype from '../../../assets/images/equipment/设备型号.png';
import shang from '../../../assets/images/equipment/生产厂家.png';
import area from '../../../assets/images/equipment/所属区域.png';
import net from '../../../assets/images/equipment/网关地址.png';
import './alarmconcenbasicmes.css';
import listStore from './listStore';
// 结构出参量表
const { armtypeList, ResultState, dStateList } = listStore;
//取出单位类型
let Orgtypes = JSON.parse(sessionStorage.getItem('Orgtypes')) || [];
const TabPane = Tabs.TabPane;


message.config({
  top: 216,
  duration: 2
})

class deviceState {
  constructor() {
    extendObservable(this, {
      runData: [{ key: 1, id: 1, state: '合格', createTime: '2016-09-26 08:50:08' }],
      patrolData: [{ key: 1, id: 1, userId: 1, type: '巡查', state: '正常', createTime: '2015-09-26 08:50:08', reportId: 1, remark: 'My name is' }],
      maintainData: [{ key: 1, id: 1, userId: 1, type: '巡查', state: '正常', createTime: '2015-09-26 08:50:08', reportId: 1, remark: 'My name is' }],

      addRun: action(function () {
        // console.log(this.runData);
        this.runData.push({ key: 2, id: 2, state: '不合格', createTime: '2016-10-26 08:50:08' })
      })
    })
  }
}

// @observer
const AlarmConcenBasicMesC = observer(class AlarmConcenBasicMesC extends Component {
  constructor() {
    super();
    this.state = {
      runData: [],
      rData: [],
      area: [],
      owner: [],
      OrgsType: null,
      device: {
        name: '',
        location: '',
        setupTime: '',
        expiryTime: '',
        lastTime: '',
        armtype: '',
        dtype: '',
        rstate: '',
        patrolId: '',
        idQc: 123,
        isShow: 'none',
      }
    };
  }
  componentWillMount() {

    const id = parseInt(this.props.params.mesid, 10)||1;
    window.rpc.device.getInfoById(id).then((result) => {
      //console.log(result);
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      window.rpc.area.getLocationName(result.location).then((res) => {
        const device = { ...result, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, location: res, };
        this.setState({ device });
        console.log(device);
      }, (err) => {
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })

    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  //单位 建筑
  componentDidMount() {
    const id = parseInt(this.props.params.mesid, 10)||1;
    const type = parseInt(this.props.params.type, 10);
    if (type) {
      this.setState({
        isShow: 'block',
      });
    } else {
      this.setState({
        isShow: 'none',
      });
    }
    //处理记录
    // window.rpc.device.alarm.getInfoById(id).then((result) => {
    //   const runData = [{ ...result, key: result.id, id: result.id, state: ResultState[result.state], type: armtypeList[result.type], userId: '巡查员A', lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString }];
    //   this.setState({ runData });
    // }, (err) => {
    //   console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    // })
    //建筑
    window.rpc.area.getInfoById(id).then((result) => {
      const area = { ...result, name: result.name, layer: result.layer, galleryful: result.galleryful, face: result.face, hight: result.hight, };
      this.setState({ area });
      //console.log(area)
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
    //单位
    window.rpc.owner.getInfoById(id).then((result) => {
      const owner = { ...result, type: Orgtypes[result.type]['name'], state: dStateList[result.state], name: result.name, asset: result.asset, face: result.face, address: result.address, peopleScale: result.peopleScale, registerTime: moment(result.registerTime).format("YYYY年MM月DD日") || new Date().toLocaleString, };

      this.setState({ owner });
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
    //处理结果详情数据
    window.rpc.device.alarm.getInfoById(id).then((result) => {
      const rData = { ...result, type: armtypeList[result.type], createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString };

      this.setState({ rData });
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  onChangeDate(date, dateString) {
    //console.log(date, dateString);
  }


  render() {
   // console.log(this.state.device);
    let mesid = parseInt(this.props.params.mesid, 10)||1;
    let backTo = '/apply/alarmcentral/'+ mesid;
    return (
      <div className="AlarmConcenBasicMes" style={{ padding: "0 12px" }}>
        <Tabs tabPosition="Top" type="card" className='alarminfoTabTwo' style={{ height: '100%' }} >
          <TabPane tab="基础信息" key="1" style={{ height: '100%', }} >
            <div style={{ height: 12 }}></div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="alarmRow-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />处理结果：已处理</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />处理人：警卫处小王007</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />所属系统：</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />所在建筑： </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />设备名称：{this.state.device.name}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />报警类型：{this.state.rData.type}  </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />所属系统： </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />所在建筑： 圆球咖啡 </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={net} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />生产厂家：</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />安装时间： {this.state.device.setupTime}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />报警时间： {this.state.rData.createTime}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={create} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />处理时间： {this.state.rData.lastTime}</div></Col>
                </Row>
              </div>
            </div>

            <div className="buildCard" style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41', borderTop: '1px solid #ddd' }}>
                <p style={{ color: '#adadad', fontsize: '0.75em', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>设备其他信息</p>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />网关地址：  </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />网关序号：</div></Col>
                </Row>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />采集模块：  </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />监控类型：</div></Col>
                </Row>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />监测类型： </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />单位：</div></Col>
                </Row>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />监测范围： </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />监测值：</div></Col>
                </Row>
              </div>
            </div>
          </TabPane>
          <TabPane tab="单位信息" className='infoTabTwoBorder' key="2">
            <div style={{ height: 12 }}></div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />单位名称：{this.state.owner.name}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />单位类型：{this.state.owner.type}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />单位状态：{this.state.owner.state}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />资产：{this.state.owner.asset} </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />面积(平方米)：{this.state.owner.face}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />详细地址：{this.state.owner.address} </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />人数规模：{this.state.owner.peopleScale} </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />注册时间：{this.state.owner.registerTime} </div></Col>
                </Row>
              </div>
            </div>
            <br />
            <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
            <br />
          </TabPane>

          <TabPane tab="建筑信息" className='infoTabTwoBorder' key="3">
            <div style={{ height: 12 }}></div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />建筑名称：{this.state.area.name}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />建筑类型：{this.state.area.type}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />层次数： {this.state.area.layer} </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />火灾危险性：{this.state.area.fireLevel} </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />容纳人数：{this.state.area.galleryful} </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />面积(平方米)： {this.state.area.face}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />高度(米)：{this.state.area.hight}</div></Col>
                  <Col span={12}></Col>
                </Row>
              </div>
            </div>

            <br />
            <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
            <br />
          </TabPane>

        </Tabs>
        <Row style={{ margin: '0', position: 'absolute', bottom: 70, left: '12px', display: this.state.isShow }}>
          <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginTop: 140, marginRight: 10, }}><Link to={backTo}>返回</Link></Button>
        </Row>
      </div>
    )
  }
})

class AlarmConcenBasicMes extends Component {
  render() {
    return (
      <AlarmConcenBasicMesC deviceState={new deviceState()} params={this.props.params} />
    )
  }
}

export default AlarmConcenBasicMes;