/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: mikey.zhaopeng
<<<<<<< HEAD
 * @Last Modified time: 2017-03-28 15:48:22
=======
 * @Last Modified time: 2017-06-13 11:31:31
>>>>>>> 84a9beca2f3f38cc1a9532537d5e40984652240a
 */
import React, { Component } from 'react';
import { Form, Button, Row, Col, message } from 'antd';
import concentFloor_pic from '../../../assets/images/concentrate/cjzongpingtu.png';
import Alarm from '../../../assets/images/application/hot.png';
//import './alarmconcenFloor.css';
import { Link } from 'react-router';
import moment from 'moment';


class AlarmConcenEquipment extends Component {

  constructor() {
    super();
    this.state = {
      isShow: 'none',
      devices: [],
    };
  }
  componentDidMount() {
    const type = parseInt(this.props.params.type, 10);
    if (type) {
      this.setState({
        isShow: 'block',
      });
    } else {
      this.setState({
        isShow: 'none',
      });
    }
    //查设备相关图片和坐标
    let mesid = parseInt(this.props.params.mesid, 10);//楼id
    let locationId = 1;//取到设备坐标
    window.rpc.area.getInfoById(mesid).then((areaData) => {
      locationId = areaData.location;
      return window.rpc.device.getInfoById(locationId).then((data) => {
        return { data, mapUrl: areaData.mapUrl };
      }).then((res) => {
        const result = res.data;
        const devices = { ...result, mapX: result.mapX||0, mapY: result.mapY||0, mapUrl: res.mapUrl };
        this.setState({ devices });
       // console.log(devices,devices.mapX,devices.mapY,devices.mapUrl);
      }, (err) => {
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    })
  }
  
  render() {
        let mesid = parseInt(this.props.params.mesid, 10) || 1;
        let locationId = parseInt(this.props.params.locationId, 10);
        let backTo = '/apply/alarmcentral/' + mesid;
        return(

      <div className= "AlarmConcenEquipment left-border" style= {{ fontSize: 14, fontFamily: '苹方中等', padding: '12px', height: '100%' }}>
  <div style={{ width: "100%", marginBottom: 12, overflow: 'hidden' }}>
    <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 3 }}></span>
    <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left' }}>设备位置图</span>
  </div>
  <Row style={{ textAlign: 'center', height: '90%' }}>
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <img src={this.state.devices.mapUrl} alt="设备位置总平图" style={{ width: '100%', height: '100%' }} />
      {/*<span id="locationMark" style={{ position: 'absolute', left: this.state.devices.mapX, top: this.state.devices.mapY, display: 'block', width: 20, height: 20, borderRadius: 50, backgroundColor: '#ff0000', }}></span>*/}
       <img id="locationMark" src={Alarm} alt="设备位置" style={{ position: 'absolute', left: this.state.devices.mapX, top: this.state.devices.mapY}} />
    </div>
  </Row>
  <hr style={{ background: '#eee', display: this.state.isShow }} />
  <Row style={{ margin: '0', display: this.state.isShow }}>

    <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginTop: 20 }}><Link to={backTo}>返回</Link></Button>

  </Row>
      </div >
    );
  }
}


export default AlarmConcenEquipment;