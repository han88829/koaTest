﻿import React, { Component } from 'react';
import { Modal, Button, Progress, Input, Upload, Icon, Row, Col, Table, message, Form,DatePicker,TreeSelect,Select } from 'antd';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import ico_image from '../../../../assets/images/monitoring/全屏-icon.png';
import ico_images from '../../../../assets/images/monitoring/视频管理-icon.png';
import Duosxt_pic from '../../../../assets/images/application/duosxt.png';
import moment from 'moment';
import "./alarmRealTimeMonitor.css";

const FormItem = Form.Item;
const Option = Select.Option;
let Num = '', ownerChildren = [];
const RangePicker = DatePicker.RangePicker;

// 设置message消息
// message.config({
//   top: 216,
//   duration: 2
// })
// 初始化mobx设置
class appState {
  // @observable tableData = [];
  // @observable selectId = null;
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      // selectIdOne: null
    })
  }
}
class BrandSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [],
      value: undefined
    }
  }
  componentWillMount() {
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    window.rpc.area.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        if (x.name !== "") {
          tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
        }
      })
      console.log(tableDate)

      loop(tableDate)
      this.setState({ types, data: tableDate });
    }, (err) => {

    })
    window.rpc.owner.getArray(0, 0).then((res) => {
      res.forEach(function (x) {
        if (x.id && x.name !== '') {
          ownerChildren.push({ ...x, key: x.id })
        }
      })
      sessionStorage.setItem('owner', JSON.stringify(ownerChildren))
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const ownerId = fieldsValue['orgs'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['state'];
        let values = { dtype: 56 };

        if (name) {
          values = { ...values, name: name };
        }
        if (ownerId) {
          values = { ...values, ownerId: parseInt(ownerId, 10) }
        }
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        if (location) {
          values = { ...values, location: location }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }


        console.log('Received values of form: ', values);
        window.rpc.device.getArrayCameraByContainer(values, 0, 0).then((result) => {
          console.log(result);
          let type = result.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          console.log(type);
          Num = type.length;
          this.props.appState.tableData = type;
          message.info(`共搜索到${type.length}条数据`);
        }, (err) => {
          console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    let data = JSON.parse(sessionStorage.getItem('owner')) || [];

    let dataChildren = [];

    data.forEach(function (value) {
      if (value.id && value.name) {
        dataChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    })

    return (
      < Form layout="inline" style={{ margin: "12px 0" }}>
        <Row>
          <Col span={5} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 190 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={5} key={2}>
            <FormItem label={`所属单位`}>
              {getFieldDecorator(`orgs`)(
                <Select style={{ width: 190 }} placeholder="请选择">
                  {dataChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={5} key={3}>
            <FormItem label={`所属建筑`}>
              {getFieldDecorator(`location`)(
                <TreeSelect
                  style={{ width: 190 }}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.data.filter(x => x.layer === 1)}
                  placeholder="Please select"
                  treeDefaultExpandAll
                  multiple
                />
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`安装时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{ width: 200 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form >
    );
  }
}


const BrandNameAdvancedSearchForm = Form.create()(BrandSearchForm);
class AlarmRealTimeMonitorC extends React.Component {

  state = {
    visiblechoose: false,
    loading: false,
    visible: false,
    previewImage: '',
    fileList: [{
      uid: -1,
      name: 'xxx.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    }],
  }


  handleOk = () => {
    this.setState({ loading: true });
    setTimeout(() => {
      this.setState({ loading: false, visible: false });
    }, 3000);
  }
  handleCancel = () => {
    this.setState({ visible: false });
  }
  componentDidMount() {
    var SSOcxs = document.getElementById("div_box");
    SSOcxs.innerHTML = '<object classid="clsid:30209FBC-57EB-4F87-BF3E-740E3D8019D2"standby="正在加载..." id="playOcx" width="100%" height="100%" name="playOcx"><param name="wmode" value="transparent" standby="正在加载..."> <embed width="300" height="200"></embed><param NAME="AutoStart" VALUE="1"> </object>';
   window.rpc.device.getArrayCameraByContainer({ dtype: 56 }, 0, 0).then((res) => {
      let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark, createTime: moment(x.createTime).format('YYYY年MM月DD日'), ownerName: x.ownerName }));
      this.props.appState.tableData = type;
      console.log(type)
    }, (err) => {
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
}

  StartPreview() {
    alert("确定要播放");
    var SSOcx = document.getElementById("playOcx");
    SSOcx.SetDeviceInfo("10.0.1.8", 37777, 0, "admin", "admin");
    SSOcx.StartPlay(); //播放
    //用来检测是否安装过：
    var objCard = document.getElementById("CardAccessor");

    if (objCard.object == null) {
      alert("CardAccessor插件未安装！");
    }
    else {
      alert("已检测到CardAccessor插件！");
    }

  }

  StopPlay() {
    var SSOcx = document.getElementById("playOcx");
    SSOcx.StopPlay();//暂停 
  }
  Capture() {

    alert('截图成功');
    var SSOcx = document.getElementById("playOcx");
    SSOcx.GetCapturePicture("d:\\1.png");//拍照
    var photos = SSOcx.GetCapturePicture("d:\\1.png");
    console.log(photos);

    window.localStorage.setItem("name", photos);
    var dd = localStorage.getItem("name");//string 1.png

  }
  StartRecord() {

    alert("开始录屏");
    var SSOcx = document.getElementById("playOcx");
    SSOcx.SaveRealData("d:\\1.avi"); //录屏

  }
  StopRecord() {

    alert("停止录制");
    var SSOcx = document.getElementById("playOcx");
    SSOcx.StopSaveRealDate();//停止录制

  }

  showModal = () => {
    this.setState({
      visiblechoose: true,
    });
  }
  handleOk = (e) => {
    if (this.props.appState.selectId != null) {
      this.setState({
        visiblechoose: false,
      });
    } else {

      message.info("请选择要播放的视频或取消！");
    }
  }
  handleCancel = (e) => {
    this.setState({
      visiblechoose: false,
    });
  }
  render() {
    let mesid = this.props.appState.mesid;
    let qpshow = '/apply/alarmrealtimemonitor/screens/'+mesid+'/1';
    const { previewVisible, previewImage, fileList } = this.state
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '摄像头名称', dataIndex: 'name', key: 'name', render: (text, record) => (<Link to={`/moni/manage/edit/${record.id}`}>{text}</Link>) },
      { title: '所属单位', dataIndex: 'ownerName', key: 'ownerId', render: (text, record) => (<Link to={`/org/orgs/info/${record.ownerId}`}>{text}</Link>) },
      { title: '安装位置', dataIndex: 'location', key: 'location', render: ((text, record) => <Link to={`/org/area/${text.substr(0, text.indexOf(':'))}`}>{text}</Link>) },
      { title: '安装时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '备注', dataIndex: 'remark', key: 'remark' },

    ];
    const data = [...this.props.appState.tableData];
    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };

    //表格单选框设置
    const rowSelection = {
      type: 'radio',
      onChange: (selectedRowKeys, selectedRows) => {
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
        this.props.appState.selectIdOne = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };
    return (

      <div className="Orgs Orgss" style={{ width: "100%", height: '26vh', padding: '12px' }}>

        <div style={{ width: "100%", height: "100%" }}>
          <div style={{ width: "100%", marginBottom: 12, overflow: 'hidden' }}>
            <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 3 }}></span>
            <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left' }}>实时监控</span>
            <img style={{ float: 'right' }} src={Duosxt_pic} alt="多屏监控" onClick={this.showModal} />
            <Modal visible={this.state.visiblechoose}
              title="监控视频信息"
              onOk={this.handleOk} onCancel={this.handleCancel}
              style={{ minWidth: 1300, minHeight: 1000, marginLeft: 300 }}
            >
            <BrandNameAdvancedSearchForm appState={this.props.appState} />
              <Row >
                <Col span={24} >
                  <Table
                    columns={columns}
                    dataSource={data}
                    pagination={pagination}
                    rowSelection={rowSelection}
                  />
                </Col>
              </Row>
            </Modal>
          </div>
          <div style={{ width: "100%", height: "90%", border: "1px solid white" }}>
            <div style={{ width: "100%", height: "12%", background: "#333744", color: "white", lineHeight: "26.66px", fontSize: "1em", paddingLeft: 5 }}>
              <span style={{ position: "relative", top: 1 }}><img src={ico_images} alt="" /></span> 摄像头名称：一号摄像头&nbsp;-->&nbsp;安装位置： 国家科技园-科创大厦-二楼楼梯口</div>
            <div style={{ width: "100%", height: "88%", background: "black" }}>
              <div style={{ width: "100%", height: "100%" }} id="div_box"></div>
            </div>
            <div style={{ width: "100%", height: "12%", background: "#333" }}>
              <div className="button_list" style={{ textAlign: 'center', position: "relative", marginLeft: '-50%', left: '50%' }}>
                <div onClick={this.StopPlay.bind(this)} className="zhanting_div" title="暂停"><a href="javascript:;" className="button_ bofang "></a></div>
                <div onClick={this.StartPreview.bind(this)} title="播放"><a href="javascript:;" className="button_  zhanting"></a></div>
                <div onClick={this.Capture.bind(this)} title="拍照"><a href="javascript:;" className="button_  paizhao"></a></div>
                <div onClick={this.StartRecord.bind(this)} title="录像"><a href="javascript:;" className="button_  luxiang"></a></div>
                <div onClick={this.StopRecord.bind(this)} title="停止录像"><a href="javascript:;" className="button_  luxiangt"></a></div>
                <div><Link to={qpshow} style={{ marginLeft: 50 }}><img src={ico_image} alt="全屏显示" /></Link> </div>
                <div>
                  <Modal
                    visible={this.state.visible}
                    title="图片信息修改"
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    footer={[
                      <Button key="back" size="large" onClick={this.handleCancel}>取消</Button>,
                      <Button key="submit" type="primary" size="large" loading={this.state.loading} onClick={this.handleOk}>
                        保存
                                    </Button>,
                    ]}
                  >
                    <div className="clearfix" style={{ float: "left" }}>
                      <Upload
                        action="//jsonplaceholder.typicode.com/posts/"
                        listType="picture-card"
                        fileList={fileList}
                        className="Uploads"
                      >
                      </Upload>
                      <Modal onCancel={this.handleCancel}>
                        <img alt="example" style={{ width: '100%' }} src={previewImage} />
                      </Modal>
                    </div>
                    <span style={{ float: "left", marginLeft: 20, marginTop: 25 }}>图片信息：</span>
                    <Input placeholder="Basic usage" style={{ float: "left", width: "350px", marginLeft: 20, marginTop: 10 }} />
                    <div style={{ width: 400, marginBottom: "50px", marginLeft: 16 }}>
                      <Progress percent={50} strokeWidth={5} status="active" />
                    </div>
                  </Modal>
                </div>

              </div>
            </div>
          </div>



        </div>

      </div>
    )
  }
}

//export default AlarmRealTimeMonitor;
class AlarmRealTimeMonitor extends Component {
  render() {
    return (
      <div className="AlarmRealTimeMonitor"  >
        <AlarmRealTimeMonitorC appState={new appState()} />
      </div>
    )
  }
}

export default AlarmRealTimeMonitor;
 // this.setState({
 //      visible: true,
 //    });