const listStore = {
  dStateList: ['/','未知', '合格', '不合格'],
  rStateList: ['/','正常', '异常', '离线'],
  networkModeList: ['/','网关', '4G', 'GSM'],
  patrolTypeList: ['/','巡查', '保养', '检测'],
  patrolStateList: ['/','巡查', '保养', '检测'],
  warningType: ['/','烟感','测温设备','灭火器'],
  resultsType: ['/','测试','已修复','已报警'],
  sexList: ['/','男','女'],
  armtypeList: ['/','测试','火情','短路'],
  ResultState:['/','已处理','误报']
}

export default listStore;