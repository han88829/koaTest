/*
 * @Author: Han.beibei 
 * @Date: 2017-04-08 11:13:48 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-20 16:14:31
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { Collapse } from 'antd';
import $ from 'jquery';
import './Backstage.css';
import listStore from '../../Equipment/listStore';

import android from '../../../assets/images/account/android.png';
import apple from '../../../assets/images/account/apple.png';
import qr from '../../../assets/images/account/qr-code.png';
import notice from '../../../assets/images/account/notice.png';
import man from '../../../assets/images/account/man.png';
import message from '../../../assets/images/account/message-o.png';
import time from '../../../assets/images/account/time.png';
import timeOne from '../../../assets/images/account/timeOne.png';
import prdu from '../../../assets/images/account/prdu.png';
import nameOne from '../../../assets/images/account/name.png';
import androidload from '../../../assets/images/account/安卓下载.png';

const Panel = Collapse.Panel;
const { taskManList } = listStore;
class Backstage extends Component {
  constructor() {
    super();
    this.state = {
      users: [],
      owners: [],
      areas: [],
      main: [],
      alarmCount: [],
      patrolCount: [],
      allDeviceCount: 0,
      commonDeviceCount: 0,
      erroeDeviceCount: 0,
      total: null,
      patrol: null,
    };
  }
  componentDidMount() {
    setTimeout(() => {
      //个人信息
      window.rpc.user.getInfo().then((result) => {
        this.setState({
          main: result,
        })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //人员
      window.rpc.user.getArray(0, 0).then((result) => {
        let users = result.map((x) => ({ ...x, key: x.id, }))
        this.setState({ users })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      // 巡查员
      window.rpc.position.patrol.user.getArrayByContainer(null, 0, 0).then((res) => {
        let patrol = res.length;
        this.setState({ patrol });
      })
      //组织
      window.rpc.cache.owner.getArrayIdNameByContainer(null, 0, 0).then((result) => {
        let owners = result.map((x) => ({ ...x, key: x.id, }))
        this.setState({ owners })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //建筑
      window.rpc.area.getArrayByContainer({ type: 50 }, 0, 0).then((result) => {
        let areas = result.map((x) => ({ ...x, key: x.id, }))
        this.setState({ areas })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //设备
      window.rpc.device.alarm.getCountFieldByContainer(null, 'type').then((result) => {
        let alarmCount = result;
        let total = parseInt(alarmCount[1], 10) || 0 + parseInt(alarmCount[2], 10) || 0 + parseInt(alarmCount[3], 10) || 0;
        this.setState({ alarmCount, total })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //维护
      window.rpc.device.patrol.getCountFieldByContainer(null, 'type').then((result) => {
        let patrolCount = result;
        this.setState({ patrolCount })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //设备数量
      window.rpc.device.getCount().then((result) => {
        let allDeviceCount = result;
        this.setState({ allDeviceCount })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //设备状态
      window.rpc.device.getCountByCond({ rstate: 1 }).then((result) => {
        let commonDeviceCount = result;
        this.setState({ commonDeviceCount })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      window.rpc.device.getCountByCond({ rstate: 2 }).then((result) => {
        let erroeDeviceCount = result;
        this.setState({ erroeDeviceCount })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
    }, 100)
  }
  handleClick(e) {
    $("#img_R").css("background-color", "#f8f8f8").html(`<img src=${androidload} alt='二维码' /><div style="font-size:12px">扫描二维码</div><div style="font-size:12px">下载Android客户端</div>`);
  }
  handleOut(e) {
    $("#img_R").css("background-color", "white").html(`<img src=${android} alt='安卓' /><div>Android</div>`);
  }
  handleClickr(e) {
    $("#img_R_O").css("background-color", "#f8f8f8").html(`<img src=${qr} alt='二维码' /><div style="font-size:12px">扫描二维码</div><div style="font-size:12px">下载iPhone客户端</div>`);
  }
  handleOutr(e) {
    $("#img_R_O").css("background-color", "white").html(`<img src=${apple} alt='苹果' /><div>iPhone</div>`);
  }
  callback(key) {
    //console.log(key);
  }

  render() {
    return (
      <div className="Backstage">
        <div style={{ height: '100%', width: '98%', marginLeft: '1%' }}>
          {/*通知栏*/}
          <div style={{ width: '100%', height: '25px', linHeight: '25px', zIndex: 99, backgroundColor: '#fff', }}>
            <img src={notice} style={{ marginLeft: 20 }} alt="" />
            <span style={{ marginLeft: 15 }}>通知： 您有<Link style={{ color: 'blue' }}>2件</Link>待办事项将达到截止时间。</span>
          </div>

          {/*头像*/}
          <div style={{ width: '100%', height: 180, marginTop: 10 }}>
            <div style={{ width: '71%', height: 180, backgroundColor: '#fff', float: 'left' }}>
              <div style={{ width: '20%', height: 180, backgroundColor: '#f9fafc', float: 'left', textAlign: 'center' }}>
                <div>
                  <img src={this.state.main.image ? this.state.main.image : man} alt="" style={{ width: 80, height: 80, border: '1px solid #cccccc', borderRadius: 80, marginTop: 10 }} />
                  <div>Hi :&nbsp;<span>{this.state.main.name}</span></div>
                  <div>
                    <img src={message} alt="" />
                    <Link to={`/memb/group/detail/${this.state.main.groupId}`}> 部门信息 </Link>
                    <span style={{ backgroundColor: '#ff9900', borderRadius: '4px', fontSize: 10 }}>HOT</span>
                  </div>
                </div>
              </div>
              <div style={{ width: '80%', height: 180, float: 'left' }}>
                <div style={{ width: '45%', height: 180, float: 'left', marginLeft: 30 }}>
                  <div className="imgR">待办事项</div>
                  <div className="imgR1"><Link style={{ color: '#373d41' }}>5</Link><span>条</span></div>
                </div>
                <div style={{ width: '45%', height: 180, float: 'left', marginLeft: 30 }}>
                  <div className="imgR">未读消息</div>
                  <div className="imgR1"><Link style={{ color: '#373d41' }}>6</Link><span>条</span></div>
                </div>
              </div>
            </div>
            {/*下载二维码*/}
            <div style={{ width: '28%', height: 180, position: 'relative', backgroundColor: '#fff', float: 'left', marginLeft: '1%' }}>
              <div onMouseEnter={this.handleClick} onMouseOut={this.handleOut} style={{ width: "35%", backgroundColor: "red", height: 140, position: "absolute", top: "6px", left: "10%", zIndex: 10, opacity: 0, cursor: "pointer" }}></div>
              <div className="img_R" id="img_R">
                {/*<div className="android">点击获取下载二维码</div>*/}
                <img src={android} alt="" />
                <div >Android</div>
              </div>
              {/*<div className="img_H" style={{ display: this.state.ImgB }} onMouseOut={() => { this.setState({ ImgA: "block", ImgB: "none" }) }}>
                <img src={qr} alt="" />
                <div>扫描二维码</div>
                <div>下载Android客户端</div>
              </div>*/}
              <div onMouseEnter={this.handleClickr} onMouseOut={this.handleOutr} style={{ width: "35%", backgroundColor: "red", height: 140, position: "absolute", top: "6px", left: "55%", zIndex: 10, opacity: 0, cursor: "pointer" }}></div>
              <div className="img_R" id="img_R_O">
                {/*<div className="apple">点击获取下载二维码</div>*/}
                <img src={apple} alt="" />
                <div>iPhone</div>
              </div>
              {/*<div className="img_H1" style={{ display: this.state.ImgD }} onMouseOut={() => { this.setState({ ImgC: "block", ImgD: "none" }) }}>
                <img src={qr} alt="" />
                <div>扫描二维码</div>
                <div>下载iPhone客户端</div>
              </div>*/}
              <div className="help">
                <Link>帮助文档链接 >></Link>
              </div>
            </div>
          </div>

          {/*主页*/}
          <div style={{ width: '100%', marginTop: 5 }}>
            <div style={{ width: '71%', float: 'left' }}>
              {/*安全预警*/}
              <div className="safe_a">
                <div>
                  <div className="safe_b">安全预警</div>
                  <div className="safe_c">
                    <span>火警 ： <span className="safe_number">{this.state.alarmCount[1] || 0}</span></span>
                    <span>事件 ： <span className="safe_number">{this.state.alarmCount[2] || 0}</span></span>
                    <span>异常 ： <span className="safe_number">{this.state.alarmCount[3] || 0}</span></span>
                  </div>
                </div>
                <div>
                  <div className="safe_d">维护保养</div>
                  <div className="safe_e">
                    <span>巡查 ： <span className="safe_number">{this.state.patrolCount[1] || 0}</span></span>
                    <span>保养 ： <span className="safe_number">{this.state.patrolCount[2] || 0}</span></span>
                    <span>检测 ： <span className="safe_number">{this.state.patrolCount[3] || 0}</span></span>
                  </div>
                </div>
              </div>

              {/*基础数据*/}
              <div className="basis_a">
                <div className="basis_title">基础数据</div>
                <div className="hr"></div>
                {/*单位信息*/}
                <div style={{ fontsize: '0.75em', color: '#373e41', padding: '0 15px', borderTop: '1px solid #ddd' }}>
                  <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>单位信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left">
                      <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                      单位总数 ：{this.state.owners.length}
                    </div>
                    <div className="Row-info-right">
                      <img src={prdu} alt="" style={{ marginRight: 20 }} />
                      建筑总数：{this.state.areas.length}
                    </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left">
                      <img src={timeOne} alt="" style={{ marginRight: 20 }} />
                      安全负责人：legalPerson
                    </div>
                    <div className="Row-info-right">
                      <img src={time} alt="" style={{ marginRight: 20 }} />
                      联系电话：legalPersonPhone
                    </div>
                  </div>
                </div>
                {/*设备信息*/}
                <div style={{ fontsize: '0.75em', color: '#373e41', padding: '0 15px', borderTop: '1px solid #ddd' }}>
                  <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>设备信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left">
                      <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                      设备总数 ：{this.state.allDeviceCount}
                    </div>
                    <div className="Row-info-right">
                      <img src={prdu} alt="" style={{ marginRight: 20 }} />
                      状态异常 ：{this.state.erroeDeviceCount}
                    </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left">
                      <img src={timeOne} alt="" style={{ marginRight: 20 }} />
                      状态正常 ：{this.state.commonDeviceCount}
                    </div>
                    <div className="Row-info-right">
                      <img src={time} alt="" style={{ marginRight: 20 }} />
                      报警次数 ：{this.state.total}
                    </div>
                  </div>
                </div>
                {/*人员信息*/}
                <div style={{ fontsize: '0.75em', padding: '0 15px', color: '#373e41', borderTop: '1px solid #ddd' }}>
                  <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>人员信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left">
                      <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                      人员总数 ：&nbsp;{this.state.users.length}
                    </div>
                    <div className="Row-info-right">
                      <img src={prdu} alt="" style={{ marginRight: 20 }} />
                      巡查员 ：{this.state.patrol}
                    </div>
                  </div>
                </div>
              </div>

              {/*需要开通购买的应用*/}
              <Collapse defaultActiveKey={['1']} onChange={this.callback}>
                <Panel header="需要开通购买/的应用" key="1" className="basis_title_one">
                  {/*需要购买左侧信息*/}
                  <div className="PanelLeft">
                    {/*单位管理*/}
                    <div style={{ fontsize: '0.75rem', paddingLeft: '15px', color: '#373e41', borderTop: '1px solid #ddd' }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>单位信息</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          单位信息
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          单位统计
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          建筑管理
                        </div>
                      </div>
                    </div>
                    {/*人员管理*/}
                    <div style={{ fontsize: '0.75rem', paddingLeft: '15px', color: '#373e41' }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>人员管理</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          人员信息
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          人员统计
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          建筑管理
                        </div>
                      </div>
                    </div>
                    {/*绩效管理*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>绩效管理</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          绩效管理
                        </div>
                      </div>
                    </div>
                    {/*任务中心*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>任务中心</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          任务清单
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          任务规则
                        </div>
                        <div className="Row-info-left">
                          <img src={timeOne} alt="" style={{ marginRight: 20 }} />
                          任务报表
                       </div>
                      </div>
                    </div>
                    {/*设施设备管理*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>设施设备管理</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          设备管理
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          设备统计
                        </div>
                        <div className="Row-info-left">
                          <img src={timeOne} alt="" style={{ marginRight: 20 }} />
                          设备预警
                        </div>
                        <div className="Row-info-left">
                          <img src={time} alt="" style={{ marginRight: 20 }} />
                          地图监控
                        </div>
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          设备维护
                        </div>
                      </div>
                    </div>
                  </div>

                  {/*需要购买右侧信息*/}
                  <div className="PanelRight">
                    {/*单位管理设置*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', borderTop: '1px solid #ddd' }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>单位管理设置</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          单位类型管理
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          建筑类型管理
                        </div>
                      </div>
                    </div>
                    {/*部门信息*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>部门信息</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          部门信息
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          部门结构
                        </div>
                        <div className="Row-info-left">
                          <img src={timeOne} alt="" style={{ marginRight: 20 }} />
                          部门权限
                        </div>
                        <div className="Row-info-left">
                          <img src={time} alt="" style={{ marginRight: 20 }} />
                          部门人员
                        </div>
                      </div>
                    </div>
                    {/*监控中心*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>监控中心</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          监控管理
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          视频管理
                        </div>
                        <div className="Row-info-left">
                          <img src={timeOne} alt="" style={{ marginRight: 20 }} />
                          截图管理
                        </div>
                        <div className="Row-info-left">
                          <img src={time} alt="" style={{ marginRight: 20 }} />
                          实时监控
                        </div>
                      </div>
                    </div>
                    {/*设备设施管理设置*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>设备设施管理设置</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          类型管理
                          </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          品牌管理
                          </div>
                      </div>
                    </div>
                    {/*警情集控中心*/}
                    <div style={{ fontsize: '0.75rem', color: '#373e41', paddingLeft: '15px', }}>
                      <p style={{ color: '#adadad', fontsize: '0.75em', marginLeft: '-10px', fontFamily: '苹方中等', padding: '15px 0 12px 9px' }}>警情集控中心</p>
                      <div className="Row-info">
                        <div className="Row-info-left">
                          <img src={nameOne} alt="" style={{ marginRight: 20 }} />
                          报警管理
                        </div>
                        <div className="Row-info-left">
                          <img src={prdu} alt="" style={{ marginRight: 20 }} />
                          报警统计
                        </div>
                        <div className="Row-info-left">
                          <img src={timeOne} alt="" style={{ marginRight: 20 }} />
                          报警处理
                        </div>
                        <div className="Row-info-left">
                          <img src={time} alt="" style={{ marginRight: 20 }} />
                          报警设定
                        </div>
                      </div>
                    </div>
                  </div>
                </Panel>
              </Collapse>

              {/*可能关注的场景*/}
              {/*<div className="attent_a">
                <div className="attent_title">您可能关注的场景<Link style={{ marginLeft: '80%' }}>查看更多<img src={update} alt="" /></Link></div>
                <div className="attent_b">
                  <div className="attent_c">
                    APP行业趋势
                    <div className="attent_e">
                      <img src={element} alt="" />
                      <div className="attent_g">高效敏捷的解决方案</div>
                      <p className="attent_f">立即查看</p>
                    </div>
                  </div>
                  <div className="attent_d">
                    <div className="attent_x">高效敏捷开发APP解决方案</div>
                    <div style={{ marginTop: 10 }}>适合客户： 从事开发APP开发企业</div>
                    <div style={{ marginTop: 10 }}>提供： APP开发全链路的解决，覆盖APP开发初始阶段架构搭建、测试、安全、加速、功能轶代各个环节</div>
                    <div style={{ marginTop: 10 }}>推荐产品：</div>
                    <div style={{ marginTop: 10 }}>移动推送</div>
                    <div style={{ marginTop: 10 }}>移动数据分析</div>
                  </div>
                </div>
                <div className="attent_z">
                  <div className="attent_y"><Link>立即查看</Link></div>
                </div>
              </div>*/}
            </div>
            {/*右侧通知信息*/}
            <div className="notice">
              {/*最新消息通知*/}
              <div>
                <div className="notice_title">最新消息通知<Link style={{ marginLeft: '70%' }}>更多</Link></div>
                <div className="hr"></div>
                <div className="button">公告</div>
                <div className="notice_conent">******************</div><br /><br />
                <div className="button">专题</div>
                <div className="notice_conent">******************</div>
              </div>
              {/*消息通知1*/}
              <div style={{ marginTop: 80 }}>
                <div className="notice_title">消息通知</div>
                <div className="hr"></div>
                <div className="button">公告</div>
                <div className="notice_conent">******************</div><br /><br />
                <div className="button">专题</div>
                <div className="notice_conent">如何快速的学习新知识！！！！！</div>
              </div>
              {/*消息通知2*/}
              <div style={{ marginTop: 80 }}>
                <div className="notice_title">产品功能和升级</div>
                <div className="hr"></div>
                <div className="notice_left">
                  <div className="notice_top"></div>
                  <div className="notice_text"></div>
                  <div className="notice_top"></div>
                </div>
                <div className="notice_right">
                  <div>12.15 &nbsp;&nbsp;&nbsp;************************</div>
                  <div>12.15 &nbsp;&nbsp;&nbsp;如何快速的学习新知识！！！！！</div>
                </div>
                <div style={{ marginTop: 50, marginLeft: '90%', fontSize: 14, fontFamily: 'PingFang-SC-Medium', }}><Link>更多</Link></div>
              </div>
              {/*最新方案发布*/}
              <div style={{ marginTop: 30 }}>
                <div className="notice_title">新解决方案发布</div>
                <div className="hr"></div>
                <div className="program">
                  <div className="notice_left">
                    <img src={apple} alt="" />
                  </div>
                  <div className="notice_right">
                    <div className="program_top">互联网+正在我国快速进行</div>
                    <div className="program_bottom">新的解决方案解决问题的效率比以往大幅度提高</div>
                  </div>
                </div>
                <div className="program">
                  <div className="notice_left">
                    <img src={apple} alt="" />
                  </div>
                  <div className="notice_right">
                    <div className="program_top">互联网+正在我国快速进行</div>
                    <div className="program_bottom">新的解决方案解决问题的效率比以往大幅度提高</div>
                  </div>
                </div>
                <div className="program">
                  <div className="notice_left">
                    <img src={apple} alt="" />
                  </div>
                  <div className="notice_right">
                    <div className="program_top">互联网+正在我国快速进行</div>
                    <div className="program_bottom">新的解决方案解决问题的效率比以往大幅度提高</div>
                  </div>
                </div>
              </div>
              {/*新产品发布*/}
              <div style={{ marginTop: 30 }}>
                <div className="notice_title">新产品发布</div>
                <div className="hr"></div>
                <div className="program">
                  <div className="notice_left">
                    <img src={android} alt="" />
                  </div>
                  <div className="notice_right">
                    <div className="product_top">互联网+正在我国快速进行</div>
                    <div className="product_bottom">新的解决方案解决问题的效率比以往大幅度提高</div>
                  </div>
                </div>
                <div className="program">
                  <div className="notice_left">
                    <img src={android} alt="" />
                  </div>
                  <div className="notice_right">
                    <div className="product_top">互联网+正在我国快速进行</div>
                    <div className="product_bottom">新的解决方案解决问题的效率比以往大幅度提高</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div >
    );
  }
}

export default Backstage;
