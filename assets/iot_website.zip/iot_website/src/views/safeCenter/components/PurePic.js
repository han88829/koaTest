import React, { Component } from 'react';

class PurePic extends Component {
  state = {
    ...this.props.pic
  }
  
  componentDidMount() {
    // console.log(this.props.pic)
  }
  
  render() {
    return (
      <div className="PurePic">
        <div className={this.state.className} style={this.state.style} onClick={()=> alert(this.state.className)}></div>
      </div>
    );
  }
}

export default PurePic;