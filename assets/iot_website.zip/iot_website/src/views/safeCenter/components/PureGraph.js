import React, { Component } from 'react';
import echarts from 'echarts';

class PureGraph extends Component {
  state = {...this.props}
  componentDidMount() {
    let graph = echarts.init(document.getElementById(this.state.id));
    graph.setOption(this.state.option);
  }

  componentWillReceiveProps(nextProps) {
    let graph = echarts.init(document.getElementById(this.state.id));
    graph.setOption(nextProps.option);
  }
  
  onMouseE() {
    let graph = echarts.init(document.getElementById(this.state.id));
    graph.setOption(this.state.option);
  }
  
  render() {
    return (
      <div className="PureGraph" onMouseEnter={this.onMouseE.bind(this)}>
        <h3 style={{margin:'auto',fontSize:14,fontFamily:'苹方',width:100,height:30,color:'#04FFFF',backgroundColor:'#162a5f',lineHeight:'30px', position:'relative', top: '-15px', zIndex: '100', textAlign: 'center' }}>{this.state.name}</h3>
        <span className="right-icon" style={{position:'absolute', top: '-5px', right: '5px', zIndex: '100'}}></span>
        <div id={this.state.id} style={this.state.style}></div>
      </div>
    );
  }
}

export default PureGraph;