/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:16:12 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-12 13:49:42
 */

import React, { Component } from 'react';
import { Row, Col } from 'antd';
import $ from 'jquery';
import echarts from 'echarts';
import right from '../../../assets/images/logined/page-turning.png';


class RightGraphs extends Component {
  state = {
    nameOne: [],
    nameTwo: [],
    names: [],
    dataOne: [],
    dataTwo: []
  }
  componentWillMount() {

  }
  componentDidMount() {
    let myChartOne = echarts.init(document.getElementById('RightGraphsOne'));
    var option = {};
    window.rpc.area.getCountFieldByContainer({}, 'fireLevel').then((result) => {
      let data = ['一级', '二级', '三级'];
      let arr = data;
      let arr1 = [];
      for (let info in result) {
        let values = `${result[info]}`;
        values = parseInt(values, 10)
        arr1.push(values);
      }
      let dataT = [];
      for (let i = 0; i < arr.length; i++) {
        let name = arr[i];
        let value = arr1[i];
        let obj = {
          name: name,
          value: value || 0,
          key: value || 0
        }
        dataT.push(obj);
      }
      this.setState({ dataTwo: dataT });
    });
    window.rpc.area.getCountFieldByContainer({}, 'fireDanger').then((result) => {
      window.rpc.alias.getValueByName('area.fireDanger').then((data) => {
        let arr = [];
        for (let key in data) {
          let value = `${data[key]}`;
          arr.push(value);
        }
        let arr1 = [];
        for (let info in result) {
          let values = `${result[info]}`;
          values = parseInt(values, 10)
          arr1.push(values);
        }
        this.setState({
          nameOne: arr1
        })
        let data1 = [];
        for (let i = 0; i < arr.length; i++) {
          let name = arr[i];
          let value = arr1[i];
          let obj = {
            name: name,
            value: value || 0,
          }
          data1.push(obj);

        }
        //此处为整个数据
        this.setState({
          dataOne: data1
        });
        option = {
          tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
          },
          legend: {
            orient: 'vertical',
            textStyle: {
              color: '#04ffff'
            },
            x: 'left',
            data: arr//['Android','IOS','OthersMobile','Windows','Mac','Linux','OthersPC']
          },
          series: [
            {
              name: '',
              type: 'pie',
              selectedMode: 'single',
              radius: [0, '30%'],
              color: ['#5d88bf', ' #a19b40', '#389c96'],
              label: {
                normal: {
                  position: 'inner'
                }
              },
              labelLine: {
                normal: {
                  show: false
                }
              },
              data: this.state.dataTwo
            },
            {
              name: '',
              type: 'pie',
              radius: ['40%', '66%'],
              color: ['#2c86b8', '#a0c730 ', '#3abbd8', '#ba7bc2', '#de5c2b', '#f0d852'],//['#9d89b7','#5d88bf', '#bc73a6', '#cf6a63', '#ce6961', '#cd9442' ],
              data: data1

            }]
        }
        myChartOne.setOption(option);
      });
    });
    //图一


    $('.ChartOne').mouseenter((e) => {
      e.stopPropagation();
      myChartOne.clear();
      myChartOne.setOption(option);
    })
    //图二
    let myChartTwo = echarts.init(document.getElementById('RightGraphsTwo'));

    var option2 = {
      backgroundColor: 'rgba(0,23,55,0)',
      tooltip: {
        show: true,
        formatter: "{b} {c}"
      },
      series: [{
        name: '单位合格占比',
        type: 'gauge',
        min: 0,
        max: 220,
        splitNumber: 5,
        radius: '120%',
        center: ['25%', '63%'],
        axisLine: { // 坐标轴线
          lineStyle: { // 属性lineStyle控制线条样式
            color: [
              [0.09, '#04ffff'],
              [0.82, '#04ffff'],
              [1, '#04ffff']
            ],
            width: 2,
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        axisLabel: { // 坐标轴小标记
          textStyle: { // 属性lineStyle控制线条样式
            fontWeight: 'bolder',
            color: '#fff',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        axisTick: { // 坐标轴小标记
          length: 10, // 属性length控制线长
          lineStyle: { // 属性lineStyle控制线条样式
            color: 'auto',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        splitLine: { // 分隔线
          length: 20, // 属性length控制线长
          lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
            width: 2,
            color: '#fff',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        pointer: { // 分隔线
          shadowColor: '#fff', //默认透明
          shadowBlur: 5,
          width: 4
        },
        title: {
          textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
            fontWeight: 'bolder',
            fontStyle: 'italic',
            color: '#fff',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10,
            fontSize: 10,
          }
        },
        detail: {
          offsetCenter: [0, '50%'], // x, y，单位px
          textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
            fontWeight: 'bolder',
            color: '#fff',
            fontSize: 10,
          }
        },
        data: [{
          value: 40,
          name: '单位'
        }]
      },
      {
        name: '设备合格占比',
        type: 'gauge',
        center: ['74%', '63%'], // 默认全局居中
        radius: '120%',
        min: 0,
        max: 100,
        //endAngle: 180,
        splitNumber: 5,
        axisLine: { // 坐标轴线
          lineStyle: { // 属性lineStyle控制线条样式
            color: [
              [0.29, '#04ffff'],
              [0.86, '#04ffff'],
              [1, '#04ffff']
            ],
            width: 1,
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        axisLabel: { // 坐标轴小标记
          textStyle: { // 属性lineStyle控制线条样式
            fontWeight: 'bolder',
            color: '#fff',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        axisTick: { // 坐标轴小标记
          length: 7, // 属性length控制线长
          lineStyle: { // 属性lineStyle控制线条样式
            color: 'auto',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        splitLine: { // 分隔线
          length: 15, // 属性length控制线长
          lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
            width: 2,
            color: '#fff',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10
          }
        },
        pointer: {
          width: 3,
          shadowColor: '#fff', //默认透明
          shadowBlur: 5
        },
        title: {
          offsetCenter: [0, '-30%'], // x, y，单位px
          textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
            fontWeight: 'bolder',
            fontStyle: 'italic',
            color: '#fff',
            shadowColor: '#fff', //默认透明
            shadowBlur: 10,
            fontSize: 10,
          }
        },
        detail: {
          //backgroundColor: 'rgba(30,144,255,0.8)',
          // borderWidth: 1,
          borderColor: '#fff',
          shadowColor: '#fff', //默认透明
          shadowBlur: 5,
          width: 80,
          height: 30,
          offsetCenter: [25, '20%'], // x, y，单位px
          textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
            fontWeight: 'bolder',
            color: '#fff',
            fontSize: 10,
          }
        },
        data: [{
          value: 34,
          name: '设备'
        }]
      }

      ]
    };

    option2.series[0].data[0].value = (Math.random() * 220).toFixed(2) - 0;
    option2.series[1].data[0].value = (Math.random() * 100).toFixed(2) - 0;
    myChartTwo.setOption(option2);
    $('.ChartTwo').mouseenter((e) => {
      e.stopPropagation();
      myChartTwo.clear();
      myChartTwo.setOption(option2);
    })


    //图四
    let myChartFour = echarts.init(document.getElementById('RightGraphsFour'));
    var data = [27, 62];
    var xMax = 100;

    let option4 = {

      tooltip: {
        show: true,
        formatter: "{b} {c}"
      },
      grid: {
        left: '20%',
      },
      xAxis: [{
        max: xMax,
        type: 'value',
        axisTick: {
          show: false,
        },
        axisLine: {
          show: false,
        },
        axisLabel: {
          show: false
        },
        splitLine: {
          show: false
        }
      }],
      yAxis: [{
        type: 'category',
        data: [{
          value: '合格单位',
          // 突出周一
          textStyle: {
            color: '#04ffff'
          }
        }, {
          value: '合格设备',
          // 突出周一
          textStyle: {
            color: '#04ffff'
          }
        },],
        nameTextStyle: {
          color: '#04ffff',
          fontSize: '14px'
        },
        axisTick: {
          show: false,
        },
        axisLine: {
          show: false,
        }
      }],
      series: [{
        name: ' ',
        type: 'bar',
        barWidth: 18,
        silent: true,
        itemStyle: {
          normal: {
            color: '#f2f2f2'
          }
        },
        barGap: '-100%',
        barCategoryGap: '50%',
        data: data.map(function (d) {
          return xMax
        }),
      },
      {
        name: ' ',
        type: 'bar',
        barWidth: 18,
        label: {
          normal: {
            show: true,
            position: 'right',
            formatter: '{c}%',
          }
        },
        data: [{
          value: 27,
          itemStyle: {
            normal: {
              color: '#b7ce9e'
            }
          }
        }, {
          value: 62,
          itemStyle: {
            normal: {
              color: '#acd680'
            }
          }
        }

        ],
      },

      ]

    };
    myChartFour.setOption(option4);
    $('.ChartFour').mouseenter((e) => {
      e.stopPropagation();
      myChartFour.clear();
      myChartFour.setOption(option4);
    });
    //图三
    let myChartThree = echarts.init(document.getElementById('RightGraphsThree'));
    let option3 = {
      backgroundColor: 'rgba(0,23,55,0)',
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#57617B'
          }
        }
      },

      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: '#04ffff'
          }
        },

        splitLine: {
          lineStyle: {
            color: '#57617B'
          }
        },
        data: ['0', '20', '40', '60', '100', '120']
      }],
      yAxis: [{
        type: 'value',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: '#04ffff'
          }
        },
        axisLabel: {
          margin: 10,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            color: '#57617B'
          }
        }
      }],
      series: [{
        name: '故障设备',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        showSymbol: false,
        lineStyle: {
          normal: {
            width: 1
          }
        },
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
              offset: 0,
              color: 'rgba(208,71,82, 0.8)' // 'rgba(137, 189, 27, 0.3)'
            }, {
              offset: 0.8,
              color: 'rgba(208,71,82, 0.1)'
            }], false),
          }
        },
        itemStyle: {
          normal: {
            color: 'rgb(208,71,82)',
            borderColor: 'rgba(208,71,82,0.27)',
            borderWidth: 12

          }
        },
        data: [220, 182, 191, 134, 150, 120, 110, 125, 145, 122, 165, 122]
      }]
    }//)
    myChartThree.setOption(option3);
    $('.ChartThree').mouseenter((e) => {
      e.stopPropagation();
      myChartThree.clear();
      myChartThree.setOption(option3);
    })
  }
  render() {
    return (
      <div className="one" style={{ height: 'calc(100vh - 136px)', width: '23.5vw' }}>
        <div id="container" style={{ width: 400, display: 'none' }} ></div>
        <Row className="left-border" style={{ height: 'calc(33.33vh - 55px)', backgroundColor: 'rgba(0,23,55,0)', width: '100%', zIndex: 1, margin: 0 }} gutter={16}>
          <Row style={{ marginTop: '-15px', textAlign: 'center' }}>
            <h3 style={{ margin: 'auto', fontSize: 14, fontFamily: '苹方', width: 100, height: 30, color: '#04ffff', backgroundColor: '#162a5f', lineHeight: '30px', cursor: 'pointer' }}>单位消安分析</h3>
            <div style={{ background: `url(${right})`, width: 30, height: 30, float: 'right', backgroundRepeat: 'no-repeat', marginTop: '-21px', marginRight: '-16px' }}></div>
          </Row>
          <Col span={18} className='ChartOne' style={{ height: 'calc(35vh - 80px)', width: '100%' }} >
            <div id="RightGraphsOne" style={{ height: 'calc(35vh - 80px)', background: 'none' }}></div>
          </Col>
        </Row>

        <Row className="left-border" style={{ height: 'calc(33.33vh - 55px)', backgroundColor: 'rgba(0,23,55,0)', width: '100%', zIndex: 1, margin: 0, marginTop: 20 }} gutter={16}>
          <Row style={{ marginTop: '-15px', textAlign: 'center' }}>
            <h3 style={{ margin: 'auto', fontSize: 14, fontFamily: '苹方', width: 100, height: 30, color: '#04ffff', backgroundColor: '#162a5f', lineHeight: '30px', cursor: 'pointer' }}>总体承载</h3>
            <div style={{ background: `url(${right})`, width: 30, height: 30, float: 'right', backgroundRepeat: 'no-repeat', marginTop: '-21px', marginRight: '-16px' }}></div>
          </Row>
          <Col span={18} className="ChartTwo" style={{ height: 'calc(25vh - 70px)', width: '100%' }}>
            <div id="RightGraphsTwo" style={{ height: 'calc(24vh - 70px)', background: 'none' }}></div>
          </Col>
          <Col span={18} className="ChartFour" style={{ height: 'calc(8vh)', width: '100%' }}>
            <div id="RightGraphsFour" style={{ height: '54px', background: 'none' }}></div>
          </Col>
        </Row>
        <Row
          className="left-border"
          style={{
            backgroundColor: 'rgba(0,23,55,0)',
            width: '100%',
            margin: 0,
            marginTop: 20,
          }}
          gutter={16}
        >
          <Row
            style={{
              marginTop: '-15px',
              textAlign: 'center'
            }} >
            <h3
              style={{
                margin: 'auto',
                fontSize: 14,
                fontFamily: '苹方',
                width: 100,
                height: 30,
                color: '#04ffff',
                backgroundColor: '#162a5f',
                lineHeight: '30px',
                cursor: 'pointer'
              }}
            >
              设备故障趋势
                </h3>
            <div
              style={{
                background: `url(${right})`,
                width: 30,
                height: 30,
                float: 'right',
                backgroundRepeat: 'no-repeat',
                marginTop: '-21px',
                marginRight: '-16px'
              }}
            >
            </div>
          </Row>
          <Col
            span={18}
            className="ChartThree"
            style={{ height: 'calc(34vh - 78px)', width: '100%' }}
          >
            <div
              id="RightGraphsThree"
              style={{ height: 'calc(34vh - 78px)', width: '100%' }}
            >
            </div>
          </Col>
        </Row>
      </div>
    );
  }
}

export default RightGraphs;