import React, { Component } from 'react';
import { browserHistory } from 'react-router';
import echarts from 'echarts';
import mapData from './mapData';
import '../newMap.css';

class NewMap extends Component {
  state = {
    nb: {
      height: 565,
      width: 465
    },
    bl: {
      className : 'beilun',
      style: {
        height: 95,
        width: 184,
        position: 'absolute',
      }
    },
    cx: {
      className : 'cixi',
      style: {
        height: 125,
        width: 207,
        position: 'absolute',
      }
    },
    dx: {
      className : 'daxie',
      style: {
        height: 20,
        width: 18,
        position: 'absolute',
      }
    },
    fh: {
      className : 'fenhua',
      style: {
        height: 150,
        width: 276,
        position: 'absolute',
      }
    },
    jb: {
      className : 'jiangbei',
      style: {
        height: 65,
        width: 88,
        position: 'absolute',
      }
    },
    ms: {
      className : 'meishan',
      style: {
        height: 28,
        width: 33,
        position: 'absolute',
      }
    },
    nh: {
      className : 'ninhai',
      style: {
        height: 186,
        width: 239,
        position: 'absolute',
      }
    },
    xs: {
      className : 'xiangshan',
      style: {
        height: 265,
        width: 193,
        position: 'absolute',
      }
    },
    yz: {
      className : 'yinzhou',
      style: {
        height: 143,
        width: 280,
        position: 'absolute',
      }
    },
    yy: {
      className : 'yuyao',
      style: {
        height: 254,
        width: 194,
        position: 'absolute',
      }
    },
    zh: {
      className : 'zhenhai',
      style: {
        height: 65,
        width: 95,
        position: 'absolute',
      }
    },
  }
  componentDidMount() {
    // console.table(mapData.ningbo);
    // let graph = echarts.init(document.getElementById('new_map_charts'));
    // graph.setOption({
    //     series: [{
    //         type: 'map',
    //         map: 'ningbo',
    //         label: {
    //             emphasis: {
    //                 textStyle: {
    //                     color: '#fff'
    //                 }
    //             }
    //         },
    //         itemStyle: {
    //             normal: {
    //                 borderColor: '#389BB7',
    //                 areaColor: '#fff',
    //             },
    //             emphasis: {
    //                 areaColor: '#389BB7',
    //                 borderWidth: 0
    //             }
    //         },
    //     }]
    // });
    setTimeout(() => {
      echarts.registerMap('ningbo', mapData.ningbo);
      var graph = echarts.init(document.getElementById('new_map_charts'));
      graph.setOption({
        series: [{
            type: 'map',
            map: 'ningbo',
            label: {
                normal: {
                    show: true,
                    textStyle: {
                        color: '#fff'
                    }
                },
                emphasis: {
                    textStyle: {
                        color: '#fff'
                    }
                }
            },
            itemStyle: {
                normal: {
                    show: true,
                    borderColor: '#fff',
                    areaColor: '#3398db',
                },
                emphasis: {
                    areaColor: '#389BB7',
                    borderWidth: 0
                }
            },
        }]
      });
      graph.on('click', function (params) {
          browserHistory.push(`/apply/equip/${params.name}`)
      });
    }, 1000)

  }

  render() {
    return (
      <div className="NewMap" style={this.state.nb}>
        {/*<PurePic pic={this.state.bl} />
        <PurePic pic={this.state.cx} />
        <PurePic pic={this.state.dx} />
        <PurePic pic={this.state.fh} />
        <PurePic pic={this.state.jb} />
        <PurePic pic={this.state.ms} />
        <PurePic pic={this.state.nh} />
        <PurePic pic={this.state.xs} />
        <PurePic pic={this.state.yz} />
        <PurePic pic={this.state.yy} />
        <PurePic pic={this.state.zh} />*/}
        <div id="new_map_charts" style={this.state.nb}></div>
      </div>
    );
  }
}

export default NewMap;