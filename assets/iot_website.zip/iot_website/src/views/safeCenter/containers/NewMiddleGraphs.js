import React, { Component } from 'react';
import { Row, Col } from 'antd';
import PureGraph from '../components/PureGraph';
import NewMap from './NewMap';
import moment from 'moment';

class NewMiddleGraphs extends Component {
  state = {
    left: {
      name: '单位巡查',
      id: 'newMiddleGraphs_hjxc',
      style: {
        position: 'relative',
        top: -15,
        overflow: 'hidden'
      },
      option: {
        baseOption: {
          backgroundColor: 'transparent',
          timeline: {
            show: false,
            axisType: 'category',
            tooltip: {
              show: true,
              formatter: function (params) {
                // console.log(params);
                return params.name + '月份数据统计';
              }
            },
            autoPlay: true,
            currentIndex: 6,
            playInterval: 1000,
            label: {
              normal: {
                show: true,
                interval: 'auto',
                formatter: '{value}月',
              },
            },
            data: [1],
          },
          grid: [{
            show: false,
            left: '4%',
            top: 15,
            bottom: 15,
            containLabel: true,
            width: '46%',
          }, {
            show: false,
            left: '50.5%',
            top: 20,
            bottom: 15,
            width: '0%',
          }, {
            show: false,
            right: '4%',
            top: 15,
            bottom: 15,
            containLabel: true,
            width: '46%',
          }, ],

          xAxis: [{
            type: 'value',
            inverse: true,
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            },
            position: 'top',
            axisLabel: {
              show: false,
              textStyle: {
                color: '#B2B2B2',
                fontSize: 12,
              },
            },
            splitLine: {
              show: true,
              lineStyle: {
                color: '#1F2022',
                width: 1,
                type: 'solid',
              },
            },
          }, {
            gridIndex: 1,
            show: false,
          }, {
            gridIndex: 2,
            type: 'value',
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            },
            position: 'top',
            axisLabel: {
              show: false,
              textStyle: {
                color: '#B2B2B2',
                fontSize: 12,
              },
            },
            splitLine: {
              show: true,
              lineStyle: {
                color: '#1F2022',
                width: 1,
                type: 'solid',
              },
            },
          }, ],
          yAxis: [{
            type: 'category',
            inverse: true,
            position: 'right',
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false,
              margin: 8,
              textStyle: {
                color: '#04ffff',
                fontSize: 12,
              },

            },
            data: ['85', '80-84', '75-79', '70-74', '65-69', '60-64', '55-59', '50-54'],
          }, {
            gridIndex: 1,
            type: 'category',
            inverse: true,
            position: 'left',
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#04ffff',
                fontSize: 12,
              },

            },
            data: ['85', '80-84', '75-79', '70-74', '65-69', '60-64', '55-59', '50-54'].map(function (value) {
              return {
                value: value,
                textStyle: {
                  align: 'center',
                }
              }
            }),
          }, {
            gridIndex: 2,
            type: 'category',
            inverse: true,
            position: 'left',
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false,
              textStyle: {
                color: '#04ffff',
                fontSize: 12,
              },

            },
            data: ['85', '80-84', '75-79', '70-74', '65-69', '60-64', '55-59', '50-54'],
          }, ],
          series: [],

        },

        options: [{
          series: [{
              name: '帅哥',
              type: 'bar',
              barGap: 20,
              barWidth: 20,
              label: {
                normal: {
                  show: false,
                },
                emphasis: {
                  show: true,
                  position: 'left',
                  offset: [0, 0],
                  textStyle: {
                    color: '#fff',
                    fontSize: 14,
                  },
                },
              },
              itemStyle: {
                normal: {
                  color: '#e25f07',
                },
                emphasis: {
                  color: '#0ff',
                },
              },
              data: [389, 259, 262, 324, 232, 176, 196, 214],
            },


            {
              name: '美女',
              type: 'bar',
              barGap: 20,
              barWidth: 20,
              xAxisIndex: 2,
              yAxisIndex: 2,
              label: {
                normal: {
                  show: false,
                },
                emphasis: {
                  show: true,
                  position: 'right',
                  offset: [0, 0],
                  textStyle: {
                    color: '#fff',
                    fontSize: 14,
                  },
                },
              },
              itemStyle: {
                normal: {
                  color: '#a2a11d',
                },
                emphasis: {
                  color: '#0ff',
                },
              },
              data: [200, 350, 300, 250, 200, 150, 100, 150],
            }
          ]
        }],
      }
    },
    right: {
      name: '设备统计',
      id: 'newMiddleGraphs_sbtj',
      style: {
        position: 'relative',
        top: -15,
        overflow: 'hidden'
      },
      option: {
        color: ['#3398DB'],
        tooltip : {
            trigger: 'axis',
            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis : [
            {
                type : 'category',
                data : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                axisTick: {
                    alignWithLabel: true
                },
                axisLabel: {
                  show: false
                },
                axisLine: {
                  lineStyle: {
                      color: '#04ffff'
                  }
              }
            }
        ],
        yAxis : [
            {
              type: 'value',
              name: '',
              nameLocation: 'end',
              nameGap: 20,
              nameTextStyle: {
                  color: '#04ffff',
                  fontSize: 16
              },
              axisLine: {
                  lineStyle: {
                      color: '#04ffff'
                  }
              },
              splitLine: {
                  show: false
              }
          }
        ],
        series : [
            {
                name:'',
                type:'bar',
                barWidth: '60%',
                data:[10, 52, 200, 334, 390, 330, 220]
            }
        ]
      }
    },
    deviceSum: 0,
    buildingSum: 0,
    memberSum: 0,
    alarmTime: '',
    alarmFrom: ''
  }

  componentDidMount() {
    const getTypeName = () => {
      return window.rpc.device.types.getArray(0, 0);
    }
    const getTypeMount = () => {
      return window.rpc.device.getCountFieldByContainer({}, 'dtype');
    }

    const getDeviceSum = () => {
      return window.rpc.device.getCount();
    }
    
    const getBuildingSum = () => {
      return window.rpc.area.getCountByContainer({ type: 50 });
    }

    const getMemberSum = () => {
      return window.rpc.user.getCount();
    }

    const getAlarm = () => {
      return window.rpc.device.alarm.getArrayBriefByContainer({alarm:{type:1, state: 2}}, 0, 1);
    }

    const getType = async () => {
      try {
        const typeName = await getTypeName();
        const typeMount = await getTypeMount();
        let types = typeName.filter(t => typeMount[t.id]).map(t => ({id:t.id,name:t.name,mount:typeMount[t.id]}))
        // console.table(types);
        this.setState((prevState) => {
          let newState = Object.assign(prevState);
          newState.right.option.xAxis[0].data = types.map(t => t.name)
          newState.right.option.series[0].data = types.map(t => t.mount)
          return {right: newState.right}
        })
        
      } catch (err) {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      }
    }

    const getMount = async () => {
      try {
        let deviceSum = await getDeviceSum();
        let buildingSum = await getBuildingSum();
        let memberSum = await getMemberSum();
        // console.log({deviceSum,buildingSum,memberSum})
        this.setState((prevState) => ({deviceSum,buildingSum,memberSum}));
      } catch (error) {
        console.warn(error);
      }
    }

    const setAlarm = async () => {
      try {
        let alarm = await getAlarm();
        // console.log(alarm);
        if(alarm.length>0){
        // console.log(moment(alarm[0].lastTime));
        let alarmTime = moment(alarm[0].lastTime).format('YYYY年MM月DD日 HH:mm:ss');
        let alarmFrom = moment().diff(moment(alarm[0].lastTime), 'days');
        this.setState((prevState) => ({alarmTime, alarmFrom}));
        }
      
      } catch (error) {
        console.warn(error);
      }
    }

    

    setTimeout(() => {
      getMount();
    getType();
    setAlarm();
    }, 1000);
  }
  

  render() {
    function toThousands(num) {
      let f = `${num}`;
      let g = f.split('');
      let len = g.length;
      return g.map((x, index) => (len -index) % 3 === 0 ? ` ${x}` : x).join('');
    }

    return (
      <div className="NewMiddleGraphs">
        <div>
          <span>近期报警</span>
          <span style={{fontFamily:'Digifacea766ed5ac18f50'}}>{this.state.alarmTime}</span>
          <span>安全运行天数</span>
          <span style={{fontFamily:'Digifacea766ed5ac18f50', color: '#e22b2b'}}>{this.state.alarmFrom}天</span>
        </div>
        <div>
          <span>已接入设备数据</span>
          <span style={{fontFamily:'Digifacea766ed5ac18f50'}}>{toThousands(this.state.deviceSum)}</span>
          <span>已接入建筑数据</span>
          <span style={{fontFamily:'Digifacea766ed5ac18f50'}}>{toThousands(this.state.buildingSum)}</span>
          <span>安全人员</span>
          <span style={{fontFamily:'Digifacea766ed5ac18f50'}}>{toThousands(this.state.memberSum)}</span>
        </div>
        <div style={{paddingTop: 20}}>
          <Row gutter={16}>
            <Col span={12}>
              <PureGraph {...this.state.left} />
            </Col>
            <Col span={12}>
              <PureGraph {...this.state.right} />
            </Col>
          </Row>
        </div>
        <div className="map_ana_dot" style={{ position:'absolute', top: 212 ,right: 242, zIndex: '100' }}></div>
        <div className="map_ana_dot" style={{ position:'absolute', top: 224 ,right: 236, zIndex: '100' }}></div>
        <div className="map_ana_dot" style={{ position:'absolute', top: 211 ,right: 225, zIndex: '100' }}></div>
        <NewMap />
      </div>
    );
  }
}

export default NewMiddleGraphs;