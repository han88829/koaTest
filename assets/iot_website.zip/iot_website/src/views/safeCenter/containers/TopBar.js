/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:16:12 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-11 15:29:19
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { Menu, Dropdown, Icon } from 'antd';
import axios from 'axios';
import moment from 'moment';

moment().locale('zh-cn');

class TopBar extends Component {
  state = {
    time: '',
    days: '',
    weeks: '',
    weatherName: 'weatherName0'
  }

  componentWillMount() {
    this.timer = setInterval(() => {
      let time = moment().format("HH:mm:ss");
      let days = moment().format('YYYY/MM/DD');
      let week = moment().format('d');
      let weeks = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日'][week - 1];
      this.setState({ time, days, weeks })
    }, 500);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
  }

  componentDidMount() {
    const weather = (city) => {
      return axios.get(`/v3/weather/now.json?key=pp1h1m0efhxnoodr&location=${city}&language=zh-Hans&unit=c`)
    }
    const getW = async (city) => {
      try {
        let w = await weather(city);
        let now = w.data.results[0].now;
        let weatherName = `weatherName${now.code}`;
        this.setState({ weatherName })
      } catch (error) {
        console.log(error);
      }
    }

    getW('ningbo');
  }


  render() {
    const menu = (
      <Menu>
        <Menu.Item key="0">
          <Link to="/apply/alarmequipmapmonitore/1">警情集中处理</Link>
        </Menu.Item>
        <Menu.Item key="1">
          <Link to="/apply/monitor">监控综合管理</Link>
        </Menu.Item>
        <Menu.Item key="2">
          <Link to="/apply/duty">执勤实时监控</Link>
        </Menu.Item>
        {/*<Menu.Item key="3">
          <Link to="/member">数据可视化</Link>
        </Menu.Item>*/}
        <Menu.Item key="4">
          <Link to="/apply/equipcenter">设备统一管理</Link>
        </Menu.Item>
      </Menu>
    );

    return (
      <div className="TopBar">
        <div className="TopBar-logo">消防设备安全云中心</div>
        <div className="TopBar-weather">
          <div style={{ fontFamily: 'Microsoft YaHei', fontSize: 22 }}>
            <span className={this.state.weatherName} id="Top_weather" style={{ height: 36, width: 36, backgroundSize: 'contain', marginRight: 12 }}></span>
            <span>{this.state.time}</span>
          </div>
          <div style={{ fontFamily: 'PingFang-SC-Medium', fontSize: 14 }}>
            <span>{this.state.days}</span><span>{this.state.weeks}</span>
          </div>
        </div>
        <div className="TopBar-menu">
          <div><Link to="/apply/equip" style={{ color: '#fff' }}>应急中心</Link></div>
          <div><Link to="/back" style={{ color: '#fff' }}>数据中心</Link></div>
          <div>
            <Dropdown overlay={menu} trigger={['click']} getPopupContainer={() => document.querySelector('.TopBar')}>
              <a className="ant-dropdown-link" href="#" >
                <span style={{ color: '#fff' }}>GIS应用</span> <Icon type={"down"} style={{ color: '#fff' }} />
              </a>
            </Dropdown>
          </div>
        </div>
      </div>
    );
  }
}

export default TopBar;
