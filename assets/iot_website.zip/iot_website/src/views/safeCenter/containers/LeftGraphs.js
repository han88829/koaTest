/*
 * @Author: Han.beibei 
 * @Date: 2017-03-15 17:04:25 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-12 13:49:44
 */
import React, { Component } from 'react';
import { Row, Col } from 'antd';
import { Link } from 'react-router';
import echarts from 'echarts';
import china from '../../../assets/images/logined/map-china.png';
import right from '../../../assets/images/logined/page-turning.png';
import background from '../../../assets/images/safecenter/bg.png';
import '../safeCenter.css';

class LeftGraphs extends Component {
  componentDidMount() {
    //图一
    let myChartOne = echarts.init(document.getElementById('LeftGraphsOne'));
    let optionOne = {
      title: {
        text: '城市定位表格',
        color: '#04ffff',
        textStyle: {
          fontWeight: 'normal',
          fontSize: 12,
          color: '#04ffff'
        },
        left: '10%'
      },
      // backgroundColor:"none",
      tooltip: {
        show: true,
        formatter: "{b} {c}"
      },
      grid: {
        left: '40%',
        top: '15%',
        bottom: '10px',
        right: '10px'
      },
      xAxis: [
        {
          max: 100,
          type: 'value',
          nameTextStyle: {
            color: '#04ffff',
          },
          textStyle: {
            color: '#04ffff',
          },
          axisTick: {
            show: false,
          },
          axisLine: {
            show: false,
          },
          axisLabel: {
            show: false
          },
          splitLine: {
            show: false
          }
        }
      ],
      yAxis: [
        {
          type: 'category',
          data: ['苏州', '上海', '杭州', '北京', '合肥', '宁波'],
          nameTextStyle: {
            color: '#04ffff',
            fontSize: '18px'
          },
          axisTick: {
            show: false,
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#04ffff',
            }
          }
        }
      ],
      series: [
        {
          name: ' ',
          type: 'bar',
          textStyle: {
            color: '#04ffff'
          },
          barWidth: 16,
          silent: true,
          itemStyle: {
            normal: { color: '#f2f2f2' }
          },
          barGap: '-100%',
          barCategoryGap: '50%',
          data: [65, 20, 45, 56, 60, 17].map(function (d) {
            return 100
          }),
        },
        {
          name: ' ',
          type: 'bar',
          barWidth: 16,
          label: {
            normal: {
              show: true,
              position: 'right',
              formatter: '{c}%',
            }
          },
          data: [
            {
              value: 17,
              itemStyle: {
                normal: { color: '#b7ce9e' }
              }
            }, {
              value: 20,
              itemStyle: {
                normal: { color: '#acd680' }
              }
            }, {
              value: 45,
              itemStyle: {
                normal: { color: '#88e186' }
              }
            }, {
              value: 56,
              itemStyle: {
                normal: { color: '#81e7cf' }
              }
            }, {
              value: 60,
              itemStyle: {
                normal: { color: '#82dae6' }
              }
            }, {
              value: 64,
              itemStyle: {
                normal: { color: '#80cbc4' }
              }
            }
          ],
        }
      ]
    }
    myChartOne.setOption(optionOne);
    document.getElementById('left-top').onmouseenter = function () {
      myChartOne.clear();
      myChartOne.setOption(optionOne);
    }
    
    window.rpc.owner.types.getArray(0, 0).then(result => {
      return window.rpc.owner.getCountFieldByContainer({}, 'type').then(data => ({ result, data }))
    }).then((res) => {
      let tableDate = res.result.filter(x => x).map(x => ({ ...x, key: x.id, value: res.data[x.id] || 0 })).filter(x => x.id);
  
      //图二
      let myChartTwo = echarts.init(document.getElementById('LeftGraphsTwo'));
      let option = {
        tooltip: {
          trigger: 'item',
          position: ['73%', '40%'],
          backgroundColor: 'rgba(50,50,50,0)',
          textStyle: {
            color: '#04ffff',
          },
          formatter: "{a} <br/>{b}<br/> 数量: {c} ({d}%)"
        },
        legend: {
          x: "left",
          height: 210,//显示过多，设置高度，拒绝自动换行
          orient: 'vertical',
          textStyle: {
            color: '#04ffff',
          },
          data: tableDate.filter(x => x.layer === 1).map(x => (x.name)),

        },
        series: [
          {
            name: '单位分布',
            type: 'pie',
            radius: ['5%', '70%'],
            roseType: 'area',
            color: ['#ed5198', '#a1cd3c', '#0194e1', '#bc5fd2', "#f8b51e ", "#5fd3bc", "#ff2323", "#42fc15", "#13fffd"],
            data: tableDate.filter(x => x.layer === 1).map(x => ({ ...x, name: x.name, vaule: x.vaule })),
            labelLine: {
              normal: {
                show: false
              }
            },
            label: {
              normal: {
                show: false
              }
            },
            itemStyle: {
              normal: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              },
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          },
          {
            name: '',
            type: 'gauge',
            min: 0,
            max: 9,
            startAngle: 90,
            endAngle: 449.9,
            radius: '82%',
            splitNumber: 9,
            clockwise: false,
            animation: false,
            detail: {
              formatter: { name },
              textStyle: {
                color: '#63869e'
              }
            },
            detail: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLine: {
              lineStyle: {
                color: [
                  [0.25, '#63869e'],
                  [0.75, '#63869e'],//外圈边框颜色
                  [1, '#63869e']
                ],
                width: '40%',
                shadowColor: '#0d4b81', //默认透明
                shadowBlur: 40,
                opacity: 1
              }
            },
            splitLine: {
              length: 5,
              lineStyle: {
                color: '#ffffff',
                width: 2
              }
            },
            axisLabel: {
              formatter: function (v) {
                return v ? v : '';
              },
              textStyle: {
                color: "red",
                fontWeight: 700
              }
            },
            itemStyle: {
              normal: {
                color: 'green',
                width: 2
              }
            }
          },
          {
            name: '',
            type: 'gauge',
            min: 0,
            max: 10,
            startAngle: 90,
            endAngle: 449.9,
            radius: '72%',
            splitNumber: 10,
            clockwise: false,
            animation: false,
            detail: {
              formatter: { name },
              textStyle: {
                color: '#63869e'
              }
            },
            detail: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLine: {
              lineStyle: {
                color: [
                  [1, '#001737']
                ],
                width: '10%',
                opacity: 0.8
              }
            },
            splitLine: {
              show: true,
              length: '92%',
              lineStyle: {
                color: 'grey',
                width: '1'
              }
            },
            axisLabel: {
              show: false,
              formatter: function (v) {
                return v ? v : '';
              },
              textStyle: {
                color: "#fb5310",
                fontWeight: 700
              }
            },
            itemStyle: {
              normal: {
                color: 'green',
                width: 2,
                borderWidth: 3,
              }
            }
          }
        ]
      }

      setTimeout(() => {
        myChartTwo.setOption(option)
      }, 300)
      document.getElementById('LeftGraphsTwo').onmouseenter = function () {
        myChartTwo.clear();
        option.legend.data = tableDate.filter(x => x.layer === 1).map(x => (x.name));
        option.series[0].data = tableDate.filter(x => x.layer === 1).map(x => ({ ...x, name: x.name, vaule: x.vaule }));
        myChartTwo.setOption(option);
      }
    }, (err) => {
      console.warn(err);
    });

    //图三
    let myChartThree = echarts.init(document.getElementById('LeftGraphsThree'));
    let option = {
      title: {
        text: '',
        subtext: ''
      },
      color: ['#162a5f', '#50acfe', '272c34'],
      // backgroundColor: '#001737',
      tooltip: {
        trigger: 'axis'
      },
      // legend: {
      //     data:['最高气温','最低气温']
      // },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['2', '4', '6', '8', '10', '12', '14'],
        nameTextStyle: {
          color: '#04ffff',
        },
        textStyle: {
          color: '#04ffff',
        },
        axisLine: {
          lineStyle: {
            color: '#04ffff'
          }
        },
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          formatter: '{value}'
        },
        axisLine: {
          lineStyle: {
            color: '#04ffff'
          }
        },
      },
      series: [{
        name: '最高电流',
        type: 'line',
        data: [11, 11, 15, 13, 12, 13, 10, 15],
        markPoint: {
          data: [{
            type: 'max',
            name: '最大值'
          }, {
            type: 'min',
            name: '最小值'
          }]
        },
        markLine: {
          data: [{
            type: 'average',
            name: '平均值'
          }]
        }
      }, {
        name: '最低电流',
        type: 'line',
        data: [1, 0, 2, 5, 3, 2, 3, 4],
        markPoint: {
          data: [{
            name: '周最低',
            value: -2,
            xAxis: 1,
            yAxis: -1.5
          }]
        },
        markLine: {
          data: [{
            type: 'average',
            name: '平均值'
          }]
        },
        smooth: true, //曲线
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
              offset: 0,
              color: 'rgba(216, 244, 247,1)'
            }, {
              offset: 1,
              color: 'rgba(216, 244, 247,1)'
            }], false)
          }
        },
      }, {
        name: '中间电流',
        type: 'line',
        data: [3, 2, 8, 6, 8, 3, 5, 3],
        smooth: true, //曲线
        //折线下方填充
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
              offset: 0,
              color: 'rgba(216, 244, 247,1)'
            }, {
              offset: 1,
              color: 'rgba(216, 244, 247,1)'
            }], false)
          }
        },
        markPoint: {
          data: [{
            name: '周最低',
            value: -2,
            xAxis: 1,
            yAxis: -1.5
          }]
        },
        markLine: {
          data: [{
            type: 'average',
            name: '平均值'
          }]
        }
      }]
    };
    var timer = setInterval(() => {
      let dataTop = [], dataC = [], dataB = [];
      for (let i = 0; i < 7; i++) {
        dataTop[i] = parseInt((Math.random() * 5 + 10), 10);
        dataC[i] = parseInt((Math.random() * 5), 10);
        dataB[i] = parseInt((Math.random() * 5 + 5), 10);
      }
      option.series[0].data = dataTop;
      option.series[1].data = dataC;
      option.series[2].data = dataB;
      myChartThree.setOption(option)
    }, 1000)
  }

  render() {
    return (
      <div className="one" style={{ height: 'calc(100vh - 136px)', width: '23.5vw', marginLeft: 10 }}>
        <Row className="left-border" id="left-top" style={{ height: 'calc(33.33vh - 55px)', backgroundImg: { background }, width: '100%', zIndex: 1, }} gutter={16}>
          <Row style={{ marginTop: '-25px', textAlign: 'center' }}>
            <h3 style={{ margin: 'auto', fontSize: 14, fontFamily: '苹方', width: 100, height: 30, color: '#04ffff', marginTop: 10, backgroundColor: '#162a5f', lineHeight: '30px' }}>系统部署分布</h3>
            <div style={{ background: `url(${right})`, width: 30, height: 30, float: 'right', backgroundRepeat: 'no-repeat', marginTop: '-18px', marginRight: '-16px' }}></div>
          </Row>
          <Col span={16} style={{ marginTop: "-13px", position: "relative" }} >
            <img src={china} style={{ backgroundRepeat: 'no-repeat', width: 310 }} alt="china" />
            <span style={{ fontFamily: '苹方', color: '#04ffff', fontSize: 10, position: "absolute", top: "73%", right: "15%" }}>浙江宁波</span>
          </Col>
          <Col span={8} style={{ padding: '-2px' }}>
            <div id="LeftGraphsOne" style={{ height: 'calc(31vh - 60px)', background: 'none' }}></div>
          </Col>
        </Row>

        <Row className="left-border" id="left-content" style={{ height: 'calc(33.33vh - 55px)', backgroundImg: { background }, width: '100%', zIndex: 1, marginTop: 20, cursor: "pointer" }} gutter={16}>
          <Row style={{ marginTop: '-15px', textAlign: 'center' }}>
            <Link to="/org/manage"><h3 style={{ margin: 'auto', fontSize: 14, fontFamily: '苹方', width: 100, height: 30, color: '#04ffff', backgroundColor: '#162a5f', lineHeight: '30px' }}>单位类型分布</h3></Link>
            <div style={{ background: `url(${right})`, width: 30, height: 30, float: 'right', backgroundRepeat: 'no-repeat', marginTop: '-18px', marginRight: '-16px', zIndex: 5 }}></div>
          </Row>
          <Col span={16} style={{ height: 'calc(33vh - 70px)', width: '100%' }}>
            <div id="LeftGraphsTwo" style={{ height: 'calc(33vh - 70px)', width: "100%", background: 'none' }}></div>
          </Col>
        </Row>

        <Row className="left-border" id="left-bottom" style={{ backgroundImg: { background }, width: '100%', marginTop: 20, }} gutter={16}>
          <Row style={{ marginTop: '-15px', textAlign: 'center' }}>
            <h3 style={{ margin: 'auto', fontSize: 14, fontFamily: '苹方', width: 100, height: 30, color: '#04ffff', backgroundColor: '#162a5f', lineHeight: '30px' }}>剩余电流检测</h3>
            <div style={{ background: `url(${right})`, width: 30, height: 30, float: 'right', backgroundRepeat: 'no-repeat', marginTop: '-18px', marginRight: '-16px', zIndex: 5 }}></div>
          </Row>
          <Col span={16} style={{ height: 'calc(33vh - 70px)', width: '100%' }}>
            <div id="LeftGraphsThree" style={{ height: 'calc(33vh - 70px)', width: '100%' }}></div>
          </Col>
        </Row>
      </div>
    );
  }
}

export default LeftGraphs;