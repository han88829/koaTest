/*
 * @Author: lai.haibo 
 * @Date: 2017-05-06 10:20:44 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-05-06 10:20:44 
 */

import React, {Component} from 'react';
import {Row, Col} from 'antd';

import LeftGraphs from './containers/LeftGraphs';
import RightGraphs from './containers/RightGraphs';
import TopBar from './containers/TopBar';
import NewMiddleGraphs from './containers/NewMiddleGraphs';
import './safeCenter.css';

class SafeCenter extends Component {
  render() {
    return (
      <div className="SafeCenter">
        <TopBar/>
        <Row gutter={16} className="SafeCenter-body">
          <Col span={6}>
            <LeftGraphs/>
          </Col>
          <Col span={12}>
            <NewMiddleGraphs/>
          </Col>
          <Col span={6}>
            <RightGraphs/>
          </Col>
        </Row>
      </div>
    );
  }
}

export default SafeCenter;