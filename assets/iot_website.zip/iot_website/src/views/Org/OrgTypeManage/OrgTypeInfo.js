/*
 * @Author:szj
 * @Date: 2017-03-27 16:09:35 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-11 11:27:11
 */
/*
  2017-3-9 by  宋珍君
 */

import React from 'react';
import { Input, Button, Form, Row, Col,} from 'antd';
import { Link } from 'react-router';

const FormItem = Form.Item;


const OrgTypeInfo = Form.create()(React.createClass({
  getInitialState() {
    return {
      value: undefined,
      types: null,
      data:[]
    };
  },
  // componentWillMount(){
  //    const id=this.props.params.id;
  //     window.rpc.area.types.getInfoById(id).then((res) => {
        
  //       const types=({...res});
  //       console.log(types);
  //       const parent=types.parentId;
  //       this.setState({ types});
  //         window.rpc.area.types.getInfoById(parent).then((result) => {
  //            const  parents=({...result}); 
  //           // const  parentName=Btype.name;
  //            console.log(parents);
  //            this.setState({parents});
             
  //         });

   
  //       //this.setState({ types});
  //      console.log(this.state.parents);
  //           this.props.form.setFieldsValue({
  //           name: this.state.types.name,
  //           remark:this.state.types.remark ,
  //          // parent:this.state.parents.name,
  //       });
  //       }, (err) => {
  //         console.log(err);
  //       })
  //     //  this.props.form.setFieldsValue({
        
  //     //   })
  // },
   componentWillMount(){
      //, key:layerNow[j].id, label: layerNow[j].name, value: `${layerNow[j].id}`
     function pushChildren(data){
		 let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
       pushChildren(layerUp)
      }
		}
     const id = parseInt(this.props.params.id, 10);
  window.rpc.owner.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      console.log(tableDate);
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let mine = res.filter(x => x.id === id)[0];
      pushChildren(tableDate)
      this.setState({ types, data: tableDate });
       window.rpc.owner.types.getInfoById(mine.parentId).then((result) => {
         console.log(result);
        this.props.form.setFieldsValue({
          name: mine.name,
          parentId:result.name,
          remark:mine.remark
        });
        this.setState({
          value:result.name
        })
      },(err) =>{
        console.warn(err);
      })


    }, (err) => {

    })


  },
  
  onChange(value) {
    console.log(arguments);
    this.setState({ value });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    //const Name=this.state.types.name;
   // console.log(Name);style={{ position: 'relative'}}
    return (
      <div >
        <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125em',color:'#333',fontSize:'0.75rem',fontFamily:'苹方中等'}}>
          <div style={{float:'left',width:100,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
            <Link to='/org/type/manage' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>单位类型管理</Link>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <div className="new-button"  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="/org/type/new">新增单位类型</Link></div>
          </div>
        </div>
      <Form onSubmit={this.handleSubmit} className="NewTypes" style={{ padding: 24 ,height:'100%',fontSize:'14px'}}>
        <FormItem>
        <span style={{paddingRight:10}}>类型名称：</span>
          {getFieldDecorator('parentId', {
            rules: [{ required: true, message: '请输入建筑类型名称!' }],
          })(
            <Input  style={{height:30 ,width:'70%'}} disabled/>
          )}
          </FormItem>
        <FormItem>
          <span style={{paddingRight:10}}>类型名称：</span>
          {getFieldDecorator('name', {
            rules: [{ required: true, message: '请输入建筑类型名称!' }],
          })(
            <Input  style={{height:30 ,width:'70%'}} disabled  />
          )}
        </FormItem>
        <FormItem>
         <span style={{paddingRight:30,display:' inlineBlock',height:'68px',lineHeight:'68px'}}> 备注：</span>
          {getFieldDecorator('remark', {
          })(
             <Input type="textarea" autosize={{ minRows: 3, maxRows: 6 }} style={{width:'70%'}} disabled />
          )}
        </FormItem>
          <div style={{ position: 'absolute', bottom: 60 }} className="search-btn" >
           <FormItem >  
               <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to="/org/type/manage">返回</Link></span> 
            {/*  <Button style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑' }}><Link to="/org/type/manage">返回</Link></Button>*/}
           </FormItem> 
         </div>    
      </Form>
     </div>
    );
  },
}));

export default OrgTypeInfo;