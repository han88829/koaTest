import React, { Component } from 'react';
import EquipTaskPendTr from './containers/EquipTaskPendTr.js';
import './containers/EquipTaskPend.css';


class EquipPendingTask extends Component {
  render() {
    return (
      <div className="EquipPendingTask">
          <EquipTaskPendTr/>
      </div>
    );
  }
}

export default EquipPendingTask;