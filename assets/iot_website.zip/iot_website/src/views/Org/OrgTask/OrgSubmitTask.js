import React, { Component} from 'react';
import './containers/EquipTaskPend.css';
import { Table, Input, Button,Radio } from 'antd';
const RadioGroup = Radio.Group;

class ChooseReceive  extends React.Component {
  state = {
    value: 1,
  }
  onChange = (e) => {
   // console.log('radio checked', e.target.equipStatus);
    this.setState({
      value: e.target.value,
    });
  } 
  render() {
    return (
      <RadioGroup onChange={this.onChange} value={this.state.value}>
        <Radio value={1}>合格</Radio>
        <Radio value={2}>不合格</Radio>
      </RadioGroup>
    );
  }
}


class EquipDetails extends Component {
constructor(props) {
super(props);
this.state = {
dataSource: [{
key: 1,
equipName: this.props.equipName,
equipStatus: this.props.value,
},{
key: 2,
equipName: this.props.equipName,
equipStatus: this.props.value,
},{
key: 3,
equipName: this.props.equipName,
equipStatus: this.props.value,
}],
};
this.handleSave = this.handleSave.bind(this);
}
//保存
// handleSave(e){
//     var k = e.target.equipName;
//     var v = e.target.value;
//     var formData = this.state.formData;
    
//     if(!formData[i]) formData[i] = {};
    
//     formData[i][k] = v;
    
//     this.setState({formData});
//     console.log({formData});
// }


handleSave() {
// const newDataSource = this.state.dataSource;

// //const newDataSource= {"equipName": this.props.equipName,"quipStatus": this.props.value};
// // newDataSource.push({//newDataSource.push一个新的数组，这个数组直接将初始化中的数组copy过来即可
// // equipName: this.props.equipName,
// // equipStatus: this.props.equipStatus,
// // });
// this.setState({
// // equipName: this.props.equipName,
// // equipStatus: this.props.value,
// dataSource: newDataSource,
// });
// console.log(this.state.equipName);
}


render() {
const columns = [
{
title: '序号',
dataIndex: 'key',
key: 'key',
render: (text, record, index) => {
return <span>{index + 1}</span>//索引从零开始，所以第一行为index+1，index为render方法里面的参数，可自动获取到下标
},
},{
title: '设备名称',
dataIndex: 'equipName',
key: 'equipName',
render: ()=> <Input placeholder="设备名称" onChange={this.props.handleSave}/>,
}, {
title: '状态',
dataIndex: 'equipStatus',
key: 'equipStatus',
render: () => <ChooseReceive />,
}];
return (
<div>
<Table dataSource={this.state.dataSource} columns={columns}//this.state.dataSource即为获取初始化dataSource数组
pagination={false} bordered
/>
 <Button className="Tablesave" onClick={this.handleSave}>保存</Button>
</div>
);
}
}


export default EquipDetails;