import React, { Component } from 'react';
import OrgsInfo from './containers/OrgsInfo';

class Orgs extends Component {
    
  /* constructor() {
    super();

    this.state = {
       Id:null
    }   */

 /* getInitialState() {
    return {
       Id:1
    };
  }*/
  //  console.log(this.props);
  // const id = parseInt(this.props.params.id,10);
  // this.setState({id});
  // console.log(id);
  // this.props.idN=id  
   //idNum={this.props.idN}  infoId={this.state.id}
 //}

  componentDidMount() {
     //console.log(this.props);
     const id = parseInt(this.props.params.id,10);
     console.log(id);
     //this.setState({Id:id});
     //idNum={this.state.Id}
  }

  render() {
   const id = parseInt(this.props.params.id,10);
   //console.log(id);
    return (
      <div className="Orgs" style={{height:'100%', }}  >
        <OrgsInfo  name={id}/>
      </div>
    )
  }
}

export default Orgs;