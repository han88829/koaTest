/*
 * @Author: szj 
 * @Date: 2017-03-27 17:18:20 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-22 14:53:31
 */

import React, { Component } from 'react';
import { Form, Input, Icon, Select, Button, TreeSelect,Modal } from 'antd';
import { Link } from 'react-router';
import './Orgs.css';
import $ from 'jquery';
import moment from 'moment';
import bd from '../../../assets/images/build/bd.png';
import org_name_pic from '../../../assets/images/orgs/org-name.png';
import create_time_pic from '../../../assets/images/orgs/create-time.png';
import last_time_pic from '../../../assets/images/orgs/last-time.png';
import org_address_pic from '../../../assets/images/orgs/orgAddress.png';
import org_state_pic from '../../../assets/images/orgs/org-state.png';
import area from '../../../assets/images/orgs/area.png';
import owner_group from '../../../assets/images/orgs/owner-group.png';
import work_person from '../../../assets/images/orgs/work-person.png';
import org_type from '../../../assets/images/orgs/org-type.png';
import org_state from '../../../assets/images/orgs/org-state.png';
import fix_face from '../../../assets/images/orgs/fix-face.png';
import duty_officer from '../../../assets/images/orgs/duty-officer.png';
import fire_remark from '../../../assets/images/orgs/fire-remark.png';
import safetyLevel from '../../../assets/images/orgs/safetyLevel.png';
import watch_level from '../../../assets/images/orgs/watch-level.png';
import owner_chief from '../../../assets/images/orgs/owner-chief.png';

const FormItem = Form.Item;
const Option = Select.Option;

const WrappedRegistrationForm = Form.create()(React.createClass({
  getInitialState() {
    return {
      imgLink: '',
      createValue: null,
      buildingType: [],
      OrgsType: [],
      dStateList: {},
      watchLevelList: [],
      safetyLevelList: [],
      ownerId: null,
      createTime: null,
      lastTime: null,
      data: [],
      types: [],
      visibleOne:false,
      x:null,
      y:null,
      xy:null
    };
  },
  componentWillMount() {
      function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    loadJScript();
    window.rpc.owner.types.getArrayIdNameByContainer(null, 0, 0).then((res) => {
      let OrgsType = res.map((x) => ({ ...x }));
      this.setState({
        OrgsType
      })
    }, (err) => {
      console.warn(err);
    });
    window.rpc.alias.getValueByName('owner.state').then((res) => {
      this.setState({
        dStateList: res
      });
    }, (err) => {
      console.warn(err);
    });

    window.rpc.alias.getValueByName('fire.safetyLevel').then((res) => {
      let arrFire = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrFire.push(values);
      }
      let safetyLevelList = arrFire;
      this.setState({
        safetyLevelList
      });

    }, (err) => {
      console.warn(err);
    });
    window.rpc.alias.getValueByName('fire.watchLevel').then((res) => {
      let arrWatch = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrWatch.push(values);
      }
      let watchLevelList = arrWatch;
      this.setState({
        watchLevelList
      });

    }, (err) => {
      console.warn(err);
    });


    var id = window.location.href;
    var index = id.lastIndexOf("\/");
    id = Number(id.substring(index + 1, id.length));
    this.setState({ ownerId: id });

    window.rpc.owner.getInfoById(id).then((res) => {
      let asc = res.mapUrl;
      $("#seeImgEdit").attr({ "href": asc });
      this.props.form.setFieldsValue({
        name: res.name,
        asset: res.asset,
        face: res.face,
        number: res.number,
        remark: res.remark,
        address: res.address,
        peopleScale: res.peopleScale,
        state: `${res.state}`,
        legalPersonPhone: res.legalPersonPhone,
        legalPerson: res.legalPerson,
        type: `${res.type}`,
        tag: res.tag,
        x: `${res.x},${res.y}`,

      });
      this.setState({ createTime: moment(res.createTime).format("YYYY-MM-DD") });// moment(result.expiryTime).format("YYYY-MM-DD")moment(result.expiryTime, dateFormat)
      this.setState({ lastTime: moment(res.lastTime).format("YYYY-MM-DD") });// moment(result.expiryTime).format("YYYY-MM-DD")moment(result.expiryTime, dateFormat)
    }, (err) => {
      console.warn(err);
    });
    window.rpc.fire.getInfoById(id).then((results) => {
      const orgFires = { ...results };
      this.props.form.setFieldsValue({
        safetyLevel: `${results.safetyLevel}`,
        watchLevel: `${results.watchLevel}`,
        chief: results.chief

      });
    }, (err) => {
      console.warn(err);
    });
    function pushChildren(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp)
      }
    }
    window.rpc.owner.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = pushChildren(tableDate)
      this.setState({ types, data: tableDate });
    })
  },
  componentDidMount() {  
    var createId = this.state.createId;
    window.rpc.upload.images.getDefaultConfig().then((res) => {
      // window.rpc.upload.images.getOwnerUniqueConfigById(createId).then((res) => {
      let { domain, uptoken } = res;
      window.Qiniu.uploader({
        runtimes: 'html5,flash,html4',    //上传模式,依次退化
        browse_button: 'pickfilesOrgEdit',       //上传选择的点选按钮，**必需**
        // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
        uptoken: uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
        unique_names:true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
        save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
        domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
        // domain: `http://omdwajej6.bkt.clouddn.com/`,
        get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
        // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
        max_file_size: '100mb',           //最大文件体积限制
        //unique_names: true,
        multi_selection: false,
        // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
        max_retries: 3,                   //上传失败最大重试次数
        // dragdrop: true,                   //开启可拖曳上传
        // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
        chunk_size: '4mb',                //分块上传时，每片的体积
        auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
        init: {
          'FilesAdded': function (up, files) {
            //plupload.each(files, function (file) {
            // 文件添加进队列后,处理相关的事情
            //});
          },
          'BeforeUpload': function (up, file) {
            // 每个文件上传前,处理相关的事情
          },
          'UploadProgress': function (up, file) {
            // 每个文件上传时,处理相关的事情
          },
          'FileUploaded': function (up, file, info) {
            //console.log(info);
            let domain = up.getOption('domain');
            let res = JSON.parse(info);
            var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
            //console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
            // this.props.appState.imgLink=sourceLink;
            var asc = sourceLink;
            $("#seeImgOrgEdit").attr({ "href": asc });
          },
          'Error': function (up, err, errTip) {
            //上传出错时,处理相关的事情
          },
          'UploadComplete': function () {
            //队列文件处理完毕后,处理相关的事情
          },
          'Key': function (up, file) {
            // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
            // 该配置必须要在 unique_names: false , save_key: false 时才生效
            // str=window.location.href;
            // let str = window.location.href;
            // var index = str.lastIndexOf("\/");
            // str = parseInt(str.substring(index + 1, str.length), 10);
            // //var key = `owner-${str}`;
            // var key = `owner-4`;
            var key = "";
            // do something with key here
            return key
          }
        }
      });
    }, (err) => {
      console.warn(err);
    })
     window.rpc.upload.images.getDefaultConfig().then((res) => {
      let { domain, uptoken } = res;
      //var uploader =
      window.Qiniu.uploader({
        runtimes: 'html5,flash,html4',    //上传模式,依次退化
        browse_button: 'pickfilesFilter',       //上传选择的点选按钮，**必需**
        // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
        uptoken: uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
        //unique_names: false, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
        //save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
        domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
        // domain: `http://omdwajej6.bkt.clouddn.com/`,
        get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
        // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
        max_file_size: '100mb',           //最大文件体积限制
        unique_names: true,
        multi_selection: false,
        // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
        max_retries: 3,                   //上传失败最大重试次数
        // dragdrop: true,                   //开启可拖曳上传
        // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
        chunk_size: '4mb',                //分块上传时，每片的体积
        auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
        init: {
          'FilesAdded': function (up, files) {
            //plupload.each(files, function (file) {
            // 文件添加进队列后,处理相关的事情
            //});
          },
          'BeforeUpload': function (up, file) {
            // 每个文件上传前,处理相关的事情
          },
          'UploadProgress': function (up, file) {
            // 每个文件上传时,处理相关的事情
          },
          'FileUploaded': function (up, file, info) {
            //console.log(info);
            let domain = up.getOption('domain');
            let res = JSON.parse(info);
            var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
            //console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
            // this.props.appState.imgLink=sourceLink;
            var asc = sourceLink;
            $("#seeImgEdit").attr({ "href": asc });
          },
          'Error': function (up, err, errTip) {
            //上传出错时,处理相关的事情
          },
          'UploadComplete': function () {
            //队列文件处理完毕后,处理相关的事情
          },
          'Key': function (up, file) {
            // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
            // 该配置必须要在 unique_names: false , save_key: false 时才生效
            // str=window.location.href;
            // let str = window.location.href;
            // var index = str.lastIndexOf("\/");
            // str = parseInt( str.substring(index + 1, str.length),10);
            // //var key = `owner-${str}`;
            // var key = `area-${str}`;
            var key = ``;
            //console.log(key);
            // do something with key here
            return key
          }
        }
      });
    }, (err) => {
      console.warn(err);
    })

  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let imgUrl = $("#seeImgEdit").attr('href');
        let license=$("#seeImgOrgEdit").attr('href')
        var id = window.location.href;
        var index = id.lastIndexOf("\/");
        id = Number(id.substring(index + 1, id.length));
        let Id = parseInt(id, 10);
          let xy = values.x;
        let xyArr = xy.split(',');
        let x = parseFloat(xyArr[0], 10), y = parseFloat(xyArr[1], 10);
        let value = { ...values, tag: parseInt(values.tag, 10),x:x,y:y, asset: parseFloat(values.asset, 10), face: parseFloat(values.face, 10), fire: 1, peopleScale: parseFloat(values.peopleScale, 10) || null, type: parseInt(values.type, 10), state: parseInt(values.state, 10), image: imgUrl || '',license:license||'' }
        //console.log(value)
        window.rpc.owner.setInfoById(Id, value).then((res) => {
          if (res) {
            window.location.href = '/org/manage';
          }
        }, (err) => {
          console.warn(err);
        });
      }
    });
  },
  showModalOne() {
    let that = this;
  
    function init() {
      var map = new window.BMap.Map("editOrgMap");
      var point = new window.BMap.Point(121.64, 29.92);
      map.centerAndZoom(point, 14);
      map.enableScrollWheelZoom();                 //启用滚轮放大缩小        
      //单击获取点击的经纬度
      map.addEventListener("click", function (e) {
        alert(e.point.lng + "," + e.point.lat);
        that.setState({ x: e.point.lng });
        that.setState({ y: e.point.lat });
        that.setState({ xy: `${e.point.lng},${e.point.lat}` });
      });
    }
    setTimeout(() => {
      init();
    }, 800)
    that.setState({
        visibleOne: true,
    });
  },
  handleOkOne(e) {
    this.setState({
      visibleOne: false,
    });
  },
  handleCancelOne(e) {
    this.setState({
      visibleOne: false,
    });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    let Orgtypes = this.state.OrgsType;
    const safety = this.state.safetyLevelList;
    const safetySupervision = this.state.watchLevelList;
    let OrgtypeChildren = [];
    let OrgstateChildren = [];
    let safetyChildren = [];
    let SupervisionsChildren = [];



    for (let i = 1; i < safety.length + 1; i++) {
      safetyChildren.push(<Option key={`${i}`}>{safety[i]}</Option>)
    }
    for (let i = 1; i < safetySupervision.length + 1; i++) {
      SupervisionsChildren.push(<Option key={`${i}`}>{safetySupervision[i]}</Option>)
    }

    let dStateObj = this.state.dStateList;
    for (let i in dStateObj) {

      OrgstateChildren.push(<Option key={`${i}`}>{dStateObj[i]}</Option>)
    }
    //如果有数据就存储到子数组中
    for (let value of Orgtypes) {
      if (value && value.id) {
        OrgtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>);
      }
    }
    return (
      <div style={{ background: '#fff', position: 'relative', color: '#ccc' }}>
        <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>单位信息</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="">修改单位</Link></Button>
          </div>

        </div>
        <div>
          <Form className="EditOrg"  style={{ marginTop: -4, overflow: 'auto' }}>
            <div span={2} style={{ textAlign: 'left' }}>
              <p style={{ color: '#373d41', fontsize: '0.75rem', fontSize: '0.75rem', fontFamily: '苹方中等', padding: '12px 0 18px 10px' }}>基础信息</p>
            </div>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={org_name_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位名称：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('name', {
                      rules: [{
                        required: true, message: '请输入单位名称',
                      }],
                    })(
                      <Input style={{ width: '400px' }} placeholder="请选择单位名称" />
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={org_type} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位类型：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('type', {
                      rules: [
                        { required: true, message: '请选择单位类型' },
                      ],
                    })(
                      <TreeSelect
                        style={{ height: 30, width: 200 }}
                        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                        treeData={this.state.data.filter(x => x.layer === 1)}
                        placeholder="请选择单位类型"
                        treeDefaultExpandAll

                      />
                      )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={duty_officer} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span style={{ paddingRight: '12px' }}>责任人：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      getFieldDecorator('legalPerson', {
                        rules: [{
                          required: true, message: '请输入责任人',
                        }],
                      })(
                        <Input placeholder="请输入责任人" style={{ width: '400px' }} />
                      )
                    }
                  </FormItem>
                </div>

                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={org_state_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位编号：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('number', {
                      rules: [{
                        required: true, message: '请输入单位编号',
                      }],
                    })(
                      <Input placeholder="请输入单位编号" style={{ width: '162px' }} />
                    )}
                  </FormItem>
                  <div >
                    <div className="col-md-12">
                      <div style={{ overflow: 'hidden' }}>
                        <div id="container" style={{ position: 'relative', float: 'left', width: 122, height: 32, marginRight: 6, marginLeft: 12 }}>
                          <Button id="pickfilesOrgEdit" onClick={this.uploadButton} style={{ position: 'relative', float: 'left', width: 122, height: 32, borderRadius: 0, color: `#00c1de`, border: `1px solid #00c1de` }} >
                            <span>选择文件</span>
                          </Button>
                        </div>
                        <a id="seeImgOrgEdit" style={{ display: 'none', float: 'right', height: 30, width: 30, marginLeft: 10, borderRadius: '100%', background: '#fff', border: '1px solid #ccc' }}><Icon type="upload" style={{ marginLeft: 7 }} /></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={owner_group} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>所属组织：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      <Input style={{ width: '400px' }} placeholder="请输入所属组织" />
                    }
                  </FormItem>
                </div>
                {/*<div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={org_state} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位状态：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('state', {
                      rules: [
                        { required: true, message: '请选择单位状态' },
                      ],
                    })(
                      <Select placeholder="请选择单位类型" style={{ width: '162px' }} >
                        {OrgstateChildren}
                      </Select>
                      )}
                  </FormItem>
                </div>*/}

                <div className="Row-info-left clearfix" >
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={org_state_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>联系电话：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('legalPersonPhone', {
                      rules: [{
                        required: true, message: '请输入联系电话',
                      }],
                    })(
                      <Input placeholder="请输入联系电话" style={{ width: '400px' }} />
                      )}
                  </FormItem>

                </div>
                  {/* <div className="Row-info-right clearfix">
                      {
                       <div >
                      <div className="col-md-12">

                        <div style={{ overflow: 'hidden' }}>
                          <div style={{ float: 'left', width: 112, lineHeight: '32px' }}>
                            <img src={bd} style={{ padding: '0 15px 0 12px' }} alt="" />
                            <span>平面图：</span>
                          </div>
                          <div id="container" style={{ position: 'relative', float: 'left', width: 112, height: 32, marginRight: 6 }}>

                            <Button id="pickfilesFilter" onClick={this.uploadButton} style={{ position: 'relative', float: 'left', width: 162, height: 32, borderRadius: 0, color: `rgb(0, 193, 222)`, border: `1px solid rgb(0, 193, 222)` }} >
                              <span>上传户籍图片</span>
                            </Button>
                          </div>
                          <a id="seeImgEdit" style={{ display: 'none', float: 'right', height: 30, width: 30, marginLeft: 10, borderRadius: '100%', background: '#fff', border: '1px solid #ccc' }}><Icon type="upload" style={{ marginLeft: 7 }} /></a>
                        </div>
                      </div>
                    </div>
                  }
                </div>*/}
     
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix" >
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={org_state} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位坐标：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('x', {
                      rules: [
                        { required: true, message: '请输入单位坐标!' },
                      ],
                    })(
                      <Input size="large" style={{ width: 309 }} placeholder="请输入单位坐标!" />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div id="container" style={{ position: 'relative', float: 'left', width: 112, height: 32, marginRight: 6 }}>
                    <Button onClick={this.showModalOne} style={{ position: 'relative', float: 'left', width: 162, height: 32, borderRadius: 0, color: `rgb(0, 193, 222)`, border: `1px solid rgb(0, 193, 222)` }} >
                      <span>采集坐标</span>
                    </Button>
                    <Modal title="采集坐标"
                      visible={this.state.visibleOne}
                      onOk={this.handleOkOne}
                      onCancel={this.handleCancelOne}
                      style={{ height: 780, position: 'absolute', left: '50%', marginLeft: '-380px', padding: '0 22px' }}
                      className="mapOrgOne"
                    >
                      <div >
                        <div id="editOrgMap" style={{ padding: '20', height: 580, width: 860, position: 'absolute', left: 20, top: 60 }} ></div>
                        <div style={{ overflow: 'hidden' }}>
                          <div style={{ float: 'left', width: 400, position: 'absolute', bottom: 20, }}>
                            <span>请复制当前坐标：</span>
                            <Input type="text" value={this.state.xy} style={{ width: 300, zIndex: 999 }} />
                          </div>
                        </div>
                      </div>
                    </Modal>
                  </div>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={org_address_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位地址：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }} //此处地图选点
                    hasFeedback
                  >
                    {getFieldDecorator('address', {
                      rules: [{
                        required: true, message: '请输入单位地址',
                      }],
                    })(
                      <Input placeholder="请输入单位地址" style={{ width: '400px' }} />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={area} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位面积（平方米）:</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('face', {
                      rules: [{
                        required: true, message: '请输入单位面积',
                      }],
                    })(
                      <Input placeholder="请输入单位面积" style={{ width: '400px' }} />
                    )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={fix_face} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>固定资产（万）：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('asset', {
                      rules: [{
                        required: true, message: '请输入固定资产',
                      }],
                    })(
                      <Input placeholder="请输入固定资产" style={{ width: '400px' }} />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 62, height: 32, lineHeight: '32px' }}>
                    <img src={work_person} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>职工人数：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('peopleScale', {
                      rules: [{
                        required: true, message: '请输入职工人数',
                      }],
                    })(
                      <Input placeholder="请输入职工人数" style={{ width: '400px' }} />
                    )}
                  </FormItem>
                </div>
              </div>

              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={create_time_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>成立时间：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      <Input disabled value={this.state.createTime} style={{ width: '400px' }} />
                    }
                  </FormItem>

                </div>
                <div className="Row-info-right clearfix">
                  <div style={{ float: 'left', marginRight: 40, height: 32, lineHeight: '32px' }}>
                    <img src={last_time_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>最后更新时间：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      <Input disabled value={this.state.lastTime} style={{ width: '400px' }} />
                    }
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 74, height: 32, lineHeight: '32px' }}>
                    <img src={area} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>NFC：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('tag', {
                      rules: [{
                        required: true, message: '请输入NFCID',
                      }],
                    })(
                      <Input style={{ width: '400px' }} placeholder="请输入NFCID" />
                    )}
                  </FormItem>
                </div>
              </div>
              <div style={{ textAlign: 'left' }}>
                <p style={{ color: '#373d41', fontsize: '0.75rem', fontSize: '0.85rem', fontFamily: '苹方中等', padding: '12px 0 18px 10px' }}>备注</p>
              </div>
              <div className="Row-info" style={{ background: '#f8fbfb', padding: '4px 0', height: 100 }}>
                <div style={{ float: 'left', marginRight: 12, height: 92, lineHeight: '92px', padding: '4px 0' }}>
                  <img src={fire_remark} style={{ padding: '0 28px 0 28px' }} alt="" />
                  <span style={{ marginRight: 24 }}>备注：</span>
                </div>
                <FormItem
                  style={{ float: 'left', height: 92 }}
                  hasFeedback
                >
                  {getFieldDecorator('remark', {
                    rules: [{
                     // required: true, message: '请输入备注',
                    }],
                  })(
                    <textarea style={{ height: 92, outline: 'none', border: '1px solid #ccc', width: '700px', textIndent: '10px' }} />
                  )}
                </FormItem>
              </div>
            </div>
            <div style={{ textAlign: 'left' }}>
              <p style={{ color: '#373d41', fontsize: '0.75rem', fontSize: '0.75rem', fontFamily: '苹方中等', padding: '12px 0 18px 10px' }}>消防信息</p>
            </div>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 36, height: 32, lineHeight: '32px' }}>
                    <img src={watch_level} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>监管等级：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('watchLevel', {
                      rules: [
                        { required: true, message: '请选择监管等级' },
                      ],
                    })(
                      <Select placeholder="请选择监管等级" style={{ width: 242 }} >
                        {SupervisionsChildren}
                      </Select>
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={safetyLevel} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>安全等级：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('safetyLevel', {
                      rules: [
                        { required: true, message: '请选择安全等级' },
                      ],
                    })(
                      <Select placeholder="请选择安全等级" style={{ width: 242 }} >
                        {safetyChildren}
                      </Select>
                    )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={owner_chief} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>消防主管部门：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      getFieldDecorator('chief', {
                        rules: [
                          { required: true, message: '请选择消防主管等级' },
                        ],
                      })(
                        <Input placeholder="请选择消防主管部门" style={{ width: 242 }} />
                      )}
                  </FormItem>
                </div>
                 <div className="Row-info-right clearfix">
                      {
                       <div >
                      <div className="col-md-12">

                        <div style={{ overflow: 'hidden' }}>
                          <div style={{ float: 'left', width: 112, lineHeight: '32px' }}>
                            <img src={bd} style={{ padding: '0 15px 0 12px' }} alt="" />
                            <span>平面图：</span>
                          </div>
                          <div id="container" style={{ position: 'relative', float: 'left', width: 112, height: 32, marginRight: 6 }}>

                            <Button id="pickfilesFilter"  style={{ position: 'relative', float: 'left', width: 162, height: 32, borderRadius: 0, color: `rgb(0, 193, 222)`, border: `1px solid rgb(0, 193, 222)` }} >
                              <span>上传户籍图片</span>
                            </Button>
                          </div>
                          <a id="seeImgEdit" style={{ display: 'none', float: 'right', height: 30, width: 30, marginLeft: 10, borderRadius: '100%', background: '#fff', border: '1px solid #ccc' }}><Icon type="upload" style={{ marginLeft: 7 }} /></a>
                        </div>
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>
            <div style={{ position: 'absolute', marginTop: 40, left: 20 }} className="search-btn" >
              <FormItem >
                <Button htmlType="submit" onClick={this.handleSubmit}> 保存</Button>
                <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.75rem', fontFamily: '微软雅黑', marginLeft: 10, width: 60, height: 32, borderRadius: 0 }}><Link to="/org/manage">返回</Link></div>
              </FormItem>
            </div>
          </Form>
        </div>
      </div>
    );
  }
})
)

/*class EquipInspectTaskNew extends Component {
  render() {
    return (
      <div className="EquipInspectTaskNew">
        <WrappedRegistrationForm />
      </div>
    );
  }
}*/

class EditOrg extends Component {
  render() {
    return (
      <div className="EditOrg">
          <WrappedRegistrationForm />
      </div>
    )
  }
}

export default EditOrg;

