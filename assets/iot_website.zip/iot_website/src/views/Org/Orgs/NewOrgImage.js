

import React from 'react';
//import moment from 'moment';
import { Icon, Button ,Row,Col} from 'antd';
import { Link } from 'react-router';
//import './Orgs.css';
import $ from 'jquery';
//const { RangePicker } = DatePicker;
//const { Option } = Select;
//const FormItem = Form.Item;



 
class NewOrgImage extends React.Component {
   constructor() {
    super();
    this.state = {
     
    };
  }
  componentWillMount() {
     //const id=this.props.idN;
    var str = window.location.href;
     var index = str.lastIndexOf("\/");
     str = parseInt( str.substring(index + 1, str.length), 10);
     // const id=this.props.name;
     var id=parseInt(str,10);
      window.rpc.upload.images.getDefaultConfig().then((res) => {
     //window.rpc.upload.images.getOwnerUniqueConfigById(str).then((res) => {  
        //console.info(res);
        let { domain, uptoken } = res;
        var uploader = window.Qiniu.uploader({
          runtimes: 'html5,flash,html4',    //上传模式,依次退化
          browse_button: 'pickfilesOrg',       //上传选择的点选按钮，**必需**
          // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
          uptoken : uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
          //unique_names: false, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
          //save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
          domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
         // domain: `http://omdwajej6.bkt.clouddn.com/`,
          get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
          // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
          max_file_size: '100mb',           //最大文件体积限制
          unique_names: true,
          multi_selection: false,
          // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
          max_retries: 3,                   //上传失败最大重试次数
          // dragdrop: true,                   //开启可拖曳上传
          // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
          chunk_size: '4mb',                //分块上传时，每片的体积
          auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
          init: {
            'FilesAdded': function (up, files) {
            //plupload.each(files, function (file) {
            // 文件添加进队列后,处理相关的事情
            //});
            },
            'BeforeUpload': function (up, file) {
            // 每个文件上传前,处理相关的事情
            },
            'UploadProgress': function (up, file) {
            // 每个文件上传时,处理相关的事情
            },
            'FileUploaded': function (up, file, info) {
                let domain = up.getOption('domain');
                let res = JSON.parse(info);
                console.log(res.key);
                var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
                console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
               // this.props.appState.imgLink=sourceLink;
                var asc=sourceLink;
                $("#seeImgOrg").attr({"href":asc});
            },
            'Error': function (up, err, errTip) {
            //上传出错时,处理相关的事情
            },
            'UploadComplete': function () {
            //队列文件处理完毕后,处理相关的事情
            },
            'Key': function (up, file) {
            // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
            // 该配置必须要在 unique_names: false , save_key: false 时才生效
            //  let str = window.location.href;
            //   var index = str.lastIndexOf("\/");
            //   str = parseInt( str.substring(index + 1, str.length),10);
            //   console.log(str);
            //   var key = `owner-${str}`;
            // do something with key here
            let key='';
            return key;
          }
        }
      });
    },(err) =>{
       console.warn(err);
    })    
      window.rpc.upload.images.getDefaultConfig().then((res) => {  
     let { domain, uptoken } = res;
      //var uploader =
      window.Qiniu.uploader({
        runtimes: 'html5,flash,html4',    //上传模式,依次退化
        browse_button: 'pickfilesFilter',       //上传选择的点选按钮，**必需**
        // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
        uptoken: uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
        //unique_names: false, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
        //save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
        domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
        // domain: `http://omdwajej6.bkt.clouddn.com/`,
        get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
        // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
        max_file_size: '100mb',           //最大文件体积限制
        unique_names: true,
        multi_selection: false,
        // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
        max_retries: 3,                   //上传失败最大重试次数
        // dragdrop: true,                   //开启可拖曳上传
        // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
        chunk_size: '4mb',                //分块上传时，每片的体积
        auto_start: true,     
          init: {
            'FilesAdded': function (up, files) {
            //plupload.each(files, function (file) {
            // 文件添加进队列后,处理相关的事情
            //});
            },
            'BeforeUpload': function (up, file) {
            // 每个文件上传前,处理相关的事情
            },
            'UploadProgress': function (up, file) {
            // 每个文件上传时,处理相关的事情
            },
            'FileUploaded': function (up, file, info) {
                let domain = up.getOption('domain');
                let res = JSON.parse(info);
                console.log(res.key);
                var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
                console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
               // this.props.appState.imgLink=sourceLink;
                var asc=sourceLink;
                $("#seeImgNewOrg").attr({"href":asc});
            },
            'Error': function (up, err, errTip) {
            //上传出错时,处理相关的事情
            },
            'UploadComplete': function () {
            //队列文件处理完毕后,处理相关的事情
            },
            'Key': function (up, file) {
            // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
            // 该配置必须要在 unique_names: false , save_key: false 时才生效
            //  let str = window.location.href;
            //   var index = str.lastIndexOf("\/");
            //   str = parseInt( str.substring(index + 1, str.length),10);
            //   console.log(str);
            //   var key = `owner-${str}`;
            var key='';
            // do something with key here
            return key;
          }
        }
      });
    },(err) =>{
       console.warn(err);
    })    
  }
  handleClick = (e) => {
    var str = window.location.href;
     var index = str.lastIndexOf("\/");
     str = parseInt( str.substring(index + 1, str.length), 10);
     var id=parseInt(str,10);
   //let value=this.state.createValue;
   let imgUrl=$("#seeImgOrg").attr('href');
   let license=$("#seeImgNewOrg").attr('href')
  // let values = {...value,mapUrl:imgUrl};
  // console.log(values);
   window.rpc.owner.getInfoById(id).then((result) => {
     console.log(result);
     let values={...result,mapUrl:imgUrl||result.imgUrl,license:license||result.license};
     console.log(values);
  //    window.rpc.owner.setInfoById(id,values).then((res) => {
  //      console.log(res);
  //      if(res){
  //        window.location.href=`/org/manage`;
  //      }
  //  },(err) =>{
  //    console.warn(err);
  //  });
   },(err) =>{
     console.warn(err);
   });
 
  }

  render() {
    return(
       <div className="OrgImage" >
         <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',color:'#333',fontFamily:'苹方中等',borderBottom:'#ddd 1px solid'}}>
          <div style={{float:'left',width:75,height:'25px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:7}}>
            <Link to='/org/manage' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>建筑信息</Link>
          </div>
          <div style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="">建筑图片上传</Link></Button>
          </div>   
        </div>
          <p style={{height:50,lineHeight:'50px',paddingLeft:12}}> <span>上传图片</span></p>
          <div style={{fontSize:'0.75rem'}}>  
              <div >
                  <div style={{overflow:'hidden'}}>           
                     <div id="container"  style={{position: 'relative',float:'left',width:842,marginRight:6,marginLeft:12}}>
                       <Row style={{margin:'18px 0 28px',lineHeight: '32px'}}>
                         <Col span={4}>
                           上传营业执照：
                         </Col>
                         <Col span={17}>
                            <Button id="pickfilesOrg"   style={{position: 'relative',float:'left',width:122,height:32,borderRadius:0,border:'1px solid #00c1de'}} > 
                             <span>选择文件</span>
                            </Button>
                           <a id="seeImgOrg" style={{display:'none',height:30,width:30,marginLeft:10, borderRadius:'100%',background:'#fff',border:'1px solid #ccc'}}><Icon type="upload"  style={{marginLeft:7}}/></a>  
                            {/*<a id="upOrg" onClick={this.handleClickButton} style={{float:'left',height:32,width:80,lineHeight:'32px', borderRadius:'0',background:'#fff',border:'1px solid #00c1de',color:'#00c1de'}}><Icon type="upload"  style={{marginLeft:20}}/>提交</a>  */}
                         </Col>
                       </Row>
                       <Row style={{lineHeight: '32px'}}>
                         <Col span={4}>
                           上传单位图片：
                         </Col>
                         <Col span={17}>
                            <Button id="pickfilesFilter"   style={{position: 'relative',float:'left',width:122,height:32,borderRadius:0,border:'1px solid #00c1de'}} > 
                             <span>选择文件</span>
                            </Button>
                             <a id="seeImgNewOrg" style={{display:'none',height:30,width:30,marginLeft:10, borderRadius:'100%',background:'#fff',border:'1px solid #ccc'}}><Icon type="upload"  style={{marginLeft:7}}/></a>  
                             {/*<a id="upOrg" onClick={this.handleClickButton} style={{float:'left',height:32,width:80,lineHeight:'32px', borderRadius:'0',background:'#fff',border:'1px solid #00c1de',color:'#00c1de'}}><Icon type="upload"  style={{marginLeft:20}}/>提交</a>  */}
                         </Col>
                       </Row>
                       
                     </div>
  
                  </div>
             </div>
           </div>
          <div style={{ position: 'absolute', bottom:60}} className="search-btn">
            <Button  onClick={this.handleClick}> 保存</Button> 
            <Button  style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑',marginLeft:10 }}><Link to="/org/manage">返回</Link></Button> 
          </div>   
       </div>
    )
  }
}


export default NewOrgImage;