/*
 * @Author:szj 
 * @Date: 2017-03-27 17:15:44 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-22 17:11:41
 */
import React, { Component } from 'react';
import { Form, Input, Select, Button, DatePicker, TreeSelect,Modal} from 'antd';
import { Link } from 'react-router';
import './Orgs.css';
import $ from 'jquery';

import org_name_pic from '../../../assets/images/orgs/org-name.png';
import create_time_pic from '../../../assets/images/orgs/create-time.png';
import org_address_pic from '../../../assets/images/orgs/org-address.png';
import org_state_pic from '../../../assets/images/orgs/org-state.png';
import area from '../../../assets/images/orgs/area.png';
import owner_group from '../../../assets/images/orgs/owner-group.png';
import work_person from '../../../assets/images/orgs/work-person.png';
import org_type from '../../../assets/images/orgs/org-type.png';
import org_state from '../../../assets/images/orgs/org-state.png';
import fix_face from '../../../assets/images/orgs/fix-face.png';
import duty_officer from '../../../assets/images/orgs/duty-officer.png';
import fire_remark from '../../../assets/images/orgs/fire-remark.png';
import safetyLevel from '../../../assets/images/orgs/safetyLevel.png';
import watch_level from '../../../assets/images/orgs/watch-level.png';
import owner_chief from '../../../assets/images/orgs/owner-chief.png';

const FormItem = Form.Item;
const Option = Select.Option;

const WrappedRegistrationForm = Form.create()(React.createClass({
  getInitialState() {
    return {
      imgLink: '',
      createValue: null,
      buildingType: [],
      OrgsType: [],
      dStateList: [],
      watchLevelList: [],
      safetyLevelList: [],
      id: null,
      data: [],
      types: [],
      visibleOne:false
    };
  },
  componentWillMount() {
     function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    loadJScript();
    window.rpc.owner.types.getArrayIdNameByContainer(null, 0, 0).then((res) => {
      let OrgsType = res.map((x) => ({ ...x }));
      this.setState({
        OrgsType
      })
    }, (err) => {
      console.warn(err);
    });
    window.rpc.alias.getValueByName('owner.state').then((res) => {
      this.setState({
        dStateList: res
      });
    }, (err) => {
      console.warn(err);
    });

    window.rpc.alias.getValueByName('fire.safetyLevel').then((res) => {
      let arrFire = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrFire.push(values);
      }
      let safetyLevelList = arrFire;
      this.setState({
        safetyLevelList
      });

    }, (err) => {
      console.warn(err);
    });
    window.rpc.alias.getValueByName('fire.watchLevel').then((res) => {
      let arrWatch = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrWatch.push(values);
      }
      let watchLevelList = arrWatch;
      this.setState({
        watchLevelList
      });

    }, (err) => {
      console.warn(err);
    });
    function pushChildren(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp)
      }
    }
    window.rpc.owner.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = pushChildren(tableDate)
      this.setState({ types, data: tableDate });
    })

  },
  uploadButton() {
    let createId = this.state.id;
  },
  handleClickButton() {
    let createId = this.state.createId;
    let value = this.state.createValue;
    let imgUrl = $("#seeImgOrg").attr('href');
    let values = { ...value, image: imgUrl };
    window.rpc.owner.setInfoById(createId, values).then((res) => {
      if (res) {
        window.location.href = '/org/manage';
      }
    }, (err) => {
      console.warn(err);
    });

  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let xy = values.x;
        let xyArr = xy.split(',');
        let x = parseFloat(xyArr[0], 10), y = parseFloat(xyArr[1], 10);
        const value1 = { ...values, tag: parseInt(values.tag, 10), asset: parseFloat(values.asset, 10), face: parseFloat(values.face, 10), fire: 1, peopleScale: parseFloat(values.peopleScale, 10), type: parseInt(values.type, 10), state: parseInt(values.state, 10),x:x,y:y, registerTime: new Date(values.registerTime.format('YYYY-MM-DD')) }
        const value2 = { watchLevel: parseInt(values.watchLevel, 10), safetyLevel: parseInt(values.safetyLevel, 10), chief: values.chief };
        this.setState({ createValue: value1 });
        //console.log(value1);
        //console.log(value2)
        window.rpc.owner.create(value1, value2).then(id => {
          if (id) {
            this.setState({ id });
            window.location.href = `/org/org/img/${id}`;
          }
        },err=>[
          console.warn(err)
        ])
      } else {
      }
    });
  },
   showModalOne() {
    let that = this;
  
    function init() {
      var map = new window.BMap.Map("editOrgMap");
      var point = new window.BMap.Point(121.64, 29.92);
      map.centerAndZoom(point, 14);
      map.enableScrollWheelZoom();                 //启用滚轮放大缩小        
      //单击获取点击的经纬度
      map.addEventListener("click", function (e) {
        alert(e.point.lng + "," + e.point.lat);
        that.setState({ x: e.point.lng });
        that.setState({ y: e.point.lat });
        that.setState({ xy: `${e.point.lng},${e.point.lat}` });
      });
    }
    setTimeout(() => {
      init();
    }, 800)
    that.setState({
        visibleOne: true,
    });
  },
  handleOkOne(e) {
    this.setState({
      visibleOne: false,
    });
  },
  handleCancelOne(e) {
    this.setState({
      visibleOne: false,
    });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const config = {
      rules: [{  required: true, message: '请选择时间!' }],
    };
    let Orgtypes = this.state.OrgsType;
    let OrgtypeChildren = [];
    let OrgstateChildren = [];
    let safetyChildren = [];
    let SupervisionsChildren = [];

    const safety = this.state.safetyLevelList;
    const safetySupervision = this.state.watchLevelList;


    for (let i = 1; i < safety.length + 1; i++) {
      safetyChildren.push(<Option key={`${i}`}>{safety[i]}</Option>)
    }

    for (let i = 1; i < safetySupervision.length + 1; i++) {
      SupervisionsChildren.push(<Option key={`${i}`}>{safetySupervision[i]}</Option>)
    }

    let dStateObj = this.state.dStateList;
    for (let i in dStateObj) {

      OrgstateChildren.push(<Option key={`${i}`}>{dStateObj[i]}</Option>)
    }
    //如果有数据就存储到子数组中
    for (let value of Orgtypes) {
      if (value && value.id) {
        OrgtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>);
      }
    }
    return (
      <div style={{ background: '#fff', fontSize: '0.75rem' }} className="" >
        <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>单位信息</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="">新增单位</Link></Button>
          </div>

        </div>
        <div>
          <Form className="EditOrg" onSubmit={this.handleSubmit} style={{ marginTop: -4, overflow: 'auto' }}>
            <div span={2} style={{ textAlign: 'left' }}>
              <p style={{ color: '#373d41', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '28px 0 28px 10px' }}>基础信息</p>
            </div>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={org_name_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位名称：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('name', {
                      rules: [{
                        required: true, message: '请输入单位名称',
                      }],
                    })(
                      <Input style={{ width: '400px' }} placeholder="请选择单位名称" />
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={org_type} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位类型：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('type', {
                      rules: [
                        { required: true, message: '请选择单位类型' },
                      ],
                    })(
                      <TreeSelect
                        style={{ height: 30, width: 200 }}
                        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                        treeData={this.state.data.filter(x => x.layer === 1)}
                        placeholder="请选择单位类型"
                        treeDefaultExpandAll

                      />
                      )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={duty_officer} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span style={{ paddingRight: '12px' }}>责任人：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      getFieldDecorator('legalPerson', {
                        rules: [{
                          required: true, message: '请输入责任人',
                        }],
                      })(
                        <Input style={{ width: '400px' }} placeholder='请输入责任人' />
                        )
                    }
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={org_state_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位编号：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('number', {
                      rules: [{
                        required: true, message: '请输入单位编号',
                      }],
                    })(
                      <Input style={{ width: '146px' }} placeholder='请输入单位编号' />
                      )}
                  </FormItem>

                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={owner_group} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>所属组织：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      <Input style={{ width: '400px' }} placeholder='请输入所属组织' />
                    }
                  </FormItem>
                </div>
                {/*<div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={org_state} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位状态：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('state', {
                      rules: [
                        { required: true, message: '请选择单位状态' },
                      ],
                    })(
                      <Select placeholder="请选择单位类型" style={{ width: '162px' }} >
                        {OrgstateChildren}
                      </Select>
                      )}
                  </FormItem>
                </div>*/}
              </div>
               <div className="Row-info">
                <div className="Row-info-left clearfix" >
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={org_state} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位坐标：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('x', {
                      rules: [
                        { required: true, message: '请输入单位坐标!' },
                      ],
                    })(
                      <Input size="large" style={{ width: 309 }} placeholder="请输入单位坐标!" />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div id="container" style={{ position: 'relative', float: 'left', width: 112, height: 32, marginRight: 6 }}>
                    <Button onClick={this.showModalOne} style={{ position: 'relative', float: 'left', width: 162, height: 32, borderRadius: 0, color: `rgb(0, 193, 222)`, border: `1px solid rgb(0, 193, 222)` }} >
                      <span>采集坐标</span>
                    </Button>
                    <Modal title="采集坐标"
                      visible={this.state.visibleOne}
                      onOk={this.handleOkOne}
                      onCancel={this.handleCancelOne}
                      style={{ height: 780, position: 'absolute', left: '50%', marginLeft: '-380px', padding: '0 22px' }}
                      className="mapOrgOne"
                    >
                      <div >
                        <div id="editOrgMap" style={{ padding: '20', height: 580, width: 860, position: 'absolute', left: 20, top: 60 }} ></div>
                        <div style={{ overflow: 'hidden' }}>
                          <div style={{ float: 'left', width: 400, position: 'absolute', bottom: 20, }}>
                            <span>请复制当前坐标：</span>
                            <Input type="text" value={this.state.xy} style={{ width: 300, zIndex: 999 }} />
                          </div>
                        </div>
                      </div>
                    </Modal>
                  </div>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={org_address_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位地址：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('address', {
                      rules: [{
                        required: true, message: '请输入单位地址',
                      }],
                    })(
                      <Input placeholder='请输入单位地址' style={{ width: '400px' }} />
                      )}
                  </FormItem>
                </div>

                {
                  /**
                   * <FormItem {...formItemLayout}label="营业照" extra="" >
                     {getFieldDecorator('number', {
                      valuePropName: 'fileList',
                      getValueFromEvent: this.normFile,
                     })(
                     <Upload name="logo" action="/upload.do" listType="picture">
                      <Button>
                        <Icon type="upload" /> Click to upload
                     </Button>
                     </Upload>
                     )}
                     </FormItem>
                   */
                }

                <div className="Row-info-right clearfix" >

                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={area} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>单位面积（平方米）：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('face', {
                      rules: [{
                        required: true, message: '请输入单位面积',
                      }],
                    })(
                      <Input style={{ width: '400px' }} placeholder='请输入' />
                      )}
                  </FormItem>

                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={fix_face} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>固定资产（万）：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('asset', {
                      rules: [{
                        required: true, message: '请输入固定资产',
                      }],
                    })(
                      <Input style={{ width: '400px' }} placeholder='请输入固定资产' />
                      )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 62, height: 32, lineHeight: '32px' }}>
                    <img src={work_person} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>职工人数：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('peopleScale', {
                      rules: [{
                        required: true, message: '请输入职工人数',
                      }],
                    })(
                      <Input style={{ width: '400px' }} placeholder='请输入' />
                      )}
                  </FormItem>
                </div>
              </div>

              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 50, height: 32, lineHeight: '32px' }}>
                    <img src={create_time_pic} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>成立时间：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('registerTime', config)(
                      <DatePicker />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 62, height: 32, lineHeight: '32px' }}>
                    <img src={work_person} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>NFC：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('tag', {
                      rules: [{
                        required: true, message: '请输入NFCID',
                      }],
                    })(
                      <Input style={{ width: '400px' }} placeholder='请输入' />
                      )}
                  </FormItem>
                </div>
              </div>
              <div style={{ textAlign: 'left' }}>
                <p style={{ color: '#373d41', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '13px 0 13px 10px' }}>备注</p>
              </div>
              <div className="Row-info" style={{ background: '#f8fbfb', padding: '4px 0', height: 100 }}>

                <div style={{ float: 'left', marginRight: 12, height: 92, lineHeight: '92px', padding: '4px 0' }}>
                  <img src={fire_remark} style={{ padding: '0 28px 0 28px' }} alt="" />
                  <span style={{ marginRight: 24 }}>备注：</span>
                </div>
                <FormItem
                  style={{ float: 'left', height: 92 }}
                  hasFeedback
                >
                  {getFieldDecorator('remark', {
                    rules: [{
                      required: false,
                    }],
                  })(
                    <textarea style={{ height: 92, outline: 'none', border: '1px solid #ccc', width: '700px', textIndent: '10px' }} />
                    )}
                </FormItem>
              </div>

            </div>

            <div style={{ textAlign: 'left' }}>
              <p style={{ color: '#373d41', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '28px 0 28px 10px' }}>消防信息</p>
            </div>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 36, height: 32, lineHeight: '32px' }}>
                    <img src={watch_level} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>监管等级：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {getFieldDecorator('watchLevel', {
                      rules: [
                        { required: true, message: '请选择监管等级' },
                      ],
                    })(
                      <Select placeholder="请选择监管等级" style={{ width: 242 }} >
                        {SupervisionsChildren}
                      </Select>
                      )}

                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={safetyLevel} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>安全等级：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >

                    {getFieldDecorator('safetyLevel', {
                      rules: [
                        { required: true, message: '请选择安全等级' },
                      ],
                    })(
                      <Select placeholder="请选择安全等级" style={{ width: 242 }} >
                        {safetyChildren}
                      </Select>
                      )}

                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={owner_chief} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span>消防主管单位：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      // getFieldDecorator('chief', {
                      //  rules: [
                      //    { required: true, message: '请选择消防主管等级' },
                      // ],
                      // })(
                      <Input placeholder="请选择消防主管单位" style={{ width: 242 }} />

                      //  )
                    }
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix">
                  <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                    <img src={duty_officer} style={{ padding: '0 15px 0 12px' }} alt="" />
                    <span style={{ paddingRight: '12px' }}>联系电话：</span>
                  </div>
                  <FormItem
                    style={{ float: 'left' }}
                    hasFeedback
                  >
                    {
                      getFieldDecorator('legalPersonPhone', {
                        rules: [{
                          required: true, message: '请输入联系电话',
                        }],
                      })(
                        <Input style={{ width: '400px' }} placeholder='请输入联系电话' />
                        )
                    }
                  </FormItem>
                </div>
              </div>
            </div>
            <div style={{ position: 'absolute', bottom: 60 }} className="search-btn">
              <FormItem >
                <Button htmlType="submit"> 保存</Button>
                <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', marginLeft: 10, width: 60, height: 32, borderRadius: 0 }}><Link to="/org/manage">返回</Link></div>
              </FormItem>
            </div>
          </Form>
        </div>
      </div>
    );
  }
})
)

class EquipInspectTaskNew extends Component {
  render() {
    return (
      <div className="EquipInspectTaskNew">
        <WrappedRegistrationForm />
      </div>
    );
  }
}

class NewOrg extends Component {
  render() {
    return (
      <div className="NewOrg">
        <EquipInspectTaskNew />
      </div>
    )
  }
}

export default NewOrg;