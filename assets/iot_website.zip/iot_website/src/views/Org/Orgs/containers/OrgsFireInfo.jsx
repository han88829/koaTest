

import React from 'react';
import {Row, Col,Button} from 'antd';
//import moment from 'moment';
import { Link } from 'react-router';
//const { RangePicker } = DatePicker;
//const { Option } = Select;
//const FormItem = Form.Item;
import "./Orgsing.css";
import '../Orgs.css';

import fire_remark from '../../../../assets/images/orgs/fire-remark.png';
import safetyLevel from '../../../../assets/images/orgs/safetyLevel.png';
import watch_level from '../../../../assets/images/orgs/watch-level.png';
import owner_chief from '../../../../assets/images/orgs/owner-chief.png';
//import fix_asset_pic from '../../../../assets/images/orgs/fix-asset.png';

class OrgsFireInfo extends React.Component {
   constructor() {
    super();
    this.state = {
      orgFires: {
        remark:'',
        safetyLevel:'',
        watchLevel:'',
        chief:''
      },
      safetyLevelObj:{},
      watchLevelObj:{}
    };
  }
  componentWillMount() {

    window.rpc.alias.getValueByName('fire.safetyLevel').then((res) => {
        this.setState({safetyLevelObj:res});
        window.rpc.alias.getValueByName('fire.watchLevel').then((wres) => {
          this.setState({watchLevelObj:res});
          var str = window.location.href;
          var index = str.lastIndexOf("\/");
          str = str.substring(index + 1, str.length);
          // const id=this.props.name;
          const id=parseInt(str,10);
     
         window.rpc.fire.getInfoById(id).then((results) => {
           console.log(results);
           //  let time;
            const orgFires= {...results,watchLevel:wres[results.watchLevel],safetyLevel:res[results.safetyLevel]};
            this.setState({ orgFires});
         }, (err) => {
          console.warn(err);
         });
        },(err) =>{
          console.warn(err);
        });

     },(err) =>{
        console.warn(err);
     });
    //  window.rpc.alias.getValueByName('fire.watchLevel').then((wres) => {
    //     this.setState({watchLevelObj:res})
    //  },(err) =>{
    //     console.warn(err);
    //  });

     //const id=this.props.idN;
    //  var str = window.location.href;
    //  var index = str.lastIndexOf("\/");
    //  str = str.substring(index + 1, str.length);
    //  // const id=this.props.name;
    //  const id=parseInt(str,10);
     
    //  window.rpc.fire.getInfoById(id).then((results) => {
    //   console.log(results);
    // //  let time;
    //   const orgFires= {...results};
    //   this.setState({ orgFires});
    // }, (err) => {
    //   console.warn(err);
    // });


  }
  handleSearch = (e) => {
    e.preventDefault();
  
  }

  render() {
// let  safetyLevel=this.state.safetyLevelObj;
//     // for (let i=1;i<dStateList.length+1;i++) {
//     //     OrgstateChildren.push(<Option key={`${i-1}`}>{dStateList[i]}</Option>)
//     // }
//       for(let i in dStateObj){
         
//          OrgstateChildren.push(<Option key={`${i}`}>{dStateObj[i]}</Option>)
//        }

    return(
       <div className="buildCard" >
         <div style={{fontsize:'0.75rem',color: '#373e41'}}>
             <p style={{color:'#adadad',fontsize:'0.75rem',fontFamily:'苹方中等',padding:'22px 0 24px 9px'}}>消防信息</p>
             <div className="Row-info">
               <div className="Row-info-left"><img src={watch_level} style={{padding:'0 15px 0 12px'}} alt=""/>监管等级：{this.state.orgFires.watchLevel}</div>
               <div className="Row-info-right"><img src={safetyLevel} style={{padding:'0 15px 0 12px'}} alt=""/>安全等级：{this.state.orgFires.safetyLevel} </div>
             </div>
             <div className="Row-info">
               <div className="Row-info-left"><img src={owner_chief} style={{padding:'0 15px 0 12px'}} alt=""/>消防主管单位：{this.state.orgFires.chief}</div>   
             </div>                 
          </div>
         <div style={{fontsize:'0.75rem',color: '#373e41'}}>
            <p style={{color:'#adadad',fontsize:'0.75rem',fontFamily:'苹方中等',padding:'22px 0 24px 9px'}}>备注</p>
              <div className="Row-info">
                  <div className="Row-info-left"><img src={fire_remark} style={{padding:'0 15px 0 12px'}} alt=""/>备注：{this.state.orgFires.remark} </div>   
             </div>                    
         </div>
          <Row style={{padding: '10px 0 10px', margin: '24px 0 0' }}>
             <Col span={9} style={{textAlign:'left'}}>
                   <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to="/org/manage">返回</Link></Button>
             </Col>
         </Row>   
      </div>
    )
  }
}


export default OrgsFireInfo;