

import React, { Component } from 'react';
import { Link,browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import listOrgStore from '../../listOrgStore';
import { Row, Col, Table, Button, Form, DatePicker, message } from 'antd';
import moment from 'moment';
import "./Orgsing.css";
const { RangePicker } = DatePicker;
// const { Option } = Select;
const FormItem = Form.Item;
const { armtypeList,ResultState } = listOrgStore;
var reg = new RegExp("^[0-9]*$");
message.config({
  top: 216,
  duration: 2
})
//获取类型 安全等级 状态 监管等级

//初始化数据
/*class appState {
  @observable timer = 0;
  @observable tableData = [];

  // @action trick(){
  //   setInterval(() => {
  //     this.timer += 1;
  //   }, 1000)
  // }
}*/

class appState {
  constructor(){
    extendObservable(this,{
      tableData:[],
      timer:0,
      id:null
  })
 }
}

class OrgsAdvancedSearchForm extends React.Component {
  componentWillMount() {
     
  }

  handleSearch = (e) => {
    e.preventDefault();
     const str=this.props.appState.id;
        
      try {
      this.props.form.validateFields((err, fieldsValue) => {
        let values = {ownerId:str};
        const rangeValue = fieldsValue['setupTime'];
        console.log(rangeValue);
        if (rangeValue) {
          values = { ...values,createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        console.log('Received values of form: ', values);
         
        if(reg.test(str)){
           window.rpc.device.alarm.getArrayByContainer(values,0,0).then((res)=>{
             console.log(res);
             let alarm = res.map(x => ({...x,user:x.userId,type:armtypeList[x.type]||'/',state:ResultState[x.state]||'/', key: x.id ,time: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss')}));
     
             this.props.appState.tableData =alarm;
          })
        }else{
          console.log('错误的单位Id'+str);
        }
      })

    } catch (e) {
      console.warn(e);
    }
   
  }

  render() {
    const { getFieldDecorator } = this.props.form;
   

    return (
      <Form inline style={{ margin: 0 }}>
         <Row style={{margin:'15px 0 15px',height:'32px',lineHight:'32px'}} >
          <Col span={12} key={5}>
            <FormItem label={`巡查日期`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker
                ranges={{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }}
                />
              )}
            </FormItem>
          </Col>
          <Col span={12} key={6} className="search-btn">
            <FormItem style={{float:'right',marginRight:'10px'}}>
              <Button
                type="primary"
                onClick={this.handleSearch}
                style={{height:'32px',width:'80px',padding:0,margin:0,fontSize:'0.75rem'}}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>    
      </Form>
    );
  }
}

const OrgAdvancedSearchForm = Form.create()(OrgsAdvancedSearchForm);

//@observer
//class OrgManageC extends Component {
  const OrgAlarmManageC=observer(class appState extends React.Component {
 
  //获取数据
  componentDidMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);
    this.props.appState.id=parseInt(str,10);
    if(reg.test(str)){
      window.rpc.device.alarm.getArrayByContainer({ownerId:str},0,0).then((res)=>{
        console.log(res);
        // const orgs =result.map((x) => ({...x,key:x.id,id:x.id,}));
        let alarm = res.map(x => ({...x,user:x.x.userId,type:armtypeList[x.type]||'/',state:ResultState[x.state]||'/', key: x.id ,time: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss')}));
     
        this.props.appState.tableData =alarm;
      })
    }else{
      console.log('错误的单位Id'+str);
    }
  
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }
   onSelectChange = (selectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    const Selected={Id:parseInt(selectedRowKeys[0],10)};
    console.log(Selected);
    this.setState({Selected:Selected});
    console.log(this.state.Selected);

  }
 

  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id) {
    browserHistory.push(`/conct/historydetail/${this.state.Selected.Id}`);
    } else {
      message.info('请选择建筑！');
    }
  }
  
  render() {
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '报警时间', dataIndex: 'time', key: 'time' },
      { title: '报警类型', dataIndex: 'type', key: 'type'},
      { title: '处理结果', dataIndex: 'state', key: 'state' },
      { title: '处理人', dataIndex: 'user', key: 'user' },
      { title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/conct/historydetail/${record.id}`} style={{color:'#0099cc'}}>查看详情</Link>
          </span>
        )
      },
    ];

  //const data = [...this.props.appState.tableData];
   const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };
// const data = [{
//   key: '1',
//   build:'1',
//   buildingname: 'John',
//   affiliationOrg: 'Brown',
//   buildingtypes: 32,
//   Risk: 'New York No. 1 Lake Park',
// }, {
//   key: '2',
//   build:'1',
//   buildingname: 'Jim',
//   affiliationOrg: 'Green',
//   buildingtypes: 42,
//   Risk: 'London No. 1 Lake Park',
// }, {
//   key: '3',
//   build:'1',
//   buildingname: 'Joe',
//   affiliationOrg: 'Black',
//   buildingtypes: 32,
//   Risk: 'Sidney No. 1 Lake Park',
// }];
   const data = [...this.props.appState.tableData];

   const pagination = {
      showTotal: total => `共  条`
   }

    return (
      <div className="OrgsAlarm" style={{marginTop:15}} >
        <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',color:'#333',fontSize:'0.75rem',fontFamily:'苹方中等',}}>  
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button type=""  style={{background:'#d8dfe4',padding:'0 15px',height:'32px',borderRadius:0}}  onClick={this.handleStaffOne}>查看详情</Button>
          </div>
        </div>
        <OrgAdvancedSearchForm  appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              style={{textAlign:'center'}}
              columns={columns}
              rowSelection={rowSelection}
              dataSource={data}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})




class OrgsAlarm extends Component {
  render() {
    return (
      <OrgAlarmManageC appState={new appState()}   />
    )
  }
}

export default OrgsAlarm;