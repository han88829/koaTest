/*
 * @Author: szj
 * @Date: 2017-03-27 17:22:37 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-06-22 15:09:45
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { Tabs, Icon, Row, Col, Button, Modal } from 'antd';
import "./Orgsing.css";
import '../Orgs.css';
import moment from 'moment';
import OrgsAlarm from './OrgsAlarm';
import OrgsFireInfo from './OrgsFireInfo'
import Orgsinspection from './Orgsinspection';
import listOrgStore from '../../listOrgStore';
import $ from 'jquery';

import org_name_pic from '../../../../assets/images/orgs/org-name.png';
import business_license_pic from '../../../../assets/images/orgs/business-license.png';
import create_time_pic from '../../../../assets/images/orgs/create-time.png';
import last_time_pic from '../../../../assets/images/orgs/last-time.png';
import fix_asset_pic from '../../../../assets/images/orgs/fix-face.png';
import org_address_pic from '../../../../assets/images/orgs/org-address.png';
import org_state_pic from '../../../../assets/images/orgs/org-state.png';

import owner_area_pic from '../../../../assets/images/orgs/owner-area.png';
import quit_time_pic from '../../../../assets/images/orgs/quit-time.png';
import remark_pic from '../../../../assets/images/orgs/remark.png';
import innet_time_pic from '../../../../assets/images/orgs/innet-time.png';
import setup_time_pic from '../../../../assets/images/orgs/setup-time.png';

import unit_area_pic from '../../../../assets/images/orgs/unit-area.png';
import worker_staff_pic from '../../../../assets/images/orgs/worker-staff.png';
import area from '../../../../assets/images/orgs/area.png';
import owner_group from '../../../../assets/images/orgs/owner-group.png';
import date from '../../../../assets/images/orgs/date.png';
import address from '../../../../assets/images/orgs/address.png';
import quit_stop_time from '../../../../assets/images/orgs/quit-stop-time.png';
import work_person from '../../../../assets/images/orgs/work-person.png';
import org_tele from '../../../../assets/images/orgs/org-tele.png';
import org_type from '../../../../assets/images/orgs/org-type.png';
import org_state from '../../../../assets/images/orgs/org-state.png';
import fix_face from '../../../../assets/images/orgs/fix-face.png';
import owner_chief from '../../../../assets/images/orgs/owner-chief.png';
import in_net from '../../../../assets/images/orgs/in-net.png';
import duty_officer from '../../../../assets/images/orgs/duty-officer.png';

const TabPane = Tabs.TabPane;
var flag = false;

// 结构出参量表
const { dStateList } = listOrgStore;

class QrCode extends React.Component {
  state = {
    modal2Visible: false
  }
  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }
  preview = () => {
    let id = 'PrintContentDiv';
    var sprnhtml = document.getElementById(id).innerHTML;
    var selfhtml = window.document.body.innerHTML; //获取当前页的html
    window.document.body.innerHTML = sprnhtml;
    window.print();
    // note
    // Re-refresh the page to load, replace the html structure directly, the binding event is destroyed
    window.location.href = `/org/orgs/info/${this.props.id}`;
  }
  render() {
    let ie = `http://qr.liantu.com/api.php?&bg=ffffff&text=http://xiot.lszpcn.com/SOrg/${this.props.id}`
    return (
      <span className="QrCode">
        <Button type="primary" onClick={() => this.setModal2Visible(true)} style={{ borderColor: "#ccc", color: "#000", backgroundColor: "white" }}>点我查看二维码</Button>
        <Modal
          title="请扫以下二维码"
          wrapClassName="vertical-center-modal"
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          style={{ height: "400px" }}
          className="QrCode"
        >
          <Button name="print" onClick={this.preview} style={{ position: 'absolute', left: 12, bottom: 12, zIndex: 999 }}>打印</Button>
          <div id="PrintContentDiv">
            <img src={ie} alt="" style={{ position: 'absolute', left: '50%', top: '50%', marginLeft: '-150px', marginTop: '-150px' }} />
          </div>
        </Modal>
      </span>
    );
  }
}

class BuildMapMonitore extends Component {
  constructor() {
    super();
    this.state = {
      x: 121,
      y: 29
    }
  }
  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
  }
  componentWillMount() {

    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);

    }
    loadJScript();
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);

    const id = parseInt(str, 10);
    window.rpc.owner.getInfoById(id).then((result) => {
      this.setState({
        x: result.x
      })
    })
  }

  componentDidMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);

    const id = parseInt(str, 10);
    window.rpc.owner.getInfoById(id).then((result) => {
      let x = result.x;
      let y = result.y;
      function init() {
        var map = new window.BMap.Map("allmap02");            // 创建Map实例
        var point = new window.BMap.Point(x, y); // 创建点坐标
        map.centerAndZoom(point, 14);
        map.enableScrollWheelZoom();                 //启用滚轮放大缩小

        var top_left_control = new window.BMap.ScaleControl({ anchor: 'BMAP_ANCHOR_TOP_LEFT' });// 左上角，添加比例尺
        var top_left_navigation = new window.BMap.NavigationControl();  //左上角，添加默认缩放平移控件
        // var top_right_navigation = new window.BMap.NavigationControl({anchor: 'BMAP_ANCHOR_TOP_RIGHT', type: 'BMAP_NAVIGATION_CONTROL_SMALL'}); //右上角，仅包含平移和缩放按钮

        //添加控件和比例尺
        function add_control() {
          map.addControl(top_left_control);
          map.addControl(top_left_navigation);
        }

        var marker = new window.BMap.Marker(new window.BMap.Point(x, y));
        map.addOverlay(marker);

        add_control();
      }
      setTimeout(() => {
        init();
      }, 1000)
    })


  }
  render() {
    return (
      <div className="BuildMapMonitore" style={{ width: '100%', height: '100%' }}>
        <div id="allmap02" style={{ width: '100%', height: '100%', overflow: 'hidden', margin: '0' }}></div>
      </div>
    );
  }
}
class OrgsInfo extends React.Component {
  constructor() {
    super();
    this.state = {
      orgs: {
        name: '',
        address: '',
        setupTime: '',
        id: '',
        images: '',
        remark: '',
        state: '',
        number: '',
        type: '',
        x: 1,
        y: 1,
        safety: '',
        createTime: '',
        lastTime: '',
        registerTime: '',
        asset: '',
        peopleScale: '',
        fRemark: '',
        safetyLevel: '',
        watchLevel: '',
        chief: '',
        tag: ""

      },
      showImg: {
        show: true
      },
      id: null,
      OrgsType: []
    };
  }
  componentWillMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);
    const id = parseInt(str, 10);
    this.setState({ id });
    window.rpc.alias.getValueByName('owner.state').then((dres) => {
      window.rpc.owner.getInfoById(id).then((result) => {
        $('#imgPhoto').attr({ 'src': result.image });
        window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then(data => {
          let type = data[`${result.type}`] || '其他';
          const orgs = { ...result, id: result.id, tag: result.tag, state: dres[`${result.state}`], type: type, legalPersonPhone: result.legalPersonPhone, legalPerson: result.legalPerson, createTime: moment(result.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(result.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), registerTime: moment(result.registerTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') };
          this.setState({ orgs });
        });
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
    });
  }
  componentDidMount() {
  }

  handleClick = (e) => {
    flag = !flag;
    if (flag) {
      $('.photo').css({ 'display': 'block' });
    } else {
      $('.photo').css({ 'display': 'none' });
    }
  }
  render() {
    return (
      <div className="OrgsInfo" style={{ height: '90vh', overflow: "hidden" }} >
        <Tabs defaultActiveKey="1" style={{ height: '100%', fontSize: '0.75rem' }} className='infoTabOne' >
          <TabPane className="firstTabInfo" tab={<span><Icon type="info-circle-o" />基础信息</span>} style={{ height: '100%', }} key="1">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>单位信息</Link>
            </div>
            <Tabs tabPosition="Top" type="card" className='infoTabTwo' style={{ height: '100%' }} >
              <TabPane tab="基础信息" key="1" style={{ height: '100%', }} >
                <div className='DclearFix' style={{ marginTop: -4, paddingTop: 5, height: '100%', maxHeight: '72vh', overflow: 'auto', }}>
                  <div className="buildCard" style={{ width: '75%', float: 'left' }}>
                    <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                      <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '22px 0 24px 9px' }}>名称信息</p>
                      <div className="Row-info">
                        <div className="Row-info-left"><img src={org_name_pic} style={{ padding: '0 15px 0 12px' }} alt="" />单位名称： {this.state.orgs.name}</div>
                        <div className="Row-info-right"><img src={org_type} style={{ padding: '0 15px 0 12px' }} alt="" />单位类型：{this.state.orgs.type} </div>
                      </div>
                      <div className="Row-info">
                        <div className="Row-info-left"><img src={area} style={{ padding: '0 15px 0 12px' }} alt="" />所属区域：</div>
                        <div className="Row-info-right"><img src={org_state} style={{ padding: '0 15px 0 12px' }} alt="" />单位状态：{this.state.orgs.state} </div>
                      </div>
                      <div className="Row-info">
                        <div className="Row-info-left"><img src={area} style={{ padding: '0 15px 0 12px' }} alt="" />联系人：{this.state.orgs.legalPerson}</div>
                        <div className="Row-info-right"><img src={org_state} style={{ padding: '0 15px 0 12px' }} alt="" />联系电话：{this.state.orgs.legalPersonPhone} </div>
                      </div>
                      <div className="Row-info">
                        <div className="Row-info-left"><img src={org_address_pic} style={{ padding: '0 15px 0 12px' }} alt="" />单位地址：{this.state.orgs.address} </div>
                        <div className="Row-info-right"><img src={org_state} style={{ padding: '0 15px 0 12px' }} alt="" />NFC：{this.state.orgs.tag}</div>
                      </div>
                      <div className="Row-info">
                        <div className="Row-info-left"><img src={org_address_pic} style={{ padding: '0 15px 0 12px' }} alt="" />单位二维码：<QrCode orgs={this.state.orgs}  id={this.state.orgs.id} /></div>
                      </div>
                    </div>
                    <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                      <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '22px 0 24px 9px' }}>营业执照</p>
                      <div className="Row-info">
                        <div className="Row-info-left"><img src={create_time_pic} style={{ padding: '0 15px 0 12px' }} alt="" />成立时间：{this.state.orgs.registerTime}</div>
                        <div className="Row-info-right"><img src={business_license_pic} style={{ padding: '0 15px 0 12px' }} alt="" />营业执照号：{this.state.orgs.number} </div>
                      </div>
                      <div className="Row-info">
                        <div className="Row-info-left"><img src={fix_face} style={{ padding: '0 15px 0 12px' }} alt="" />固定资产：{this.state.orgs.asset} </div>
                        <div className="Row-info-right"><img src={duty_officer} style={{ padding: '0 15px 0 12px' }} alt="" />职工人员：{this.state.orgs.peopleScale} </div>
                      </div>
                      <div className="Row-info">
                        <div className='Row-info-left'><img src={area} style={{ padding: '0 15px 0 12px' }} alt="" />单位面积：{this.state.orgs.face} </div>
                        <div style={{ minWidth: 500, width: '40%', padding: '10px 0', float: 'left' }}> <Button onClick={this.handleClick} style={{ fontFamily: '苹方中等', fontSize: '0.75rem', color: '#00c1de', border: '1px solid #00c1de', width: 120, height: 30, borderRadius: 0 }}>显示营业执照</Button></div>
                      </div>
                    </div>
                    <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                      <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '22px 0 24px 9px' }}>时间</p>
                      <div className="Row-info">
                        <div className='Row-info-left'><img src={in_net} style={{ padding: '0 15px 0 12px' }} alt="" />入网时间： </div>
                        <div className='Row-info-right'><img src={quit_stop_time} style={{ padding: '0 15px 0 12px' }} alt="" />服务截止时间： </div>
                      </div>
                      <div className="Row-info">
                        <div className='Row-info-left'><img src={create_time_pic} style={{ padding: '0 15px 0 12px' }} alt="" />创立时间：{this.state.orgs.createTime} </div>
                        <div className='Row-info-right'><img src={last_time_pic} style={{ padding: '0 15px 0 12px' }} alt="" />最后更新时间：{this.state.orgs.lastTime} </div>
                      </div>
                    </div>
                    <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                      <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '22px 0 24px 9px' }}>备注</p>
                      <div className="Row-info">
                        <div className='Row-info-left' style={{ height: 100, width: '100%', marginRight: 12 }}><img src={remark_pic} style={{ padding: '0 15px 0 12px' }} alt="" />备注：{this.state.orgs.remark}</div>
                      </div>
                    </div>
                  </div>
                  <div className="photo" style={{ float: 'left', 'display': 'none' }} >
                    <img src="" alt="" id='imgPhoto' style={{ height: 'auto', width: '100%', padding: '30px 15px' }} />
                  </div>
                </div>
                <Row style={{ padding: '10px 0 0px', marginTop: 20 }}>
                  <Col span={9} style={{ textAlign: 'left' }}>
                    <div className="new-button" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', width: 60, height: 32, borderRadius: 0 }}><Link to="/org/manage">返回</Link></div>
                  </Col>
                </Row>
              </TabPane>
              <TabPane tab="消防信息" className='infoTabTwoBorder' key="2">
                <OrgsFireInfo />
              </TabPane>
              <TabPane tab="定位地图" className='infoTabTwoBorder' key="3">
                <BuildMapMonitore mapX={this.state.orgs.x} mapY={this.state.orgs.y} />
              </TabPane>
              <TabPane tab="消防预案" className='infoTabTwoBorder' key="4">
              </TabPane>
            </Tabs>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />报警记录</span>} key="3">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>单位信息</Link>
            </div>
            <OrgsAlarm />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />巡查记录</span>} key="4">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>单位信息</Link>
            </div>
            <Orgsinspection />
          </TabPane>
        </Tabs>
      </div>
    );
  }
}

export default OrgsInfo;