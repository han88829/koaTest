import React, { Component } from 'react';
import { browserHistory } from 'react-router';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form,  DatePicker, message} from 'antd';
import moment from 'moment';
import $ from 'jquery';
import './Orgsing.css';

const { RangePicker } = DatePicker;
//const { Option } = Select;
const FormItem = Form.Item;
var reg = new RegExp("^[0-9]*$");
message.config({
  top: 216,
  duration: 2
})

// class appState {
//   @observable timer = 0;
//   @observable tableData = [];

//   @action trick(){
//     setInterval(() => {
//       this.timer += 1;
//     }, 1000)
//   }
// }
class appState {
  constructor(){
    extendObservable(this,{
      tableData:[],
      timer:0,
      trick:action(function(){
        setInterval(() => {
        this.timer += 1;
         }, 1000)
        })
  })
 }
}

class AdvancedSearchForm extends React.Component {

  componentWillMount() {
     
  }

  handleSearch = (e) => {
    e.preventDefault();
     const str=this.props.appState.id;
        
      try {
      this.props.form.validateFields((err, fieldsValue) => {
        let values = {ownerId:str};
        const rangeValue = fieldsValue['setupTime'];
        console.log(rangeValue);
        if (rangeValue) {
          values = { ...values,createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }//createTime
           //createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        console.log('Received values of form: ', values);
         
        if(reg.test(str)){
         window.rpc.alias.getValueByName('device.patrol.state').then(sres => {
          //console.log(arr);
          window.rpc.alias.getValueByName('device.patrol.type').then(tres => {
           window.rpc.device.patrol.getArrayExByContainer(values,0,0).then((res)=>{
             console.log(res);
              message.info(`共搜索到${res.length}条数据`);
            let result=res.reverse();//key: x.userId ,id:x.userId,
             //let alarm = res.map(x => ({...x,user:x.userId,type:armtypeList[x.type]||'/',state:ResultState[x.state]||'/', key: x.id ,time: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss')}));
            let alarm = result.map(x => ({...x, type:tres[x.type],state:sres[x.state],userName:x.userName,createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss')}));
             //let alarms = alarm.each();
             let alarms=[];
             $.each(alarm ,function(key,value){  
                console.log("arr :" + key + '-' + value);  
                value={...value,key:key+1};
                alarms.push(value);
             })
             console.log(alarms);
             this.props.appState.tableData =alarms;
          })
        })
      })
        }else{
          console.log('错误的单位Id'+str);
        }
      })

    } catch (e) {
      console.warn(e);
    }
   
  }

  render() {
    const { getFieldDecorator } = this.props.form;
   

    return (
      <Form inline style={{ margin: 0 }}>
         <Row style={{margin:'15px 0 15px',height:'32px',lineHight:'32px'}} >
          <Col span={12} key={1}>
            <FormItem label={`巡查日期`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker
                ranges={{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }}
                />
              )}
            </FormItem>
          </Col>
          <Col span={12} key={2} className="search-btn">
            <FormItem style={{float:'right',marginRight:'10px'}}>
              <Button
                type="primary"
                onClick={this.handleSearch}
                style={{height:'32px',width:'80px',padding:0,margin:0,fontSize:'0.75rem'}}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>    
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

// @observer
// class EquipManageC extends Component {
  const EquipManageC=observer(class appState extends React.Component {
  // componentDidMount() {
  //   window.rpc.device.patrol.getArrayExByContainer({},0,0,console.log).then((result) =>{
  //     console.log(result);
  //     let devices = result.map((x) => ({...x, key: x.id, setupTime: '2016-09-26', sign: `!@#$%^&*`, lastPatrolDate: '2016-09-26 08:50:08'}));
  //     this.props.appState.tableData = devices;
  //   }, (err) => {
  //     console.warn(err);
  //   })
  // }


 
  // //详情跳转
  // handleStaffOne = () => {
  //   if (this.state.Selected.Id) {
  //   browserHistory.push(`/org/floor/${this.state.Selected.Id}`);
  //   } else {
  //     message.info('请选择建筑！');
  //   }
  // }
 
 componentDidMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);
    this.props.appState.id=parseInt(str,10);

    window.rpc.alias.getValueByName('device.patrol.type').then(dres => {
    //   let arr=[];
    //   for(let key in dres){   
    //     let values=`${dres[key]}`
    //     arr.push(values);
    //  }
      window.rpc.alias.getValueByName('device.patrol.state').then(sres => {
     //console.log(arr);
        window.rpc.alias.getValueByName('device.patrol.type').then(result => {
        // let arr1=[];
        // for(let key in result){   
        //   let value=`${result[key]}`
        //   arr1.push(value);
        // }
        // console.log(arr);
        if(reg.test(str)){
          window.rpc.device.patrol.getArrayExByContainer({ownerId:str},0,0).then((res)=>{
          console.log(res);
          res=res.reverse();
          console.log(sres);
          // const orgs =result.map((x) => ({...x,key:x.id,id:x.id,}));
          let alarm = res.map(x => ({...x, key: x.userId ,id:x.userId,type:result[x.type],state:sres[x.state],userName:x.userName,createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss')}));
          this.props.appState.tableData =alarm;
        })
       }else{
         console.log('错误的单位Id'+str);
       }

        },(error)=>{
           console.log(error);
        })
      })
    })
  //  }else{
  //        console.log('错误的单位Id'+str);
  //  }
  
    // window.rpc.alias.getValueByName('device.patrol.type').then(result => {
    //   return window.rpc.device.patrol.getArrayExByContainer({ownerId:str},0,0).then(data =>
    //   { return { data, result } })
    // }).then(date => {
    //   console.log(date.data)
    //   date.data.forEach((x, index) => {
    //     console.log(x.userId)
    //     window.rpc.device.patrol.getArrayExByContainer({ userId: x.userId }, 0, 0).then(info => {
    //       console.log(1)
    //       console.log(info)
    //       if (x.type == 1) {
    //         var patrol = { ...x, key: index, createTime: moment(x.createTime || new Date()).format('YYYY-MM-DD'), state: date.result[x.type], userId: info[0].userName }
    //         this.props.deviceState.patrolData.push(patrol)
    //       } else {
    //         var maintai = { ...x, key: index, createTime: moment(x.createTime || new Date()).format('YYYY-MM-DD'), state: date.result[x.type], userId: info[0].userName }
    //         this.props.deviceState.maintainData.push(maintai)
    //       }
    //     }
    //     )
    //   }
    //   )
    // })
  
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }
   onSelectChange = (selectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    const Selected={Id:parseInt(selectedRowKeys[0],10)};
    console.log(Selected);
    this.setState({Selected:Selected});
    console.log(this.state.Selected);

  }
 

  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id) {
    browserHistory.push(`/conct/historydetail/${this.state.Selected.Id}`);
    } else {
      message.info('请选择建筑！');
    }
  }
  

  render() {
    const columns = [
      { title: '序号', dataIndex: 'key', key: 'key' },
      { title: '巡查时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '巡查结果', dataIndex: 'state', key: 'state' },
      { title: '处理结果', dataIndex: 'dealResult', key: 'dealResult' },
      { title: '巡查人', dataIndex: 'userName', key: 'userName' },
      { title: '维护类型', dataIndex: 'type', key: 'type' }
    ];

    const data = [...this.props.appState.tableData];
    console.log(data);
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };
    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    return (
      <div  className="OrgsAlarm OrgsIns" style={{marginTop:15}} >
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ margin: '10px 0 10px  0' }}  >
          <Col span={24}>
            <Button type="primary" style={{ margin:'0 20px 0  0',display:'none' }}    onClick={this.handleStaffOne}>查看详情</Button>            
          </Col>
        </Row>
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              columns={columns}
              rowSelection={rowSelection}
              dataSource={data}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class Orgsinspection extends Component {
  render() {
    return (
      <EquipManageC appState={new appState()} />
    )
  }
}

export default Orgsinspection;