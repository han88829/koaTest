import React, { Component } from 'react';
import {Link} from 'react-router';
import { Table } from 'antd';

const columns = [{
  title: '序号',
  dataIndex: 'id',
  key: 'id',
  render: text => <a href="#">01</a>
}, {
  title: '巡检计划名称',
  dataIndex: 'name',
  key: 'name'
}, {
  title: '设备总数',
  dataIndex: 'num',
  key: 'num'
}, {
  title: '计划状态',
  dataIndex: 'state',
  key: 'state'
}, {
  title: '计划周期',
  dataIndex: 'life',
  key: 'life'
}, {
  title: '检查人员',
  dataIndex: 'person',
  key: 'person'
},{
  title: 'Action',
  key: 'action',
  render: (text, record) => (
    <ul>
      <li style={{float:'left',marginRight:'10px'}}><Link to="/equipment/equiprandomtaskdetail/:id" activeStyle={{color:'red'}}>查看</Link></li>
      <li style={{float:'left'}}><Link to="/equipment/equiprandomtaskedit/:id" activeStyle={{color:'red'}}>修改</Link></li>
    </ul>
  ),
}];

const data = [{
  key: '1',
  name: 'John Brown',
  age: 32,
  address: 1,
}, {
  key: '2',
  name: 'Jim Green',
  age: 42, 
  address:1 ,
}, {
  key: '3',
  name: 'Joe Black',
  age: 32,
  address: 1,
}];


const Causal = () =>(
    <Table columns={columns} dataSource={data} />
)

export default Causal;