import React, { Component } from 'react';
import {Link} from 'react-router';
import { Tabs ,Button,Table } from 'antd';
import Causal from './causal';

const columns = [{
  title: '序号',
  dataIndex: 'id',
  key: 'id',
  render: text => <a href="#">01</a>
}, {
  title: '巡检计划名称',
  dataIndex: 'name',
  key: 'name'
}, {
  title: '设备总数',
  dataIndex: 'num',
  key: 'num'
}, {
  title: '计划状态',
  dataIndex: 'state',
  key: 'state'
}, {
  title: '计划周期',
  dataIndex: 'life',
  key: 'life'
}, {
  title: '检查人员',
  dataIndex: 'person',
  key: 'person'
},{
  title: 'Action',
  key: 'action',
  render: (text, record) => (
    <ul>
      <li style={{float:'left',marginRight:'10px'}}><Link to="/equipment/equipinspecttaskdetail/:id" activeStyle={{color:'red'}}>查看</Link></li>
      <li style={{float:'left'}}><Link to="/equipment/equipinspecttaskedit/:id" activeStyle={{color:'red'}}>修改</Link></li>
    </ul>
  ),
}];

const data = [{
  key: '1',
  name: 'John Brown',
  age: 32,
  address: 1,
}, {
  key: '2',
  name: 'Jim Green',
  age: 42,
  address:1 ,
}, {
  key: '3',
  name: 'Joe Black',
  age: 32,
  address: 1,
}];


const TabPane = Tabs.TabPane;

function callback(key) {
  console.log(key);
}

const Setting = () =>(
  <Tabs defaultActiveKey="1" onChange={callback}>
    <TabPane tab="巡查任务设置" key="1"> 
      <Button type="primary" size="small" style={{margin:'5px 0 15px'}}  ><Link to="/equipment/equipinspecttasknew">新建巡检任务</Link></Button>
      <Table columns={columns} dataSource={data} />
    </TabPane>
    <TabPane tab="抽检任务设置" key="2">
      <Button type="primary" size="small" style={{margin:'5px 0 15px'}} ><Link to="/equipment/equiprandomtasknew">新建抽检任务</Link></Button>
      <Causal />
    </TabPane>
  </Tabs>
)
class OrgTaskSetting extends Component {
  render() {
    return (
      <div className="OrgTaskSetting" style={{ padding: 24 }}>
        <Setting />
      </div>
    )
  }
}

export default OrgTaskSetting;