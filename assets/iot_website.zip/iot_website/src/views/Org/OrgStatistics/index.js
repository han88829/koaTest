import React, { Component } from 'react';
import { Link } from 'react-router';
import { Tabs, Icon } from 'antd';
import OrgState from './containers/OrgState';
import OrgTrend from './containers/OrgTrend';
import OrgType from './containers/OrgType';
import OrgWarning from './containers/OrgWarning';
import SafeLevel from './containers/SafeLevel';
import SuperviseLevel from './containers/SuperviseLevel';
import './equipStatistics.css';

const { TabPane } = Tabs;


class OrgStatistics extends Component {
  render() {
    return (
      <div className="OrgStatistics OrgsInfo" style={{padding:'0 12px',}}>
        <Tabs defaultActiveKey="1"  style={{fontSize:'0.75rem' }} className='infoTabOne' >
          <TabPane tab={<span><Icon type="info-circle-o" />数量统计</span>} key="1">
            <div style={{position:'absolute',left:0,top:10,width:75,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/org/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0',fontFamily: `苹方中等`}}>单位统计</Link>
            </div>
            <Tabs tabPosition="top" type="card" className='infoTabTwo' >
              <TabPane tab="单位类型" key="1">
                <OrgType />
              </TabPane>
              <TabPane tab="监管等级" key="2">
                <SuperviseLevel />
              </TabPane>
              <TabPane tab="安全等级" key="3">
                <SafeLevel />
              </TabPane>
              <TabPane tab="单位状态" key="4">
                <OrgState />
              </TabPane>
            </Tabs>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />报警统计</span>} key="3">
            <div style={{position:'absolute',left:0,top:10,width:75,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/org/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0',fontFamily: `苹方中等`}}>单位统计</Link>
            </div>
            <OrgWarning />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />趋势分析</span>} key="4">
             <div style={{position:'absolute',left:0,top:10,width:75,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/org/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0',fontFamily: `苹方中等`}}>单位统计</Link>
             </div>
            <OrgTrend />
          </TabPane>
        </Tabs>
      </div>
    )
  }
}

export default OrgStatistics;