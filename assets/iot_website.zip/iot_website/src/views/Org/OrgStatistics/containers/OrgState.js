import React, {
	Component
} from 'react';
import {
	Row,
	Col,
	Card,
	Table
} from 'antd';
import {
	extendObservable
} from 'mobx';
import {
	observer
} from 'mobx-react';
import echarts from 'echarts';

class typeMountState {
	constructor() {
		extendObservable(this, {
			tableData: []
		})
	}
}

const columns = [{
	title: '单位类型',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '单位数量',
	dataIndex: 'value',
	key: 'value',
}];

// 取出类型和locations
let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
//let locations = JSON.parse(sessionStorage.getItem('locations'));

@observer
class OrgStateC extends Component {
	// const DeviceTypeMountC=observer(class DeviceTypeMountC extends React.Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			parentType: [],
			data: [],
			states: []
		};
	}

	onChangeDate(date, dateString) {
		console.log(date, dateString);
	}

	handleSizeChange = (e) => {
		this.setState({
			size: e.target.value
		});
	}

	componentWillMount() {

		window.rpc.alias.getValueByName('owner.state').then(result => {
			return window.rpc.owner.getCountFieldByContainer({}, 'state').then(data => ({
				result,
				data
			}))
		}).then((res) => {
			//console.log(res);
			//console.log(res.result);
			//console.log(res.data);
			// let tableDate =res.result.map(x=>{
			// 	res.data.map(y=>{
			// 		if()
			// 	})
			let arr = [];
			for (let key in res.result) {

				let value = `${res.result[key]}`;

				arr.push(value);

			}
			console.log(arr);
			let arr1 = [];
			//let data=res.data;

			for (let info in res.data) {

				let values = `${res.data[info]}`;

				// values['']
				values = parseInt(values, 10)
				arr1.push(values);
				//	console.log(values);

			}
			this.setState({
				states: arr1
			})
			console.log(arr1);
			let data = [];
			for (let i = 0; i < arr.length; i++) {
				let name = arr[i];
				let value = arr1[i];
				let obj = {
					name: name,
					value: value || 0,
					key: value || 0
				}
				console.log(obj);
				data.push(obj);


			}
			console.log(data);
			// })
			// let tableDate=[];
			// let len = res.result.length;
			// console.log(arr);
			// console.log(tableDate)
			this.setState({
				data
			})
			console.log(this.state.data);
			//this.props.typeMountState.tableDate = data;
			//console.log(this.props.typeMountState.tableDate)
			let myChart = echarts.init(document.getElementById('OrgStateMountEcharts'));
			myChart.setOption({
				title: {
					text: '单位状态占比',
					x: 'center'
				},
				//     title : {
				//     text: '安全等级占比',
				//      x:'center'
				//    },
				tooltip: {
					trigger: 'item',
					formatter: "{a} <br/>{b} : {c} ({d}%)"
				},
				legend: {
					orient: 'vertical',
					x: 'left',
					data: this.state.data.map(x => x.name)
				},
				calculable: true,
				series: [{
					name: '面积模式',
					type: 'pie',
					radius: [30, 110],
					center: ['35%', '50%'],
					color: ['#a1d91b', '#f1c100', '#10eedc', '#d53d34'],
					//roseType : 'area',
					data: [...this.state.data],
				}]

			});


		}, (err) => {
			console.warn(err);
		});
		console.log(this.props.typeMountState.tableDate);
	}

	render() {
		console.log(this.state.data)
		//console.log([...this.props.typeMountState.tableData])
		return ( 
			  <div className="DeviceTypeMount">
						<Row  style={{ padding: '3px',marginTop:12}} >
						<Col span={8} style={{ padding: '0 12px 0 0' }} >
							<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
								<Table dataSource={this.state.data} bordered columns={columns} style={{ height: '70vh'}} pagination={false} />
							</Card>
						</Col>
						<Col span={16}>
							<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
								<div id="OrgStateMountEcharts" style={{ height: '60vh', width: '100%' }}></div>
							</Card>
						</Col> 
					</Row>
				</div>
		);
	}
}


class OrgState extends Component {
	render() {
		//deviceState={new deviceState()}
		return ( 
			<OrgStateC typeMountState = {new typeMountState()} />
		)
	}
}

export default OrgState;