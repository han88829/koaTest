import React, { Component } from 'react';
import { Row, Col, Card, Table } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import echarts from 'echarts';

class buildingMountState {
  constructor(){
    extendObservable(this,{
      tableData:[]
    })
  }
}

const columns = [{
	title: '安全等级',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '数量',
	dataIndex: 'value',
	key: 'value',
}];

// 取出类型和locations
let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
//let locations = JSON.parse(sessionStorage.getItem('locations'));

@observer
class SafeLevelC  extends Component {
// const DeviceTypeMountC=observer(class DeviceTypeMountC extends React.Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			parentType:[],
			data:[],
			states:[]
		};
	}
    
	onChangeDate(date, dateString) {
		console.log(date, dateString);
	}

	handleSizeChange = (e) => {
		this.setState({ size: e.target.value });
	}

	componentWillMount() {
	
		window.rpc.alias.getValueByName('fire.safetyLevel').then(result=>{
			return window.rpc.fire.getCountFieldByContainer({},'safetyLevel').then(data=>({result,data}))
		}).then((res) => {
			//console.log(res);
			//console.log(res.result);
			//console.log(res.data);
			// let tableDate =res.result.map(x=>{
			// 	res.data.map(y=>{
			// 		if()
			// 	})
			let arr=[];
		   for(let key in res.result){
            
            let value=`${res.result[key]}`;
           
            arr.push(value);
          
         }
		 console.log(arr);
		let  arr1=[];
		//let data=res.data;
		
		 for(let info in res.data){
            
            let values=`${res.data[info]}`;
			
          // values['']
		  values=parseInt(values,10)
            arr1.push(values);
		//	console.log(values);
          
         }
		 this.setState({
			 states:arr1
		 })
		 console.log(arr1);
		 let data=[];
		   for (let i=0;i<arr.length;i++) {
               let name=arr[i];
			   let value=arr1[i];
			   let obj={name:name,value:value||0,key:i}
               console.log(obj);
			   data.push(obj);
                 
      
             }
             console.log(data);
			// })
			// let tableDate=[];
			// let len = res.result.length;
			// console.log(arr);
			// console.log(tableDate)
			this.setState({
				data
			})
			console.log(this.state.data);
			//this.props.typeMountState.tableDate = data;
			//console.log(this.props.typeMountState.tableDate)
			let myChart = echarts.init(document.getElementById('OrgSafetyMountEcharts'));
			myChart.setOption({
				// title: { text: '安全等级占比' ,x:'center' },
				// //tooltip: {},
				// color: ['#74cb62', '#32b3f2', '#8387c3'],
				// legend: {
				// 	orient: 'vertical',
				// 	x: 'left',
			      
				// 	data:this.state.data.map(x=>x.name)
				// 	//data:['合格','不合格']
				// 	//data: ['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
				// },
				// series: [{
				// 	name: '安全等级占比',
				// 	type: 'pie',
				// 	//radius: '50%',
				// 	radius: ['0', '50%'],
				// 	center: ['50%', '50%'],
				// 	color:['#00d8bf', '#db0014','#ffb400'],
				// 	data:[...this.state.data],// [...this.props.typeMountState.tableDate],
				// 	// data:[
				// 	// 	{value:1,name:"合格"},
				// 	// 	{value:0,name:"不合格"}
				// 	// ],
				// 	itemStyle: {
				// 		emphasis: {
				// 			shadowBlur: 10,
				// 			shadowOffsetX: 0,
				// 			shadowColor: 'rgba(0, 0, 0, 0.5)'
				// 		},
				// 		normal: {
				// 			label: {
				// 				show: true,
				// 				formatter: '{b} \n\n {c}个 \n\n({d}%)'
				// 			}
				// 		},
				// 		labelLine: { 
				// 			show: true,
				// 			 smooth:true,
				// 			normal:{
                //                  show: true,
				// 				 length:20,
				// 				 smooth:true
				// 			}
				// 		 },
				// 	},
				// }]
	  title : {
         text: '安全等级占比',
         x:'center'
      },
       tooltip : {
          trigger: 'item',
          formatter: "{a} <br/>{b} : {c} ({d}%)"
       },
        legend: {
        //    x : 'left',
        //    y : 'top',
			orient: 'vertical',
			x: 'left',
           data:this.state.data.map(x=>x.name)
        },
        calculable : true,
        series : [
  
         {
            name:'面积模式',
            type:'pie',
            radius : [50, 160],
            center : ['50%', '50%'],
		    color: ['#f1c100', '#a1d91b', '#10eedc','#d53d34'],
            roseType : 'area',
            data:[...this.state.data],
         }
        ]

	 	});
		},(err) =>{
        console.warn(err);
      });
		console.log( this.props.buildingMountState.tableDate);
	}

	render() {
		console.log(this.state.data)
		//console.log([...this.props.typeMountState.tableData])
			return ( 
				<div className="DeviceTypeMount">
						<Row  style={{ padding: '3px',marginTop:12}} >
						<Col span={8} style={{ padding: '0 12px 0 0' }} >
							<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
								<Table dataSource={this.state.data} bordered columns={columns} pagination={false} style={{ height: '60vh'}} />
							</Card>
						</Col>
						<Col span={16}>
							<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
								<div id="OrgSafetyMountEcharts" style={{ height: '60vh', width: '100%' }}></div>
							</Card>
						</Col> 
					</Row>
				</div>
			);
	}
}


class SafeLevel extends Component {
	render() {
		return(
			<SafeLevelC buildingMountState={new buildingMountState()}/>
		)
	}
}

export default SafeLevel;