import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Radio, Card, Form, message } from 'antd';
import echarts from 'echarts';
import moment from 'moment';
//import './deivceWarnning.css'
const FormItem = Form.Item;
let nowday = new Date();
let beginTime = '';
let lastTime = moment(nowday).format('YYYY-MM-DD');
const { RangePicker } = DatePicker;

    function datearr(data,res,dataArr){
        let  tableDate=[],arr=[],nDtate=[],arrD=[],arrValue=[];
		//console.log(data);//Object {2017-04-12: Object, 2017-04-13: Object, 2017-04-18: Object}
		//console.log(res);//"火警", "误报", "测试"]
		//console.log(dataArr);//["2017-04-13", "2017-04-14", "2017-04-15", "2017-04-16", "2017-04-17", "2017-04-18", "2017-04-19"]
		for (let i in data) {
			tableDate.push({ name: data[i], data: [] })
		}
		//console.log(tableDate);
		//组成数组，仅value；				
        for (let i in res) {
			//let i=1;
			arrValue=[];
            for(let m in dataArr){			 
              //console.log(dataArr[m]);
		      //arr.push({date:dataArr[m],value:0});
			   arrValue.push(0)			
               for(let n in data){
                 if(dataArr[m]==n){
				    // console.log(m);    
				    //arr.splice(m,1,{date:dataArr[m],value:data[n][i]||0});
				    arrValue.splice(m,1,data[n][i]||0);
				 }                  
               }
               // 如果不存在这个date，push value为0   eg数组去重
		       //  arr.push({name:res[i],vData:arrValue});
			   // console.log( arrValue);
            }
            console.log( arrValue);
		    arr.push({name:res[i],vData:arrValue});
                       
        }
        //console.log(arr);
		 return arr;  
						
	}


class deviceState {
	constructor() {
	}
}

const TrendSearchFormUp = Form.create()(React.createClass({
//valueArr
    // constructor() {
	// 	super();
	// 	this.state = {
	// 		valueArr:[]
	// 	};
	// },
	getInitialState() {
      return {
       valueArr:[]

     };
   },
	componentWillMount() {

		let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
		let month = date.getMonth() + 1;
		let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
		beginTime = moment(weekday).format('YYYY-MM-DD');
		//this.setState({ beginTime: weekday });
		this.changeTimeData(1);
	},
	changeTimeData(timeType) {
		/*图表一*/
		let timeDate = 'date';
		if (timeType === 2) {
			timeDate = 'month';
			//timeDate = 'week';
		} else if (timeType === 3) {
			timeDate = 'month';
		}
        //  console.log(timeDate) ;
		 console.log([new Date(beginTime), new Date(lastTime)]);
		window.rpc.alias.getValueByName('device.alarm.type').then(result => {
			return window.rpc.device.alarm.getTrendCountTypeByContainer({ createTime: [new Date(beginTime), new Date(lastTime)] }, timeDate).then(data => { return { result, data } })
		}).then(res => {
			console.log(res);
			const info = res.data;
			console.log(info);
			let arr = [];
			//报警类型
			for (var i in res.result) {
				arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
			}
			this.props.deviceState.patrolData = arr;
			console.log(arr);
			this.setState({
				data: arr
			});
			// const deviceAlarm = arr.map(x => ([x.createTime, x.value, x.name]))
			 console.log(arr);
			let typeNameArr = arr.map(x => x.name);
			console.log(typeNameArr);
			let timeArr = [];
			const reducs = (new Date(lastTime).getTime() - new Date(beginTime).getTime()) / 86400 / 1000;
			if (timeType === 1) {
				//周
				let dateTime = '';
				for (let i = 6; i >= 0; i--) {
					dateTime = new Date(nowday.getTime() - i * 24 * 3600 * 1000);
					timeArr.push(moment(dateTime).format('YYYY-MM-DD'));
				}
			} else if (timeType === 2) {
				//月
				let monthTime = nowday.getFullYear() + "-" + (nowday.getMonth()+1);
				timeArr.push(moment(monthTime).format('YYYY-MM'));
			} else if (timeType === 3) {
				let seaconTime = ''
				for (let i = -1; i <= 1; i++) {
					seaconTime = nowday.getFullYear() + "-" + (nowday.getMonth() + i);
					timeArr.push(moment(seaconTime).format('YYYY-MM'));

				}
			} else {
				
				for (let i = reducs; i >= 0; i--) {
					(function () {
						timeArr.push(`${new Date(lastTime).getFullYear()}-${(new Date(lastTime).getMonth() + 1).toString().length === 1 ? '0' + (new Date(lastTime).getMonth() + 1) : (new Date(lastTime).getMonth() + 1)}-${((new Date(lastTime).getDate() - i).toString().length === 1 ? '0' + (new Date(lastTime).getDate() - i) : (new Date(lastTime).getDate() - i))}`)
					})(i)
				}
			}
             console.log(timeArr);
			//具体数据
			//const valueArr = arr.map(x => x.value);

			//const valueArr = datearr(info, typeNameArr, timeArr);
			let valueArr = datearr(info, res.result, timeArr);
			console.log(valueArr);
			// let num = 7;
			// if (timeType === 2) {
			// 	num = 1;
			// } else if (timeType === 3) {
			// 	num = 3;
			// }else if(timeType === 5){
			// 	num = reducs+1;
			// }
            // console.log(num)
			// let data = [], num1 = 0;
			// for (let i = 0; i < typeNameArr.length; i++) {
			// 	for (let j = num1 * num; j < valueArr.length; j++) {
			// 		data.push([i, (j - num1 * num), valueArr[j]]);
			// 		if ((j + 1) % num === 0) {
			// 			num1++; break;
			// 		}
			// 	}
			// }
			//value
            // console.log(data);
			//  let dataValue=[];
			// // valueArr
			// if(valueArr.length>0){
            //   for(let i=0;i<valueArr.length;i++){
            //     let x=valueArr.map(x=>x.vData);
            //     dataValue=x;     
			//  }
			// }

        let sData=[];
	    this.setState({valueArr});
    	if(valueArr.length>0){
              for(let i=0;i<valueArr.length;i++){
                // let x=valueArr.map(x=>x.vData);
                // dataValue=x;  
				   sData.push ({ name:valueArr[i].name, type:'line', areaStyle: {normal: {}},data:valueArr[i].vData})
			 }
		}
           
	  console.log(typeNameArr);
	  //console.log(dataValue);
	  let myChartOne = echarts.init(document.getElementById('DeviceTypeMountEcharts01'));
	  myChartOne.setOption({
		    title: {
                 text: '单位报警趋势' ,x:'left' 
            },
            tooltip : {
              trigger: 'axis',
              axisPointer: {
                 type: 'cross',
                 label: {
                    backgroundColor: '#6a7985'
                 }
              }
            },
            legend: {
               // data:['邮件营销','联盟广告','视频广告','直接访问','搜索引擎']
	           data:typeNameArr//["火警", "误报", "测试"]//
            },
            // toolbox: {
            //     feature: {
           //         saveAsImage: {}
           //     }
           // },
           grid: {
             left: '2%',
             right: '2%',
             bottom: '3%',
             containLabel: true
          },
          xAxis : [
             {
               type : 'category',
               boundaryGap : false,
               data : timeArr
            }
         ],
         yAxis : [
           {
              type : 'value'
           }
         ],
         series :sData
	     });
	
	  })

		/*图表二*/
 console.log(beginTime+`---`+lastTime);
		window.rpc.alias.getValueByName('device.alarm.type').then(result => {
			//{ createTime: [new Date(beginTime), new Date(lastTime)] }
			return window.rpc.device.alarm.getCountFieldByContainer({ createTime: [new Date(beginTime), new Date(lastTime)] }, 'type').then(data => { return { result, data } })
		}).then(res => {
			console.log(res);
			const info = res.data;
			let arr = [];
			for (var i in res.result) {
				arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
			}
			this.props.deviceState.patrolData = arr
			this.setState({
				data: arr
			});
			console.log(arr);
			console.log(res);
			const deviceAlarm = arr.map(x => ([x.createTime, x.value, x.name]))
			const pieAlarm = arr.map(x => ({ value: x.value, name: x.name }))
			const pAlarm =this.state.valueArr;
		// 	console.log(pAlarm);
		// 	grtTotal(pAlarm);
		//    function grtTotal(data){
		// 	   console.log(data);
        //       if(data.length>0){
        //         for(let i=0;i<data.length;i++){
		// 			let totalValue=0;
		// 			for(let j=0;j<data[i].vData.length;i++){
        //                    totalValue+=data[i].vData[j];
		// 			}
		// 			//valueArr[i].vData
		// 			console.log(totalValue);
		// 		   // sData.push ({ name:valueArr[i].name,value:totalValue})
		// 	     }
		//      }
		//    }
			let myChartTwo = echarts.init(document.getElementById('DeviceTypeMountEcharts02'));

			myChartTwo.setOption({
				title: {
					top: 10,
					left: 10,
					text: '报警占比',
					x: 'left',
					textStyle: {
						font: '14px 微软雅黑 Light',
						color: "#666666"
					}
				},
				legend: {
					orient: 'vertical',
					// x: 'left',
					// y: 'middle',
					x: 'right',
					y: 'top',
					data: arr.map(x => x.name)
				},
				tooltip: {
					trigger: 'item',
					formatter: "{a} <br/>{b} : {c} ({d}%)"
				},
				calculable: true,
				series: [
					{
						type: 'pie',
						radius: [20, 160],
						center: ['45%', '50%'],
						roseType: 'radius',
						label: {
							normal: {
								show: true
							},
							emphasis: {
								show: true
							}
						},
						lableLine: {
							normal: {
								show: false
							},
							emphasis: {
								show: true
							}
						},
						data: pieAlarm
					}
				],
				color: ['#d53b34', '#10eedc', '#a1d91b', '#fec100']
			});

		})
	},
	handleSearch(e) {
		e.preventDefault();
		try {
			this.props.form.validateFields((err, fieldsValue) => {
				const targetTime = fieldsValue['targetTime'];
				beginTime = targetTime[0].format('YYYY-MM-DD');
				lastTime = targetTime[1].format('YYYY-MM-DD');
				this.changeTimeData(5);
			});

		} catch (e) {
			console.warn(e);
		}
	},
	onChangeTop(e) {
		// console.log(e.target.value);
		// this.props.deviceState.addPatrolUp();
		// this.setState({ size: e.target.value });
		switch (e.target.value) {
			case 'week':
				let date = new Date(nowday.getTime() - 7 * 24 * 3600 * 1000);
				let month = date.getMonth() + 1;
				let weekday = date.getFullYear() + '-' + month + '-' + date.getDate();
				beginTime = moment(weekday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(1);
				break;
			case 'month': {
				let monthday = nowday.getFullYear() + '-' + nowday.getMonth() + '-' + nowday.getDate();
				beginTime = moment(monthday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				//this.setState({ beiginTime: monthday, lastTime: moment(nowday).format('YYYY-MM-DD') });
				this.changeTimeData(2);
				break;
			}
			case 'seacon': {
				let seaconday = nowday.getFullYear() + '-' + (nowday.getMonth() - 2) + '-' + nowday.getDate();
				beginTime = moment(seaconday).format('YYYY-MM-DD');
				lastTime = moment(nowday).format('YYYY-MM-DD');
				this.changeTimeData(3);
				break;
			}
			default: {

			}
		}
	},
	render() {
		const { getFieldDecorator } = this.props.form;

		return (
			<Form inline style={{ margin: '20px 0' }}>
				<Row>
					<Col style={{ float: "left", marginRight: 20 }} key={1}>
						<FormItem>
							{getFieldDecorator('chooseTime', {
								initialValue: 'week'
							})(
								<Radio.Group onChange={this.onChangeTop}>
									<Radio.Button value="week">周</Radio.Button>
									<Radio.Button value="month">月</Radio.Button>
									<Radio.Button value="seacon">季</Radio.Button>
								</Radio.Group>
								)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={2}>
						<FormItem label={`时间`}>
							{getFieldDecorator(`targetTime`)(
								<RangePicker
									showTime
									format="YYYY-MM-DD"
									placeholder={['开始日期', '结束日期']}
									style={{ width: 200 }} />
							)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={3}>
						<FormItem>
							<Button
								type="primary"
								onClick={this.handleSearch}
							>
								搜索
                           </Button>
						</FormItem>
					</Col>
				</Row>
			</Form>
		);
	}
}));



@observer
class DeviceTrendC extends Component {
	constructor() {
		super();

		this.state = {
			size: 'default'
		};
	}

	componentDidMount() {

	}


	render() {
		return (
			<div className="DeviceTrend" style={{ height: '85vh' }}>
				<TrendSearchFormUp deviceState={this.props.deviceState} />
					<Row  style={{ padding: '3px',marginTop:12}} >
						<Col span={14} style={{ padding: '0 12px 0 0' }} >
						<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
							<div id="DeviceTypeMountEcharts01" style={{ height: '60vh', width: '100%' }}></div>
						</Card>
					</Col>
					<Col span={10}>
						<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
							<div id="DeviceTypeMountEcharts02" style={{ height: '60vh', width: '100%' }}></div>
						</Card>
					</Col>
				</Row>
				
			</div >
		);
	}
}

class OrgTrend extends Component {
	render() {
		return (
			<div><DeviceTrendC deviceState={new deviceState()} /></div>
		)
	}
}

export default OrgTrend;