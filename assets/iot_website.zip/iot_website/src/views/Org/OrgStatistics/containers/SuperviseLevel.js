import React, { Component } from 'react';
import { Row, Col, Card, Table } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import echarts from 'echarts';

class buildingMountState {
  constructor(){
    extendObservable(this,{
      tableData:[]
    })
  }
}

const columns = [{
	title: '监管等级',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '数量',
	dataIndex: 'value',
	key: 'value',
}];

// 取出类型和locations
let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
//let locations = JSON.parse(sessionStorage.getItem('locations'));

@observer
class SuperviseLevelC extends Component {
// const DeviceTypeMountC=observer(class DeviceTypeMountC extends React.Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			parentType:[],
			data:[],
			states:[]
		};
	}
    
	onChangeDate(date, dateString) {
		console.log(date, dateString);
	}

	handleSizeChange = (e) => {
		this.setState({ size: e.target.value });
	}

	componentWillMount() {
	
		window.rpc.alias.getValueByName('fire.watchLevel').then(result=>{
			return window.rpc.fire.getCountFieldByContainer({},'watchLevel').then(data=>({result,data}))
		}).then((res) => {
			//console.log(res);
			console.log(res.result);
			console.log(res.data);
			// let tableDate =res.result.map(x=>{
			// 	res.data.map(y=>{
			// 		if()
			// 	})
			let arr=[];
		   for(let key in res.result){
            
            let value=`${res.result[key]}`;
           
            arr.push(value);
          
         }
		 console.log(arr);
		let  arr1=[];
		//let data=res.data;
		
		 for(let info in res.data){
            
            let values=`${res.data[info]}`;
			
          // values['']
		  values=parseInt(values,10)
            arr1.push(values);
		//	console.log(values);
          
         }
		 this.setState({
			 states:arr1
		 })
		 console.log(arr1);
		 let data=[];
		   for (let i=0;i<arr.length;i++) {
               let name=arr[i];
			   let value=arr1[i];
			   let obj={name:name,value:value||0,key:i}
               console.log(obj);
			   data.push(obj);
                 
      
             }
             console.log(data);
			// })
			// let tableDate=[];
			// let len = res.result.length;
			// console.log(arr);
			// console.log(tableDate)
			this.setState({
				data
			})
			console.log(this.state.data);
			//this.props.typeMountState.tableDate = data;
			//console.log(this.props.typeMountState.tableDate)
			let myChart = echarts.init(document.getElementById('OrgSuperviseMountEcharts'));
			// myChart.setOption({
			// 	title: { text: '监管等级占比' ,x:'center' },
			// 	//tooltip: {},
			// 	color: ['#74cb62', '#32b3f2', '#8387c3'],
			// 	legend: {
			// 		orient: 'vertical',
			// 		x: 'left',
			      
			// 		data:this.state.data.map(x=>x.name)
			// 		//data:['合格','不合格']
			// 		//data: ['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
			// 	},
			// 	series: [{
			// 		name: '单位状态占比',
			// 		type: 'pie',
			// 		//radius: '50%',
			// 		radius: ['0', '50%'],
			// 		center: ['50%', '50%'],
			// 		color:['#00d8bf', '#db0014','#ffb400'],
			// 		data:[...this.state.data],// [...this.props.typeMountState.tableDate],
			// 		// data:[
			// 		// 	{value:1,name:"合格"},
			// 		// 	{value:0,name:"不合格"}
			// 		// ],
			// 		itemStyle: {
			// 			emphasis: {
			// 				shadowBlur: 10,
			// 				shadowOffsetX: 0,
			// 				shadowColor: 'rgba(0, 0, 0, 0.5)'
			// 			},
			// 			normal: {
			// 				label: {
			// 					show: true,
			// 					formatter: '{b} \n\n {c}个 \n\n({d}%)'
			// 				}
			// 			},
			// 			labelLine: { 
			// 				show: true,
			// 				 smooth:true,
			// 				normal:{
            //                      show: true,
			// 					 length:20,
			// 					 smooth:true
			// 				}
			// 			 },
			// 		},
			// 	}]
			// });

	const text = this.state.data.map(x => ({ text: x.name }));
    const textName = this.state.data.map(x => x.name);
     const textValue =this.state.data.map(x => x.value);
	 console.log(text);
         	myChart.setOption({
				title: {
					top: 10,
					left: 10,
					text: '监管等级',
					x: 'left',
					textStyle: {
						font: '14px 微软雅黑 Light',
						color: "#666666"
					}
				},
				tooltip: {
					trigger: 'axis'
				},
				radar: [
					{
						indicator: text,
						center: ['35%', '65%'],
						radius: 140
					},

				],
				name: {
					show: true,
					formatter: textName,
					textStyle: {
						font: '0.75em 苹方中等',
						color: "#373d41"
					}
				},
				series: [
					{
						type: 'radar',
						tooltip: {
							trigger: 'item'
						},
						itemStyle: { normal: { areaStyle: { type: 'default' } } },
						data: [
							{
								value: textValue,
								name: '维护占比'
							}
						]
					},

				],
				color: ['rgba(255,0,0,0.5)', '#fff', '#d4d4d4']
			})
		},(err) =>{
        console.warn(err);
      });
		console.log( this.props.buildingMountState.tableDate);
	}

	render() {
		console.log(this.state.data)
		//console.log([...this.props.typeMountState.tableData])
			return ( 
				<div className="DeviceTypeMount">
					<Row  style={{ padding: '3px',marginTop:12}} >
						<Col span={8} style={{ padding: '0 12px 0 0' }} >
							<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
								<Table dataSource={this.state.data} bordered columns={columns} pagination={false} style={{ height: '60vh', }} />
							</Card>
						</Col>
						<Col span={16}>
							<Card bordered={false} style={{boxShadow:'0 0  3px  #ccc'}}>
								<div id="OrgSuperviseMountEcharts" style={{ height: '60vh', width: '100%' }}></div>
							</Card>
						</Col> 
					</Row>
				</div>
			);
	}
}


class SuperviseLevel extends Component {
	render() {
		return(
			<SuperviseLevelC buildingMountState={new buildingMountState()}/>
		)
	}
}

export default SuperviseLevel;