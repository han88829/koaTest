import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Radio, Card, Table, Form, message } from 'antd';
import moment from 'moment';
import echarts from 'echarts';
//import './deivceWarnning.css'
const FormItem = Form.Item;

const { RangePicker } = DatePicker;

const columns = [{
	title: '报警类型',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '报警数量',
	dataIndex: 'value',
	key: 'value',
}];
const color = ['red', 'green', 'yellow'];
class deviceState {
	constructor() {
		extendObservable(this, {
			patrolData: [],

			addPatrol: action(function (e) {
				let before;
				console.log(e)
				switch (e) {
					case "week":
						before = new Date().getFullYear() + '-' + (parseInt(new Date().getMonth()) + 1) + '-' + (parseInt(new Date().getDate()) - 7);
						break;
					case "month":
						before = new Date().getFullYear() + '-' + (parseInt(new Date().getMonth()));
						break;
					case "seacon":
						before = new Date().getFullYear() + '-' + (parseInt(new Date().getMonth()) - 2);
						break;
					default:
						break;
				}
				let now = moment(new Date()).format('YYYY-MM-DD');

				console.log(before)
				window.rpc.alias.getValueByName('device.alarm.type').then(result => {
					return window.rpc.device.alarm.getCountFieldByContainer({ createTime: [new Date(before), new Date(now)] }, 'type').then(data => { return { result, data } })
				}).then(res => {
					console.log(res)
					const info = res.data;
					let arr = [];
					for (var i in res.result) {
						arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
					}
					this.patrolData = arr;
					var dataAxis = arr.map(x => x.name);
					var data = arr.map(x => x.value);
					console.log(dataAxis)
					console.log(data)
					const deviceAlarm = arr.map(x => ([x.createTime, x.value, x.name]))
					var dataShadow = [];
					let myChart = echarts.init(document.getElementById('DeviceWarningEcharts'));

					myChart.setOption({
						tooltip: {
							trigger: 'axis',
							axisPointer: {
								type: 'none'
							},
							formatter: function (params) {
								return params[0].name + ': ' + params[0].value;
							}
						},
						xAxis: {
							data: arr.map(x => x.name),
							axisTick: { show: false },
							axisLine: { show: false },
							axisLabel: {
								textStyle: {
									color: '#e54035'
								}
							}
						},
						yAxis: {
							splitLine: { show: false },
							axisTick: { show: false },
							axisLine: { show: false },
							axisLabel: { show: false }
						},
						series: [{
							name: 'hill',
							type: 'pictorialBar',
							barCategoryGap: '-130%',
							//symbol: 'path://M0,10 L10,10 L5,0 L0,10 z',
							symbol: 'path://M0,10 L10,10 C5.5,10 5.5,5 5,0 C4.5,5 4.5,10 0,10 z',
							itemStyle: {
								normal: {
									opacity: 0.5,
									color: function (value) {
										console.log(value.dataIndex)
										console.log(parseInt(value.dataIndex) - 1)
										console.log(color[parseInt(value.dataIndex) - 1])
										return (value.color = color[parseInt(value.dataIndex)])
									}
								},
								emphasis: {
									opacity: 1
								}
							},
							data: arr.map(x => x.value),
							z: 10
						}]

					});
				})
			}),
			search: action(function (obj) {
				window.rpc.alias.getValueByName('device.alarm.type').then(result => {
					console.log(obj);
					return window.rpc.device.alarm.getCountFieldByContainer(obj, 'type').then(data => { return { result, data } })
				}).then(res => {
					console.log(res)
					const info = res.data;
					let arr = [];
					for (var i in res.result) {
						arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
					}
					this.patrolData = arr;
					var dataAxis = arr.map(x => x.name);
					var data = arr.map(x => x.value);
					console.log(dataAxis)
					console.log(data)
					const deviceAlarm = arr.map(x => ([x.createTime, x.value, x.name]))
					var dataShadow = [];
					let myChart = echarts.init(document.getElementById('DeviceWarningEcharts'));

					myChart.setOption({
						tooltip: {
							trigger: 'axis',
							axisPointer: {
								type: 'none'
							},
							formatter: function (params) {
								return params[0].name + ': ' + params[0].value;
							}
						},
						xAxis: {
							data: arr.map(x => x.name),
							axisTick: { show: false },
							axisLine: { show: false },
							axisLabel: {
								textStyle: {
									color: '#e54035'
								}
							}
						},
						yAxis: {
							splitLine: { show: false },
							axisTick: { show: false },
							axisLine: { show: false },
							axisLabel: { show: false }
						},
						series: [{
							name: 'hill',
							type: 'pictorialBar',
							barCategoryGap: '-130%',
							//symbol: 'path://M0,10 L10,10 L5,0 L0,10 z',
							symbol: 'path://M0,10 L10,10 C5.5,10 5.5,5 5,0 C4.5,5 4.5,10 0,10 z',
							itemStyle: {
								normal: {
									opacity: 0.5,
									color: function (value) {
										console.log(value.dataIndex)
										console.log(parseInt(value.dataIndex) - 1)
										console.log(color[parseInt(value.dataIndex) - 1])
										return (value.color = color[parseInt(value.dataIndex)])
									}
								},
								emphasis: {
									opacity: 1
								}
							},
							data: arr.map(x => x.value),
							z: 10
						}]
					});
				})
			})
		})
	}
}



const WarningSearchForm = Form.create()(React.createClass({
	getInitialState() {
		return {
			size: "week"
		}
	},
	handleSearch(e) {
		e.preventDefault();
		try {
			this.props.form.validateFields((err, fieldsValue) => {
				const rangeValue = fieldsValue['field-5'];
				const values = {
					...fieldsValue,
					'field-5': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
				}
				const json = { createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))],ownerId:1}
				console.log('Received values of form: ', values);
				//json={...json,ownerId:1};
				this.props.deviceState.search(json);
			});
			message.info('已更新');
		} catch (e) {
			console.log(e)
		}		
	},
	onChange(e) {
		console.log(e.target.value)
		this.props.deviceState.addPatrol(e.target.value);
		this.setState({ size: e.target.value });
	},
	componentDidMount() {

	},
	render() {
		const { getFieldDecorator } = this.props.form;

		return (
			<Form inline style={{ margin: 10 }} className="deivceWarnning">
				<Row>
					<Col style={{ float: 'left', marginRight: 20 }} key={1}>
						<Radio.Group onChange={this.onChange} type="card" value={this.state.size}>
							<Radio.Button value="week">周</Radio.Button>
							<Radio.Button value="month">月</Radio.Button>
							<Radio.Button value="seacon">季</Radio.Button>
						</Radio.Group>

					</Col>
					<Col style={{ float: 'left' }} key={2}>
						<FormItem label={`时间`}>
							{getFieldDecorator(`field-5`)(
								<RangePicker style={{ width: 200 }} />
							)}
						</FormItem>
					</Col>
					<Col span={1} key={3} style={{ float: 'left' }}>
						<FormItem>
							<Button
								type="primary"
								onClick={this.handleSearch}
							>
								搜索
              				</Button>
						</FormItem>
					</Col>
				</Row>
			</Form>
		);
	}
}));

@observer
class DeviceWarningC extends Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			data: []
		};
	}
	componentWillMount() {

	}
	componentDidMount() {
		let flag = 1;
		let now = moment(new Date()).format('YYYY-MM-DD');
		let before = new Date().getFullYear() + '-' + (parseInt(new Date().getMonth()) + 1) + '-' + (parseInt(new Date().getDate()) - 7);
		console.log(before)
		window.rpc.alias.getValueByName('device.alarm.type').then(result => {
			return window.rpc.device.alarm.getCountFieldByContainer({ createTime: [new Date(before), new Date(now)] }, 'type').then(data => { return { result, data } })
		}).then(res => {
			console.log(res)
			const info = res.data;
			let arr = [];
			for (var i in res.result) {
				arr.push({ name: res.result[i], value: info[i] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') })
			}
			console.log(arr)
			this.props.deviceState.patrolData = arr
			this.setState({
				data: arr
			})
			console.log(arr.map(x => x.name))
			const deviceAlarm = arr.map(x => ([x.createTime, x.value, x.name]))
			let myChart = echarts.init(document.getElementById('DeviceWarningEcharts'));
			myChart.setOption({
				tooltip: {
					trigger: 'axis',
					axisPointer: {
						type: 'none'
					},
					formatter: function (params) {
						return params[0].name + ': ' + params[0].value;
					}
				},
				xAxis: {
					data: arr.map(x => x.name),
					axisTick: { show: false },
					axisLine: { show: true },
					axisLabel: {
						textStyle: {
							color:'0099cc' //'#e54035'
						}
					}
				},
				yAxis: {
					splitLine: { show: false },
					axisTick: { show: false },
					axisLine: { show: false },
					axisLabel: { show: false }
				},
				series: [{
					name: 'hill',
					type: 'pictorialBar',
					barCategoryGap: '-130%',
					//symbol: 'path://M0,10 L10,10 L5,0 L0,10 z',
					symbol: 'path://M0,10 L10,10 C5.5,10 5.5,5 5,0 C4.5,5 4.5,10 0,10 z',
					itemStyle: {
						normal: {
							opacity: 0.5,
							color: function (value) {
								console.log(value.dataIndex)
								console.log(parseInt(value.dataIndex) - 1)
								console.log(color[parseInt(value.dataIndex) - 1])
								return (value.color = color[parseInt(value.dataIndex)])
							}
						},
						emphasis: {
							opacity: 1
						}
					},
					data: arr.map(x => x.value),
					z: 10
				}]
			});
		})

	}

	render() {
		return (
			<div className="DeviceWarning" style={{ padding: '5px' }}>
				<WarningSearchForm deviceState={this.props.deviceState} />
				<Row  style={{ padding: '3px',marginTop:12}} >
				  <Col span={16} style={{ padding: '0 12px 0 0' }} >
					<p style={{marginTop:16,marginBottom:10,fontSize:16,fontWeight:'bold',fontFamily:"PingFang-SC-Medium"}}>报警统计占比</p>
					<div id="DeviceWarningEcharts" style={{ height: '70vh', width: '100%' }}></div>
				  </Col>
				  <Col span={8} style={{ padding: '5px 0' }} gutter={16}>
					<p style={{marginTop:16,marginBottom:10,height:60,fontSize:16,fontWeight:'bold',fontFamily:"PingFang-SC-Medium"}}>报警统计占比</p>
					<Table bordered dataSource={[...this.props.deviceState.patrolData]} columns={columns} pagination={false} style={{ height: '70vh' }} />
				  </Col>
				</Row>
			</div>
		);
	}
}


class orgWarning extends Component {
	render() {
		return (
			<DeviceWarningC deviceState={new deviceState()} />
		)
	}
}

export default orgWarning;