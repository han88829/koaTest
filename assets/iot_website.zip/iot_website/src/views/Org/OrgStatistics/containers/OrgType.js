import React, { Component } from 'react';
import { Row, Col, Card, Table } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import echarts from 'echarts';

class typeMountState {
	constructor() {
		extendObservable(this, {
			tableData: []
		})
	}
}

const columns = [{
	title: '单位类型',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '单位数量',
	dataIndex: 'value',
	key: 'value',
}];

@observer
class OrgTypeC extends Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			parentType: [],
			data: []
		};
	}

	onChangeDate(date, dateString) {
	}

	handleSizeChange = (e) => {
		this.setState({ size: e.target.value });
	}

	componentWillMount() {
		function pushChildren(data) {
			let arr = [...data];
			let layer = arr.map(x => x.layer).sort((a, b) => b - a)[0];
			let layerNow = arr.filter(x => x.layer === layer);
			let layerUp = arr.filter(x => x.layer !== layer);
			let parentDataA = layerUp.map(x => ({ ...x, key: x.id, value: x.value, name: x.name }));

			for (let i = 0; i < layerUp.length; i++) {
				for (let j = 0; j < layerNow.length; j++) {
					if (layerNow[j].parentId === layerUp[i].id) {
						if (layerUp[i].children) {
							layerUp[i].children.push({ ...layerNow[j], key: `${layerNow[j].id}-${layer}` });
						} else {
							layerUp[i].children = [{ ...layerNow[j], key: `${layerNow[j].id}-${layer}` }];
						}
					}
				}
			}
			if (layer === 2) {
				return layerUp;
			} else {
				pushChildren(layerUp);
			}
		}

		window.rpc.owner.types.getArray(0, 0).then(result => {
			return window.rpc.owner.getCountFieldByContainer({}, 'type').then(data => ({ result, data }))
		}).then((res) => {
			let tableDate = res.result.filter(x => x).map(x => ({ ...x, key: x.id, value: res.data[x.id] || 0 })).filter(x => x.id);
			this.setState({
				data: tableDate
			})
			this.props.typeMountState.tableDate = tableDate;
			let myChart = echarts.init(document.getElementById('DeviceTypeMountEcharts'));
			myChart.setOption({
				title: {
					text: '单位类型占比',
					x: 'center'
				},
				color: ['#3398DB'],
				tooltip: {
					trigger: 'axis',
					axisPointer: {            // 坐标轴指示器，坐标轴触发有效
						type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
					}
				},
				grid: {
					left: '3%',
					right: '4%',
					bottom: '3%',
					containLabel: true
				},
				xAxis: [
					{
						type: 'value'
					}

				],
				yAxis: [
					{
						type: 'category',
						data: this.state.data.filter(x => x.layer === 1).map(x => x.name),
						axisTick: {
							alignWithLabel: true
						}
					}
				],
				series: [
					{
						name: '直接访问',
						type: 'bar',
						barWidth: '60%',
						data: this.state.data.filter(x => x.layer === 1).map(x => x.value),
					}
				]
			});
		}, (err) => {
			console.warn(err);
		});
	}

	render() {
		return (
			<div className="DeviceTypeMount">
				<Row style={{ padding: '3px', marginTop: 12 }} >
					<Col span={8} style={{ padding: '0 12px 0 0' }} >
						<Card bordered={false} style={{ boxShadow: '0 0  3px  #ccc' }}>
							<Table dataSource={this.state.data.filter(x => x.layer === 1)} bordered style={{ height: '70vh' }} columns={columns} pagination={false} />
						</Card>
					</Col>
					<Col span={16}>
						<Card bordered={false} style={{ boxShadow: '0 0  3px  #ccc' }}>
							<div id="DeviceTypeMountEcharts" style={{ height: '70vh', width: '100%' }}></div>
						</Card>
					</Col>
				</Row>
			</div>
		);
	}
}




class OrgType extends Component {
	render() {
		return (
			<OrgTypeC typeMountState={new typeMountState()} />
		)
	}
}

export default OrgType;