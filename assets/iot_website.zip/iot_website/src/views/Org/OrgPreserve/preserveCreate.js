/*
 * @Author: szj
 * @Date: 2017-03-24 19:58:48 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-11 11:22:56
 */

import React, { Component } from 'react';
import { Button,Steps,Card,Form,Input,Row,Select,Col,DatePicker} from 'antd';
import { Link,browserHistory} from 'react-router';
import moment from 'moment';
import './Steps.css';

const FormItem = Form.Item;
const Option = Select.Option;
const Step = Steps.Step;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';

let config = {};
let objb =[];
class PreverseCreateFormC extends React.Component {
    state={
      Id:null,
      PreserveType:[],
      reportType:[]
    }
    componentWillMount(){
      //rpc.cache.alias.getValueByName('task.type',console.log)
       window.rpc.cache.alias.getValueByName('task.type').then((res) => {
         let arr=['/'];
         for(let key in res){
            //let keys=`${key}`;
            let values=`${res[key]}`
            //values={keys:values};
            arr.push(values);
           // console.log(res[i]);
         }
         console.log(arr);
      // let  PreserveType=res.map((x)=>({...x}));
      let  PreserveType=arr;
       // console.log( OrgsType);
       this.setState({
         PreserveType
       }) 
     },(err) =>{
        console.warn(err);
     });
      window.rpc.report.template.getArrayIdNameByContainer({},0,0).then((res) => {
        console.log(res);
        let  reportType =res.map(x=>({...x}));
        console.log(reportType);
        this.setState({
          reportType
        }) 
     },(err) =>{
        console.warn(err);
     });

    }
    componentDidMount(){
     //const id=this.props.params.id;
     //console.log(id);
      var str = window.location.href;
      var index = str.lastIndexOf(`\/`);
      let Id = Number(str.substring(index + 1, str.length));
      //console.log(Id);
      this.setState({Id});
     
    //  let objb = JSON.parse(sessionStorage.getItem('rulesObj')) || [];
    //    config = {
    //     initialValue: objb.cycle || '',
    //     rules: rules,
    //    }
    let createObj =JSON.parse(sessionStorage.getItem('OrgPreserve')) || [];
    if(createObj.name){
      console.log(createObj.beginTime);
      //Id=Id+2;
      if(createObj.type){
         let id=createObj.type;
         this.setState({Id:id});
      }
     
      let date=[];
      date.push(moment(createObj.beginTime, dateFormat));
      date.push(moment(createObj.endTime, dateFormat));
      console.log('-----'+date);
       this.props.form.setFieldsValue({
         type:`${createObj.type}`||`${Id}`, 
         name:`${createObj.name}`,
         report:`${createObj.report}`,
         date: date
       }); 
    }else{
       this.props.form.setFieldsValue({
         type:`${Id}`, 
       }); 
    }
    //  config = {
    //     initialValue:'',
    //     //rules: rules,
    //   }

      // about cookie ,只可以存文本
  //   let sName='EquipPreserve';
  //   let a=getCookie(sName);
  //   console.log(a);
  //   let vName='ePreserveValue';
  //   let b=getCookie(vName);
  //     console.log(b);
  //    //function GetCookieObj(sName){

  // function getCookie(name) 
  // { 
  //   var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
 
  //   if(arr=document.cookie.match(reg))
 
  //       return unescape(arr[2]); 
  //   else 
  //       return null; 
  //  } 

   
  }
   handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {

      if (!err) {
        //console.log('Received values of form: ', values);
        //new Date(TaskDate[0].format('YYYY-MM-DD HH:mm:ss'))
        // let values = {...values, name:values.name, type: parseInt(values.type, 10), beginTime: new Date(values.date[0].format('YYYY-MM-DD HH:mm:ss')), endTime: new Date(values.date[1].format('YYYY-MM-DD HH:mm:ss')), report: parseInt(values.report, 10) };
         const value = {name:values.name, type: parseInt(values.type, 10),reportId: parseInt(values.report, 10),beginTime:new Date(values.date[0].format('YYYY-MM-DD')),endTime:new Date(values.date[1].format('YYYY-MM-DD'))};
        //console.log(values);
      if(value){
        //sessionStorage.setItem('ePreserveValue',JSON.stringify(values));
        //setCookie('ePreserveValue',values);//EquipPreserve
        // function setCookie( name, value){
        //    var cookie = name + "=" + encodeURIComponent( value );
        //    document.cookie =cookie;
        // }
         let obj =value;
         let obj1 = JSON.parse(sessionStorage.getItem('OrgPreserve'));
         //console.log('-------');
         console.log(obj1);
         //delete obj1.resId;
         let obj2 = eval('(' + (JSON.stringify(obj) + JSON.stringify(obj1)).replace(/}{/, ',') + ')');
         //console.log(obj2)
         sessionStorage.setItem('OrgPreserve', JSON.stringify(obj2));
         browserHistory.push(`/org/preserve/member/${this.state.Id}`);
      }
      }else{
        console.log(err);
      }
    });
  }
   render() {
    const {getFieldDecorator} = this.props.form;

   let  PreserveTypes=this.state.PreserveType;
     console.log(PreserveTypes);
    let preTypeLists=[];
    
    for (let i=1;i<PreserveTypes.length+1;i++) {
      
        //preTypeLists.push(<Option key={`${i}`}>{PreserveTypes[i]}</Option>)
         if(PreserveTypes[i]=="整改"){
           preTypeLists.push(<Option key={`${i}`}>{PreserveTypes[i]}</Option>)
         }else{
           preTypeLists.push(<Option key={`${i}`} disabled >{PreserveTypes[i]}</Option>)
         }
      
    }
     //console.log(preTypeLists);
    let  reportTypes=this.state.reportType;
   // reportTypes.unshift('/');
    console.log(reportTypes);
    let reportTypeLists=[];
    // for (let i=1;i<reportTypes.length+1;i++) {
      
    //     reportTypeLists.push(<Option key={`${i}`}>{reportTypes[i]}</Option>)
      
    // }
     for(let value of reportTypes){
      if(value && value.id){
        reportTypeLists.push(<Option key={`${value.id}`}>{value.name}</Option>);
      }
    }
 
    //   for (let value of reportTypes) {
    //   if (value && value.id) {
    //     reportTypeLists.push(<Option key={`${value.id}`}>{value.name}</Option>)
    //   }
    // }
    // reportTypeLists
    return (
         <div style={{width:400,position:'absolute',left:'50%',marginLeft:'-200px'}}>
           <Form onSubmit={this.handleSubmit} className="Pre-create" style={{ height:400,fontSize:'14px',padding:0,margin:0}}>       
             <Row type="flex" justify="start" style={{marginBottom:18,marginTop:30}}>
              <Col span={3} style={{width:80}}><span type="所属品牌" disabled="false">整改主题：</span></Col>
              <Col span={6}>
                <FormItem>
                  {getFieldDecorator('name', {
                    //initialValue: objb.name || '',
                    rules: [{ required: true, message: '请输入内容!' }],
                  })(
                    <Input  placeholder="请输入内容" style={{width:300}} />
                  )}
                </FormItem>
              </Col>
             </Row>
             <Row type="flex" justify="start"  style={{marginBottom:18}}>
               <Col span={3}  style={{width:80}}><span >起止时间：</span></Col>
               <Col span={6} >
                 <FormItem>
                   {getFieldDecorator('date', {
                     //initialValue: objb.date || '',
                     rules: [{ required: true, message: '请输入时间!' }],
                   })(
                      <RangePicker style={{width:300}} />
                   )}
                 </FormItem>
               </Col>
             </Row>
             <Row type="flex" justify="start"  style={{marginBottom:18}}>
               <Col span={4}  style={{width:80}}><span disabled="false">整改类型：</span></Col>
               <Col span={4}>
                 <FormItem>
                   {getFieldDecorator('type', {
                    // initialValue: objb.type || '',
                     rules: [{ required: true, message: '更换!' }],
                   })(
                      <Select placeholder="请选择"  style={{width:300}}>
                         {preTypeLists}
                       </Select>
                   )}
                 </FormItem>
               </Col>
             </Row>
             <Row type="flex" justify="start"  style={{marginBottom:18}}>
               <Col span={4}  style={{width:80}}><span disabled="false">选择报表：</span></Col>
               <Col span={4}>
                 <div>
                   <FormItem>
                     {getFieldDecorator('report', {
                       //initialValue: objb.report || '',
                       rules: [{ required: true, message: '请输入设备类型!' }],
                     })(
                       <Select placeholder="请选择"  style={{width:300}}>
                        {reportTypeLists}
                       </Select>
                     )}
                   </FormItem>
                  </div>
                 </Col>
                </Row>
                <div style={{position:'absolute',marginTop:60,left:'50%',marginLeft:'-50px',zIndex:'99'}}>
                  <FormItem>
                    <Button htmlType="submit" type="primary" style={{height:30}}>下一步</Button>
                    {/*<Button style={{marginLeft:10}}><Link to={`/equip/preserve`}>返回修改</Link></Button>*/}
                    <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:80,height:32,borderRadius:0 }}><Link to={`/equip/preserve`}>返回修改</Link></span>
                  </FormItem>
               </div>
           </Form>   
         </div>
    );
  }
}
const  PreverseCreateForm = Form.create()( PreverseCreateFormC);
class  EquipPreserveCreate extends Component {
   state = {
     value: this.props.value,
   }
   handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values); 
      }
    });
 
  }
  render() {
  //  const { getFieldDecorator} = this.props.form;
   //const { getFieldDecorator } = this.props.form;
    return (
      <div className="EquipPreserveCreate" style={{ padding:'0 22px' }}>
          <div style={{position:'realitive'}}>
             <Card style={{height:450}} className="PreserveCard">
               <div style={{padding:'0px 0 15px'}}>
                 <p style={{fontSize:'18px',fontFamily:'苹方',fontWeight:'600'}}>整改设置</p> 
               </div>   
               <div >
                 <Steps current={1}>
                   <Step title="选择单位" description="" />
                   <Step title="基础信息" description="" />
                   <Step title="选择人员" description="" />
                   <Step title="完成" description="" />
                 </Steps>
               </div>
               < PreverseCreateForm />
             </Card> 
              
          </div>
    
      </div>
    );
  }
}

export default EquipPreserveCreate;