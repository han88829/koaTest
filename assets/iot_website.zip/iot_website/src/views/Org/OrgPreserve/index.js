/*
 * @Author: szj
 * @Date: 2017-03-24 19:58:48 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-16 09:27:07
 */



import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, Select, message, Popconfirm, TreeSelect } from 'antd';

import '../OrgManage/OrgManage.css';

const { Option } = Select;
const FormItem = Form.Item;
var Num = '';

message.config({
  top: 216,
  duration: 2
})

//获取类型 安全等级 状态 监管等级
let Orgtypes = JSON.parse(sessionStorage.getItem('Orgtypes')) || [];

class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      timer: 0,
      OrgTypes: [],
      dStateList: [],
      values: {},
      Num: '',
      name: null,
      state: [],
      types: [],
      watchLevel: [],
      safetyLevel: []
    })
  }
}

class AdvancedSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      Selected: {
        Id: 0
      },
      OrgsType: [],
      dStateObj: {},
      dStateListTable: [],
      watchLevelList: [],
      safetyLevelList: [],
      types: [],
      data: [],

    }
  }
  componentWillMount() {
    window.rpc.owner.types.getArrayIdNameByContainer(null, 0, 0).then((res) => {
      let OrgsType = res.map((x) => ({ ...x }));
      this.setState({
        OrgsType
      });
    }, (err) => {
      console.warn(err);
    });


    window.rpc.alias.getValueByName('owner.state').then((res) => {
      this.setState({ dStateObj: res })
      let arr = ['/'];
      let arr1 = [];
      for (let key in res) {
        let values = `${res[key]}`
        arr.push(values);
        arr1.push(values);
      }
    }, (err) => {
      console.warn(err);
    });

    window.rpc.alias.getValueByName('fire.safetyLevel').then((res) => {
      let arrFire = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrFire.push(values);
      }
      let safetyLevelList = arrFire;
      this.setState({
        safetyLevelList
      });

    }, (err) => {
      console.warn(err);
    });
    window.rpc.alias.getValueByName('fire.watchLevel').then((res) => {
      let arrWatch = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arrWatch.push(values);
      }
      let watchLevelList = arrWatch;
      this.setState({
        watchLevelList
      });

    }, (err) => {
      console.warn(err);
    });
    function pushChildren(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp)
      }
    }
    window.rpc.owner.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = pushChildren(tableDate)
      this.setState({ types, data: tableDate });
    })

  }

  handleSubmit = (e) => {
    const dStateList = this.state.dStateObj;
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        let obj = { ...fieldsValue };
        const name = obj.Orgname;
        const orgtype = obj.Orgtype;

        const Orgstate = obj.OrgState;
        const Supervision = obj.Supervision;
        const safety = obj.safety;
        let values = {}, fire = {};
        // //如果数据存在就存到values中
        if (name) {
          values = { ...values, name: `  ${name}  ` };
          this.props.appState.name = values.name;
        }
        if (orgtype) {
          values = { ...values, type: orgtype.map(x => parseInt(x, 10)) };
          this.props.appState.types = values.type;
        }
        /**筛选的rpc.owner.getArrayByContainer 中无等级 */
        if (Supervision) {
          fire = { ...fire, watchLevel: Supervision.map(x => parseInt(x, 10)) }
          this.props.appState.watchLevel = values.watchLevel;

        }
        if (safety) {
          fire = { ...fire, safetyLevel: safety.map(x => parseInt(x, 10)) }
          this.props.appState.safetyLevel = values.safetyLevel;
        }
        if (Orgstate) {
          values = { ...values, state: Orgstate.map(x => parseInt(x, 10)) };
          this.props.appState.state = values.state;
        }
        let value = { ...values, fire: fire };

        window.rpc.owner.getId().then(dataId => {
          values = { ...values, fire: fire, deep: 999 };
          this.props.appState.values = values;
          window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then((res) => {
            window.rpc.alias.getValueByName('fire.safetyLevel').then((data) => {
              window.rpc.owner.getArrayBriefByContainer(values, 0, 10).then((result) => {
                result = result.reverse();//.sort()
                let orgs = result.map((x) => ({ ...x, id: x.id, key: x.id, Orgname: x.name, safetyLevel: data[x.safetyLevel], Orgtype: res[x.type] || "其他", safety: null, Orgstate: dStateList[x.state], Orgnum: x.number, Orglocation: x.address, contacts: x.parentId, legalPersonPhone: x.legalPersonPhone, legalPerson: x.legalPerson }));
                Num = orgs.length;
                this.props.appState.Num = Num;
                message.info(`共搜索到${Num}条数据`);
                this.props.appState.tableData = orgs;

              }, (err) => {
                console.warn(err);
              })
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          });

          //console.log(data);
          window.rpc.owner.getArrayBriefByContainer({ values }, 0, 0).then((num) => {
            Num = num.length;
            this.props.appState.Num = Num;
          }, (err) => {
            console.warn(err);
          })
        }, err => {
          console.warn(err);
        })

      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 18 },
    };
    const formnUumItemLayout = {
      labelCol: { span: 10 },
      wrapperCol: { span: 14 },
    };
    const formStateItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 },
    };
    let Orgtypes = this.state.OrgsType || [];
    let OrgtypeChildren = [];
    let OrgstateChildren = [];
    let safetyChildren = [];
    let SupervisionsChildren = [];

    const safety = this.state.safetyLevelList;
    const safetySupervision = this.state.watchLevelList;
    //如果有数据就存储到子数组中
    for (let value of Orgtypes) {
      if (value && value.id) {
        OrgtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>);
      }
    }

    for (let i = 1; i < safety.length + 1; i++) {
      safetyChildren.push(<Option key={`${i}`}>{safety[i]}</Option>)
    }

    for (let i = 1; i < safetySupervision.length + 1; i++) {
      SupervisionsChildren.push(<Option key={`${i}`}>{safetySupervision[i]}</Option>)
    }

    let dStateObj = this.state.dStateObj;
    for (let i in dStateObj) {
      OrgstateChildren.push(<Option key={`${i}`}>{dStateObj[i]}</Option>)
    }

    return (
      <Form inline style={{ margin: '0' }}>
        <Row style={{ margin: '15px 0 15px', height: '32px', lineHight: '32px' }}  >
          <Col span={5} key={1}>
            <FormItem {...formItemLayout} label={`单位名称`}>
              {getFieldDecorator(`Orgname`)(
                <Input style={{ width: '75%', minWidth: 186 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={5} key={2}>
            <FormItem {...formItemLayout} label={`单位类型`}>
              {getFieldDecorator(`Orgtype`)(

                <TreeSelect
                  style={{ height: 30, width: 186 }}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.data.filter(x => x.layer === 1)}
                  placeholder="请选择单位类型"
                  multiple
                />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3} style={{ whiteSpace: 'nowrap', marginRight: '16px' }}>
            <FormItem {...formnUumItemLayout} label={`监管等级`}>
              {getFieldDecorator(`Supervision`)(
                <Select multiple style={{ width: 120 }} size="large" placeholder="请选择">
                  {SupervisionsChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4} style={{ whiteSpace: 'nowrap', marginRight: '16px' }}>
            <FormItem  {...formnUumItemLayout} label={`安全等级`}>
              {getFieldDecorator(`safety`)(
                <Select multiple style={{ width: 120 }} size="large" placeholder="请选择" >
                  {safetyChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={5}>
            <FormItem {...formStateItemLayout} label={`单位状态`}>
              {getFieldDecorator(`OrgState`)(
                <Select multiple style={{ width: 130 }} size="large" placeholder="请选择">
                  {OrgstateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6} className="search-btn" style={{ float: 'right', marginRight: 10, width: 60 }}>
            <FormItem style={{ padding: 0, marginLeft: 10, }}>
              <Button
                type="primary"
                htmlType="submit"
                onClick={this.handleSubmit}
                style={{ height: '32px', width: '60px', padding: 0, margin: 0, fontSize: '0.75rem' }}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

const OrgManageC = observer(class appState extends React.Component {
  //获取数据
  constructor() {
    super();
    this.state = {
      Selected: {
        Id: 0
      },
      OrgsType: {},
      dStateList: {},
      parentId: null,
      PreserveType: []

    }
  }
  componentWillMount() {
    window.rpc.cache.alias.getValueByName('task.type').then((res) => {
      let arr = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arr.push(values);
      }
      let PreserveType = arr;
      // console.log( OrgsType);
      this.setState({
        PreserveType
      })
    }, (err) => {
      console.warn(err);
    });

    window.rpc.alias.getValueByName('owner.state').then((res) => {
      this.setState({
        dStateList: res
      })
    }, (err) => {
      console.warn(err);
    });
    window.rpc.owner.getId().then(data => {
      this.setState({ parentId: data });
    }, err => {
      console.log(err)
    })
  }
  componentDidMount() {
    window.rpc.owner.getId().then((parent) => {
      window.rpc.alias.getValueByName('owner.state').then((dres) => {
        window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then((res) => {
          this.setState({ OrgsType: res });
          window.rpc.alias.getValueByName('fire.safetyLevel').then((data) => {
            window.rpc.owner.getArrayBriefByContainer({ deep: 999 }, 0, 10).then((result) => {
              let orgs = result.map((x) => ({ ...x, id: x.id, key: x.id, Orgname: x.name, safetyLevel: data[x.safetyLevel], Orgstate: dres[x.state], Orgnum: x.number, Orglocation: x.address, contacts: x.parentId, legalPersonPhone: x.legalPersonPhone, legalPerson: x.legalPerson, floorCount: x.floorCount, Orgtype: res[`${x.type}`] || "其他" }));
              this.props.appState.tableData = orgs;
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        });

      }, (err) => {
        console.warn(err);
      });

    }, err => {
      console.log(err)
    })
    window.rpc.owner.getId().then(data => {
      window.rpc.owner.getArrayBriefByContainer({ deep: 999 }, 0, 0).then((num) => {
        Num = num.length;
        this.props.appState.Num = Num;
      }, (err) => {
        console.warn(err);
      })
    }, err => {
      console.warn(err);
    })

  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = selectedRowKeys;
    this.setState({ Selected });
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }
  //维护更改选择变化
  handleChange = (value) => {
    this.setState({ nature: value });
  }
  natureClick = (index, selectId) => {
    this.setState({ nature: index });

    let Selected = [];
    Selected.push(selectId);
    this.setState({ Selected });
    //存入单个数据
    let dObj = { resId: Selected }
    sessionStorage.setItem('OrgPreserve', JSON.stringify(dObj));
    browserHistory.push(`/org/preserve/create/${index}`);

  }
  handelClick = (e) => {
    if (this.state.Selected.length !== 0 && this.state.nature) {
      let EquipSelected = this.state.Selected;
      let dObj = { resId: EquipSelected }
      sessionStorage.setItem('OrgPreserve', JSON.stringify(dObj));

      browserHistory.push(`/org/preserve/create/${this.state.nature}`);
    }

  }
  render() {
    let PreserveTypes = this.state.PreserveType;
    let preTypeLists = [];

    for (let i = 1; i < PreserveTypes.length + 1; i++) {
      if (PreserveTypes[i] == "整改") {
        preTypeLists.push(<Option key={`${i}`}>{PreserveTypes[i]}</Option>)
      }
    }
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      {
        title: '单位名称', dataIndex: 'Orgname', key: 'Orgname', render: (text, record) => (
          <span>
            <Link to={`/org/orgs/info/${record.key}`} style={{ color: '#0099cc' }}>{text}</Link>
          </span>
        )
      },
      { title: '安全等级', dataIndex: 'safetyLevel', key: 'safetyLevel' },
      { title: '建筑数目', dataIndex: 'floorCount', key: 'floorCount' },
      { title: '单位类型', dataIndex: 'Orgtype', key: 'Orgtype' },

      { title: '单位地址', dataIndex: 'Orglocation', key: 'Orglocation' },
      { title: '单位状态', dataIndex: 'Orgstate', key: 'Orgstate' },
      { title: '联系人', dataIndex: 'legalPerson', key: 'legalPerson' },//legalPerson
      { title: '联系电话', dataIndex: 'legalPersonPhone', key: 'legalPersonPhone' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to='' onClick={() => this.natureClick(5, record.key)} style={{ color: '#999' }}>整改</Link>
            <span className="ant-divider" />
            <Link to={`/org/orgs/info/${record.key}`} style={{ color: '#0099cc' }}>查看</Link>
          </span>
        )
      },
    ];

    const data = [...this.props.appState.tableData];
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };
    const pagination = {
      total: this.props.appState.Num,
      showTotal: total => `共 ${this.props.appState.Num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (page, PageSize) => {
        const dStateList = this.state.dStateList;
        let pagenum = (parseInt(page, 10) - 1) * 10;
        let name = this.props.appState.name;
        let type = [...this.props.appState.types];
        let state = [...this.props.appState.state];
        let watchLevel = [...this.props.appState.watchLevel];
        let safetyLevel = [...this.props.appState.safetyLevel];
        let value = {}, fire = {};
        if (name) {
          value = { ...value, name: name }
        }
        if (type.length !== 0) {
          value = { ...value, type: type }
        }
        if (state.length !== 0) {
          value = { ...value, state: state }
        }
        if (watchLevel.length !== 0) {
          fire = { ...fire, watchLevel: watchLevel }
        }
        if (safetyLevel.length !== 0) {
          fire = { ...fire, safetyLevel: safetyLevel }
        }

        let values = { ...this.props.appState.values };
        window.rpc.owner.getId().then((parent) => {
          value = { ...value, fire: fire, deep: 999 };
          window.rpc.alias.getValueByName('owner.state').then((dres) => {
            window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then((res) => {

              this.setState({ OrgsType: res });
              window.rpc.alias.getValueByName('fire.safetyLevel').then((data) => {
                window.rpc.owner.getArrayBriefByContainer(value, pagenum, 10).then((result) => {
                  let orgs = result.map((x) => ({ ...x, id: x.id, key: x.id, Orgname: x.name, safetyLevel: data[x.safetyLevel], Orgstate: dres[x.state], Orgnum: x.number, Orglocation: x.address, contacts: x.parentId, legalPersonPhone: x.legalPersonPhone, legalPerson: x.legalPerson, floorCount: x.floorCount, Orgtype: res[`${x.type}`] || "其他" }));
                  this.props.appState.tableData = orgs;
                }, (err) => {
                  console.warn(err);
                })
              }, (err) => {
                console.warn(err);
              })
            }, (err) => {
              console.warn(err);
            });

          }, (err) => {
            console.warn(err);
          });

        }, err => {
          console.log(err)
        })
      },
    };
    return (
      <div className="OrgManage OrgPreserve" style={{ padding: '0 15px' }}>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75em', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/org/preserve' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>消防整改</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, fontSize: '0.875em' }} ><Link to={``} onClick={this.handelClick} >批量操作</Link></Button>
          </div>
          <div style={{ float: 'left', width: 100, height: 32, marginRight: 4 }} className='select-small'>
            <Select style={{ width: 100, height: 32, fontSize: '0.875em', color: '#373d41' }} placeholder="更多操作" onChange={this.handleChange}>
              {preTypeLists}
            </Select>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />

        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              style={{ textAlign: 'center', color: '#999' }}
              columns={columns}
              dataSource={data}
              rowSelection={rowSelection}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})



class EquipPreserve extends Component {
  render() {
    return (
      <OrgManageC appState={new appState()} params={this.props.params} />
    )
  }
}

export default EquipPreserve;