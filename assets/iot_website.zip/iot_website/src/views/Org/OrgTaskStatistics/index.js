import React, { Component } from 'react';
import { Tabs, Icon } from 'antd';
import TaskInspect from './containers/TaskInspect';
import TaskRandom from './containers/TaskRandom';
import TaskResult from './containers/TaskResult';
import './orgTaskStatistics.css';

const { TabPane } = Tabs;

class OrgTaskStatistics extends Component {
  render() {
    return (
      <div className="EquipTaskStatistics" style={{ padding: 24 }}>
        <Tabs defaultActiveKey="1">
          <TabPane tab={<span><Icon type="info-circle-o" />数量统计</span>} key="1">
            <TaskInspect />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />抽检统计</span>} key="2">
            <TaskRandom />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />结果统计</span>} key="3">
            <TaskResult />
          </TabPane>
        </Tabs>
      </div>
    );
  }
}

export default OrgTaskStatistics;