/*
 * @Author: Han.beibei 
 * @Date: 2017-06-02 11:23:46 
 * @Last Modified by:   Han.beibei 
 * @Last Modified time: 2017-06-02 11:23:46 
 */
import React, { Component } from 'react';

class SMSManage extends Component {
  render() {
    return (
      <div>
        短信管理
      </div>
    );
  }
}

export default SMSManage;