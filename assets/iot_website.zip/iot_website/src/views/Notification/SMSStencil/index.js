/*
 * @Author: Han.beibei 
 * @Date: 2017-06-02 11:23:27 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-14 17:57:40
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Modal, Row, Col, Table, Button, Form, Input, DatePicker, Select, message, TimePicker } from 'antd';
import moment from 'moment';
import listStore from '../listStore';
import './SMSStencil.css';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const SMSState = ["未审核", "审核成功", "审核失败"]
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

//结构出参量表
const { levelList } = listStore;

// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      selectIdOne: [],
      number: 555,
    })
  }
}

/*class AdvancedSearchForm extends React.Component {
  componentDidMount() {
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const createTime = fieldsValue['createTime'];
        const name = fieldsValue['name'];
        const ownerId = fieldsValue['ownerId'];
        const level = fieldsValue['level'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (ownerId) {
          values = { ...values, ownerId: fieldsValue['ownerId'].map(x => parseInt(x, 10)) }
        }
        if (level) {
          values = { ...values, level: fieldsValue['level'].map(x => parseInt(x, 10)) }
        }
        if (createTime) {
          values = { ...values, createTime: [new Date(createTime[0].format('YYYY-MM-DD')), new Date(createTime[1].format('YYYY-MM-DD'))] }
        }
        window.rpc.group.getArrayBriefByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let groups = result.map((x) => ({ ...x, key: x.id, level: levelList[x.level], ownerId: x.ownerId, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          this.props.appState.tableData = groups;

        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    let ownerNames = JSON.parse(sessionStorage.getItem('groupownerNames')) || [];
    let levelChildren = [];
    let ownerNameChildren = [];

    for (let i = 1; i < levelList.length; i++) {
      levelChildren.push(<Option key={`${i}`}>{levelList[i]}</Option>)
    }
    for (let value of ownerNames) {
      if (value && value.id) {
        ownerNameChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 180 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`等级`}>
              {getFieldDecorator(`level`)(
                <Select multiple style={{ width: 180 }} placeholder="请选择">
                  {levelChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`部门`}>
              {getFieldDecorator(`ownerId`)(
                <Select multiple style={{ width: 180 }} placeholder="请选择">
                  {ownerNameChildren}
                </Select>
              )}
            </FormItem>
          </Col>

          <Col span={6} key={4}>
            <FormItem label={`创建时间`}>
              {getFieldDecorator(`createTime`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={5}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
                  </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);*/

const GroupManageC = observer(Form.create()(React.createClass({
  // state = {
  //   sortedInfo: null,
  //   visibleNew: false,
  //   visible: false,
  // },
  getInitialState() {
    return {
      sortedInfo: null,
      visibleNew: false,
      visible: false,
      tableData: null,
      selectedRowKeys: []
    };
  },
  handleChange(pagination, filters, sorter) {
    this.setState({
      sortedInfo: sorter,
    });
  },
  clearAll() {
    this.setState({
      sortedInfo: null,
    });
  },


  componentDidMount() {
    window.rpc.sms.getArray(0, 0).then((result) => {
      let groups = result.map((x) => ({ ...x, key: x.id, name: x.name, body: x.body, state: SMSState[x.state], createTime: moment(x.registerTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
      this.props.appState.tableData = groups;
      this.setState({ tableData: groups });
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  },
  handleSearch(e) {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  },
  handleStaff() {
    if (this.props.appState.selectIdOne.length !== 0) {
      message.info(`你选择了序号为${this.props.appState.selectIdOne}模板！`);
      setTimeout(() => {
        this.setState({ selectedRowKeys: [] });
        this.props.appState.selectIdOne = [];
      }, 500)
    } else {
      message.info("请选择模板！");
    }
  },

  //模板详情
  showModal() {
    this.setState({
      visible: true,
    });
  },
  handleOk(e) {
    this.setState({
      visible: false,
    });
  },
  handleCancel(e) {
    this.setState({
      visible: false,
    });
  },
  //添加模板
  showModalNew() {
    this.setState({
      visibleNew: true,
    });
  },
  handleOkNew(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let { name, body, remark } = values;
        let obj = { name, body, remark };
        window.rpc.sms.create(obj).then(() => {
          message.info('创建成功！')
          this.setState({
            visibleNew: false,
          });
          this.props.form.resetFields();
          window.rpc.sms.getArray(0, 0).then((result) => {
            let groups = result.map((x) => ({ ...x, key: x.id, name: x.name, body: x.body, state: SMSState[x.state], createTime: moment(x.registerTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
            this.props.appState.tableData = groups;
            this.setState({ tableData: groups });
            values = null;
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      } else {
        console.error(err)
      }

    });
  },
  handleCancelNew(e) {
    e.preventDefault();
    this.props.form.resetFields();
    this.setState({ visibleNew: false });
  },
  render() {
    let { sortedInfo } = this.state;
    const { getFieldDecorator } = this.props.form;
    const { selectedRowKeys } = this.state;
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 12 },
    };
    const config = {
      rules: [{ type: 'object', required: true, message: 'Please select time!' }],
    };
    const rangeConfig = {
      rules: [{ type: 'array', required: true, message: 'Please select time!' }],
    };
    sortedInfo = sortedInfo || {};
    const columns = [
      {
        title: '序号',
        dataIndex: 'id',
        key: 'id',
        sorter: (a, b) => a.id - b.id,
        sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
        render: text => <span>{text}</span>,
      },
      { title: '模板名称', dataIndex: 'name', key: 'name' },
      { title: '模板内容', dataIndex: 'body', key: 'body' },
      { title: '模板状态', dataIndex: 'state', key: 'state' },
      { title: '添加时间', dataIndex: 'createTime', key: 'createTime' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={``} onClick={this.showModal}>详情</Link>
            <span className="ant-divider" />
            <Link to={``} onClick={() => {
              window.rpc.sms.removeById(record.key).then((x) => {
                if (x) {
                  message.info("删除成功！")
                  window.rpc.sms.getArray(0, 0).then((result) => {
                    let groups = result.map((x) => ({ ...x, key: x.id, name: x.name, body: x.body, state: SMSState[x.state], createTime: moment(x.registerTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') }));
                    this.props.appState.tableData = groups;
                  }, (err) => {
                    console.warn(err);
                  })
                } else {
                  message.info("删除失败！")
                }
              },err=>{
                 console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
              })
            }}>删除</Link>
          </span>
        )
      },
    ];
    const data = [...this.props.appState.tableData];
    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };

    //表格单选框设置
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        this.props.appState.selectIdOne = selectedRowKeys;
        this.setState({ selectedRowKeys });
      },
      onSelect: (record, selected, selectedRows) => {
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (

      <div className="ConcenHistory">
        <div style={{ fontSize: '0.75rem', height: 35, paddingBottom: '1.125rem', color: '#333', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/memb/group' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>短信模板</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.showModalNew}>添加模板</Button>
            <Button style={{ float: 'left', background: '#d9dee4', color: '#373e41', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={this.handleStaff}>删除模板</Button>
          </div>
        </div>
        {/*<WrappedAdvancedSearchForm appState={this.props.appState} style={{ width: '80%', textAlign: 'center' }} />*/}
        <Modal
          title="短信模板详情"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          className="SMSDetai"
        >
          <div style={{ width: '100%', height: 30, backgroundColor: '#f9f9f9', paddingLeft: 10, lineHeight: "30px" }}>
            <span style={{ color: 'red', fontSize: 12, fontFamily: '苹方中等' }}><span style={{ color: "#666666" }}>提醒 ： </span> 以下人员基本信息均为真实信息，所有权归蓝晟监管平台所有。</span>
          </div>
        </Modal>
        <Modal
          title="添加模板"
          visible={this.state.visibleNew}
          onOk={this.handleOkNew}
          onCancel={this.handleCancelNew}
          className="SMSDetai"
        >
          <div style={{ width: '100%', height: 30, backgroundColor: '#f9f9f9', paddingLeft: 10, lineHeight: "30px" }}>
            <span style={{ color: 'red', fontSize: 12, fontFamily: '苹方中等' }}><span style={{ color: "#666666" }}>提醒 ： </span> 系统提示您正在进行模板验证，通过验证后方可接受消息!</span>
          </div>
          <Form onSubmit={this.handleOkNew} className="FormSms" style={{ marginTop: 50, width: "80%", marginLeft: "10%" }}>
            <FormItem label="模板名称：">
              {getFieldDecorator('name', {
                rules: [{ required: true, message: '请输入名称！' }],
              })(
                <Input style={{ width: 300, marginLeft: 20 }} />
                )}
            </FormItem>
            <FormItem label="模板 I D：">
              {getFieldDecorator('id', {
                rules: [{ required: true, message: '请输入ID！' }],
              })(
                <Input style={{ width: 300, marginLeft: 21 }} />
                )}
            </FormItem>
            <FormItem label="模板内容：">
              {getFieldDecorator('body', {
                rules: [{ required: true, message: '请输入内容！' }],
              })(
                <Input style={{ width: 300, marginLeft: 20 }} />
                )}
            </FormItem>
            <FormItem label="申请说明：">
              {getFieldDecorator('remark', {
                rules: [{ required: true, message: '请输入名称！' }],
              })(
                <Input style={{ width: 300, marginLeft: 20 }} />
                )}
            </FormItem>
          </Form>
        </Modal>
        <Row style={{ padding: '5px 0 0', marginTop: 10 }}>
          <Col span={24}>
            <Table
              bordered
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})));


class SMSStencil extends Component {
  render() {
    return (
      <GroupManageC appState={new appState()} />
    )
  }
}
export default SMSStencil;