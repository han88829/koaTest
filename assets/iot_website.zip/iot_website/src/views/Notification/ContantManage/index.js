/*
 * @Author: Han.beibei 
 * @Date: 2017-06-02 11:23:51 
 * @Last Modified by:   Han.beibei 
 * @Last Modified time: 2017-06-02 11:23:51 
 */
import React, { Component } from 'react';

class ContantManage extends Component {
  render() {
    return (
      <div>
        联系人管理
      </div>
    );
  }
}

export default ContantManage;