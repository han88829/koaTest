/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:16:03 
 * @Last Modified by: xmj
 * @Last Modified time: 2017-04-06 11:34:30
 */

import React, { Component } from 'react';
import { browserHistory } from 'react-router';
import { Row, Col } from 'antd';
import echarts from 'echarts';

class MiddleGraphs extends Component {
  componentDidMount() {
    let left = echarts.init(document.getElementById('middle_left_graph'));
    let right = echarts.init(document.getElementById('middle_right_graph'));

    // left

    left.setOption({
        tooltip : {
            trigger: 'axis',
            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        legend: {
            data:['利润', '支出', '收入'],
            textStyle: {
              color: '#04FFFF'
            },
            top: 20
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis : [
            {
                type : 'value'
            }
        ],
        yAxis : [
            {
                type : 'category',
                axisTick : {show: false},
                data : ['周一','周二','周三','周四','周五','周六','周日']
            }
        ],
        textStyle: {
              color: '#04FFFF'
            },
        series : [
            {
                name:'利润',
                type:'bar',
                label: {
                    normal: {
                        show: true,
                        position: 'inside'
                    }
                },
                data:[200, 170, 240, 244, 200, 220, 210]
            },
            {
                name:'收入',
                type:'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true
                    }
                },
                data:[320, 302, 341, 374, 390, 450, 420]
            },
            {
                name:'支出',
                type:'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true,
                        position: 'left'
                    }
                },
                data:[-120, -132, -101, -134, -190, -230, -210]
            }
        ]
    });

    // right

    var category = [];
    var dottedBase = +new Date();
    var lineData = [];
    var barData = [];

    for (var i = 0; i < 20; i++) {
        var date = new Date(dottedBase + 3600 * 24);
        category.push([
            date.getFullYear(),
            date.getMonth() + 1,
            date.getDate()
        ].join('-'));
        var b = Math.random() * 200;
        var d = Math.random() * 200;
        barData.push(b)
        lineData.push(d + b);
    }

    right.setOption({
        backgroundColor: '#001737',
        tooltip: {
        },
        legend: {
            data: ['line', 'bar'],
            textStyle: {
                color: '#04FFFF'
            },
            top: 20
        },
        xAxis: {
            data: category,
            axisLine: {
                lineStyle: {
                    color: '#ccc'
                }
            }
        },
        textStyle: {
          color: '#04FFFF'
        },
        yAxis: {
            splitLine: {show: false},
            axisLine: {
                lineStyle: {
                    color: '#ccc'
                }
            }
        },
        series: [{
            name: 'line',
            type: 'line',
            smooth: true,
            showAllSymbol: true,
            symbol: 'emptyCircle',
            symbolSize: 15,
            data: lineData
        }, {
            name: 'bar',
            type: 'bar',
            barWidth: 10,
            itemStyle: {
                normal: {
                    barBorderRadius: 5,
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: '#14c8d4'},
                            {offset: 1, color: '#43eec6'}
                        ]
                    )
                }
            },
            data: barData
        }, {
            name: 'line',
            type: 'bar',
            barGap: '-100%',
            barWidth: 10,
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: 'rgba(20,200,212,0.5)'},
                            {offset: 0.2, color: 'rgba(20,200,212,0.2)'},
                            {offset: 1, color: 'rgba(20,200,212,0)'}
                        ]
                    )
                }
            },
            z: -12,
            data: lineData
        }, {
            name: 'dotted',
            type: 'pictorialBar',
            symbol: 'rect',
            itemStyle: {
                normal: {
                    color: '#0f375f'
                }
            },
            symbolRepeat: true,
            symbolSize: [12, 4],
            symbolMargin: 1,
            z: -10,
            data: lineData
        }]
    });
  }

  render() {
    return (
      <Row gutter={16} style={{ background: '#001737', height: 'calc(100vh - 80px)', color: '#FFF' }}>
        <Col span={24} style={{ height: 'calc(67vh - 80px)' }}>
          <h2><span style={{ fontSize: '20px', color: '#8FB4CB' }}>全球总体数据分布：</span><br /><span style={{ fontSize: '32px', color: '#04FFFF' }}>123523153</span></h2>
          <div id="map_ana" onDoubleClick={() => browserHistory.push(`/concen`)}>
            <div className="map_ana_dot" style={{ position:'absolute', top: 239 ,right: 141, zIndex: '100' }}></div>
            <div className="map_ana_dot" style={{ position:'absolute', top: 206 ,right: 706, zIndex: '100' }}></div>
            <div className="map_ana_dot" style={{ position:'absolute', top: 166 ,right: 495, zIndex: '100' }}></div>
            <div className="map_ana_dot" style={{ position:'absolute', top: 331 ,right: 186, zIndex: '100' }}></div>
            <div className="map_ana_dot" style={{ position:'absolute', top: 450 ,right: 60, zIndex: '100' }}></div>
          </div>
        </Col>
        <Col span={12} style={{ height: 'calc(33vh - 40px)' }}>
          <h3 style={{margin:'auto',fontSize:14,fontFamily:'苹方',width:100,height:30,color:'#04FFFF',backgroundColor:'#162a5f',lineHeight:'30px', position:'relative', top: '15px', zIndex: '100' }}>横向堆积图</h3>
          <div className="right-icon" style={{position:'absolute', top: '25px', right: '5px', zIndex: '100'}}></div>
          <div id="middle_left_graph"></div>
        </Col>
        <Col span={12} style={{ height: 'calc(33vh - 40px)'}}>
          <h3 style={{margin:'auto',fontSize:14,fontFamily:'苹方',width:100,height:30,color:'#04FFFF',backgroundColor:'#162a5f',lineHeight:'30px', position:'relative', top: '15px', zIndex: '100'}}>虚线柱状图</h3>
          <div className="right-icon" style={{position:'absolute', top: '25px', right: '5px', zIndex: '100'}}></div>
          <div id="middle_right_graph" style={{paddingRight:0}}></div>
        </Col>
      </Row>
    );
  }
}

export default MiddleGraphs;