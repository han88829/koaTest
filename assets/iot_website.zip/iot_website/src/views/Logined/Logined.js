import React, { Component } from 'react';
import { browserHistory } from 'react-router';
import { Layout, Row, Col } from 'antd';

import LeftGraphs from './containers/LeftGraphs';
import RightGraphs from './containers/RightGraphs';
import MiddleGraphs from './containers/MiddleGraphs';
import './newLogined.css';

const { Header, Content } = Layout;

class Logined extends Component {
  render() {
    return (
      <Layout className="Logined">
        <Header style={{ height: '64px', background: '#001737' }}>
          <div className="top-title" style={{ fontSize: '32px', textAlign: 'center', color: '#FFF' }}>大数据可视化分析</div>
          <div className="top-home" style={{ position:'absolute', top: '15px', right: '15px', zIndex: '100', Color: 'white' }} onClick={() => browserHistory.push(`/back`)}></div>
        </Header>
        <Content style={{ textAlign: 'center' }}>
          <div style={{ background: '#001737', padding: 8, height: 'calc(100vh - 64px)' }}>
            <Row gutter={16} style={{margin:0}}>
              <Col span={6}>
                <LeftGraphs />
              </Col>
              <Col span={12}>
                <MiddleGraphs />
              </Col>
              <Col span={6} style={{paddingLeft:0}}>
                <RightGraphs />
              </Col>
            </Row>
          </div>
        </Content>
      </Layout>
    );
  }
}

export default Logined;