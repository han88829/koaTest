import React, { Component } from 'react';
import { Link } from 'react-router';
import { Layout, Row, Col } from 'antd';
import LeftGraphs from './containers/LeftGraphs';
import RightGraphs from './containers/RightGraphs';
import MiddleGraphs from './containers/MiddleGraphs';

import './Logined.css';

const { Header, Footer} = Layout;

class Logined extends Component {
  componentDidMount() {
  }
  render() {
    return (
        <Layout className="Logined">
          <Header className="LoginedHeader" >
            <Link to="/org" style={{color:"#ffffff",marginLeft:110,}} className="HeaderLink">户籍管理</Link>
            <Link to="/member" style={{color:"#ffffff"}} className="HeaderLink">人员管理</Link>
            <Link to="/logined" style={{color:"#ffffff"}} className="HeaderLink">监控中心</Link>
            <Link to="/equipment" style={{color:"#ffffff"}} className="HeaderLink">设施设备</Link>
            <Link to="/concen" style={{color:"#ffffff"}} className="HeaderLink">警情集控中心</Link>
            <Link to="/logined" style={{color:"#ffffff"}} className="HeaderLink">综合评估中心</Link>
          </Header>
          <Layout className="gsagsgs">
            {/*<div className="LoginedContent">
              <div className="ContentImg"></div>
              <div className="ContentText">
                <div>蓝晟消防安全综合管控平台</div>
                <p>Intelligence changes the world</p>
              </div>
              <ul className="ContentUl">
                <li style={{marginLeft:680}}>智慧</li>
                <li>安全</li>
                <li>物联</li>
                <li>大数据</li>
              </ul>
            </div>*/}
            <Row gutter={16}>
              <Col span={6}>
                <LeftGraphs />
              </Col>
              <Col span={12}>
                <MiddleGraphs />
              </Col>
              <Col span={6}>
                <RightGraphs />
              </Col>
            </Row>
          </Layout>
          <Footer className="LoginedFooter">
          </Footer>
        </Layout>
    );
  }
}

export default Logined;