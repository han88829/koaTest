/*
 * @Author: lai.haibo 
 * @Date: 2017-03-23 16:50:20 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-23 16:50:20 
 */

import React from 'react';
import ReactDOM from 'react-dom';
import App from './views/App';
import './index.css';


ReactDOM.render(<App /> ,
  document.getElementById('root')
);