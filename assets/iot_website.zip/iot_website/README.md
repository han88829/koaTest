# how to use it?
1. 安装 `node.js(6.x)` 和 `npm(3.x)`

2. 安装所需的包 `npm i`

3. 运行 `npm start`

4. 打包 `npm run build`

5. 反向代理
```
  server {
        location / {
            root   html;
            index  index.html index.htm;
            //允许cros跨域访问
            add_header 'Access-Control-Allow-Origin' *;

        }
        //反向代理天气api
        location /apis {
            rewrite  ^.+apis/?(.*)$ /$1 break;
            include  uwsgi_params;
            proxy_pass   https://api.seniverse.com;
       }
}
```