# 目录{#dir}
- [版本](#ver)
- [区域](#area)
- [设备](#device)
- [分组](#group)
- [组织](#onwer)
- [用户](#user)
- [品牌](#brand)
- [产品](#product)
- [火灾危险](#areafireDanger)
- [消防信息](#fire)
- [联网模式](#networkModeList)
- [维护类型](#patrolTypeList)
- [维护状态](#patrolStateList)
- [设备状态](#dstateList)
- [运行状态](#rstateList)
- [设备巡查](#devicePatrol)
- [设备运行](#deviceRun)
- [设备分类](#deviceTypes)
- [区域分类](#areaTypes)
- [组织分类](#onwerTypes)
- [设备任务](#deviceTask)
- [常量表](#constTable)
- [设备文件类型](#deivceFileType)
- [报表](#report)
- [报表模板](#reportTemplate)
- [消息](#message)
- [位置](#position)
- [位置记录](#positionLog)
- [位置巡逻](#positionPatrol)
- [位置巡逻时间表](#positionPatrolSchedule)
- [资源](#resource)


## 版本

## 区域{#area}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
number|文本(64)|唯一|编号|
name|文本(255)| |名称|
tag|文本(20)|可选,唯一|标签|
parentId|整数| |父节点Id|
type|整数| |[系统类型](#areaTypes)|
subtype|整数| |[构造类型](#areaTypes)|
layer|整数|只读|层次数|
x|浮点| |坐标X|
y|浮点| |坐标Y|
point|文本| |点集合|
mapX|浮点| |像素X|平面图
mapY|浮点| |像素Y|平面图
mapUrl|文本| |底图|平面图
mapPoint|文本| |平面点集合|
fireDanger|整数| |火灾危险|[参量表](#areafireDanger)
fireLevel|整数| |奶火等级|
galleryful|整数| |容纳人数|
face|浮点| |面积|单位:米²
hight|浮点| |高度|单位:米
extend|对象|保留|扩展|
remark|文本| |备注|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 区域火灾危险{#areafireDanger}
**别名：area.fireDanger**

序号|意义|说明
-|-|-
1|甲级|
2|乙级|
3|丙级|
4|丁级|
5|戊级|
6|民用|
[返回目录](#dir)

## 设备{#device}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
number|文本(64)|唯一|编号|
name|文本(255)| |名称|
tag|文本(20)|可选,唯一|标签|
dtype|整数| |[设备类型](#deviceTypes)|
stype|整数| |子类型|
dstate|整数| |设备状态|[参量表](#dstateList)
rstate|整数| |运行状态|[参量表](#rstateList)
validity|整数| |有效期(天)|
floor|整数| |楼宇Id|
location|整数| |位置id|
x|整数| |坐标x|物理位置
y|整数| |坐标y|物理位置
mapX|整数| |像素X|平面图
mapY|整数| |像素Y|平面图
networkMode|整数| |联网模式|[参量表](#networkModeList)
networkUrl|文本(255)| |联网参数|
networkNode|整数| |网络节点Id|
networkId|整数| |网络内部Id|
networkAddr|文本(64)| |网络内部地址|
productId|整数| |产品Id|
patrolId|整数| |巡查Id|最后
ownerId|整数|只读|组织Id|
extend|对象|保留|扩展|
remark|文本| |备注|
expiryTime|日期| |过期时间|
setupTime|日期| |安装时间|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 分组{#group}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
name|文本(255)| |名称|
tag|文本(20)|可选,唯一|标签|
remark|文本| |备注|
level|整数| |等级|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 组织{#owner}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
number|文本(64)|唯一|编号/执照
name|文本(255)| |名称|
tag|文本(20)|可选,唯一|标签|
type|整数| |[类型](#onwerTypes)|
state|整数| |状态|参量表
asset|浮点| |资产|
face|浮点| |面积|
address|文本| |详细地址|
image|文本| |图片|
remark|文本| |备注|
peopleScale|整数| |人数规模|
parentId|整数| |父节点|默认:0
registerTime|日期|可空|注册时间|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 用户{#user}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
number|文本(64)| |工号|
tag|文本(20)|可选,唯一|标签|
username|文本(64)| |用户名|
password|文本(64)| |密码|MD5
name|文本(255)| |名称|
email|文本(255)| |邮箱|
mobile|文本(13)| |手机号码|
gender|整数| |性别|
level|整数| |等级|
image|文本| |头像|
groupId|整数|只读|用户组Id|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 品牌{#brand}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
name|文本(64)| |名称|
remark|文本| |备注|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 产品{#product}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
number|文本(64)| |型号|
name|文本(64)| |名称|
make|文本| |制作商|
remark|文本| |备注|
type|整数| |[设备类型](#deviceTypes)|
brandId|整数||品牌Id|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 组织消防信息{#fire}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
safetyLevel|整数| |安全等级|参量表
watchLevel|整数| |监督等级|参量表
chief|文本|只读|消费主管单位|
remark|文本| |备注|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备状态{#dstateList}
**别名：device.dstate**

序号|意义|说明
-|-|-
1|未知|
2|合格|
3|不合格|
[返回目录](#dir)

## 运行状态{#rstateList}
**别名：device.rstate**

序号|意义|说明
-|-|-
1|正常|
2|异常|
3|离线|
[返回目录](#dir)

## 联网模式{#networkModeList}
**别名：device.networkMode**

序号|意义|说明
-|-|-
1|网关|
2|4G|
3|GSM|
[返回目录](#dir)

## 维护类型{#patrolTypeList}
**别名：device.patrol.type**

序号|意义|说明
-|-|-
1|巡查|
2|保养|
3|检测|
[返回目录](#dir)

## 维护状态{#patrolStateList}
**别名：device.patrol.state**

序号|意义|说明
-|-|-
1|巡查|
2|保养|
3|检测|
[返回目录](#dir)

## 设备类型属性{#deviceTypeFlags}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|设备类型Id
name|文本(255)|唯一|名称|
unit|文本(8)| |单位|
single|整数| |单值|是:1
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备类型{#deviceTypes}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
name|文本(255)|唯一|名称|
alias|文本(255)| |别名|
layer|整数|只读|层次|
parentId|整数| |父节点|默认:0
remark|文本| |备注|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 区域类型{#areaTypes}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
name|文本(255)|唯一|名称|
parentId|整数| |父节点|默认:0
layer|整数|只读|层次数|默认:1
remark|文本| |备注|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 组织类型{#onwerTypes}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|ID|
name|文本(255)|唯一|名称|
parentId|整数| |父节点|默认:0
layer|整数|只读|层次数|默认:1
ownerId|整数|只读|组织Id|
remark|文本| |备注|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备巡查/维护记录{#devicePatrol}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|设备Id|
userId|整数| |用户Id|
reportId|整数| |报告Id|
type|整数|默认(1)|维护类型|[参量表](#patrolTypeList)
state|整数| |巡查状态|[参量表](#patrolStateList)
remark|文本| |备注|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备运行记录{#deviceRun}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|设备Id|
state|整数| |运行状态|[参量表](#rstateList)
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备报警{#deviceAlarm}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|设备Id|
type|整数|默认(1)|报警类型|参量表
state|整数| |结果状态|参量表
userId|整数| |处理人Id|
deviceId|整数| |设备Id|
ownerId|整数|只读|组织Id|
remark|文本| |备注|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备任务{#deviceTask}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|设备Id|
number|文本(64)|唯一|编号|
name|文本(255)| |名称|
cycle|文本(32)|只读|循环时间|格式 yyyy-MM-dd hh:mm:ss
state|整数| |状态|参量表
audit|整数|默认(1)|类型|
type|整数|默认(1)|类型|别名:task.type
reType|整数|默认(1)|资源类型|别名:task.resType
resId|整数数组| |资源Id|
userId|整数数组| |用户Id|
parentId|整数| |父Id|
reportId|整数|只读|报表Id|
ownerId|整数|只读|组织Id|
groupId|整数|只读|分组Id|批次标记
extend|对象| |扩展|
remark|文本| |备注|
beginTime|日期|只读|开始时间|
endTime|日期|只读|截止时间|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 任务规则{#taskRule}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|设备Id|
number|文本(64)|唯一|编号|
name|文本(255)| |名称|
taskType|整数|默认(1)|任务类型|别名:rule.taskType
auditType|整数|默认(1)|审核方式|别名:rule.auditType
allotType|整数|默认(1)|分别方式|别名:rule.allotType
resType|整数|默认(1)|资源类型|别名:task.resType
workDay|整数|默认(7)|工作天数|
cycle|文本(32)| |循环时间|格式 yyyy-MM-dd hh:mm:ss
state|整数| |状态|参量表
type|整数|默认(1)|类型|
resId|整数数组| |资源Id|
userId|整数数组| |用户Id|
reportId|整数|只读|报表Id|
ownerId|整数|只读|组织Id|
extend|对象| |扩展|
remark|文本| |备注|
beginTime|日期|只读|开始时间|
endTime|日期|只读|截止时间|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 常量表{#constTable}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|设备Id|
number|文本(64)|唯一|编号|
name|文本(255)| |名称|
value|对象| |别名表|{id:name}
remark|文本| |备注|
parentId|整数| |父Id|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备文件{#deivceFile}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|设备Id|
type|整数|必选|类型|[参量表](#deivceFileType)
name|文本(255)| |名称|
remark|文本| |备注|
url|文本|必选|链接|
deviceId|整数|必选|设备Id|
ownerId|整数|只读|组织Id|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 设备文件类型{#deivceFileType}
**别名：device.file.type**

序号|意义|说明
-|-|-
1|未知|
2|图片|
3|视频|
[返回目录](#dir)

## 报表{#report}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|模板Id|
name|文本|可选|名称|
page|文本|可选|类型|JSON
remark|文本|可选|备注|
userId|整数|只读|用户Id|
ownerId|整数|只读|组织Id|
taskId|整数|必选|任务Id|
targetId|整数|必选|目标Id|
targetState|整数|必选|目标状态|
templateId|整数|可选|组织Id|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 报表模板{#reportTemplate}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|模板Id|
number|文本(64)|唯一|编号|
name|文本(255)| |名称|
page|文本|必选|类型|JSON
remark|文本| |备注|
userId|整数|只读|用户Id|
lastUserId|整数|只读|用户Id|
ownerId|整数|只读|组织Id|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 消息{#message}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|模板Id|
name|文本(255)| |名称|
state|整数|只读|状态|
type|整数|初始|类型|别名:message.type
body|文本|必选|正文|
remark|文本| |备注|
users|整数数组| |接收Id|
userId|整数|只读|用户Id|创建人
ownerId|整数|只读|组织Id|
param|对象| |参数|值文本|
extend|对象| |扩展|值任意|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 位置{#position}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|Id|
name|文本(255)| |名称|
tag|文本(20)|可选,唯一|标签|
state|整数|只读|状态|
floor|整数|可选|楼宇|
storey|整数|可选|楼层|
location|整数|必选|位置|
x|浮点| |坐标x|物理位置
y|浮点| |坐标y|物理位置
diameter|浮点|直径| |
mapX|浮点| |像素X|平面图
mapY|浮点| |像素Y|平面图
remark|文本| |备注|
ownerId|整数|只读|组织Id|
extend|对象| |扩展|值任意|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 位置记录{#positionLog}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|Id|
state|整数|只读|状态|
x|浮点| |坐标x|物理位置
y|浮点| |坐标y|物理位置
positionId|整数|必选|位置Id|
userId|整数|只读|用户Id|
ownerId|整数|只读|组织Id|
images|文本数组| |图片集|
remark|文本| |备注|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 位置巡逻{#positionPatrol}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|Id|
state|整数|只读|状态|
positionId|整数|必选|位置Id|
userId|整数|只读|用户Id|
ownerId|整数|只读|组织Id|
images|文本数组| |图片集|
remark|文本| |备注|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 位置巡逻时间表{#positionPatrolSchedule}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|Id|
name|文本(255)| |名称|
state|整数|只读|状态|没用
duration|时间||持续时间|
table|时间数组|时间表|升序
ownerId|整数|只读|组织Id|
extend|对象| |扩展|
remark|文本| |备注|
createTime|日期|只读|创建时间|
[返回目录](#dir)

## 资源{#resource}
字段|类型|约束|名称|说明
-|-|-|-|-
id|整数|只读|Id|
name|文本(255)| |名称|
x|浮点| |坐标x|物理位置
y|浮点| |坐标y|物理位置
ownerId|整数|只读|组织Id|0公有
extend|对象| |扩展|
remark|文本| |备注|
buildTime|日期|可选|建造时间|
lastTime|日期|只读|修改时间|
createTime|日期|只读|创建时间|
[返回目录](#dir)


## 权限表{#PermissionTable}
字段|类型|约束|名称|说明
-|-|-|-|-
default|布尔|可选,默认(false)|默认行为|true/false:允许/拒绝
table|对象|可选|权限表|key为模块路径,value为[权限描述](#Permission),如:position_patrol_user
[返回目录](#dir)

## 权限表{#Permission}
字段|类型|约束|名称|说明
-|-|-|-|-
default|布尔|可选,默认(false)|默认行为|true/false:允许/拒绝
prefix|对象|可选|[前缀名](#PermissionMethodPrefix)|
method|对象|可选|函数名|为函数名首字母小写
[返回目录](#dir)

## 权限函数前缀名{#PermissionMethodPrefix}

**作用于该模块所有设置接口**

前缀|说明
-|-
set|设置
get|获取
remove|删除
append|添加
update|更新/同步
[返回目录](#dir)

## 菜单{#menu}
字段|类型|约束|名称|说明
-|-|-|-|-
show|布尔|可选,默认(false)|是否显示|true/false:显示/不显示
option|对象|可选|选项|[菜单项](#menuOption),可扩充任意key/value
subMenu|对象|可选|权限表|key为菜单id,value为对象[菜单](#menuTable)
[返回目录](#dir)

## 菜单项{#menuOption}
字段|类型|约束|名称|说明
-|-|-|-|-
name|文本|可选|名称|
[返回目录](#dir)