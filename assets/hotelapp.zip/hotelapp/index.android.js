import React from 'react';
import { AppRegistry, AsyncStorage, ToastAndroid } from 'react-native';
import { StackNavigator } from 'react-navigation';
import Storage from 'react-native-storage';
import CardStackStyleInterpolator from 'react-navigation/src/views/CardStack/CardStackStyleInterpolator';
import { parseString } from 'react-native-xml2js';

import Mine from './src/Mine';//个人信息
import SelectHotel from './src/SelectHotel';//选择酒店
import SelectRoom from './src/Hotel/SelectRoom';//选择房间
import About from './src/About_us';//关于我
import Home from './src/Home';//酒店预定首页
import Test from './src/Test';//测试页面
import SelectCity from './src/SelectCity';//选择城市
import Login from './src/personal/Login';//登录
import register from './src/personal/register';//注册
import Order from './src/Hotel/Order';//订单确认
import exchange from './src/Hotel/exchange';//历史兑换
import consumption from './src/Hotel/consumption';//积分
import resetPassword from './src/personal/resetPassword';//密码重置1
import Password from './src/personal/Password';//密码管理
import validateID from './src/personal/validateID';//重置密码1
import editInfo from './src/personal/editInfo';//编辑个人信息
import nickname from './src/personal/nickname';//昵称修改
import PhoneNum from './src/personal/PhoneNum';//手机修改
import detailAddress from './src/personal/detailAddress';//修改地址
import Pay from './src/Hotel/Pay';//支付订单
import Loading from './src/Loading';//loading
import SelectAdders from './src/Hotel/SelectAdders';//动态城市列表
import Setting from './src/personal/Setting'//设置
import OrderSuess from './src/Hotel/OrderSuess'//订单创建成功
import App from './src/App'//首页
import OrderDetail from './src/OrderDetail'//首页

var storage = new Storage({
  // 最大容量，默认值1000条数据循环存储
  size: 1000,

  // 存储引擎：对于RN使用AsyncStorage，对于web使用window.localStorage
  // 如果不指定则数据只会保存在内存中，重启后即丢失
  storageBackend: AsyncStorage,

  // 数据过期时间，默认一整天（1000 * 3600 * 24 毫秒），设为null则永不过期
  defaultExpires: 1000 * 3600 * 2400,

  // 读写时在内存中缓存数据。默认启用。
  enableCache: true,

  // 如果storage中没有相应数据，或数据已过期，
  // 则会调用相应的sync方法，无缝返回最新数据。
  // sync方法的具体说明会在后文提到
  // 你可以在构造函数这里就写好sync的方法
  // 或是在任何时候，直接对storage.sync进行赋值修改
  // 或是写到另一个文件里，这里require引入
  //sync: {}
})

global.storage = storage;


const SimpleApp = StackNavigator({

  App: { screen: App },
  Loading: { screen: Loading },
  Home: { screen: Home },
  SelectHotel: { screen: SelectHotel },
  Mine: { screen: Mine },
  SelectRoom: { screen: SelectRoom },
  About: { screen: About },
  Test: { screen: Test },
  SelectCity: { screen: SelectCity },
  Login: { screen: Login },
  register: { screen: register },
  Order: { screen: Order },
  exchange: { screen: exchange },
  consumption: { screen: consumption },
  resetPassword: { screen: resetPassword },
  Password: { screen: Password },
  validateID: { screen: validateID },
  editInfo: { screen: editInfo },
  nickname: { screen: nickname },
  PhoneNum: { screen: PhoneNum },
  detailAddress: { screen: detailAddress },
  Pay: { screen: Pay },
  SelectAdders: { screen: SelectAdders },
  Setting: { screen: Setting },
  OrderSuess: { screen: OrderSuess },
  OrderDetail: { screen: OrderDetail },
}, {
    transitionConfig: () => ({
      screenInterpolator: CardStackStyleInterpolator.forHorizontal,
    })
  });

AppRegistry.registerComponent('hotelapp', () => SimpleApp);