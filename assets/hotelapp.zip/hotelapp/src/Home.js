/*
 * @page:   预订首页
 * @Author: Han 
 * @Date: 2017-09-12 18:19:30 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:51:11
 */
import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    Button,
    TouchableOpacity,
    Dimensions,
    Alert,
    ToastAndroid,
    Modal,
} from 'react-native';
import { SearchBar } from 'react-native-elements';
import icon from './images/img';
import DateTimePicker from 'react-native-modal-datetime-picker';
import moment from 'moment';
import Icon from 'react-native-vector-icons/FontAwesome';
import Carousel from 'react-native-looped-carousel';
import Geolocation from 'Geolocation';
import SelectAdders from './Hotel/SelectAdders';

class SelectHotel extends Component {
    static navigationOptions = {
        title: "首页",
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            position: "宁波",
            isDateTimePickerVisible: false,
            date: null,
            today: "选择时间",
            next: "选择时间",
            total: null,
            todalDiaplay: "",
            Visible: false,
            nextTime: null,
            tTime: null,
            modalVisible: false,
            isLogin: true,
            getAdd: true,
            bTime: null,
        }
    }

    componentWillMount() {
        const { navigate } = this.props.navigation;
        storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            if (!x.Code) {
                this.setState({ isLogin: false });
                return
            }
            this.setState({ isLogin: true });
        }).catch(err => {
            this.setState({ isLogin: false });
        })
    }

    componentDidMount() {
        this.setState({
            date: new Date(moment().format("YYYY/MM/DD 12:00:00")),
            nextTime: new Date(moment().format("YYYY/MM/DD 12:00:00")),
        });

    }

    GetPosition = () => {
        this.setState({
            position: "正在定位，请稍候！...",
        });
        let error = "", position = "", _this = this;
        Geolocation.getCurrentPosition(
            location => {
                // var result = "速度：" + location.coords.speed +
                //     "\n经度：" + location.coords.longitude +
                //     "\n纬度：" + location.coords.latitude +
                //     "\n准确度：" + location.coords.accuracy +
                //     "\n行进方向：" + location.coords.heading +
                //     "\n海拔：" + location.coords.altitude +
                //     "\n海拔准确度：" + location.coords.altitudeAccuracy +
                //     "\n时间戳：" + location.timestamp;
                fetch(`http://api.map.baidu.com/geocoder/v2/?location=${location.coords.latitude},${location.coords.longitude}&output=json&pois=1&ak=GuYLMTSrRt7KKnoFRVRpSEhwAwm2gGal`).then((x) => {
                    return x.json()
                }).then((x) => {
                    if (!x.result.addressComponent.city) {
                        ToastAndroid.showWithGravity('您不在服务区，请重新定位或手动选择!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                        _this.setState({
                            position: x.result.addressComponent.country
                        });
                        return;
                    }
                    _this.setState({
                        position: x.result.addressComponent.city
                    });
                })
            },
            error => {
                if (error.code == 3) {
                    error = "定位超时，请重新定位或手动选择城市！"
                } else {
                    error = error.message
                }
                _this.setState({ position: error })
            },
            { enableHighAccuracy: true, timeout: 5000, maximumAge: 5000 }
        );
    }

    MoadlConfirm = (data) => {
        this.setState({ position: data, modalVisible: false });
    }
    MoadlCancel = () => {
        this.setState({ modalVisible: false });
    }

    Booking = () => {
        const { navigate } = this.props.navigation;


        if (this.state.position === '定位超时，请重新定位或手动选择城市！') {
            ToastAndroid.showWithGravity('请重新选择位置!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }

        let a = moment(this.state.nextTime);
        let b = moment(this.state.tTime);
        if (b.diff(a) < 0) {
            ToastAndroid.showWithGravity('请重新选择离店日期!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }
        navigate("SelectHotel", { today: this.state.today, next: this.state.next, bTime: this.state.bTime, beginTime: this.state.nextTime, endTime: this.state.tTime, total: this.state.total, position: this.state.position })
    }

    render() {
        const { navigate } = this.props.navigation;
        const width = Dimensions.get('window').width;
        return (
            <View style={{ flex: 1, flexDirection: 'column', backgroundColor: '#fff' }}>
                {/* 图片 */}
                <View style={{ height: 190, flexDirection: 'row' }}>
                    <Carousel
                        delay={50000}
                        style={{ width: width, height: 180 }}

                        bullets={true}
                    >
                        <Image
                            style={{ width: width, height: 180 }}
                            source={require('./images/bg1.png')}
                        />
                        <Image
                            style={{ width: width, height: 180 }}
                            source={require('./images/bg2.png')}
                        />
                        <Image
                            style={{ width: width, height: 180 }}
                            source={require('./images/bg3.png')}
                        />
                    </Carousel>
                </View>
                {/* 选择位置时间 */}
                <View style={{ flex: 8, padding: 20, paddingTop: 0, }}>
                    {/* 选择城市 */}
                    <Modal
                        animationType={"slide"}
                        transparent={false}
                        visible={this.state.modalVisible}
                        onRequestClose={() => { this.setState({ modalVisible: false }); }}
                    >
                        <SelectAdders onClick={this.MoadlConfirm} cancle={this.MoadlCancel} />
                    </Modal>
                    <View style={styles.bottomItem} >
                        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', }}>
                            <View style={{ flex: 8 }} >
                                <TouchableOpacity
                                    underlayColor="#ccc"
                                    onPress={() => {
                                        {/* if (!this.state.isLogin) {
                                            ToastAndroid.showWithGravity('请先登录!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                            navigate("Login")
                                            return
                                        } */}
                                        this.setState({ modalVisible: true });
                                    }}
                                >
                                    <Text
                                        style={{ textAlign: "left", color: "#333" }}
                                    >{this.state.position}</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end', marginRight: 5 }} >
                                {/* <Text style={{ textAlign: "right", fontSize: 20, color: "#ccc", marginRight: 5 }}>></Text> */}
                                {/* <Image source={require('./images/qianjin.png')} /> */}
                            </View>
                            <View style={{ flex: 2 }} >
                                <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center', }}>
                                    <TouchableOpacity
                                        style={{ flex: 1, }}
                                        underlayColor="rgba(204, 204, 204, 0)"
                                        onPress={this.GetPosition}
                                    >
                                        <Image style={{ marginTop: 5 }} source={require('./images/position.png')} />
                                    </TouchableOpacity>
                                    <View style={{ flex: 1, }}>
                                        <Text style={{ fontSize: 12 }} onPress={this.GetPosition}>我的位置</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>
                    <View style={styles.bottomItem} >
                        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', }}>
                            <View style={{ flex: 2, flexDirection: 'row', }} >
                                <Text
                                    style={{ textAlign: "left" }}
                                    onPress={() => {
                                        this.setState({
                                            isDateTimePickerVisible: true
                                        });
                                    }}
                                >入住   <Text style={{ color: "#008389" }}>{this.state.today}</Text></Text>

                                <Text style={{ textAlign: "left", fontSize: 10, color: "#333", marginLeft: 5, paddingTop: 3 }}>      </Text>

                                <Text
                                    style={{ textAlign: "left", marginLeft: 10 }}
                                    onPress={() => {
                                        this.setState({
                                            Visible: true
                                        });
                                    }}
                                >离店   <Text style={{ color: "#008389" }}>{this.state.next}</Text></Text>
                                <Text style={{ fontSize: 10, color: "#999", textAlign: "left", marginLeft: 10, paddingTop: 3 }}>{this.state.total}</Text>
                            </View>

                            <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end', }} >

                            </View>
                        </View>
                    </View>
                    <View style={{ height: 50, marginTop: 20, }} >
                        <Text
                            onPress={this.Booking}
                            style={{ color: "#fff", backgroundColor: "#008389", borderRadius: 4, height: 40, textAlign: "center", fontSize: 16, padding: 9 }}
                        >立即预定</Text>
                    </View>
                </View>
                {/* 时间 */}
                <DateTimePicker
                    isVisible={this.state.isDateTimePickerVisible}
                    onConfirm={(x) => {
                        let date = moment(x).format("MM月DD日");
                        let str = moment(x).toNow(true);
                        if (str.indexOf("seconds") >= 0 || str.indexOf("minute") >= 0 || str.indexOf("hour") >= 0) {
                            this.setState({
                                todalDiaplay: "今天"
                            });
                        } else if (str.indexOf("a day") >= 0) {
                            this.setState({ todalDiaplay: "明天" });
                        } else {
                            this.setState({ todalDiaplay: "" });
                        }
                        if (this.state.next === "选择时间") {
                            this.setState({ isDateTimePickerVisible: false, bTime: x, today: date, nextTime: new Date(moment(x).add(1, 'days')) });
                        } else {
                            let a = moment(x);
                            let b = moment(this.state.tTime);
                            let total = `共 ${b.diff(a, 'days')} 晚`;
                            this.setState({ isDateTimePickerVisible: false, bTime: x, today: date, total, nextTime: new Date(moment(x).add(1, 'days')) });
                        }
                    }}
                    onCancel={() => {
                        this.setState({ isDateTimePickerVisible: false });
                    }}
                    minimumDate={this.state.date}
                />
                <DateTimePicker
                    isVisible={this.state.Visible}
                    onConfirm={(x) => {
                        let date = moment(x).format("MM月DD日");
                        let a = moment(this.state.nextTime || new Date());
                        let b = moment(x);
                        let tTime = x;
                        let total = `共 ${b.diff(a, 'days') + 1} 晚`;
                        this.setState({ Visible: false, next: date, total, tTime });
                    }}
                    onCancel={() => {
                        this.setState({ Visible: false });
                    }}
                    minimumDate={this.state.nextTime}
                />
            </View >

        )
    }
}

const styles = StyleSheet.create({
    foot: {
        flex: 1,
        height: 30,
        flexDirection: 'row',
        borderTopColor: "#ccc",
        borderTopWidth: 1,
    },
    footItem: {
        flex: 1
    },
    ItemC: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    wrapper: {
    },
    slide1: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#9DD6EB',
    },
    slide2: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#97CAE5',
    },
    slide3: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#92BBD9',
    },
    text: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
    },
    bottomItem: {
        height: 50,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
    },
    title: {
        fontWeight: '500',
    },
});


export default SelectHotel;