import queryString from 'query-string';
import _ from 'lodash';
import {parseString} from 'react-native-xml2js';
import config from './config';

/*定义一个request对象*/
let request = {};

/*封装一个get方法*/
request.get = function(url,params){

  if(params){
    url += '?' + queryString.stringify(params);
  }
  return fetch(url).then((response)=>response.json());
}

/*封装一个post方法*/
request.post = function(url,body){
  let options = _.assign(config.header,{
    body:body
  })
  return new Promise(function(resolve,reject){
    fetch(url,options)
    .then((response)=>{
        if (response.ok) {
            let res = null;
            resolve(response)
        } else {
            reject({status:response.status})
        }
    })
    .catch((err)=> {
      reject({status:-1});
    })
  })

}

/*封装登录方法*/
request.login = function(params){
  var paramsString = ''
  for(var key in params){
    paramsString += key + '=' + params[key] +'&'
  }
  return this.post('http://182.92.222.169:9611/CRS.asmx/crs1MemberLoginJson',paramsString)
}

/*封装注册方法*/
request.register = function(params){
  var paramsString = ''
  for(var key in params){
    paramsString += key + '=' + params[key] +'&'
  }
  console.log(paramsString)
  return this.post('http://182.92.222.169:9611/CRS.asmx/crs1MemberRegisterJson',paramsString)
}


export default request
