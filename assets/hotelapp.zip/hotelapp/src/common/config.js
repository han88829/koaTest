const config = {
  header:{
    method:'POST',
    headers:{
      'Content-Type':'application/x-www-form-urlencoded'
    }
  },
}

export default config
