/*
 * @Author: frank 
 * @Date: 2017-09-19 13:40:51 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:36:13
 */

import React from 'react';
import {
    AppRegistry,
    Text,
    View,
    StyleSheet,
    ListView,
    Image,
    TouchableOpacity,
    AsyncStorage,
    Alert,
    Dimensions,
    ToastAndroid
} from 'react-native';

import Button from 'react-native-button';
import Storage from 'react-native-storage';
import icon from '../images/img';

const width = Dimensions.get('window').width;
class Setting extends React.Component {
    static navigationOptions = {
        title: '填写订单',
        header: null
    };
    constructor() {
        super();
        this.state = {
            isLogin: false
        }
    }

    // 返回
    _back() {
        const { navigate, goBack } = this.props.navigation;
        goBack();
    }
    // 退出登录
    _logOut = () => {
        const { navigate } = this.props.navigation
        storage.remove({
            key: 'personalInfo'
        })
        ToastAndroid.showWithGravity('退出成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
        navigate('App')
    }

    render() {
        const { navigate } = this.props.navigation
        return (
            <View style={styles.view}>
                <View style={{ height: 44, flexDirection: 'row', paddingLeft: 20, alignItems: 'center', justifyContent: 'flex-start', borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, }}
                        />
                    </TouchableOpacity>
                    <Text style={{ flex: 1, fontSize: 16, textAlign: 'center', color: "#333", marginLeft: -20 }}>设置</Text>
                    <View style={{ flex: 1 }}></View>
                </View>


                {/*密码管理，关于我们*/}
                <View style={{ flexDirection: 'column', padding: 20, paddingTop: 0 }} >

                    <TouchableOpacity
                        underlayColor="#f0f0f0"
                        onPress={() => {
                            navigate('Password')
                        }}
                    >
                        <View style={{ borderBottomWidth: 1, height: 54, borderBottomColor: "#f0f0f0" }} >
                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', }}>
                                <View style={{ flex: 8, flexDirection: 'row', alignItems: 'center' }} >
                                    <Image
                                        source={require('../images/password.png')}
                                    />
                                    <Text style={{ textAlign: "left", marginLeft: 10 }}>密码管理</Text>
                                </View>
                                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} >
                                    <Image source={require('../images/qianjin.png')} />
                                </View>
                            </View>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity
                        underlayColor="#f0f0f0"
                        onPress={() => navigate('About', { id: "关于我们" })}
                    >
                        <View style={styles.bottomItem} >
                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', }}>
                                <View style={{ flex: 8, flexDirection: 'row', alignItems: 'center' }} >
                                    <Image
                                        source={require('../images/about.png')}
                                    />
                                    <Text style={{ textAlign: "left", marginLeft: 10 }}>关于我们</Text>
                                </View>
                                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} >
                                    <Image source={require('../images/qianjin.png')} />
                                </View>
                            </View>
                        </View>
                    </TouchableOpacity>
                </View>

                <TouchableOpacity
                    style={styles.logOut}
                    onPress={this._logOut}
                >
                    <Text style={{ fontSize: 14, color: '#008389', paddingTop: 8, textAlign: "center" }} >退出登录</Text>
                </TouchableOpacity>
            </View >
        );
    }
}

const styles = StyleSheet.create({
    view: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: "white"
    },
    row: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: "center",
        alignItems: 'center',
    },
    column: {
        flex: 1,
        flexDirection: 'column',
    },
    bottomItem: {
        height: 54,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
    },
    logOut: {
        marginTop: 30,
        borderColor: '#f0f0f0',
        borderRadius: 5,
        width: width - 40,
        height: 36,
        borderWidth: 1,
        backgroundColor: '#fff',
        marginLeft: 20
    }
});

export default Setting;
