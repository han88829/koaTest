import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Dimensions, ToastAndroid, AsyncStorage, TouchableOpacity, Image } from 'react-native';
import Button from 'react-native-button';
import request from '../common/request';
import { parseString } from 'react-native-xml2js';
import Storage from 'react-native-storage';
import validator from 'validator';
import icon from '../images/img';

const width = Dimensions.get('window').width;
class ResetPassword extends Component {
    static navigationOptions = {
        title: "登录",
        header: null
    };
    constructor() {
        super();
        this.state = {
            phoneNum: '',
            password: '',
            personalInfo: null,
            getCaptchaButton: '获取验证码',
            captchaButtonStyle: styles.captchaButton,
            captchaButtonTextStyle: styles.capchaButtonText,
        }
    }
    // 发送验证码
    _sendCaptcha = () => {
        const { navigate } = this.props.navigation;
        let phoneNum = this.state.phoneNum;
        let password = this.state.password;

        if (password != phoneNum) {
            ToastAndroid.showWithGravity('两次输入的密码不一致!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }

        let url = `user=admin&pwd=a&rule=&CardNo=${this.props.navigation.state.params.name}&NewPassword=${phoneNum}&ConfirmNewPassword=${password}`;
        fetch(`http://182.92.222.169:9611/CRS.asmx/crsIfcMemberResetPasswordJson?` + url).then(x => x.text()).then((x) => {
            parseString(x, (err, json) => {
                let data = JSON.parse(json.string._);
                if (data[0].msgInfo || data[0].msgInfo.indexOf("OK") >= 0) {
                    ToastAndroid.showWithGravity('修改成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    navigate("Login");
                    return;
                }
                ToastAndroid.showWithGravity('修改失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);

            })
        }).catch(err => ToastAndroid.showWithGravity('重置密码失败!', ToastAndroid.SHORT, ToastAndroid.CENTER))

    }
    _back() {
        const { navigate, goBack } = this.props.navigation;
        goBack();
    }
    render() {
        const { navigate } = this.props.navigation
        return (
            <View style={styles.container}>

                <TouchableOpacity onPress={this._back.bind(this)} style={styles.back}>
                    <Image
                        source={{ uri: icon.backX }}
                        style={{ height: 20, width: 20, marginLeft: 20 }}
                    />
                    <Text style={{ flex: 2, textAlign: 'center', color: '#999', marginLeft: -20 }}>重置密码 2/2</Text>
                    <View style={{ width: 20 }}></View>
                </TouchableOpacity>

                <Text style={styles.title}>重置密码</Text>

                <View style={styles.inputBox}>
                    <TextInput
                        style={styles.input}
                        placeholder="请输入密码"
                        underlineColorAndroid='transparent'
                        onChangeText={(text) => {
                            this.setState({
                                phoneNum: text
                            })
                        }}
                    />

                    <TextInput
                        style={styles.input}
                        placeholder="请再次输入密码"
                        underlineColorAndroid='transparent'
                        onChangeText={(text) => {
                            this.setState({
                                password: text
                            })
                        }}
                    />



                </View>
                <View style={styles.loginButton}>
                    <Button
                        style={{ fontSize: 14, color: '#fff', paddingTop: 10 }}
                        onPress={this._sendCaptcha}
                    >确认</Button>
                </View>

            </View>
        )
    }
}

var styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#fafafa'
    },
    back: {
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        height: 44,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1
    },
    title: {
        marginTop: 30,
        fontSize: 20,
        fontFamily: 'PingFang-SC-Regular',
        color: "#333"
    },
    inputBox: {
        marginTop: 20
    },
    input: {
        height: 40,
        marginTop: 20,
        width: width - 40,
        borderBottomColor: '#F0F0F0',
        borderBottomWidth: 1,
        fontSize: 14,
        color: '#333'
    },
    inputCaptcha: {
        height: 40,
        marginTop: 20,
        width: width * 0.55,
        borderBottomColor: '#F0F0F0',
        borderBottomWidth: 1,
        fontSize: 14,
        color: '#333'
    },
    loginButton: {
        marginTop: 40,
        borderColor: '#008389',
        borderRadius: 5,
        width: width - 40,
        height: 40,
        borderWidth: 1,
        backgroundColor: '#008389'
    },
    captchaButton: {
        backgroundColor: '#008389',
        height: 26,
        width: 90,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#008389'
    },
    captchaButton_disabled: {
        backgroundColor: '#f0f0f0',
        height: 26,
        width: 90,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#f0f0f0'
    },
    capchaButtonText: {
        fontSize: 12, color: '#333', paddingTop: 6
    },
    capchaButtonText_disabled: {
        fontSize: 12, color: '#999999', paddingTop: 6
    }
});


export default ResetPassword
