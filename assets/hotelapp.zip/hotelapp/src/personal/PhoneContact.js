import React, { Component } from 'react';
import { View, Text, StyleSheet, Dimensions, ToastAndroid, ScrollView } from 'react-native';
import List from 'antd-mobile/lib/list';
import Checkbox from 'antd-mobile/lib/checkbox';
import Contacts from 'react-native-contacts';

const CheckboxItem = Checkbox.CheckboxItem;
const AgreeItem = Checkbox.AgreeItem;
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

class Test extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            select: 0
        }
    }

    onChange = (x, i) => {
        // let data = this.state.data;
        // data[i].value = !data[i].value;
        // this.setState({ data })
    }
    componentDidMount() {
        let name = this.props.name, phone = this.props.phone;
        Contacts.checkPermission((err, data) => {
            if (data !== "authorized") {
                Contacts.requestPermission((error, dataRequest) => {
                    if (dataRequest !== "authorized") {
                        ToastAndroid.showWithGravity('获取联系人失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                        return
                    }
                })
            }
            Contacts.getAll((error, contacts) => {
                let dataName = [{ name: name, tel: phone, value: false }];
                contacts.forEach(function (x, i) {
                    x.phoneNumbers.forEach(function (item, index) {
                        if (item.label === "mobile") {
                            dataName.push({
                                name: (x.familyName || "") + x.givenName,
                                tel: item.number.replace(/\s+/g, "").replace(/\-+/g, ""),
                                value: false
                            })
                        }
                    }, this);
                }, this);
                this.setState({ data: dataName });
            })
        })
    }

    render() {
        let data = this.state.data;
        return (

            <View style={styles.contect}>
                <View style={styles.header}>
                    <Text
                        style={{ flex: 1, textAlign: "left", color: "#008389", paddingLeft: 10 }}
                        onPress={() => {
                            this.props.cancel()
                        }}
                    >取消</Text>
                    <Text style={{ flex: 2, textAlign: "center" }}>添加联系人</Text>
                    <Text
                        style={{ flex: 1, textAlign: "right", color: "#008389", paddingRight: 10, }}
                        onPress={() => {
                            let data = this.state.data;
                            let select = []
                            data.forEach(function (x, i) {
                                if (x.value) {
                                    select.push(data[i].name)
                                }
                            }, this);
                            this.props.confirm(select)
                        }}
                    >{this.props.only === 0 ? "" : "确定"}</Text>
                </View>
                <ScrollView style={styles.content}>

                    {data.map((x, i) => {
                        return (
                            <CheckboxItem
                                key={x.name}
                                checked={x.value}
                                style={{ borderWidth: 0 }}
                                disabled={this.state.select >= this.props.only && this.props.only ? x.value ? false : true : false}
                                onChange={(e) => {
                                    data[i].value = e.target.checked;
                                    let select = this.state.select;
                                    if (e.target.checked) {
                                        select++
                                    } else {
                                        select--
                                    }
                                    this.setState({ data, select });
                                    if (this.props.only === 0) {
                                        this.props.confirm(x.tel)
                                    }
                                }}
                            >
                                <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                                    <Text style={{ flex: 1, textAlign: "left", marginLeft: 5,color:this.state.select >= this.props.only && this.props.only ? x.value ? "black" : "#ccc" : "black" }}>{x.name}</Text>
                                    <Text style={{ flex: 1, textAlign: "left",color:this.state.select >= this.props.only && this.props.only ? x.value ? "black" : "#ccc" : "black" }}>tel : {x.tel}</Text>
                                </View>
                            </CheckboxItem>
                        )
                    })}

                </ScrollView>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    contect: {
        width: width,
        height: height,
        flex: 1,
        flexDirection: 'column',
    },
    header: {
        height: 44,
        width: width,
        flexDirection: 'row',
        paddingTop: 12,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1
    },
    content: {
        width: width,
        paddingLeft: 20,
        paddingRight: 20,
    }
})


export default Test;