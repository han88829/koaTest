/*
 * @Author: frank 
 * @Date: 2017-09-15 15:14:53 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:43:23
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Dimensions, Image, ToastAndroid } from 'react-native';
import { parseString } from 'react-native-xml2js';
import icon from '../images/img'

const width = Dimensions.get('window').width;
class PhoneNum extends Component {
    static navigationOptions = {
        title: "修改密码",
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            phone: '',
            offer: false
        }
    }

    _back() {
        const { navigate, goBack } = this.props.navigation;
        goBack();
    }

    onSumbit = () => {
        const { navigate } = this.props.navigation;
        let Mobile = this.state.phone;
        let data = this.props.navigation.state.params;
        var regex = /^0\d{2,3}-?\d{7,8}$|^((\+)?86|((\+)?86)?)0?1[3578]\d{9}$/;

        if (!Mobile || !regex.test(Mobile)) {
            ToastAndroid.showWithGravity('请输入正确的手机号！', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }

        let url = `user=admin&pwd=a&rule=&CardNo=${data.CardNo}&ColName=Mobile&finalValue=${Mobile}`;

        fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberCardUpdateJson?' + url).then(x => x.text()).then((x) => {
            parseString(x, (err, json) => {
                let dataE = JSON.parse(json.string._);
                if (dataE[0].msgInfo && dataE[0].msgInfo.indexOf("OK") < 0 || dataE[0][''] === "|") {
                    ToastAndroid.showWithGravity('修改失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ offer: false });
                    return;
                }
                //ToastAndroid.showWithGravity('修改成功,正在为您更新信息!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                this.setState({ offer: true });
                // 更新缓存信息
                fetch(`http://182.92.222.169:9611/CRS.asmx/crsIfcMemberLoginJson?user=admin&pwd=a&rule=&CardNo=&IdNo=&Email=&Mobile=${Mobile}&password=${data.userInfo.Password}`).then((x) => {
                    return x.text();
                }).then((x) => {
                    parseString(x, (err, json) => {
                        let dataS = JSON.parse(json.string._);
                        if (dataS[0].msgInfo || !dataS[0].Code) {
                            ToastAndroid.showWithGravity('更新信息失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            return;
                        }
                        // 本地数据存储
                        storage.save({
                            key: 'personalInfo',
                            data: dataS[0],
                        })
                        //ToastAndroid.showWithGravity('更新信息成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                        navigate("editInfo");
                    })
                })
            })
        }).catch(err => ToastAndroid.showWithGravity('修改失败!71', ToastAndroid.SHORT, ToastAndroid.CENTER));

    }

    render() {
        return (
            <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center', paddingTop: 5, backgroundColor: '#fff' }}>

                <View style={{ flexDirection: 'row', alignItems: 'center', width: width, height: 44, borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, marginLeft: 20 }}
                        />
                    </TouchableOpacity>
                    <Text style={{ textAlign: 'center', fontSize: 16, flex: 1, color: "#333" }}>手机号码</Text>
                    <Text style={{ flex: 1, textAlign: 'right', color: '#008389', marginRight: 20 }} onPress={this.state.offer ? null : this.onSumbit}>完成</Text>
                </View>

                <View style={{ marginTop: 30 }}>
                    <TextInput
                        style={{ fontSize: 12, textAlign: 'left', width: width - 40, height: 40 }}
                        placeholder="      最多可输入20字符"
                        underlineColorAndroid='#f0f0f0'
                        onChangeText={(text) => {
                            this.setState({
                                phone: text
                            })
                        }}
                    />
                </View>

            </View >
        )

    }
}

export default PhoneNum