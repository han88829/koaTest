/*
 * @page:   关于我
 * @Author: Han
 * @Date: 2017-09-12 18:19:39
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:36:40
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Dimensions, Image, ToastAndroid } from 'react-native';
import icon from '../images/img';
import { parseString } from 'react-native-xml2js';

const width = Dimensions.get('window').width;
class Password extends Component {
    static navigationOptions = {
        title: "修改密码",
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            oldPass: '',
            newPass: '',
            newPassword: '',
            data: {}
        }
    }

    componentDidMount() {
        storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            this.setState({ data: x });
        }).catch(err => {
            ToastAndroid.showWithGravity('35！', ToastAndroid.SHORT, ToastAndroid.CENTER);
        })
    }


    _back() {
        const { navigate, goBack } = this.props.navigation;
        goBack();
    }

    onSubmit = () => {
        const { navigate } = this.props.navigation;
        let { oldPass, newPass, newPassword, data } = this.state;
        if (!oldPass || !newPass || !newPassword) {
            ToastAndroid.showWithGravity('密码不能为空!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }
        if (newPass !== newPassword) {
            ToastAndroid.showWithGravity('两次输入的密码不一样，请检查新密码!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }

        let url = `user=admin&pwd=a&rule=&CardNo=${data.CardNo}&OldPassword=${oldPass}&NewPassword=${newPass}&ConfirmNewPassword=${newPassword}`;
        fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberChangePasswordJson?' + url).then(x => x.text()).then((x) => {
            parseString(x, (err, json) => {
                let data = JSON.parse(json.string._);
                if (data[0].msgInfo && data[0].msgInfo.indexOf('OK') >= 0) {
                    ToastAndroid.showWithGravity('修改成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    storage.remove({
                        key: 'personalInfo'
                    });
                    navigate('Login');
                } else {
                    ToastAndroid.showWithGravity('修改失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                }
            })
        })
    }
    render() {
        return (
            <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center', backgroundColor: '#fff' }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', padding: 20, height: 44, borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, }}
                        />
                    </TouchableOpacity>
                    <Text style={{ textAlign: 'center', fontSize: 16, flex: 1, fontWeight: "bold" }}>修改密码</Text>
                    <Text
                        style={{ flex: 1, textAlign: 'right', color: '#008389' }}
                        onPress={this.onSubmit}
                    >完成</Text>
                </View>

                <View style={{ marginTop: 30 }}>
                    <TextInput
                        style={styles.input}
                        underlineColorAndroid='#f0f0f0'
                        placeholder="请输入原密码"
                        secureTextEntry={true}
                        onChangeText={(text) => {
                            this.setState({
                                oldPass: text
                            })
                        }}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="请输入新密码"
                        secureTextEntry={true}
                        underlineColorAndroid='#f0f0f0'
                        onChangeText={(text) => {
                            this.setState({
                                newPass: text
                            })
                        }}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="请再次输入新密码"
                        secureTextEntry={true}
                        underlineColorAndroid='#f0f0f0'
                        onChangeText={(text) => {
                            this.setState({
                                newPassword: text
                            })
                        }}
                    />
                </View>
            </View >
        );
    }
}

var styles = StyleSheet.create({
    input: {
        height: 40,
        marginTop: 20,
        width: width * 0.85,
        fontSize: 14,
        color: '#333'
    }
})
export default Password
