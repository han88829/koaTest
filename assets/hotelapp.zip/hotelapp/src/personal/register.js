import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Dimensions, ToastAndroid, AsyncStorage, TouchableOpacity, Image } from 'react-native';
import Button from 'react-native-button';
import validator from 'validator';
import request from '../common/request';
import { parseString } from 'react-native-xml2js';
import icon from '../images/img';
import md5 from 'md5';

const width = Dimensions.get('window').width;
class Login extends Component {
    static navigationOptions = {
        title: "注册",
        header: null
    };
    constructor() {
        super();
        this.state = {
            getCaptchaButton: '获取验证码',
            captchaButtonStyle: styles.captchaButton,
            captchaButtonTextStyle: styles.capchaButtonText,
            loginButtonStyle: styles.loginButton,
            phoneNum: '',
            storedCaptcha: '',
            inputCaptcha: '',
            password: '',
            repeatPassword: '',
            loginState: false,
        }
    }
    /*发送验证码*/
    _sendCaptcha() {
        let phoneNum = this.state.phoneNum

        if (!validator.isMobilePhone(this.state.phoneNum, 'zh-CN')) {
            ToastAndroid.showWithGravity('手机号格式不正确!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }

        var token = md5('hotelApi_sendSms')
        let url = `sendCode?phone=${phoneNum}&token=${token}`;
        fetch('http://hotelapi.wecai360.com/' + url).then(x => x.json()).then((x) => {
            /*将验证码保存起来*/
            storage.save({
                key: 'captcha',
                data: String(x.code),
                expires: 1000 * 3600
            })
            storage.load({
                key: 'captcha',
            }).then(res => { this.setState({ storedCaptcha: res }) });
        }).catch(err => ToastAndroid.showWithGravity('操作失败!', ToastAndroid.SHORT, ToastAndroid.CENTER))

        var timer = 15;
        var i = setInterval(() => {
            timer--;
            this.setState({
                getCaptchaButton: timer + 's后重新发送',
                captchaButtonStyle: styles.captchaButton_disabled,
                captchaButtonTextStyle: styles.capchaButtonText_disabled
            })
            if (timer == 0) {
                clearInterval(i);
                this.setState({
                    getCaptchaButton: '获取验证码',
                    captchaButtonStyle: styles.captchaButton,
                    captchaButtonTextStyle: styles.capchaButtonText
                })
            }
        }, 1000)

    }

    /*点击注册,提交数据至后台接口*/
    _register = () => {
        const { navigate } = this.props.navigation;
        this.setState({
            loginButtonStyle: styles.loginButton_change,
            loginState: true
        })

        var storedCaptcha = this.state.storedCaptcha;
        var inputCaptcha = this.state.inputCaptcha;
        var phoneNum = this.state.phoneNum;
        var password = this.state.password;
        var repeatPassword = this.state.repeatPassword;

        if (!inputCaptcha) {
            ToastAndroid.showWithGravity('请输入验证码!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            this.setState({ loginState: false });
            return
        }
        if (inputCaptcha != storedCaptcha) {
            ToastAndroid.showWithGravity('验证码输入错误!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            this.setState({ loginState: false });
            return
        }
        if (!password) {
            ToastAndroid.showWithGravity('请输入密码!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            this.setState({ loginState: false });
            return
        }
        if (password != repeatPassword) {
            ToastAndroid.showWithGravity('两次密码输入不一致!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            this.setState({ loginState: false });
            return
        }

        var params = {
            user: 'admin',
            pwd: 'a',
            LoginName: String(phoneNum),
            LoginPWD: String(password),
            Name: '小明',
            Gender: '男'
        }

        fetch(`http://182.92.222.169:9611/CRS.asmx/crs1MemberRegisterJson?user=admin&pwd=a&LoginName=${String(phoneNum)}&LoginPWD=${String(password)}&Name="Mast"&Gender="男"`).then((x) => {
            return x.text();
        }).then((x) => {
            parseString(x, (err, json) => {
                let data = JSON.parse(json.string._);
                if (data[0].Result == '1') {
                    ToastAndroid.showWithGravity('注册失败，帐号已存在!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ loginState: false });
                    return;
                } else if (data[0].Result !== '0') {
                    ToastAndroid.showWithGravity('注册失败，请检查验证码是否正确!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ loginState: false });
                    return
                }
                ToastAndroid.showWithGravity('注册成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                navigate("Login");
            })
        }).catch((err) => {
            ToastAndroid.showWithGravity('登录请求失败，请重新登录!', ToastAndroid.SHORT, ToastAndroid.CENTER);
        })
    }

    render() {
        const { goBack } = this.props.navigation;
        return (
            <View style={styles.container}>
                <View style={{ height: 44, flexDirection: 'row' }}>
                    <TouchableOpacity
                        onPress={() => {
                            goBack()
                        }}
                        style={{ flex: 1, height: 44, paddingTop: 12 }}
                    >
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, marginLeft: 20 }}
                        />
                    </TouchableOpacity>
                    <View style={{ flex: 2 }}>

                    </View>
                </View>
                <Text style={styles.title}>账号注册</Text>
                <View style={styles.inputBox}>
                    <TextInput
                        style={styles.input}
                        placeholder="请输入手机号"
                        autoCaptialize="none"
                        keyboardType="numeric"
                        disabled={this.state.loginState}
                        onChangeText={(text) => {
                            this.setState({
                                phoneNum: text
                            })
                        }}
                    />
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                        <TextInput
                            style={styles.inputCaptcha}
                            placeholder="请输入验证码"
                            keyboardType='numeric'
                            disabled={this.state.loginState}
                            onChangeText={(text) => {
                                this.setState({
                                    inputCaptcha: text
                                })
                            }}
                        />
                        <TouchableOpacity style={this.state.captchaButtonStyle}  onPress={this._sendCaptcha.bind(this)}>
                            <Button
                                style={this.state.captchaButtonTextStyle}
                               
                            >{this.state.getCaptchaButton}</Button>
                        </TouchableOpacity>
                    </View>
                    <TextInput
                        style={styles.input}
                        placeholder="请输入密码"
                        secureTextEntry={true}
                        keyboardType='numeric'
                        disabled={this.state.loginState}
                        onChangeText={(text) => {
                            this.setState({
                                password: text
                            })
                        }}
                    />
                    <TextInput
                        style={styles.input}
                        secureTextEntry={true}
                        placeholder="请重复输入密码"
                        disabled={this.state.loginState}
                        keyboardType='numeric'
                        onChangeText={(text) => {
                            this.setState({
                                repeatPassword: text
                            })
                        }}
                    />
                </View>
                <TouchableOpacity style={this.state.loginButtonStyle} onPress={this._register}>
                    <Button
                        style={{ fontSize: 14, color: '#fff', paddingTop: 7 }}
                        
                        disabled={this.state.loginState}
                    >{this.state.loginState ? "正在注册请稍候..." : "注册"}</Button>
                </TouchableOpacity>
            </View >
        )
    }
}

var styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: "#fafafa"
    },
    back: {
        paddingLeft: 10,
        marginTop: 35,
        fontSize: 30,
        alignSelf: 'flex-start'
    },
    title: {
        marginTop: 40,
        fontSize: 20,
        fontFamily: 'PingFang-SC-Regular',
        color: "#333"
    },
    inputBox: {
        marginTop: 40,
        width: width - 40
    },
    input: {
        height: 40,
        marginTop: 20,
        width: width - 40,
        borderBottomColor: '#F0F0F0',
        borderBottomWidth: 1,
        fontSize: 14,
        color: '#333'
    },
    inputCaptcha: {
        height: 40,
        marginTop: 20,
        width: width * 0.65,
        borderBottomColor: '#F0F0F0',
        borderBottomWidth: 1,
        fontSize: 14,
        color: '#333'
    },
    captchaButton: {
        backgroundColor: '#008389',
        height: 26,
        width: 90,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#008389',
        marginTop: -10
    },
    captchaButton_disabled: {
        backgroundColor: '#f0f0f0',
        height: 26,
        width: 90,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#f0f0f0'
    },
    capchaButtonText: {
        fontSize: 12, color: '#fff', paddingTop: 3
    },
    capchaButtonText_disabled: {
        fontSize: 12, color: '#999999', paddingTop: 3
    },
    loginButton: {
        marginTop: 40,
        borderColor: '#008389',
        borderRadius: 5,
        width: width - 40,
        height: 40,
        borderWidth: 1,
        backgroundColor: '#008389'
    },
    loginButton_change: {
        marginTop: 40,
        borderColor: '#009197',
        borderRadius: 5,
        width: width - 40,
        height: 40,
        borderWidth: 1,
        backgroundColor: '#009197',
        paddingTop: 3
    }
});


export default Login
