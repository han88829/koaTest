import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Dimensions, Alert, AsyncStorage, ToastAndroid, TouchableOpacity, Image } from 'react-native';
import Button from 'react-native-button';
import request from '../common/request';
import { parseString } from 'react-native-xml2js';
import Storage from 'react-native-storage';
import icon from '../images/img';

const width = Dimensions.get('window').width;
class Login extends Component {
    static navigationOptions = {
        title: "登录",
        header: null
    };
    constructor() {
        super();
        this.state = {
            phoneNum: '',
            password: '',
            personalInfo: null,
            loginState: false
        }
    }
    _login = () => {
        const { navigate } = this.props.navigation;
        var phoneNum = this.state.phoneNum;
        var password = this.state.password;

        if (!phoneNum) {
            ToastAndroid.showWithGravity('手机号码不能为空!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return;
        }
        if (!password) {
            ToastAndroid.showWithGravity('登录密码不能为空!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return;
        }
        this.setState({ loginState: true });
        fetch(`http://182.92.222.169:9611/CRS.asmx/crsIfcMemberLoginJson?user=admin&pwd=a&rule=&CardNo=&IdNo=&Email=&Mobile=${phoneNum}&password=${password}`).then((x) => {
            return x.text();
        }).then((x) => {
            parseString(x, (err, json) => {
                let data = JSON.parse(json.string._);
                if (data[0].msgInfo || !data[0].Code) {
                    ToastAndroid.showWithGravity('登录失败，请检查帐号密码!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ loginState: false });
                    return;
                }
                ToastAndroid.showWithGravity('登录成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                // 本地数据存储
                storage.save({
                    key: 'personalInfo',
                    data: data[0],
                })
                if (this.props.navigation.state.params && this.props.navigation.state.params.selectHotel) {
                    navigate("SelectHotel", { 
                        position: this.props.navigation.state.params.position,
                        beginTime: this.props.navigation.state.params.beginTime,
                        endTime: this.props.navigation.state.params.endTime,
                        next: this.props.navigation.state.params.next,
                        today: this.props.navigation.state.params.today,
                        bTime: this.props.navigation.state.params.bTime,
                        total: this.props.navigation.state.params.total,
                    });
                    this.setState({ loginState: false });
                    return
                }
                this.setState({ loginState: false });
                navigate("App", { num: 3 });
            })

        }).catch((err) => {
            this.setState({ loginState: false });
            ToastAndroid.showWithGravity('登录请求失败，请重新登录!', ToastAndroid.SHORT, ToastAndroid.CENTER);
        })
    }
    render() {
        const { navigate, goBack } = this.props.navigation;
        return (
            <View style={styles.container}>
                <View style={{ height: 44, flexDirection: 'row' }}>
                    <TouchableOpacity
                        onPress={() => {
                            goBack()
                        }}
                        style={{ flex: 1, height: 44, paddingTop: 12 }}
                    >
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, marginLeft: 20 }}
                        />
                    </TouchableOpacity>
                    <View style={{ flex: 2 }}>

                    </View>
                </View>
                <Text style={styles.title}>账号登录</Text>
                <View style={styles.inputBox}>
                    <TextInput
                        style={styles.input}
                        underlineColorAndroid='transparent'
                        placeholder="请输入手机号"
                        onChangeText={(text) => {
                            this.setState({
                                phoneNum: text
                            })
                        }}
                    />
                    <TextInput
                        style={styles.input}
                        secureTextEntry={true}
                        placeholder="请输入登录密码"
                        underlineColorAndroid='transparent'
                        onChangeText={(text) => {
                            this.setState({
                                password: text
                            })
                        }}
                    />
                </View>
                <View style={styles.loginButton}>
                    <Button
                        style={{ fontSize: 14, color: '#fff', paddingTop: 7 }}
                        onPress={() => {
                            this.state.loginState ? null : this._login()
                        }}
                    >{this.state.loginState ? "正在登录请稍候..." : "登录"}</Button>
                </View>
                <View style={styles.operateBox}>
                    <Text
                        style={[styles.register, styles.operateText]}
                        onPress={() => {
                            navigate("register")
                        }}
                    >免费注册</Text>
                    <Text style={styles.operateText}>|</Text>
                    <Text
                        style={[styles.forgetPassword, styles.operateText]}
                        onPress={() => {
                            navigate('validateID')
                        }}
                    >忘记密码</Text>
                </View>
            </View >
        )
    }
}

var styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: "#fff"
    },
    back: {
        paddingLeft: 10,
        marginTop: 35,
        fontSize: 30,
        alignSelf: 'flex-start'
    },
    title: {
        marginTop: 40,
        fontSize: 20,
        fontFamily: 'PingFang-SC-Regular',
        color: "#333"
    },
    inputBox: {
        marginTop: 50,
        width: width - 40
    },
    input: {
        height: 40,
        marginTop: 20,
        width: width - 40,
        borderBottomColor: '#F0F0F0',
        borderBottomWidth: 1,
        fontSize: 14,
        color: '#333'
    },
    loginButton: {
        marginTop: 40,
        borderColor: '#008389',
        borderRadius: 5,
        width: width - 40,
        height: 40,
        borderWidth: 1,
        paddingTop: 3,
        backgroundColor: '#008389'
    },
    operateBox: {
        marginTop: 20,
        flexDirection: 'row'
    },
    operateText: {
        color: '#008389',
        fontSize: 12
    },
    register: {
        marginRight: 5
    },
    forgetPassword: {
        marginLeft: 5
    }
});


export default Login
