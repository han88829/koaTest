/*
 * @page:   联系人界面
 * @Author: Han 
 * @Date: 2017-09-15 10:17:44 
 * @Last Modified by: Han
 * @Last Modified time: 2017-09-19 14:30:58
 */
import React, { Component } from 'react';
import { View, Text, Dimensions, StyleSheet, TouchableOpacity, Image, ToastAndroid, Modal, TextInput } from 'react-native';
// import { CheckBox } from 'native-base';
import Checkbox from 'antd-mobile/lib/checkbox';
import Button from 'react-native-button';
import PhoneContact from './PhoneContact';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

class Contact extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataName: [{ name: this.props.name, value: false, tel: this.props.phone }],
      selectName: [this.props.name],
      num: props.room,
      selectNum: 1,
      offer: false,
      modalVisible: false,
      PhoneName: []
    }
  }

  componentDidMount() {
    let { dataName, selectName } = this.state;
    selectName.forEach(function (item, index) {
      dataName.forEach(function (element, i) {
        if (element.name === item) {
          dataName[index].value = true;
        }
      }, this);
    }, this);

    this.setState({
      dataName,
      selectName,
    });
  }
  cancel = () => {
    this.setState({ modalVisible: false });
  }

  confirm = (data) => {
    let { dataName } = this.state;
    let select = [];
    dataName.forEach(function (x) {
      select.push(x.name)
    }, this);
    data.forEach(function (x, i) {
      data[i].value = false;
      if (select.indexOf(x.name) < 0) {
        dataName.push(data[i])
      }
    }, this);
    this.setState({ modalVisible: false, dataName });
  }
  render() {
    return (
      <View style={styles.contect}>
        <View style={styles.header}>
          <Text
            style={{ flex: 1, textAlign: "left", color: "#008389", paddingLeft: 10 }}
            onPress={() => {
              this.props.cancel()
            }}
          >取消</Text>
          <Text style={{ flex: 2, textAlign: "center" }}>常用入住人</Text>
          <Text
            style={{ flex: 1, textAlign: "right", color: "#008389", paddingRight: 10 }}
            onPress={() => {
              let dataName = this.state.dataName;
              let data = [];
              dataName.forEach(function (item) {
                if (item.value) {
                  data.push(item.name)
                }
              }, this);
              this.props.confirm(data)
            }}
          >确定</Text>
        </View>
        <View style={styles.contact}>
          <Button
            style={styles.button}
            onPress={() => {
              this.setState({ modalVisible: true });
            }}
          >
            从通讯录中导入
          </Button>
        </View>
        {/* modal */}
        <Modal
          animationType={"slide"}
          transparent={false}
          visible={this.state.modalVisible}
          onRequestClose={() => { this.setState({ modalVisible: false }); }}
        >
          <PhoneContact cancel={this.cancel} confirm={this.confirm} name={this.props.name} phone={this.props.phone} />
        </Modal>
        <View style={styles.content}>
          <View style={{ flex: 1, flexDirection: 'column', }}>
            <Text
              style={{ fontSize: 10, paddingLeft: 10, borderBottomColor: "#ccc", borderBottomWidth: 0.5, paddingBottom: 10 }}
            >
              最多选择{this.state.num}人
            </Text>
            <View style={{ padding: 10 }}>
              {this.state.dataName.map((x, index) => {
                return (
                  <View key={index} style={{ flexDirection: 'row', marginTop: 5, height: 30, borderBottomColor: "#CCC", borderBottomWidth: 0.5 }}>
                    <Text style={{ flex: 6 }}>{x.name}</Text>
                    <View style={{ flex: 1 }}>
                      <Checkbox
                        style={{ width: 20, height: 20 }}
                        color="#008389"
                        checked={x.value}
                        disabled={this.state.selectNum < this.state.num ? false : x.value ? false : true}
                        onChange={(e) => {
                          let { num, dataName, selectNum, } = this.state;
                          if (e.target.checked) {
                            selectNum++;
                          } else {
                            selectNum--;
                          }
                          dataName[index].value = e.target.checked;
                          if (num === selectNum && !x.value) {
                            this.setState({ selectNum, dataName });
                            ToastAndroid.showWithGravity(`已添加${num}人！`, ToastAndroid.SHORT, ToastAndroid.CENTER);
                            return;
                          }

                          this.setState({
                            dataName,
                            selectNum
                          });
                        }}
                      />
                    </View>
                  </View>
                )

              })}
            </View>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  contect: {
    width: width,
    height: height,
    flex: 1,
    flexDirection: 'column',
  },
  header: {
    height: 30,
    width: width,
    flexDirection: 'row',
    paddingTop: 10
  },
  contact: {
    height: 50,
    width: width,
    padding: 10,
    marginTop: 10
  },
  button: {
    height: 30,
    width: width - 20,
    borderColor: "#008389",
    borderWidth: 1,
    color: "#008389",
    backgroundColor: "white",
    fontSize: 14,
    padding: 5,
    borderRadius: 3
  },
  content: {
    width: width,
    height: height - 110,

  }
})

export default Contact;