/*
 * @page:   关于我
 * @Author: Han
 * @Date: 2017-09-12 18:19:39
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:39:58
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableOpacity, SectionList, Image, Dimensions, StyleSheet, ToastAndroid } from 'react-native';
import icon from '../images/img'
import List from 'antd-mobile/lib/list';
import Picker from 'antd-mobile/lib/picker';
import { parseString } from 'react-native-xml2js';
import DateTimePicker from 'react-native-modal-datetime-picker';
import ActionSheet from 'antd-mobile/lib/action-sheet';
import moment from 'moment';
import { createForm } from 'rc-form';
import listStore from '../Hotel/Area';
import ImagePicker from 'react-native-image-picker';

let wrapProps;
const isIPhone = new RegExp('\\biPhone\\b|\\biPod\\b', 'i').test(window.navigator.userAgent);
if (isIPhone) {
    wrapProps = {
        onTouchStart: e => e.preventDefault(),
    };
}
const width = Dimensions.get('window').width;
const { City } = listStore;

var BUTTONS = [{ text: '男', color: '#008389' }, { text: '女', color: '#008389' }];
var DESTRUCTIVE_INDEX = 3;
var CANCEL_INDEX = 4;

var photoOptions = {
    //底部弹出框选项
    title: '请选择',
    cancelButtonTitle: '取消',
    takePhotoButtonTitle: '拍照',
    chooseFromLibraryButtonTitle: '选择相册',
    quality: 0.75,
    allowsEditing: true,
    noData: false,
    storageOptions: {
        skipBackup: true,
        path: 'images'
    }
}

const CustomChildren = props => (
    <TouchableOpacity style={styles.itemInfo}
        onPress={props.onClick}
    >
        <Text style={{ paddingLeft: 8, fontSize: 14, color: '#666' }}>{props.children}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text>{props.extra}</Text>
            <Image source={require('../images/qianjin.png')} style={{ marginLeft: 8 }} />
        </View>
    </TouchableOpacity>
);

class EditInfo extends Component {
    static navigationOptions = {
        title: "个人信息",
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            language: 'Java',
            clicked: '',
            birthDay: null,
            gender: null,
            userInfo: {},
            address: '',
            data: [],
            Visible: false,
            date: '',
            avatar: "data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAAA8AAD/4QNxaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6NkYxNDI1RjU0MjIwNjgxMTgwODM4RjQyOEIzQ0M4MUUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QjFCMzUwMkEzQUVCMTFFNEIzM0U4Q0I5MkNEOTVGMkMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTlDRDEwOTQzQUVCMTFFNEIzM0U4Q0I5MkNEOTVGMkMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkJDRTc1MDAyMzEyMDY4MTE4MDgzOUE3MjIxRTIwQTNGIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjZGMTQyNUY1NDIyMDY4MTE4MDgzOEY0MjhCM0NDODFFIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/+4ADkFkb2JlAGTAAAAAAf/bAIQABgQEBAUEBgUFBgkGBQYJCwgGBggLDAoKCwoKDBAMDAwMDAwQDA4PEA8ODBMTFBQTExwbGxscHx8fHx8fHx8fHwEHBwcNDA0YEBAYGhURFRofHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8f/8AAEQgAeAB4AwERAAIRAQMRAf/EAKAAAQACAwEBAQAAAAAAAAAAAAAEBQMGBwECCAEBAAMBAQEAAAAAAAAAAAAAAAMEBQIBBhAAAQMDAgIHAwQPCQAAAAAAAQACAxEEBRIGIUExUXGBIhMHYZEUwUIVCKGx0VJicoKiIzNDY9MlF/AykrLSg7PDNBEBAAIBAgQEBgIDAAAAAAAAAAECEQMEIRITBTFRYYFBwSIyQhRx0ZGhYv/aAAwDAQACEQMRAD8A6Op1MQEBAQEBAQEBAQEBAQEBAQEBAQUu4N47cwDf5nesilIq23bV8p7GNqe88F5M4exWZaq/1z2c00EF84dYij+WULnnh30pfP8AXXaFafC3/b5cP8ZOeDpS9Hrps8n/AM18P9uL+KnPB0pZ7X1o2tdTtgt7W/kmeaMY2GMk+6ROeDpSk/1a2sXXIDbkss26riUMjMYrwADhIQ4k8BTpXvPB0pX+2dz43cePdf44SC3bI6E+a3QdTQCaCp4eJexOXFq4Wy9eCAgICAgIOfeqXqI/b8LcZjHD6WuG6nS8CIIzwDqH57uXv6lza2EmnTLhFxcT3M757iR008h1SSvJc5xPMk8SolhjQesY97gxjS5x4BoFSe4ILKLCGIeZlJhYRdPluGq4d+LCPEO1+kIJUN1LduOLwkPwlvID8RO936V8beLnzy8NLAOJa3h2oImVvrfymY6wJ+AgOoyEUdPLShlcOrk0ch7SUH6B9MsS7GbKx0MjdM07DcyDnWY6217GFoUtY4Kt5zLaV05EBAQEBAQfl7PTZLP5vL5eOGSeNsrpZnsaXCKHVoj1U6GhoAqoLSuVrw4KRAQTn5zKuYWNuHRRkULIA2FpHtEYYCgx2uNu7lpmoI7cHx3Up0xj8o9J9gqfYgkXWRghtDj8dUQPobq5cKPncOjh82Mcm959gW3p5s+bcmeijew/RtsRLfSctANRHXrf0dlTyXtYy4vbEP0mAAAAKAcAB0UUys9QEBAQEBAQcl+r1blmbzzXjjHFHG4Hr8x3+lZm8nhDb2EcZb5uT0e2VnHPmFqcfdu4mezIjBP4UZBjPt8Nfaq1Nzevqtam1pb0c7y31d87CS7FZK3u2cmTtdA/s8PmtPvCs13kfGFW2wt8Jaxd+jvqJbE1xJlbydDLC+vcH6vsKWNzSfigna6kfBGd6c+os7mRyYe8f5Y0R6x4Wt6gXGgC669PNz+vqeTZtt+ge5r2Zj83JHjLWtXsa5s05HUAwlg7S7uUN93WPDin09lafu4Oy47beI29jIMdi4BDbsqXE8Xvfwq97vnOP9uC72WpNptM+iHuOlWkViPX5M6vswQEBAQEBAQaL6TYw2G9N7QkUbHcQlg/AmdNIz80hZe++Db7bxifZ1NUGmICAgIIWR/Z9/yLR7f+Xt82R3X8ff5Ia0mQICAgICAgIMOCxDLbO5bJMp/MI7UP69cAlbX/AAuas3uEeHu2O1Twt7fNA3mfUmW8gtNqNtILR8WqfI3JBeyQOI0BhD+GmhroPdzqafJjNl/V6mcUwi7Vb6s2mYjtdxuschinteZchAQyRjg3wNDQ2GtXfu+9e6nTmM1zEudPqxOLYmG8KBZc9zcXrRf5W7ZiZsficbDI5tpLJSR80YPhc6rJ6EjpGlvyqxXpRHHMyq3jWmZxiIX2zJd8mG6h3ZDbNlhc1tpc2rq+c0g63OaDwoaU4DsUeryfil0Zv+a3yP7Pv+RXe3/l7fNm91/H3+SGtJkCAgICAgIJeMt45rg+YNTI2OkLevTy+yoNxqTWuYWdppRe+J8EsXPmSuiJ8TGtdoHAAOJAoPyVi2mZ4y+jrWK8IYshDcz2FzDazfD3UsT2QXFNXlyOaQ19Oek8V5E8XtomY4KbYuG3HiMF8JuDI/Sd/wCa94n1Pk0xuppZrkAc6lCeI505LvVtWZzWMI9Glq1xacynfSc/3rfcfurjCxyq7euI3JmtvNtsBkfovIOkjkdOHPj1MAOpmuMOe3iQeHVRd6Vq1t9UZhX16WtGKziV5j4bmDH20N1N8RdRRMZPcUp5kjWgOfTlqPFcTPFJWJiOLML5tvd2lu8Bzb6UwaTxqRG+T7TCu9KZieCPViJjii5e1jtrwtj4Me0PDeqtRT7C2dC82rxfPbrTil8QhKZXEBAQEBBmtLl9tO2VnEjgWnoIPSFxqUi0Yl3pak0tmEe1ycE+8r+1jaWN+jrOZrDx4+fdNfT2f3Vk7nR5IhvbTcdWZn+F2qq6IKFdJV1b/qI/xW/aXKOWRHjV8/mWWm99p2hGvU+9uXNH7u0fG3/mKt7XT5sqO91uTC1u7qS5ndM/gT0AdAA5LVpSKxiGFq6k3tmWFduBAQEBAQEGrMvxaer1jC40ZkcQ+Bo5F8Uzph+a0qjvq5rlp9tti2PN0JZTbVeb3Pt/BtY7LX8Nn5v6tsjvE6nSQ0VcR3LqtLW8IcX1K18Zay71B2B5nhztuGdklf8AKpejfyeft6fm2DB7w2rmZPhsTk4LqaNtfJa6j9I5hrqEjsUdtO1fGCutW3hK6XCRynLZD431ytbVpqzGWDmOHU+RjpCfdK1amyriuWL3K2bY8m+q+yxAQEBAQEBBzj1bt8pYXGG3ZjW6pMPKfP5gNc5pbqp8wkFru1RatOaMJ9vqctsojPrIcPHt7jzIu/kMKz/0vVrfv/8AP+3NNzZ663fumfIyllq66IbBFNKPLjaxlGR+YQ1orTpIAqePWrVKclcKepedS+UcbUzrfHc2xs7bnd3JEUFOtsh4P7GVJ5L3qQdG3xjCJhcrc4nLWmTtiRNaSslbQ0rpNS2vU4cCvbVzGHFLcsxMOyH6x9pThgZCeo3LR/1ql+lPm0P348lX6Vy3+f35md0TxFkMjZOPSGvme0sjB4V0xtp7loaNOWMMvc6nNOfN2BTKogICAgICAg+J4IbiF8E7GywytLJI3gFrmuFCCDyKDiW+vR+/sJZL/b7HXdgaudZjxTRexo6ZG/ndvSo5qnpqebmj2PY4se0te00c0ihBHIhcJXiAg3bZ/pTn87Iye7Y7HYw0Lp5W0keP3cZ48fvjw7V1Fco7akQ7vhMJjcJjosfjohFbRculznHpc483FSRCCZynr14ICAgICAgICAg+XObUAkVPQOap72Po92n2qZ6k+WHiy2+9aRWlePUtDYx4yxu7TP0x/L6WgxhAQEBAQEBAQEHzJIyNjpHuDWNFXOPQAF5M4jMuqUm8xWsZmWsZHcdzM4stT5MXRq+ee/ks7V3Uz9vCH2Gx7Fp0iJ1Pqt5fCP7VttezwXTbkHXI08dXGteBqqs8W1bSrNeWIxDYWbmsDDrc17ZB+zpX3HoXHKoTs759FFkMjLeXXnkaNI0xgHoA9q7jgvaejFa8vik2G4b23IbKfPi5hx8Q7HfdVnT3Nq+PGGZvOyaOrGa/Rb08P8NotLuC7hE0LqtPSOYPUVoUvFozD47c7a+jfkvHFmXaAQEBAQEBAQa3ubIlzxZRnwtoZqczyHcqG71fxh9X2DY4jrW8Z+3+1CqT6YQEBAQTsPkXWV0CT+hf4ZW+zr7lNoavJb0ZvdNjG408R98eH9e7dAQQCDUHiCtZ8BMY4SICAg//2Q=="
        }
    }

    _back() {
        const { navigate, goBack } = this.props.navigation;
        navigate('App', { num: 3 })
    }


    componentDidMount() {
        storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            this.setState({ userInfo: x, avatar: x.CardNo ? "http://wecaihotelapp.oss-cn-hangzhou.aliyuncs.com/Avatar/" + x.CardNo + '.jpg' : "" });
        }).catch(err => {
            this.setState({ LoginSate: false });
        })
        storage.load({
            key: 'city',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            this.setState({ data: x });
        }).catch(err => {
            let data = [];
            for (let i = 0; i < City.length; i++) {
                let dataA = []
                for (let j = 0; j < City[i].city.length; j++) {
                    let dataB = []
                    let area = City[i].city[j].area || [];
                    for (let z = 0; z < area.length; z++) {
                        dataB.push({
                            value: City[i].city[j].area[z],
                            label: City[i].city[j].area[z],
                        });
                    }
                    dataA.push({
                        value: City[i].city[j].name,
                        label: City[i].city[j].name,
                        children: dataB
                    })
                }
                if (City[i].name == "北京" || City[i].name == "上海" || City[i].name == "香港" || City[i].name == "澳门") {
                    data.push({
                        value: City[i].name + '市',
                        label: City[i].name + '市',
                        children: dataA
                    })
                } else {
                    data.push({
                        value: City[i].name + '省',
                        label: City[i].name + '省',
                        children: dataA
                    })
                }
            }
            this.setState({ data });
            // 本地数据存储
            storage.save({
                key: 'city',
                data: data,
            })
        })

    }

    getInfo = () => {
        let userInfo = this.state.userInfo;
        // 更新缓存信息
        fetch(`http://182.92.222.169:9611/CRS.asmx/crsIfcMemberLoginJson?user=admin&pwd=a&rule=&CardNo=&IdNo=&Email=&Mobile=${userInfo.Mobile}&password=${userInfo.Password}`).then((x) => {
            return x.text();
        }).then((x) => {
            parseString(x, (err, json) => {
                let dataS = JSON.parse(json.string._);
                if (dataS[0].msgInfo || !dataS[0].Code) {
                    ToastAndroid.showWithGravity('更新信息失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    return;
                }
                //console.log(dataS)
                // 本地数据存储
                storage.save({
                    key: 'personalInfo',
                    data: dataS[0],
                })
                this.setState({ userInfo: dataS[0] });
                //ToastAndroid.showWithGravity('更新信息成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            })
        })
    }

    // 更新性别
    EditGender = (x) => {
        let userInfo = this.state.userInfo;
        userInfo.Gender = x;
        this.setState({ userInfo });
        let url = `user=admin&pwd=a&rule=&CardNo=${userInfo.Mobile}&ColName=Gender&finalValue=${x}`;
        fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberCardUpdateJson?' + url).then(x => x.text()).then((x) => {
            parseString(x, (err, json) => {
                let dataE = JSON.parse(json.string._);
                if (dataE[0].msgInfo && dataE[0].msgInfo.indexOf("OK") < 0) {
                    ToastAndroid.showWithGravity('修改失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    return;
                }
                //ToastAndroid.showWithGravity('修改成功,正在为您更新信息!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                this.getInfo()
            })
        }).catch(err => ToastAndroid.showWithGravity('修改失败!107', ToastAndroid.SHORT, ToastAndroid.CENTER));
    }

    // 更新生日
    getDate = (x) => {
        let userInfo = this.state.userInfo;
        let url = `user=admin&pwd=a&rule=&CardNo=${userInfo.Mobile}&ColName=BirthDate&finalValue=${moment(x).format('YYYY-MM-DD')}`;
        fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberCardUpdateJson?' + url).then(x => x.text()).then((x) => {
            parseString(x, (err, json) => {
                let dataE = JSON.parse(json.string._);
                if (dataE[0].msgInfo && dataE[0].msgInfo.indexOf("OK") < 0) {
                    ToastAndroid.showWithGravity('修改失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    return;
                }
                // console.log(dataE)
                //ToastAndroid.showWithGravity('修改成功,正在为您更新信息!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                this.getInfo()
            })
        })
    }

    // 修改地区
    EditAddress = async (x) => {
        this.setState({ address: x });
        let userInfo = this.state.userInfo;
        userInfo.State = x[0];
        userInfo.City = x[1];
        this.setState({ userInfo });
        let url = `user=admin&pwd=a&rule=&CardNo=${userInfo.Mobile}&ColName=State&finalValue=${x[0]}`;
        let urlC = `user=admin&pwd=a&rule=&CardNo=${userInfo.Mobile}&ColName=City&finalValue=${x[1]}`;
        try {
            let S = await fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberCardUpdateJson?' + url);
            let C = await fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberCardUpdateJson?' + urlC);
            let ST = await S.text();
            let CT = await C.text();
            let SD, CD;
            parseString(ST, (err, json) => {
                SD = JSON.parse(json.string._)[0];
            });
            parseString(CT, (err, json) => {
                CD = JSON.parse(json.string._)[0];
            })
            if (SD.msgInfo.indexOf("OK") < 0) {
                ToastAndroid.showWithGravity('省份修改失败（自治区、特别行政区）!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            } else {
                //ToastAndroid.showWithGravity('修改成功,正在为您更新信息!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            }
            this.getInfo()
        } catch (error) {
            ToastAndroid.showWithGravity('修改失败205!', ToastAndroid.SHORT, ToastAndroid.CENTER);
        }
    }

    // 性别选择
    showActionSheet = () => {
        const BUTTONS = ['男', '女', "取消"];
        ActionSheet.showActionSheetWithOptions({
            options: BUTTONS,
            cancelButtonIndex: BUTTONS.length - 1,
            message: '',
            maskClosable: false,
            'data-seed': 'logId',
            wrapProps,
        },
            (buttonIndex) => {
                if (buttonIndex === 0) {
                    this.EditGender('M')
                } else if (buttonIndex === 1) {
                    this.EditGender('F')
                }
            });
    }

    // 更换头像
    EditAvatar = () => {

        ImagePicker.showImagePicker(photoOptions, (response) => {
            if (response.didCancel) {
                //console.log('User cancelled image picker');
            }
            else if (response.error) {
                //console.log('ImagePicker Error: ', response.error);
            } else {

                let source = { uri: response.uri.replace('file://', ''), isStatic: true }
                let uri = response.uri;

                let formData = new FormData();
                let imgSuffix = response.fileName.substr(response.fileName.lastIndexOf('.'));
                let file = { uri: uri, type: 'multipart/form-data', name: this.state.userInfo.CardNo + imgSuffix };
                formData.append('avatar', file);
                const myFetchOptions = {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                    body: formData,
                };

                fetch('http://hotelapi.wecai360.com/uploadAvatar', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                    body: formData,
                }).then((res) => {
                    let _bodyText = JSON.parse(res._bodyText);

                    let img_url = _bodyText.url;
                    this.setState({
                        avatar: "https://gss0.baidu.com/-Po3dSag_xI4khGko9WTAnF6hhy/zhidao/pic/item/9e3df8dcd100baa10ecf73ac4710b912c9fc2ec1.jpg"
                    })
                    var timer = setTimeout(() => {
                        this.setState({
                            avatar: img_url
                        })
                        clearTimeout(timer);
                    }, 1000)
                    this.getInfo();
                }).catch((err) => {
                    // console.log(err);
                });

            }

        })
    }


    render() {
        const { navigate } = this.props.navigation;
        let userInfo = this.state.userInfo;
        return (
            <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center', backgroundColor: '#fff' }}>

                <View style={{ flexDirection: 'row', alignItems: 'center', paddingTop: 3, height: 44, width: width, borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, marginLeft: 10 }}
                        />
                    </TouchableOpacity>
                    <Text style={{ textAlign: 'center', fontSize: 16, flex: 2 }}>个人信息</Text>
                    <View style={{ flex: 1 }}></View>
                </View>

                <View style={{ flexDirection: 'column', alignItems: 'center', }}>
                    {/*头像*/}
                    <TouchableOpacity
                        style={styles.itemInfo}
                        onPress={this.EditAvatar}
                    >
                        <Text style={{ paddingLeft: 8, fontSize: 14, color: '#666' }}>头像</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Image source={{ uri: this.state.avatar }} style={{ width: 40, height: 40, borderRadius: 20, }} />
                            <Image source={require('../images/qianjin.png')} style={{ marginLeft: 8 }} />
                        </View>
                    </TouchableOpacity>

                    {/* 昵称 */}
                    <TouchableOpacity style={styles.itemInfo}
                        onPress={() =>
                            navigate('nickname', { title: "EnglishName", CardNo: userInfo.CardNo, userInfo })
                        }
                    >
                        <Text style={{ paddingLeft: 8, fontSize: 14, color: '#666' }}>英文名</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text>{userInfo.EnglishName || ""}</Text>
                            <Image source={require('../images/qianjin.png')} style={{ marginLeft: 8 }} />
                        </View>
                    </TouchableOpacity>
                    {/* 姓名 */}
                    <TouchableOpacity style={styles.itemInfo}
                        onPress={() =>
                            navigate('nickname', { title: "AlternateName", CardNo: userInfo.CardNo, userInfo })
                        }
                    >
                        <Text style={{ paddingLeft: 8, fontSize: 14, color: '#666' }}>中文名</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text>{userInfo.AlternateName || ""}</Text>
                            <Image source={require('../images/qianjin.png')} style={{ marginLeft: 8 }} />
                        </View>
                    </TouchableOpacity>

                    {/* 性别 */}
                    <TouchableOpacity style={styles.itemInfo}
                        onPress={this.showActionSheet}
                    >
                        <Text style={{ paddingLeft: 8, fontSize: 14, color: '#666' }}>性别</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text>{userInfo.Gender ? userInfo.Gender === "M" ? "男" : "女" : ''}</Text>
                            <Image source={require('../images/qianjin.png')} style={{ marginLeft: 8 }} />
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.itemInfo}
                        onPress={() => { this.setState({ Visible: true }); }}
                    >
                        {/* 出生日期   */}
                        <Text

                            style={{ textAlign: "left", flex: 1, marginLeft: 5 }}
                        >出生日期</Text>
                        <Text style={{ textAlign: "right", flex: 1, }}>{this.state.date ? this.state.date : userInfo.BirthDate ? moment(new Date(userInfo.BirthDate)).format("YYYY-MM-DD") : "无"}  </Text>
                        <Image source={require('../images/qianjin.png')} style={{ marginLeft: 3 }} />
                        <DateTimePicker
                            isVisible={this.state.Visible}
                            onConfirm={(x) => {
                                let date = moment(x).format("YYYY-MM-DD");
                                this.setState({ Visible: false, date });
                                this.getDate(x)
                            }}
                            onCancel={() => {
                                this.setState({ Visible: false });
                            }}
                        />
                    </TouchableOpacity>


                    {/* 手机号码 */}
                    <TouchableOpacity style={styles.itemInfo}
                        onPress={() =>
                            navigate('PhoneNum', { CardNo: userInfo.CardNo, userInfo })
                        }
                    >
                        <Text style={{ paddingLeft: 8, fontSize: 14, color: '#666' }}>手机号码</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text>{userInfo.Mobile}</Text>
                            <Image source={require('../images/qianjin.png')} style={{ marginLeft: 8 }} />
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity>
                        {/* 地区   */}
                        <Picker
                            data={this.state.data}
                            title="选择地区"
                            value={[userInfo.State, userInfo.City, ""]}
                            onChange={this.EditAddress}
                            extra="请选择"
                        >
                            <CustomChildren>地区</CustomChildren>
                        </Picker>

                    </TouchableOpacity>


                    {/* 详细地址 */}
                    <TouchableOpacity style={styles.itemInfo}
                        onPress={() =>
                            navigate('detailAddress', { CardNo: userInfo.CardNo, userInfo })
                        }
                    >
                        <Text style={{ paddingLeft: 8, fontSize: 14, color: '#666' }}>详细地址</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text>{userInfo.HomeAddress || "请填写详细地址"}</Text>
                            <Image source={require('../images/qianjin.png')} style={{ marginLeft: 8 }} />
                        </View>
                    </TouchableOpacity>

                </View>
            </View >
        );
    }
}

const styles = StyleSheet.create({
    itemInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: width - 40,
        height: 54,
        paddingTop: 8,
        paddingBottom: 8,
        borderBottomWidth: 1,
        borderBottomColor: '#F0F0F0'
    }
})


export default EditInfo