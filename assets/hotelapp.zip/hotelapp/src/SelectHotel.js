/*
 * @page:   选择酒店
 * @Author: Han 
 * @Date: 2017-09-12 18:19:30 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 16:18:08
 */
import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    ListView,
    RefreshControl,
    SectionList,
    ScrollView,
    TextInput,
    Image,
    Button,
    TouchableOpacity,
    Dimensions,
    Alert,
    Modal,
    ToastAndroid
} from 'react-native';
import { SearchBar } from 'react-native-elements';
import { parseString } from 'react-native-xml2js';
import SelectAdders from './Hotel/SelectAdders';
import icon from './images/img';


class SelectHotel extends Component {
    static navigationOptions = {
        title: "宁波",
        header: null,
    };
    constructor(props) {
        super(props);
        this.state = {
            dataSource: [],
            data: [],
            dataNull: [],
            refreshing: false,
            num: 5,
            text: '请输入！',
            offer: false,
            position: props.navigation.state.params ? props.navigation.state.params.position : "成都市",
            getData: "正在加载请稍候。。。",
            loginState: false,
            modalVisible: false
        }
    }

    componentDidMount() {
        // 获取登录状态
        storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            this.setState({ loginState: true });
        }).catch(err => {
            this.setState({ loginState: false });
        })
        // 获取酒店列表
        let dataSource = [], data = [];
        let num = this.state.num;
        let url = `user=admin&pwd=a&Language=&GroupCode=&CityCode=${this.state.position}&ArrivalDate=&DepartureDate=&Rooms=&Persons=`;
        fetch('http://182.92.222.169:9611/CRS.asmx/crs1GetPropertyInfoListJson?' + url).then((x) => {
            return x.text();
        }).then((x) => {
            parseString(x, (err, json) => {
                dataSource = JSON.parse(json.string._);
                if (!dataSource[0].Address || dataSource.length <= 0) {
                    //ToastAndroid.showWithGravity('所地区未查询到酒店就重新选择地区！!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ getData: '', dataNull: [1] });
                    return
                }
                if (dataSource.length <= num) {
                    for (let i = 0; i < dataSource.length; i++) {
                        data.push(dataSource[i])
                    }
                } else {
                    for (let i = 0; i < num; i++) {
                        data.push(dataSource[i])
                    }
                }
                this.setState({
                    dataSource,
                    data,
                    getData: "到底啦~"
                });
            })
        }).catch(err => this.setState({ dataNull: [1] }));
    }

    getHotel = (position) => {
        // 获取酒店列表
        let dataSource = [], data = [];
        let num = this.state.num;
        let url = `user=admin&pwd=a&Language=&GroupCode=&CityCode=${position ? position : this.state.position}&ArrivalDate=&DepartureDate=&Rooms=&Persons=`;
        fetch('http://182.92.222.169:9611/CRS.asmx/crs1GetPropertyInfoListJson?' + url).then((x) => {
            return x.text();
        }).then((x) => {
            parseString(x, (err, json) => {
                dataSource = JSON.parse(json.string._);
                if (!dataSource[0].Address || dataSource.length <= 0) {
                    //ToastAndroid.showWithGravity('所地区未查询到酒店就重新选择地区！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ getData: '', dataNull: [1] });
                    return
                }
                if (dataSource.length <= num) {
                    for (let i = 0; i < dataSource.length; i++) {
                        data.push(dataSource[i])
                    }
                } else {
                    for (let i = 0; i < num; i++) {
                        data.push(dataSource[i])
                    }
                }
                this.setState({
                    dataSource,
                    data,
                    getData: "到底啦~"
                });
            })
        }).catch(err => this.setState({ dataNull: [1] }));
    }

    MoadlConfirm = (x) => {
        this.setState({ modalVisible: false, position: x });
        this.getHotel(x);
    }
    MoadlCancel = () => {
        this.setState({ modalVisible: false });
    }
    render() {
        const { navigate, goBack } = this.props.navigation;
        const width = Dimensions.get('window').width;
        const height = Dimensions.get('window').height;
        return (
            <View style={{ flex: 1, flexDirection: 'column', backgroundColor: "#fff" }}>
                <View style={{ height: 44, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
                    <TouchableOpacity
                        style={{ flex: 1, height: 44, paddingTop: 12 }}
                        underlayColor="rgba(204, 204, 204, 0)"
                        onPress={() => {
                            goBack()
                        }}
                    >
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, marginLeft: 15 }}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={{ flex: 4, flexDirection: 'row', justifyContent: 'center', }}
                        onPress={() => {
                            this.setState({ modalVisible: true });
                        }}
                    >
                        <Text style={{ textAlign: "center", fontSize: 16, color: "#333" }}>{this.state.position}</Text>
                        <Image
                            source={{ uri: icon.down }}
                            style={{ height: 10, width: 13, marginTop: 5, marginLeft: 3 }}
                        />
                    </TouchableOpacity>
                    {/* 选择城市modal */}
                    <Modal
                        animationType={"slide"}
                        transparent={false}
                        visible={this.state.modalVisible}
                        onRequestClose={() => { this.setState({ modalVisible: false }); }}
                    >
                        <SelectAdders onClick={this.MoadlConfirm} cancle={this.MoadlCancel} />
                    </Modal>
                    <View style={{ flex: 1 }}>

                    </View>
                </View>
                {/* 中间详细酒店信息 */}
                <View style={{ flex: 12, padding: 20, paddingTop: 0 }}>
                    <SectionList
                        sections={[
                            { data: this.state.data.length > 0 ? this.state.data : this.state.dataNull },
                        ]}
                        showsVerticalScrollIndicator={false}
                        onRefresh={this.getHotel}
                        refreshing={this.state.refreshing}
                        onEndReachedThreshold={0.1}
                        onEndReached={() => {
                            this.setState({ refreshing: true });
                            let dataSource = this.state.dataSource;
                            let data = [];
                            let num = this.state.num, offer = false;

                            num += 5;
                            if (num >= dataSource.length) {
                                for (let i = 0; i < dataSource.length; i++) {
                                    data.push(dataSource[i])
                                }
                                offer = true;
                            } else {
                                for (let i = 0; i < num; i++) {
                                    data.push(dataSource[i])
                                }
                            }
                            this.setState({
                                data,
                                num,
                                refreshing: false,
                                offer
                            });
                        }}
                        keyExtractor={(item, i) => i}
                        ListFooterComponent={() => {
                            return this.state.offer ? <Text style={{ textAlign: "center", marginTop: 10, color: "#999", fontSize: 12 }}>{this.state.getData}</Text> : <Text></Text>
                        }}
                        renderItem={({ item, index }) => {
                            return (
                                this.state.data.length > 0 ?
                                    < TouchableOpacity
                                        key={index}
                                        activeOpacity={1}
                                        onPress={() => {
                                            
                                            if (this.props.navigation.state.params) {
                                                if (!this.state.loginState) {
                                                    ToastAndroid.showWithGravity('请先登录！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                                    navigate('Login', { 
                                                        selectHotel: true, 
                                                        position: this.state.position ,
                                                        beginTime: this.props.navigation.state.params.beginTime,
                                                        endTime: this.props.navigation.state.params.endTime,
                                                        next: this.props.navigation.state.params.next,
                                                        today: this.props.navigation.state.params.today,
                                                        bTime: this.props.navigation.state.params.bTime,
                                                        total: this.props.navigation.state.params.total,
                                                    });
                                                    return
                                                }
                                                let data = {
                                                    beginTime: this.props.navigation.state.params.beginTime,
                                                    endTime: this.props.navigation.state.params.endTime,
                                                    next: this.props.navigation.state.params.next,
                                                    today: this.props.navigation.state.params.today,
                                                    bTime: this.props.navigation.state.params.bTime,
                                                    position: this.state.position,
                                                    code: item.code,
                                                    Price: item.Price,
                                                    Address: item.Address,
                                                    Telephone: item.Telephone,
                                                    PictureURL: item.PictureURL,
                                                    total: this.props.navigation.state.params.total,
                                                }
                                                navigate('SelectRoom', { data })
                                                return
                                            }
                                            if (!this.state.loginState) {
                                                ToastAndroid.showWithGravity('请先登录！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                   
                                                navigate('Login', { selectHotel: true, position: this.state.position });
                                                return
                                            }
                                            let data = {
                                                position: this.state.position,
                                                code: item.code,
                                                Price: item.Price,
                                                Address: item.Address,
                                                Telephone: item.Telephone,
                                                PictureURL: item.PictureURL
                                            }
                                            navigate('SelectRoom', { data })
                                        }}
                                        style={{ marginTop: 10, borderBottomColor: "#f0f0f0", borderBottomWidth: index === this.state.data.length - 1 ? 1 : 0, paddingBottom: 10 }}
                                    >
                                        <View style={{ flex: 1, flexDirection: 'column', height: 220 }}>
                                            <View style={{ flex: 5, }}>
                                                <Image
                                                    source={{ uri: item.PictureURL }}
                                                    style={{ height: 170, width: width - 20 }}
                                                />
                                            </View>
                                            <View style={{ flex: 1, flexDirection: 'row', }}>
                                                <View style={{ flex: 1, paddingTop: 0 }}>
                                                    <Text >{item.code}</Text>
                                                    <Text style={{ fontSize: 10, color: "#999999" }}>{item.PropertyType}</Text>
                                                </View>
                                                <View style={{ flex: 1, }}>
                                                    <Text style={{ color: "#008389", textAlign: "right" }}>￥ {item.Price}/晚</Text>
                                                </View>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                    :
                                    <View style={{ flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: height - 200 }}>
                                        <Image source={require('./images/jiudian.png')} style={{ width: 60, height: 60 }} />
                                        <Text style={{ marginTop: 10, color: "#ccc", fontSize: 14 }}>当前城市暂无酒店信息</Text>
                                    </View>
                            )
                        }}

                    />
                </View>
            </View >
        )
    }
}

export default SelectHotel;