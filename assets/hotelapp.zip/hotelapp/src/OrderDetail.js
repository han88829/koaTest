import React, { Component } from 'react';
import { Text, ToastAndroid, View, TouchableOpacity, Image, StyleSheet, Dimensions, Linking } from 'react-native';
import { parseString } from 'react-native-xml2js';
import icon from './images/img';
import MapLinking from 'react-native-map-linking';//打开外部地图
import moment from 'moment';
// import Modal from 'antd-mobile/lib/modal';//关闭
// import Button from 'antd-mobile/lib/button';
// import Toast from 'antd-mobile/lib/toast';

// const prompt = Modal.prompt;

const width = Dimensions.get('window').width;

class OrderDetail extends Component {
    static navigationOptions = {
        title: "订单详情",
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            data: { hotelDetail: {} },
            state: this.props.navigation.state.params.state
        }
    }

    componentDidMount() {
        let user = storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        });
        let url = `user=admin&pwd=a&rule=&reservationCode=${this.props.navigation.state.params.OrderNumber}`;
        // 查询订单信息
        fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcReservationListByCodeJson?' + url).then(x => x.text()).then((x) => {
            parseString(x, (err, json) => {
                let data = JSON.parse(json.string._)[0];
                // 查询酒店信息
                fetch(`http://182.92.222.169:9611/CRS.asmx/crsIfcRoomTypeDetailJson?user=admin&pwd=a&rule=&Hotel=${data.Property}&roomType= `).then(x => x.text()).then((z) => {
                    parseString(z, (err, jsonH) => {
                        data.hotelDetail = JSON.parse(jsonH.string._)[0];
                        this.setState({ data });
                    })
                })
            })
        }).catch(err => ToastAndroid.showWithGravity('查询订单信息失败！', ToastAndroid.SHORT, ToastAndroid.CENTER));
    }

    // 返回
    _back() {
        const { goBack } = this.props.navigation;
        goBack();
    }

    //转换地址坐标
    positionApi = () => {
        let data = this.state.data;

        let url = `output=json&address=${data.hotelDetail.Address}&ak=GuYLMTSrRt7KKnoFRVRpSEhwAwm2gGal`;
        fetch('http://api.map.baidu.com/geocoder/v2/?' + url).then((x) => {
            return x.json();
        }).then((x) => {
            if (x.status != 0) {
                ToastAndroid.showWithGravity('地址获取失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                return
            }
            let lat = x.result.location.lat;
            let lng = x.result.location.lng;
            let title = data.Property, content = data.hotelDetail.Address;
            MapLinking.markLocation({ lat, lng }, title, content);
        }).catch(err => ToastAndroid.showWithGravity('地址获取失败!', ToastAndroid.SHORT, ToastAndroid.CENTER))
    }

    // 取消 预订
    onEditOrder = (x) => {
        let data = this.state.data;
        const { navigate } = this.props.navigation;
        try {
            switch (x) {
                case "cancel":
                    let url = `user=admin&pwd=a&rule=&rvCancellationReason=&reservationCode=${data.CRSNo}`;
                    fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcReservationCancelJson?' + url).then(x => x.text()).then((x) => {
                        parseString(x, (err, json) => {
                            let a = JSON.parse(json.string._)[0];
                            if (a.msgInfo && a.msgInfo.indexOf("OK") >= 0) {
                                ToastAndroid.showWithGravity('操作成功!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                navigate('App',{num:2})
                            }
                        })
                    })

                    break;
                case "delete":

                    break;
                case "again":
                    let GetHotel = {
                        code: data.Property,
                        Address: data.hotelDetail.Address,
                        Telephone: data.hotelDetail.Phone
                    }
                    navigate('SelectRoom', { data: GetHotel })
                    break;

                default:
                    break;
            }
        } catch (error) {
            ToastAndroid.showWithGravity('操作失败!', ToastAndroid.SHORT, ToastAndroid.CENTER)
        }
    }

    render() {
        let data = this.state.data;
        let S = this.state.state;
        return (
            <View style={styles.order}>
                <View style={styles.header}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20, }}
                        />
                    </TouchableOpacity>
                    <Text style={{ flex: 1, fontSize: 16, textAlign: 'center', color: "#333" }}>订单详情</Text>
                    <View style={{ flex: 1 }}></View>
                </View>
                {/* 详情内容 */}
                <View style={styles.content}>
                    <View style={{ padding: 20, paddingTop: 15 }}>
                        <Text style={{ paddingBottom: 10, color: S === "PP" ? "#008389" : S === "NOG" ? "#2C99CD" : "#999", height: 30, }}>{S === "PP" ? "待入住" : S === "NOG" ? "已完成" : "已取消"}</Text>
                        <Text style={{ height: 30, borderTopColor: "#f0f0f0", borderTopWidth: 1, paddingTop: 15, fontSize: 12 }}>房费 ￥{data.RoomRate}</Text>
                        {/* 根据订单状态显示按钮 */}
                        <View style={{ height: 50, width: width, marginTop: 20, backgroundColor: "#f1f1f1", marginLeft: -20, paddingLeft: 20, paddingTop: 10 }}>
                            {S === "PP" ?
                                <Text style={styles.buttonO} onPress={this.onEditOrder.bind(this, 'cancel')}>取消订单</Text>
                                :
                                <Text style={styles.buttonTS} onPress={this.onEditOrder.bind(this, 'again')}>再次预订</Text>

                            }
                        </View>
                        <Text style={{ marginTop: 15, fontWeight: 'bold', color: "#333" }}>{data.Property}</Text>
                        <Text style={{ marginTop: 12, fontSize: 10, color: "#333" }}>{this.props.navigation.state.params.type} {data.Rooms}间</Text>
                        <Text style={{ fontSize: 10, color: "#333" }}>{moment(new Date(data.InsertDate)).format("YYYY-MM-DD")}  -  {moment(new Date(data.DepartureDate)).format("YYYY-MM-DD")}</Text>
                        <View style={styles.address}>
                            <Text style={{ fontSize: 11 }}>地址：{data.hotelDetail.Address}</Text>
                            <TouchableOpacity
                                underlayColor="rgba(204, 204, 204, 0)"
                                onPress={this.positionApi}
                            >
                                <Image
                                    source={require('./images/position.png')}
                                />
                            </TouchableOpacity>
                        </View>
                        <View style={styles.phone}>
                            <Text style={{ fontSize: 11 }}>电话：{data.hotelDetail.Phone}</Text>
                            <TouchableOpacity
                                underlayColor="rgba(204, 204, 204, 0)"
                                onPress={() => {
                                    return Linking.openURL(`tel:${data.hotelDetail.Phone}`)
                                }}
                            >
                                <Image
                                    source={require('./images/phone.png')}
                                />
                            </TouchableOpacity>
                        </View>


                    </View>
                    <View style={{ height: 10, backgroundColor: "#f1f1f1", marginTop: -5 }}>

                    </View>
                    <View style={{ padding: 20, paddingTop: 10 }}>
                        <Text style={styles.detail}>订单信息</Text>
                        <Text style={{ fontSize: 11, marginTop: 5 }}>入住人         {data.CallerName}</Text>
                        <Text style={{ fontSize: 11, marginTop: 5 }}>手机号         {data.CallerPhone}</Text>
                        <Text style={{ fontSize: 11, marginTop: 5 }}>订单号         {data.CRSNo}</Text>
                        <Text style={{ fontSize: 11, marginTop: 5 }}>下单时间     {data.InsertDate}</Text>
                    </View>
                    <View style={{ flex: 1, backgroundColor: "#f1f1f1" }}></View>

                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    order: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: 'white'
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        padding: 5,
        paddingBottom: 5,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
        height: 40
    },
    content: {
        flex: 1,
        flexDirection: 'column',
    },
    buttonO: {
        height: 30,
        borderColor: "#f0f0f0",
        borderRadius: 5,
        borderWidth: 1,
        width: width - 40,
        textAlign: 'center',
        padding: 5,
        backgroundColor: "#fff"
    },
    buttonT: {
        height: 30,
        borderColor: "#f0f0f0",
        borderRadius: 5,
        borderWidth: 1,
        width: (width - 40) / 2,
        textAlign: 'center',
        padding: 5,
        marginLeft: 5
    },
    buttonTS: {
        height: 30,
        borderColor: "#008389",
        borderRadius: 5,
        borderWidth: 1,
        width: width - 40,
        textAlign: 'center',
        padding: 5,
        color: "#008389",
        backgroundColor: "#fff"
    },
    address: {
        height: 30,
        flexDirection: 'row',
        alignItems: 'center',
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
        marginTop: 10,
        paddingTop: 10,
        justifyContent: 'space-between',
        paddingRight: 5
    },
    phone: {
        height: 30,
        flexDirection: 'row',
        alignItems: 'center',
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
        marginTop: 10,
        paddingTop: 10,
        justifyContent: 'space-between',
        paddingRight: 5
    },
    detail: {
        height: 30,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
        fontWeight: "bold",
        fontSize: 12,
        color: "#333"
    }

})

export default OrderDetail;