/*
 * @page:   首页
 * @Author: Han 
 * @Date: 2017-09-12 18:19:30 
 * @Last Modified by: Han
 * @Last Modified time: 2017-09-29 10:59:46
 */
import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    Button,
    TouchableOpacity,
    Dimensions,
    Alert,
    ToastAndroid,
    Modal,
    ScrollView
} from 'react-native';
import Home from './Home';
import Mine from './Mine';
import OrderView from './OrderView';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

class App extends Component {
    static navigationOptions = {
        title: "首页",
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            selectN: props.navigation.state.params ? props.navigation.state.params.num : 1,
            isLogin: false,
            user: {}
        }
    }

    componentWillMount() {
        const { navigate } = this.props.navigation;
        storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            if (!x.Code) {
                this.setState({ isLogin: false });
                return
            }
            this.setState({ isLogin: true, user: x });
        }).catch(err => {
            this.setState({ isLogin: false });
        })
    }



    render() {
        const { navigate } = this.props.navigation;

        return (
            <View style={{ width: width, height: height, flexDirection: 'column', position: "relative" }}>
                <View style={{ height: height - 69, width: width }}>
                    {/* 状态存储 */}
                    <View style={{ flex: this.state.selectN === 1 ? 1 : 0 }}>
                        <Home navigation={this.props.navigation} />
                    </View>
                    <View style={{ flex: this.state.selectN === 3 ? 1 : 0 }}>
                        <Mine navigation={this.props.navigation} />
                    </View>
                    <View style={{ flex: this.state.selectN === 2 ? 1 : 0 }}>
                        <OrderView navigation={this.props.navigation} />
                    </View>
                    {/* {this.state.selectN === 1 ? <Home navigation={this.props.navigation} /> : null}
                    {this.state.selectN === 3 ? <Mine navigation={this.props.navigation} /> : null}
                    {this.state.selectN === 2 ? <OrderView navigation={this.props.navigation} /> : null} */}
                </View>
                <View style={styles.foot}>
                    <TouchableOpacity
                        style={styles.footItem}
                        underlayColor="#ccc"
                        onPress={() => {
                            this.setState({ selectN: 1 });
                        }}
                    >
                        <View style={styles.ItemC}>
                            <View style={{ flex: 2 }}>
                                <Image style={{ marginTop: 5 }} source={this.state.selectN === 1 ? require('./images/homeS.png') : require('./images/home.png')} />
                            </View>
                            <View style={{ flex: 1 }}>
                                <Text style={{ marginTop: -5, fontSize: 11, color: this.state.selectN === 1 ? "#008389" : '#666' }}>首页</Text>
                            </View>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.footItem}
                        underlayColor="#ccc"
                        onPress={() => {
                            if (!this.state.isLogin) {
                                ToastAndroid.showWithGravity('请先登录!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                navigate("Login")
                                return
                            }
                            this.setState({ selectN: 2 });
                        }}
                    >
                        <View style={styles.ItemC}>
                            <View style={{ flex: 2 }}>
                                <Image style={{ marginTop: 5 }} source={this.state.selectN === 2 ? require('./images/dingdans.png') : require('./images/dingdan.png')} />
                            </View>
                            <View style={{ flex: 1 }}>
                                <Text style={{ marginTop: -5, fontSize: 11, color: this.state.selectN === 2 ? "#008389" : '#666' }}>订单</Text>
                            </View>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.footItem}
                        underlayColor="#ccc"
                        onPress={() => {
                            this.setState({ selectN: 3 });
                        }}
                    >
                        <View style={styles.ItemC}>
                            <View style={{ flex: 2 }}>
                                <Image style={{ marginTop: 5 }} source={this.state.selectN === 3 ? require('./images/mine.png') : require('./images/mineS.png')} />
                            </View>
                            <View style={{ flex: 1 }}>
                                <Text style={{ marginTop: -5, fontSize: 11, color: this.state.selectN === 3 ? "#008389" : '#666' }}>我的</Text>
                            </View>
                        </View>
                    </TouchableOpacity>
                </View>
            </View >

        )
    }
}

const styles = StyleSheet.create({
    foot: {
        width: width,
        height: 49,
        flexDirection: 'row',
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
        backgroundColor: '#fff',
        position: "absolute",
        bottom: 20
    },
    footItem: {
        flex: 1
    },
    ItemC: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    wrapper: {
    },
    slide1: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#9DD6EB',
    },
    slide2: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#97CAE5',
    },
    slide3: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#92BBD9',
    },
    text: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
    },
    bottomItem: {
        height: 50,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
    },
    title: {
        fontWeight: '500',
    },
});


export default App;