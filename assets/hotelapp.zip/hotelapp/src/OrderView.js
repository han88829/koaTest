import React, { Component } from 'react';
import { Text, View, StyleSheet, ListView, Image, SectionList, TouchableOpacity, ToastAndroid, Dimensions, PanResponder } from 'react-native';
import { parseString } from 'react-native-xml2js';


const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

class OrderView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            select: 1,
            data: [],
            refreshing: false,
            dataSource: [],
            offer: false,
            getData: '正在加载请稍候。。。',
            State: false,
            dataAll: [],
            length: 0
        }
    }


    componentDidMount() {

        let dataSource = [], data = [], offer = false;
        try {
            getAll = async () => {
                let user = await storage.load({
                    key: 'personalInfo',
                    autoSync: true,
                    syncInBackground: true,
                });
                let url = await `user=admin&pwd=a&Language=&OrderNumber=&TelPhone=&LoginName=${user.Mobile}&LoginPwd=${user.Password}`;
                let getOrder = await fetch('http://182.92.222.169:9611/CRS.asmx/crs1GetOrderListJson?' + url);
                let getOrderData = await getOrder.text();
                parseString(getOrderData, (err, json) => {
                    dataSource = JSON.parse(json.string._);
                    if (!dataSource[0].OrderNumber) {
                        //ToastAndroid.showWithGravity('未查询到订单信息！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                        this.setState({ getData: '未查询到订单信息！', data: [] });
                        return
                    }
                    for (let i = 0; i < dataSource.length; i++) {
                        data.push(dataSource[i]);
                    }
                    offer = true;
                    this.setState({
                        dataSource,
                        data,
                        getData: '',
                        dataAll: dataSource,
                        offer
                    });
                })
            }
        } catch (error) {
            // console.log(err)
        }

        getAll()
    }

    getOrder = async () => {
        try {
            let dataSource = [], data = [], offer = false;
            let select = this.state.select;
            let user = await storage.load({
                key: 'personalInfo',
                autoSync: true,
                syncInBackground: true,
            });
            let url = await `user=admin&pwd=a&Language=&OrderNumber=&TelPhone=&LoginName=${user.Mobile}&LoginPwd=${user.Password}`;
            let getOrder = await fetch('http://182.92.222.169:9611/CRS.asmx/crs1GetOrderListJson?' + url);
            let getOrderData = await getOrder.text();
            parseString(getOrderData, (err, json) => {
                dataSource = JSON.parse(json.string._);
                if (!dataSource[0].OrderNumber) {
                    ToastAndroid.showWithGravity('未查询到订单信息！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ getData: '未查询到订单信息！', data: [] });
                    return
                }
                offer = true;
                for (let i = 0; i < dataSource.length; i++) {
                    switch (select) {
                        case 1:
                            data.push(dataSource[i]);
                            break;
                        case 2:
                            if (dataSource[i].Status === "PP") {
                                data.push(dataSource[i]);
                            }
                            break;
                        case 3:
                            if (dataSource[i].Status === "NOG") {
                                data.push(dataSource[i]);
                            }
                            break;
                        case 4:
                            if (dataSource[i].Status === "Cancellation") {
                                data.push(dataSource[i]);
                            }
                            break;

                        default:
                            break;
                    }

                }

                this.setState({
                    dataSource,
                    data,
                    getData: '',
                    dataAll: dataSource,
                    offer
                });
            })
        } catch (error) {

        }
    }

    render() {
        let { select } = this.state;
        const dataNull = [1];
        const { navigate } = this.props.navigation;
        return (
            <View style={styles.OrderView}>
                <Text style={styles.header}>我的订单</Text>
                <View style={styles.tabs}>
                    <Text
                        style={{
                            flex: 1,
                            textAlign: "center",
                            color: select === 1 ? "#008389" : '#666',
                            borderBottomColor: "#008389",
                            borderBottomWidth: select === 1 ? 2 : 0,
                            paddingBottom: 5,
                            height: 30
                        }}
                        onPress={() => {
                            this.setState({ refreshing: true });
                            let data = this.state.data;
                            let dataAll = this.state.dataAll;
                            this.setState({ select: 1, data: dataAll, refreshing: false });
                        }}
                    >
                        全部订单
                    </Text>
                    <Text
                        style={{
                            flex: 1,
                            textAlign: "center",
                            color: select === 2 ? "#008389" : '#666',
                            borderBottomColor: "#008389",
                            borderBottomWidth: select === 2 ? 2 : 0,
                            paddingBottom: 5,
                            height: 30
                        }}
                        onPress={() => {
                            this.setState({ refreshing: true });
                            let data = [];
                            let dataAll = this.state.dataAll;
                            dataAll.forEach(function (x, i) {
                                if (x.Status === "PP") {
                                    data.push(x)
                                }
                            }, this);
                            this.setState({ select: 2, data, refreshing: false });
                        }}
                    >
                        待入住
                    </Text>
                    <Text
                        style={{
                            flex: 1,
                            textAlign: "center",
                            color: select === 3 ? "#008389" : '#666',
                            borderBottomColor: "#008389",
                            borderBottomWidth: select === 3 ? 2 : 0,
                            paddingBottom: 5,
                            height: 30
                        }}
                        onPress={() => {
                            this.setState({ refreshing: true });
                            let data = [];
                            let dataAll = this.state.dataAll;
                            dataAll.forEach(function (x, i) {
                                if (x.Status === "NOG") {
                                    data.push(x)
                                }
                            }, this);
                            this.setState({ select: 3, data, refreshing: false });
                        }}
                    >
                        已完成
                    </Text>
                    <Text
                        style={{
                            flex: 1,
                            textAlign: "center",
                            color: select === 4 ? "#008389" : '#666',
                            borderBottomColor: "#008389",
                            borderBottomWidth: select === 4 ? 2 : 0,
                            paddingBottom: 5,
                            height: 30
                        }}
                        onPress={() => {
                            this.setState({ refreshing: true });
                            let data = [];
                            let dataAll = this.state.dataAll;
                            dataAll.forEach(function (x, i) {
                                if (x.Status === "Cancellation") {
                                    data.push(x)
                                }
                            }, this);
                            this.setState({ select: 4, data, refreshing: false });
                        }}
                    >
                        已取消
                    </Text>
                </View>
                <View
                    style={styles.content}
                >
                    <SectionList
                        sections={[
                            { data: this.state.data.length > 0 ? this.state.data : dataNull },
                        ]}
                        showsVerticalScrollIndicator={false}
                        onRefresh={this.getOrder}
                        refreshing={this.state.refreshing}
                        onEndReachedThreshold={0.1}
                        keyExtractor={(item, i) => i}
                        onEndReached={() => {

                        }}
                        ListFooterComponent={() => {
                            return this.state.offer ? <Text style={{ textAlign: "center" }}>{this.state.getData}</Text> : <Text></Text>
                        }}
                        renderItem={({ item, index }) => {
                            return (
                                this.state.data.length > 0 ?
                                    <TouchableOpacity
                                        style={styles.list}
                                        onPress={() => {
                                            // ToastAndroid.showWithGravity('正在跳转！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                            navigate('OrderDetail', { OrderNumber: item.OrderNumber, type: item.RoomTypeName, state: item.Status })
                                        }}
                                    >
                                        <View style={{ flex: 5, flexDirection: 'row', }}>
                                            <View style={{ flex: 4 }}>
                                                <Text style={{ fontWeight: 'bold', color: item.Status === "Cancellation" ? '#999' : '#333' }}>{item.PropertyName}</Text>
                                                <Text style={{ fontSize: 10, marginTop: 10, color: item.Status === "Cancellation" ? '#999' : '#333' }}>{item.RoomTypeName}</Text>
                                                <Text style={{ fontSize: 10, color: item.Status === "Cancellation" ? '#999' : '#333' }}>{item.ResvDate}</Text>
                                            </View>
                                            <Text
                                                style={{
                                                    flex: 1,
                                                    color: item.Status === "Cancellation" ? '#999' : item.Status === "PP" ? '#008389' : '#2C99CD',
                                                    fontSize: 11,
                                                    textAlign: "right"
                                                }}
                                            >
                                                {item.Status === "Cancellation" ? "已取消" : item.Status === "PP" ? "待入住" : "已完成"}
                                            </Text>
                                        </View>
                                        <View style={styles.bottom}>
                                            <Text style={{ flex: 1, fontSize: 16, color: item.Status === "Cancellation" ? '#999' : '#333' }}>￥ {item.RoomRate}</Text>
                                            <Text
                                                style={{
                                                    color: item.Status === "PP" ? '#333' : "#008389",
                                                    width: 80,
                                                    height: 25,
                                                    textAlign: "center",
                                                    borderWidth: 1,
                                                    borderColor: item.Status === "PP" ? '#DCDCDC' : "#008389",
                                                    borderRadius: 5,
                                                    padding: 4,
                                                    fontSize: 12
                                                }}
                                            >
                                                {item.Status === "PP" ? "取消订单" : "再次预定"}
                                            </Text>
                                        </View>
                                    </TouchableOpacity>
                                    :
                                    <View style={styles.kong}>
                                        <Image source={require('./images/dingdanW.png')} style={{ width: 50, height: 60 }} />
                                        <Text style={{ marginTop: 10, color: "#ccc" }}>您当前没有任何订单</Text>
                                    </View>
                            )
                        }}

                    />
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    OrderView: {
        flex: 1,
        backgroundColor: "#f1f1f1",
        flexDirection: 'column',
    },
    header: {
        textAlign: "center",
        height: 44,
        padding: 12,
        fontSize: 16,
        color: "#333",
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
        backgroundColor: "#fff",
    },
    tabs: {
        height: 40,
        flexDirection: 'row',
        backgroundColor: "#fff",
        padding: 10
    },
    content: {
        flex: 1,
        backgroundColor: "#f1f1f1",
    },
    list: {
        height: 140,
        padding: 20,
        paddingBottom: 10,
        paddingTop: 10,
        backgroundColor: "white",
        borderTopColor: "#f1f1f1",
        borderTopWidth: 10,
    },
    bottom: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 10,
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
    },
    kong: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: height - 200,
    }
})

export default OrderView;