/*
 * @page:   个人信息
 * @Author: Han 
 * @Date: 2017-09-12 18:19:53 
 * @Last Modified by: Han
 * @Last Modified time: 2017-09-26 15:35:24
 */
import React from 'react';
import {
    AppRegistry,
    Text,
    View,
    Button,
    StyleSheet,
    ListView,
    Image,
    TouchableOpacity,
    Alert,
    ToastAndroid
} from 'react-native';
import icon from './images/img';
import { parseString } from 'react-native-xml2js';

class Mine extends React.Component {
    static navigationOptions = {
        headerTitle: '我的',
        headerStyle: { elevation: 0 },
        gesturesEnabled: true,
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            LoginSate: false,
            data: {},
            cardPointInfo: {},
            avatar: "data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAAA8AAD/4QNxaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6NkYxNDI1RjU0MjIwNjgxMTgwODM4RjQyOEIzQ0M4MUUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QjFCMzUwMkEzQUVCMTFFNEIzM0U4Q0I5MkNEOTVGMkMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTlDRDEwOTQzQUVCMTFFNEIzM0U4Q0I5MkNEOTVGMkMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkJDRTc1MDAyMzEyMDY4MTE4MDgzOUE3MjIxRTIwQTNGIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjZGMTQyNUY1NDIyMDY4MTE4MDgzOEY0MjhCM0NDODFFIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/+4ADkFkb2JlAGTAAAAAAf/bAIQABgQEBAUEBgUFBgkGBQYJCwgGBggLDAoKCwoKDBAMDAwMDAwQDA4PEA8ODBMTFBQTExwbGxscHx8fHx8fHx8fHwEHBwcNDA0YEBAYGhURFRofHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8f/8AAEQgAeAB4AwERAAIRAQMRAf/EAKAAAQACAwEBAQAAAAAAAAAAAAAEBQMGBwECCAEBAAMBAQEAAAAAAAAAAAAAAAMEBQIBBhAAAQMDAgIHAwQPCQAAAAAAAQACAxEEBRIGIUExUXGBIhMHYZEUwUIVCKGx0VJicoKiIzNDY9MlF/AykrLSg7PDNBEBAAIBAgQEBgIDAAAAAAAAAAECEQMEIRITBTFRYYFBwSIyQhRx0ZGhYv/aAAwDAQACEQMRAD8A6Op1MQEBAQEBAQEBAQEBAQEBAQEBAQUu4N47cwDf5nesilIq23bV8p7GNqe88F5M4exWZaq/1z2c00EF84dYij+WULnnh30pfP8AXXaFafC3/b5cP8ZOeDpS9Hrps8n/AM18P9uL+KnPB0pZ7X1o2tdTtgt7W/kmeaMY2GMk+6ROeDpSk/1a2sXXIDbkss26riUMjMYrwADhIQ4k8BTpXvPB0pX+2dz43cePdf44SC3bI6E+a3QdTQCaCp4eJexOXFq4Wy9eCAgICAgIOfeqXqI/b8LcZjHD6WuG6nS8CIIzwDqH57uXv6lza2EmnTLhFxcT3M757iR008h1SSvJc5xPMk8SolhjQesY97gxjS5x4BoFSe4ILKLCGIeZlJhYRdPluGq4d+LCPEO1+kIJUN1LduOLwkPwlvID8RO936V8beLnzy8NLAOJa3h2oImVvrfymY6wJ+AgOoyEUdPLShlcOrk0ch7SUH6B9MsS7GbKx0MjdM07DcyDnWY6217GFoUtY4Kt5zLaV05EBAQEBAQfl7PTZLP5vL5eOGSeNsrpZnsaXCKHVoj1U6GhoAqoLSuVrw4KRAQTn5zKuYWNuHRRkULIA2FpHtEYYCgx2uNu7lpmoI7cHx3Up0xj8o9J9gqfYgkXWRghtDj8dUQPobq5cKPncOjh82Mcm959gW3p5s+bcmeijew/RtsRLfSctANRHXrf0dlTyXtYy4vbEP0mAAAAKAcAB0UUys9QEBAQEBAQcl+r1blmbzzXjjHFHG4Hr8x3+lZm8nhDb2EcZb5uT0e2VnHPmFqcfdu4mezIjBP4UZBjPt8Nfaq1Nzevqtam1pb0c7y31d87CS7FZK3u2cmTtdA/s8PmtPvCs13kfGFW2wt8Jaxd+jvqJbE1xJlbydDLC+vcH6vsKWNzSfigna6kfBGd6c+os7mRyYe8f5Y0R6x4Wt6gXGgC669PNz+vqeTZtt+ge5r2Zj83JHjLWtXsa5s05HUAwlg7S7uUN93WPDin09lafu4Oy47beI29jIMdi4BDbsqXE8Xvfwq97vnOP9uC72WpNptM+iHuOlWkViPX5M6vswQEBAQEBAQaL6TYw2G9N7QkUbHcQlg/AmdNIz80hZe++Db7bxifZ1NUGmICAgIIWR/Z9/yLR7f+Xt82R3X8ff5Ia0mQICAgICAgIMOCxDLbO5bJMp/MI7UP69cAlbX/AAuas3uEeHu2O1Twt7fNA3mfUmW8gtNqNtILR8WqfI3JBeyQOI0BhD+GmhroPdzqafJjNl/V6mcUwi7Vb6s2mYjtdxuschinteZchAQyRjg3wNDQ2GtXfu+9e6nTmM1zEudPqxOLYmG8KBZc9zcXrRf5W7ZiZsficbDI5tpLJSR80YPhc6rJ6EjpGlvyqxXpRHHMyq3jWmZxiIX2zJd8mG6h3ZDbNlhc1tpc2rq+c0g63OaDwoaU4DsUeryfil0Zv+a3yP7Pv+RXe3/l7fNm91/H3+SGtJkCAgICAgIJeMt45rg+YNTI2OkLevTy+yoNxqTWuYWdppRe+J8EsXPmSuiJ8TGtdoHAAOJAoPyVi2mZ4y+jrWK8IYshDcz2FzDazfD3UsT2QXFNXlyOaQ19Oek8V5E8XtomY4KbYuG3HiMF8JuDI/Sd/wCa94n1Pk0xuppZrkAc6lCeI505LvVtWZzWMI9Glq1xacynfSc/3rfcfurjCxyq7euI3JmtvNtsBkfovIOkjkdOHPj1MAOpmuMOe3iQeHVRd6Vq1t9UZhX16WtGKziV5j4bmDH20N1N8RdRRMZPcUp5kjWgOfTlqPFcTPFJWJiOLML5tvd2lu8Bzb6UwaTxqRG+T7TCu9KZieCPViJjii5e1jtrwtj4Me0PDeqtRT7C2dC82rxfPbrTil8QhKZXEBAQEBBmtLl9tO2VnEjgWnoIPSFxqUi0Yl3pak0tmEe1ycE+8r+1jaWN+jrOZrDx4+fdNfT2f3Vk7nR5IhvbTcdWZn+F2qq6IKFdJV1b/qI/xW/aXKOWRHjV8/mWWm99p2hGvU+9uXNH7u0fG3/mKt7XT5sqO91uTC1u7qS5ndM/gT0AdAA5LVpSKxiGFq6k3tmWFduBAQEBAQEGrMvxaer1jC40ZkcQ+Bo5F8Uzph+a0qjvq5rlp9tti2PN0JZTbVeb3Pt/BtY7LX8Nn5v6tsjvE6nSQ0VcR3LqtLW8IcX1K18Zay71B2B5nhztuGdklf8AKpejfyeft6fm2DB7w2rmZPhsTk4LqaNtfJa6j9I5hrqEjsUdtO1fGCutW3hK6XCRynLZD431ytbVpqzGWDmOHU+RjpCfdK1amyriuWL3K2bY8m+q+yxAQEBAQEBBzj1bt8pYXGG3ZjW6pMPKfP5gNc5pbqp8wkFru1RatOaMJ9vqctsojPrIcPHt7jzIu/kMKz/0vVrfv/8AP+3NNzZ663fumfIyllq66IbBFNKPLjaxlGR+YQ1orTpIAqePWrVKclcKepedS+UcbUzrfHc2xs7bnd3JEUFOtsh4P7GVJ5L3qQdG3xjCJhcrc4nLWmTtiRNaSslbQ0rpNS2vU4cCvbVzGHFLcsxMOyH6x9pThgZCeo3LR/1ql+lPm0P348lX6Vy3+f35md0TxFkMjZOPSGvme0sjB4V0xtp7loaNOWMMvc6nNOfN2BTKogICAgICAg+J4IbiF8E7GywytLJI3gFrmuFCCDyKDiW+vR+/sJZL/b7HXdgaudZjxTRexo6ZG/ndvSo5qnpqebmj2PY4se0te00c0ihBHIhcJXiAg3bZ/pTn87Iye7Y7HYw0Lp5W0keP3cZ48fvjw7V1Fco7akQ7vhMJjcJjosfjohFbRculznHpc483FSRCCZynr14ICAgICAgICAg+XObUAkVPQOap72Po92n2qZ6k+WHiy2+9aRWlePUtDYx4yxu7TP0x/L6WgxhAQEBAQEBAQEHzJIyNjpHuDWNFXOPQAF5M4jMuqUm8xWsZmWsZHcdzM4stT5MXRq+ee/ks7V3Uz9vCH2Gx7Fp0iJ1Pqt5fCP7VttezwXTbkHXI08dXGteBqqs8W1bSrNeWIxDYWbmsDDrc17ZB+zpX3HoXHKoTs759FFkMjLeXXnkaNI0xgHoA9q7jgvaejFa8vik2G4b23IbKfPi5hx8Q7HfdVnT3Nq+PGGZvOyaOrGa/Rb08P8NotLuC7hE0LqtPSOYPUVoUvFozD47c7a+jfkvHFmXaAQEBAQEBAQa3ubIlzxZRnwtoZqczyHcqG71fxh9X2DY4jrW8Z+3+1CqT6YQEBAQTsPkXWV0CT+hf4ZW+zr7lNoavJb0ZvdNjG408R98eH9e7dAQQCDUHiCtZ8BMY4SICAg//2Q=="
        }
    }


    componentWillMount() {
        storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            this.setState({ LoginSate: true, data: x, avatar: x.CardNo ? "http://wecaihotelapp.oss-cn-hangzhou.aliyuncs.com/Avatar/" + x.CardNo + '.jpg' : "" });

            // 获取积分
            let url = `user=admin&pwd=a&rule=&CardNo=${x.CardNo}`;
            fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberCardPointListJson?' + url).then(s => s.text()).then((s) => {
                parseString(s, (err, json) => {
                    let data = JSON.parse(json.string._);
                    this.setState({ cardPointInfo: data[0] });
                })
            })
        }).catch(err => {
            this.setState({ LoginSate: false });
        })
    }


    render() {
        const { navigate, goBack } = this.props.navigation;
        return (
            <View style={styles.view}>
                <View style={{ height: 44, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
                    <Text style={{ textAlign: "center", fontSize: 16, color: "#333" }}>我的</Text>
                </View>
                <View
                    style={{
                        flex: 9,
                        flexDirection: 'column',
                        padding: 20,
                        backgroundColor: "white"
                    }}
                >
                    <View style={{ flex: 1, flexDirection: 'row', }}>
                        {this.state.LoginSate ?
                            <View style={{ flex: 1, flexDirection: 'row', }}>
                                <View style={{ flex: 1, justifyContent: "center", paddingLeft: 10 }}>
                                    <Image source={{ uri: this.state.avatar }} style={styles.imagesMe} />
                                </View>
                                <View style={{ flex: 3, justifyContent: "center", }}>
                                    <Text style={{ color: "#333", fontWeight: "bold", fontSize: 20 }}>{this.state.data.AlternateName || this.state.data.EnglishName || ""}</Text>
                                    <TouchableOpacity
                                        onPress={() => {
                                            navigate("editInfo")
                                        }}
                                    >
                                        <Text style={{ fontSize: 12, color: "#999999", marginTop: 2 }}>编辑信息 ></Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                            :
                            <View style={{ flex: 1, justifyContent: "center", padding: 45, }}>
                                {/* <Button
                                    onPress={() => {
                                        navigate('Login')
                                    }}
                                    title="登录 / 注册"
                                    color="#008389"
                                /> */}
                                <Text
                                    onPress={() => {
                                        navigate('Login')
                                    }}
                                    style={{ height: 35, textAlign: "center", backgroundColor: "#008389", color: "#fff", borderRadius: 4, padding: 8 }}
                                >
                                    登录 / 注册
                                </Text>
                            </View>
                        }
                    </View>
                    <View style={{ flex: 1, borderTopWidth: 1, borderTopColor: "#f0f0f0", flexDirection: 'row', }} >
                        <View style={styles.column} >
                            <View style={styles.row}>
                                <Image source={require('./images/wallet.png')} />
                                <Text style={{ textAlign: "left", marginLeft: 10 }}>我的钱包</Text>
                            </View>
                            {/* 钱包 */}
                            <Text style={{ textAlign: "center", flex: 1 }}>￥ {this.state.data.Balance || 0}</Text>
                        </View>
                        <View style={styles.column} >
                            <View style={styles.row}>
                                <Image source={require('./images/integral.png')} />
                                <Text style={{ textAlign: "left", marginLeft: 10 }}>我的积分</Text>
                            </View>
                            {/* 钱包 */}
                            <Text style={{ textAlign: "center", flex: 1 }}>￥ {this.state.cardPointInfo.Point || 0}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 3, flexDirection: 'column', }} >
                        <TouchableOpacity
                            underlayColor="#f0f0f0"
                            onPress={() => {
                                if (!this.state.LoginSate) {
                                    navigate('Login')
                                    return
                                }
                                navigate('consumption')
                            }}
                        >
                            <View style={styles.bottomItem} >
                                <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', }}>
                                    <View style={{ flex: 1 }} >
                                        <Image source={require('./images/consumption.png')} />
                                    </View>
                                    <View style={{ flex: 8 }} >
                                        <Text style={{ textAlign: "left" }}>历时消费</Text>
                                    </View>
                                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} >
                                        <Image source={require('./images/qianjin.png')} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity
                            underlayColor="#f0f0f0"
                            onPress={() => {
                                if (!this.state.LoginSate) {
                                    navigate('Login')
                                    return
                                }
                                navigate("exchange", { data: this.state.cardPointInfo })
                            }}
                        >
                            <View style={styles.bottomItem} >
                                <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', }}>
                                    <View style={{ flex: 1 }} >
                                        <Image source={require('./images/exchange.png')} />
                                    </View>
                                    <View style={{ flex: 8 }} >
                                        <Text style={{ textAlign: "left" }}>历史兑换</Text>
                                    </View>
                                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} >
                                        {/* <Text style={{ textAlign: "right", fontSize: 20, color: "#ccc" }}>></Text> */}
                                        <Image source={require('./images/qianjin.png')} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity
                            underlayColor="#f0f0f0"
                            onPress={() => {
                                if (!this.state.LoginSate) {
                                    navigate('Login')
                                    return
                                }
                                navigate('Setting');
                            }}
                        >
                            <View style={styles.Seting} >
                                <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', }}>
                                    <View style={{ flex: 1 }} >
                                        <Image source={require('./images/set.png')} />
                                    </View>
                                    <View style={{ flex: 8 }} >
                                        <Text style={{ textAlign: "left" }}>设置</Text>
                                    </View>
                                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} >
                                        {/* <Text style={{ textAlign: "right", fontSize: 20, color: "#ccc" }}>></Text> */}
                                        <Image source={require('./images/qianjin.png')} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </View >
        );
    }
}

const styles = StyleSheet.create({
    view: {
        flex: 1,
        backgroundColor: "white"
    },
    text: {
        color: '#fff',
        fontSize: 15,
        fontWeight: 'bold'
    },
    imagesMe: {
        width: 50,
        height: 50,
        borderRadius: 50
    },
    row: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: "center",
        alignItems: 'center',
    },
    column: {
        flex: 1,
        flexDirection: 'column',
    },
    bottomItem: {
        height: 50,
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,

    },
    Seting: {
        height: 50,
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
    },
    foot: {
        flex: 1,
        height: 30,
        flexDirection: 'row',
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
    },
    footItem: {
        flex: 1
    },
    ItemC: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
});


export default Mine;