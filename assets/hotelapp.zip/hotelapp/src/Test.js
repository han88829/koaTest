import React, { Component } from 'react';
import List from 'antd-mobile/lib/list';
import Checkbox from 'antd-mobile/lib/checkbox';
import listStore from './Hotel/Area';

const CheckboxItem = Checkbox.CheckboxItem;
const AgreeItem = Checkbox.AgreeItem;
const { City } = listStore;

class Test extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: []
        }
    }

    componentDidMount() {
        let data = [];
        for (let i = 0; i < City.length; i++) {
            let dataA = []
            for (let j = 0; j < City[i].city.length; j++) {
                let dataB = []
                let area = City[i].city[j].area || [];
                for (let z = 0; z < area.length; z++) {
                    dataB.push({
                        value: City[i].city[j].area[z],
                        label: City[i].city[j].area[z],
                    });
                }
                dataA.push({
                    value: City[i].city[j].name,
                    label: City[i].city[j].name,
                    children: dataB
                })
            }
            data.push({
                value: City[i].name,
                label: City[i].name,
                children: dataA
            })
        }
        // City.forEach(function (x, i) {
        //     let dataA = []
        //     x.city.forEach(function (y, j) {
        //         let dataB = []
        //         y.area.forEach(function (z, n) {

        //             dataB.push({
        //                 value: z,
        //                 label: z,
        //             });
        //             dataA.push({
        //                 value: y.name,
        //                 label: y.name,
        //                 children: dataB
        //             })
        //             data.push({
        //                 value: x.name,
        //                 label: x.name,
        //                 children: dataA
        //             })
        //         }, this);
        //     }, this);
        // }, this);

        //console.log(JSON.stringify(data));
        // 本地数据存储
        storage.save({
            key: 'city',
            data: data,
        })

    }

    onChange = (val) => {
        // console.log(val);
    }
    render() {
        const data = [
            { value: 0, label: 'Ph.D.' },
            { value: 1, label: 'Bachelor' },
            { value: 2, label: 'college diploma' },
        ];
        return (
            <List renderHeader={() => 'CheckboxItem demo'}>
                {data.map(i => (
                    <CheckboxItem key={i.value} onChange={() => this.onChange(i.value)}>
                        {i.label}
                    </CheckboxItem>
                ))}
                <CheckboxItem key="disabled" data-seed="logId" disabled defaultChecked multipleLine>
                    undergraduate<List.Item.Brief>Auxiliary text</List.Item.Brief>
                </CheckboxItem>
            </List>
        );
    }
}

export default Test;