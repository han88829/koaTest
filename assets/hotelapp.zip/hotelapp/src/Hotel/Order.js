/*
 * @page:   Order 订单确认页面
 * @Author: Han 
 * @Date: 2017-09-12 18:19:39 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 16:30:37
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, Dimensions, StyleSheet, TouchableOpacity, Image, ToastAndroid, Modal, TextInput, Picker } from 'react-native';
import Button from 'react-native-button';
import Contact from '../personal/Contact';
import ActionSheet from 'antd-mobile/lib/action-sheet';
import moment from 'moment';
import icon from '../images/img';
import PhoneContact from '../personal/PhoneContact';
import { parseString } from 'react-native-xml2js';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
const isIPhone = new RegExp('\\biPhone\\b|\\biPod\\b', 'i').test(window.navigator.userAgent);
let wrapProps;
if (isIPhone) {
    wrapProps = {
        onTouchStart: e => e.preventDefault(),
    };
}

class Order extends Component {
    static navigationOptions = {
        title: '填写订单',
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false,
            selectName: ["请选择联系人"],
            room: 1,
            Visible: false,
            phone: '',
            data: { selectRoom: {} },
            name: '',
            mine: {}
        }
    }

    componentDidMount() {
        let data = this.props.navigation.state.params.data;
        this.setState({ data });
        storage.load({
            key: 'personalInfo',
            autoSync: true,
            syncInBackground: true,
        }).then((x) => {
            this.setState({ phone: x.Phone, name: x.AlternateName, mine: x, selectName: [x.AlternateName] });
        }).catch(err => {
            ToastAndroid.showWithGravity('55！', ToastAndroid.SHORT, ToastAndroid.CENTER);
        })
    }


    _back() {
        const { navigate, goBack } = this.props.navigation;
        goBack();
    }

    submit = () => {
        var regex = /^0\d{2,3}-?\d{7,8}$|^((\+)?86|((\+)?86)?)0?1[3578]\d{9}$/;
        if (this.state.selectName.length != this.state.room || this.state.selectName[0] == "请选择联系人") {
            ToastAndroid.showWithGravity('入住人不能小于房间数！', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }
        if (!this.state.phone || !regex.test(this.state.phone)) {
            ToastAndroid.showWithGravity('电话号码格式错误！', ToastAndroid.SHORT, ToastAndroid.CENTER);
            return
        }

        const { navigate } = this.props.navigation;
        let data = this.state.data;
        let mine = this.state.mine;
        let num = parseInt(data.total.replace(/[^0-9]/ig, ""), 10);
        let number = (Math.random() * 10).toFixed(0)
        let crspwd = "s" + moment(new Date()).format('YYMMDDHHssmm'); + number;
        data.room = this.state.room;
        data.selectName = this.state.selectName;
        data.tel = this.state.phone;
        data.Tprice = this.state.room * this.state.data.selectRoom.Price;
        let url = `user=admin&pwd=a&rule=&Hotel=${data.code}&LastName=&FirstName=&AlternateName=${mine.AlternateName}&Gender=` +
            `&Title=&MemberCard=${mine.MemberCard}&MembershipLevel=${mine.MembershipLevel}` +
            `&Country=&Language=&Nation=&VipLevel=&Preference=&Phone=&Address=&Company=&Agent=&Source=&Block=&Party=&CallerName=${data.selectName[0]}&` +
            `CallerPhone=${data.tel}&ReserveName=&ReservationType=PP&ArrivalDate=${moment(data.bTime).format('YYYY-MM-DD')}&Night=${num}&Adult=${data.selectName.length}&Child=&Rooms=${data.room}&RoomType=${data.selectRoom.Code}&Room=&RateCode=${data.selectRoom.RateCode}&` +
            `PrintRate=&Package=&MarketCode=&SourceCode=&OriginCode=WEB&PaymentType=&CreditCardNo=&CreditCardExpireDate=` +
            `&ApproveAmount1=&ApproveCode=&Special=&RoomFeature=&ETA=&ETD=&Confidential=&Note=&CashierNote=&CRSNo=` +
            `&CRSpwd=${crspwd}&RoomRate=&Email=${mine.Email}`;
        fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcReservationInsertJson?' + url).then((x) => {
            return x.text()
        }).then((x) => {
            parseString(x, (err, json) => {
                let data = JSON.parse(json.string._);
                let a = data[0][''];
                if (a && (a === "015" || a === '014' || a === '013' || a === '023' || a === '034' || a === '035' || a === '012')) {
                    switch (a) {
                        case "015":
                            ToastAndroid.showWithGravity('酒店已关房!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            break;
                        case "014":
                            ToastAndroid.showWithGravity('酒店已满房!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            break;
                        case "013":
                            ToastAndroid.showWithGravity('房间数量不足!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            break;
                        case "023":
                            ToastAndroid.showWithGravity('此房已关闭!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            break;
                        case "034":
                            ToastAndroid.showWithGravity('网络故障!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            break;
                        case "035":
                            ToastAndroid.showWithGravity('程序错误!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            break;
                        case "012":
                            ToastAndroid.showWithGravity('订单已存在，请勿重复提交!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                            break;
                        default:
                            break;
                    }
                    return
                } else if (a.indexOf('0') == 0) {
                    ToastAndroid.showWithGravity('订单发生错误!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    return
                }
                ToastAndroid.showWithGravity(`提交成功!，您的订单号为：${a}`, ToastAndroid.SHORT, ToastAndroid.CENTER);
                navigate("OrderSuess", { number: a })
            })
        })
    }

    cancel = () => {
        this.setState({ modalVisible: false });
    }

    confirm = (data) => {
        let selectName = this.state.selectName;
        for (let i = 0; i < selectName.length; i++) {
            if (i < data.length) {
                selectName[i] = data[i]
            } else {
                selectName[i] = ""
            }
        }
        this.setState({ modalVisible: false, selectName });
    }

    // 添加手机号码
    cancelPhone = () => {
        this.setState({ Visible: false });
    }

    confirmPhone = (data) => {
        this.setState({ Visible: false, phone: data });
    }

    showActionSheet = () => {
        const BUTTONS = ['一间', '两间', '三间', "四间", "取消"];
        ActionSheet.showActionSheetWithOptions({
            options: BUTTONS,
            cancelButtonIndex: BUTTONS.length - 1,
            message: '房间数选择',
            maskClosable: false,
            'data-seed': 'logId',
            wrapProps,
        },
            (buttonIndex) => {
                if (buttonIndex !== BUTTONS.length - 1) {
                    let room = buttonIndex + 1;
                    let selectName = this.state.selectName;
                    selectName.length = room;
                    for (let i = 0; i < room; i++) {
                        if (!selectName[i]) {
                            selectName[i] = "";
                        }
                    }
                    this.setState({ room, selectName });
                }
            });
    }

    render() {
        const { navigate } = this.props.navigation;
        let data = this.state.data;
        return (
            <View style={styles.order}>
                <View style={{ flexDirection: 'row', alignItems: 'center', height: 44, backgroundColor: "white" }}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, marginLeft: 10, height: 44, paddingTop: 12 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20 }}
                        />
                    </TouchableOpacity>
                    <Text style={{ textAlign: 'center', fontSize: 16, flex: 1, marginLeft: -5, color: "#333" }}>填写订单</Text>
                    <View style={{ flex: 1 }}></View>
                </View>
                <View style={styles.header}>
                    <View style={styles.headerText}>
                        <Text style={{ fontSize: 16, fontWeight: "bold", color: "#333" }}>{data.code}</Text>
                        <Text style={{ fontSize: 10 }}>{data.selectRoom.Note}</Text>
                        <Text style={{ fontSize: 14, color: "#333", marginTop: 5 }}>入住 {data.today}  离店 {data.next}   {data.total}</Text>
                    </View>
                </View>
                <View style={styles.content}>
                    <TouchableOpacity
                        style={styles.contentItem}
                        onPress={this.showActionSheet}
                    >
                        <Text style={{ flex: 2 }}>房间数</Text>
                        <Text style={{ flex: 5, color: "#333", textAlign: "left" }}>{this.state.room}间</Text>
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} >
                            <Image source={require('../images/qianjin.png')} />
                        </View>
                    </TouchableOpacity>
                    <View
                        style={{
                            flexDirection: 'row',
                            borderBottomColor: "#f0f0f0",
                            borderBottomWidth: 1,
                            alignItems: 'center',
                            minHeight: 50
                        }}
                    >
                        <View style={{ flex: 7, flexDirection: "row", alignItems: 'center', }}>
                            <Text style={{ flex: 2 }}>入住人</Text>
                            <View style={{ flex: 5, }}>
                                {this.state.selectName.map((x, i) => {
                                    return (
                                        <View
                                            key={i}
                                            style={{
                                                height: 50,
                                                marginLeft: -3
                                            }}
                                        >
                                            <TextInput
                                                style={{ flex: 5, }}
                                                underlineColorAndroid={i === this.state.selectName.length - 1 ? 'transparent' : '#f0f0f0'}
                                                placeholder='请输入联系人姓名'
                                                onChangeText={(value) => {
                                                    let selectName = this.state.selectName;
                                                    selectName[i] = value;
                                                    this.setState({ selectName });
                                                }}
                                                value={x}
                                            />
                                        </View>

                                    )
                                })}
                            </View>
                        </View>
                        <TouchableOpacity
                            style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'flex-end',
                            }}
                            onPress={() => {
                                this.setState({ modalVisible: true });
                            }}
                        >
                            <Image
                                source={require("../images/add.png")}
                            />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.contentItem}>
                        <Text style={{ flex: 2 }}>手机号码</Text>
                        <TextInput
                            style={{ borderBottomColor: 'gray', borderBottomWidth: 0, flex: 5, marginLeft: -2 }}
                            underlineColorAndroid='transparent'
                            keyboardType="numeric"
                            placeholder='请输入电话号码'
                            onChangeText={(phone) => this.setState({ phone })}
                            value={this.state.phone}
                        />
                        {/* <Text style={{ flex: 5 }}>{this.state.phone}</Text> */}
                        <TouchableOpacity
                            style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'flex-end',
                            }}
                            onPress={() => {
                                this.setState({ Visible: true });
                            }}
                        >
                            <Image
                                source={require("../images/contact.png")}
                            />
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={styles.foot}>
                    <Text style={{ flex: 2 }}>支付总价： <Text style={{ color: "#008389" }}>￥{data.selectRoom.Price * this.state.room}</Text></Text>
                    <Button
                        style={{ height: 30, width: 70, fontSize: 12, backgroundColor: "#008389", color: "white", paddingTop: 7, borderRadius: 5 }}
                        onPress={this.submit}
                    >
                        提交订单
                    </Button>
                </View>
                {/* modal */}
                <Modal
                    animationType={"slide"}
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => { this.setState({ modalVisible: false }); }}
                >
                    <PhoneContact cancel={this.cancel} name={this.state.name} phone={this.state.phone} confirm={this.confirm} only={this.state.room} />
                </Modal>
                {/* 手机号码 */}
                <Modal
                    animationType={"slide"}
                    transparent={false}
                    visible={this.state.Visible}
                    onRequestClose={() => { this.setState({ Visible: false }); }}
                >
                    <PhoneContact cancel={this.cancelPhone} name={this.state.name} phone={this.state.phone} confirm={this.confirmPhone} only={0} />
                </Modal>
            </View >
        );
    }
}

const styles = StyleSheet.create({
    order: {
        height: height,
        width: width,
        flex: 1,
        flexDirection: 'column',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        height: 112,
        width: width,
        backgroundColor: "#D8EBEC",
        padding: 5,
    },
    headerText: {
        flex: 1,
        width: width,
        height: 98,
        flexDirection: 'column',
        backgroundColor: "white",
        borderRadius: 5,
        justifyContent: 'space-around',
        padding: 15
    },
    content: {
        flexDirection: 'column',
        width: width,
        backgroundColor: "white",
        height: height - 240,
        padding: 20,
        paddingTop: 0
    },
    foot: {
        flex: 1,
        width: width,
        height: 80,
        flexDirection: 'row',
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
        backgroundColor: "white",
        alignItems: 'center',
        padding: 20
    },
    contentItem: {
        height: 50,
        flexDirection: 'row',
        borderBottomColor: "#f0f0f0",
        borderBottomWidth: 1,
        alignItems: 'center',
    }
});

export default Order;