/*
 * @page:   城市列表
 * @Author: Han 
 * @Date: 2017-09-18 13:29:55 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:44:16
 */
import React, { Component } from 'react';
import { Text, StyleSheet, TouchableOpacity, FlatList, View, NetInfo, ToastAndroid, Image } from 'react-native';
import { parseString } from 'react-native-xml2js';
import icon from '../images/img';

class SelectAdders extends Component {
    static navigationOptions = {
        title: "首页",
        header: null
    }
    constructor(props) {
        super(props);
        this.state = {
            data: []
        }
    }


    componentWillMount() {
        NetInfo.isConnected.fetch().done((isConnected) => {
            if (isConnected === "offline") {
                ToastAndroid.showWithGravity('请连接网络!', ToastAndroid.SHORT, ToastAndroid.CENTER);
            }
        });
    }


    componentDidMount() {
        // var FetchOptions = {
        //     method: 'POST',
        //     headers: {
        //         'Content-Type': 'application/x-www-form-urlencoded'
        //     },
        //     body: JSON.stringify({
        //         user: "admin",
        //         pwd: "a",
        //         Language: "",
        //         GroupCode: ""
        //     })
        // };
        fetch('http://182.92.222.169:9611/CRS.asmx/crs1GetPropertyCityListJson?user=admin&pwd=a&Language=&GroupCode=').then((x) => {
            return x.text()
        }).then((x) => {
            parseString(x, (err, json) => {
                this.setState({ data: JSON.parse(json.string._) });
            })
        }).catch(err => { })
    }
    _back() {
        this.props.cancle();
    }
    render() {
        return (
            <View style={styles.view} >
                <View style={{ height: 44, flexDirection: 'row', paddingLeft: 20, alignItems: 'center', justifyContent: 'flex-start', borderBottomColor: "#f0f0f0", borderBottomWidth: 1, margin: -20 }}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20 }}
                        />
                    </TouchableOpacity>
                    <Text style={{ flex: 1, fontSize: 16, textAlign: 'center', color: "#333", marginLeft: -20 }}>选择城市</Text>
                    <View style={{ flex: 1 }}></View>
                </View>
                <FlatList
                    data={this.state.data}
                    style={{ marginTop: 20 }}
                    keyExtractor={(item, i) => i}
                    showsVerticalScrollIndicator={false}
                    renderItem={({ item, i }) => {
                        return (
                            <TouchableOpacity
                                style={styles.item}
                                onPress={() => {
                                    this.props.onClick(item.Code)
                                }}
                            >
                                <Text style={{ flex: 1 }}>{item.Code}</Text>
                                <Text style={{ color: "#CCC" }}>{item.State}</Text>
                            </TouchableOpacity>
                        )
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    view: {
        padding: 20,
        backgroundColor: "white",
        flex: 1,
    },
    item: {
        borderBottomWidth: 1,
        borderBottomColor: "#f0f0f0",
        height: 35,
        flexDirection: 'row',
        alignItems: 'center',
    }
})

export default SelectAdders;