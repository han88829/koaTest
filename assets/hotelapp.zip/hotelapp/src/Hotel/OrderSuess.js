import React, { Component } from 'react';
import { Text, View, TouchableOpacity, StyleSheet, Image } from 'react-native';

class OrderSuess extends Component {
    static navigationOptions = {
        title: '创建订单成功！',
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            colorNum: 0
        }
    }

    onSubmit = (value) => {
        const { navigate } = this.props.navigation;
        if (value) {
            navigate('App', { num: 1 });
            return
        }
        this.setState({ colorNum: 1 });
        navigate('App', { num: 2 });
    }

    render() {
        return (
            <View style={styles.OrderSuess}>
                <View style={styles.header}>
                    <Text style={{ flex: 1 }}></Text>
                    <Text style={{ flex: 1, textAlign: "center", fontSize: 16, color:"#333" }}>订单状态</Text>
                    <Text
                        style={{ flex: 1, textAlign: "right", color: "#008389" }}
                        onPress={this.onSubmit.bind(this, true)}
                    >完成   </Text>
                </View>
                <View style={styles.content}>
                    <Image
                        source={require('../images/wancheng.png')}
                        style={{ height: 60, width: 60 }}
                    />
                    <Text style={{ marginTop: 10, fontWeight: 'bold', fontSize: 16, color: "#333" }}>预定完成</Text>
                    <View style={styles.button}>
                        <Text
                            style={{ height: 30, width: 100, color: this.state.colorNum ? '#008389' : "#333", borderColor: this.state.colorNum ? '#008389' : "#ccc", borderWidth: 1, borderRadius: 5, textAlign: "center", padding: 5 }}
                            onPress={this.onSubmit.bind(this, false)}
                        >
                            查看订单
                        </Text>
                        <Text
                            style={{ marginLeft: 30, height: 30, color: this.state.colorNum ? '#333' : "#008389", width: 100, borderColor: this.state.colorNum ? '#ccc' : "#008389", borderWidth: 1, borderRadius: 5, textAlign: "center", padding: 5 }}
                            onPress={this.onSubmit.bind(this, true)}
                        >
                            返回首页
                        </Text>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    OrderSuess: {
        flex: 1,
        backgroundColor: "white"
    },
    header: {
        height: 44,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderBottomColor:"#dcdcdc",
        borderBottomWidth:1
    },
    content: {
        flex: 1,
        marginTop: 70,
        flexDirection: 'column',
        alignItems: 'center',
    },
    button: {
        height: 80,
        flexDirection: 'row',
        marginTop: 30
    }
})

export default OrderSuess;