/*
 * @page:   历史兑换
 * @Author: Han
 * @Date: 2017-09-12 18:19:39
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:39:29
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableOpacity, SectionList, Image, Dimensions } from 'react-native';
import icon from '../images/img';
const width = Dimensions.get('window').width;

export default class Exchange extends Component {
  static navigationOptions = {
    title: "历史兑换",
    header: null
  };


  constructor(props) {
    super(props);
    this.state = {
      data: []
    }
  }

  _back() {
    const { navigate, goBack } = this.props.navigation;
    goBack();
  }


  componentDidMount() {
    let data = [];
    for (let i = 1; i < 5; i++) {
      data.push({
        key: i,
        img: 'http://st.cdn1.yestone.com/thumbs/1000204/image/2072/20727983/api_thumb_450.jpg',
        name: '咖啡杯',
        cost: '1000'
      })
    }
    this.setState({
      data: data
    })
  }


  render() {
    return (
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'flex-start', backgroundColor: '#fff' }}>

        <View style={{ flexDirection: 'row', alignItems: 'center', width: width, height: 44, borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
          <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
            {/* <IconFA name="angle-left" style={{ fontSize: 30 }} /> */}
            <Image
              source={{ uri: icon.backX }}
              style={{ height: 20, width: 20, marginLeft: 20 }}
            />
          </TouchableOpacity>
          <Text style={{ textAlign: 'center', fontSize: 16, flex: 1 }}>历史兑换</Text>
          <View style={{ flex: 1 }}></View>
        </View>

        <View style={{ flexDirection: 'row', marginTop: 35, borderBottomWidth: 1, width: width - 40, paddingBottom: 25, borderBottomColor: '#f0f0f0', marginLeft: 20 }}>
          <Text style={{ fontSize: 16 }}>总计:</Text>
          <Text style={{ paddingLeft: 8, color: '#008389', fontSize: 16, fontWeight: 'bold' }}>5000积分</Text>
        </View>

        <SectionList
          sections={[{ data: this.state.data }]}
          renderItem={({ item, index }) => {
            return (
              <View
                key={item.key}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  width: width - 40,
                  borderBottomWidth: 1,
                  justifyContent: 'space-between',
                  paddingTop: 11,
                  marginLeft: 20,
                  paddingBottom: 11,
                  borderBottomColor: '#f0f0f0'
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Image source={{
                    uri: "https://s3.amazonaws.com/uifaces/faces/twitter/ladylexy/128.jpg"
                  }}
                    style={{ width: 32, height: 32, borderRadius: 4 }} />
                  <Text style={{ paddingLeft: 10 }}>{item.name}</Text>
                </View>

                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Text>合计:<Text style={{ color: '#008389' }}>{item.cost}积分</Text></Text>
                  <Text>  </Text>
                  <Image source={require('../images/del.png')} />
                </View>
              </View>
            )
          }}
        />

      </View >
    );
  }
}
