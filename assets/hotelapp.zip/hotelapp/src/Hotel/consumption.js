/*
 * @page:   历史消费
 * @Author: Han
 * @Date: 2017-09-12 18:19:39
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:39:21
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableOpacity, SectionList, Image, Dimensions } from 'react-native';
import icon from '../images/img';
import { parseString } from 'react-native-xml2js';

const width = Dimensions.get('window').width;

export default class Consumption extends Component {
  static navigationOptions = {
    title: "历史消费",
    header: null
  };

  constructor(props) {
    super(props);
    this.state = {
      data: [],
      total: ''
    }
  }

  _back() {
    const { goBack } = this.props.navigation;
    goBack();
  }


  componentDidMount() {
    let data = [];
    storage.load({
      key: 'personalInfo',
      autoSync: true,
      syncInBackground: true,
    }).then(x => {
      let url = `user=admin&pwd=a&rule=&CardNo=${x.Mobile}`;
      fetch('http://182.92.222.169:9611/CRS.asmx/crsIfcMemberCardTransactionListJson?' + url).then(x => x.text()).then(x => {
        parseString(x, (err, json) => {
          data = JSON.parse(json.string._);
          let total = 0;
          data.forEach(function (item) {
            //console.log(item.TransactionAmount)
            total += Math.abs(parseInt(item.TransactionAmount || 0, 10));
          }, this);
          //onsole.log(data)
          this.setState({
            data,
            total
          })
        })
      }).catch(err => {
        //console.log(err)
      });
    })

  }


  render() {
    return (
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'flex-start', backgroundColor: '#fff' }}>

        <View style={{ flexDirection: 'row', alignItems: 'center', width: width, height: 44, borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}>
          <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, height: 44, paddingTop: 12 }}>
            {/* <IconFA name="angle-left" style={{ fontSize: 30 }} /> */}
            <Image
              source={{ uri: icon.backX }}
              style={{ height: 20, width: 20, marginLeft: 20 }}
            />
          </TouchableOpacity>
          <Text style={{ textAlign: 'center', fontSize: 16, flex: 1, color: "#333" }}>历史消费</Text>
          <View style={{ flex: 1 }}></View>
        </View>

        <View style={{ flexDirection: 'row', marginTop: 25, marginLeft: 20 }}>
          <Text style={{ fontSize: 16 }}>总计:</Text>
          <Text style={{ paddingLeft: 8, color: '#008389', fontSize: 16, fontWeight: 'bold' }}>¥ {this.state.total}</Text>
        </View>

        <SectionList
          sections={[{ data: this.state.data }]}
          keyExtractor={(item, index) => index}
          style={{ marginTop: 20 }}
          renderItem={({ item, index }) => {
            return (
              <View
                key={index}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  width: width - 40,
                  marginLeft: 20,
                  borderTopWidth: index === 0 ? 1 : 0,
                  borderTopColor: "#f0f0f0",
                  borderBottomWidth: 1,
                  justifyContent: 'space-between',
                  paddingTop: 11,
                  paddingBottom: 11,
                  height: 50,
                  borderBottomColor: '#f0f0f0',
                }}
              >
                <View style={{ flexDirection: 'row', flex: 2, alignItems: 'center' }}>
                  {/* <Image source={{
                    uri: "https://s3.amazonaws.com/uifaces/faces/twitter/ladylexy/128.jpg"
                  }}
                    style={{ width: 32, height: 32, borderRadius: 4 }} /> */}
                  <Text >{item.TransactionDescription.length > 20 ? item.TransactionDescription.substring(0, 20) + "..." : item.TransactionDescription}</Text>
                </View>

                <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                  <Text style={{ flex: 1 }}>合计: </Text>
                  <Text style={{ color: '#008389', flex: 1 }}>¥ {Math.abs(parseInt(item.TransactionAmount || 0, 10))}</Text>
                </View>

              </View>
            )
          }}
        />

      </View >
    );
  }
}
