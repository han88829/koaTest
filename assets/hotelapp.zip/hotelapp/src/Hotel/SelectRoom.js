/*
 * @page:   select rome
 * @Author: Han 
 * @Date: 2017-09-14 14:16:45 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-10 16:34:15
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableOpacity, Dimensions, StyleSheet, Image, SectionList, ToastAndroid, Linking } from 'react-native';
import { parseString } from 'react-native-xml2js';
import Carousel from 'react-native-looped-carousel';
import Button from 'react-native-button';
import icon from '../images/img';
import DateTimePicker from 'react-native-modal-datetime-picker';
import moment from 'moment';
import MapLinking from 'react-native-map-linking';//打开外部地图

export default class About extends Component {
    static navigationOptions = {
        title: '预订！',
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            dataSource: [],
            data: [],
            refreshing: false,
            num: 5,
            offer: false,
            isDateTimePickerVisible: false,
            Visible: false,
            today: "选择时间",
            nextTime: new Date(moment().format("YYYY/MM/DD 12:00:00")),
            next: "选择时间",
            date: new Date(moment().format("YYYY/MM/DD 12:00:00")),
            total: "",
            tTime: null,
            code: '',
            Address: '',
            Telephone: '',
            imgUrl: [],
            getData: '正在加载数据请稍候。。。',
            bTime: null,
            url: '',
            loginState: false
        }
    }
    componentDidMount() {
        let data = this.props.navigation.state.params.data, dataS = [], dataSource = [];

        if (data.beginTime) {
            this.setState({
                today: data.today,
                next: data.next,
                total: data.total,
                nextTime: data.beginTime,
                bTime: data.bTime,
                tTime: data.endTime,
                code: data.code,
                Address: data.Address,
                Telephone: data.Telephone,
                url: data.PictureURL
            });
        } else {
            this.setState({
                code: data.code,
                Address: data.Address,
                Telephone: data.Telephone,
                url: data.PictureURL
            });
        }

        // 获取酒店房间
        let url = `user=admin&pwd=a&Language=&PropertyCode=${data.code}&ArrivalDate=&DepartureDate=&Rooms=&Persons=`;
        let num = this.state.num, imgUrl = [];
        fetch('http://182.92.222.169:9611/CRS.asmx/crs1GetRoomTypeListJson?' + url).then((x) => {
            return x.text();
        }).then(x => {
            parseString(x, (err, json) => {
                dataSource = JSON.parse(json.string._);
                if (!dataSource[0].Price) {
                    ToastAndroid.showWithGravity('未查询到房间信息！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ getData: '未查询到房间信息！' });
                    return
                }
                if (dataSource.length <= num) {
                    for (let i = 0; i < dataSource.length; i++) {
                        dataS.push(dataSource[i]);
                        imgUrl.push(dataSource[i].URL);
                    }
                } else {
                    for (let i = 0; i < num; i++) {
                        dataS.push(dataSource[i])
                        imgUrl.push(dataSource[i].URL);
                    }
                }
                this.setState({
                    dataSource,
                    data: dataS,
                    imgUrl,
                    getData: ''
                });
            })
        }).catch(err => { })
    }

    getHotelRoom = () => {
        let dataSource = [], data = [], imgUrl = [];
        let num = this.state.num;
        // 获取酒店房间
        let url = `user=admin&pwd=a&Language=&PropertyCode=${this.state.code}&ArrivalDate=&DepartureDate=&Rooms=&Persons=`;
        fetch('http://182.92.222.169:9611/CRS.asmx/crs1GetRoomTypeListJson?' + url).then((x) => {
            return x.text();
        }).then(x => {
            parseString(x, (err, json) => {
                dataSource = JSON.parse(json.string._);
                if (!dataSource[0].Price) {
                    ToastAndroid.showWithGravity('未查询到房间信息！', ToastAndroid.SHORT, ToastAndroid.CENTER);
                    this.setState({ getData: '未查询到房间信息！' });
                    return
                }
                if (dataSource.length <= num) {
                    for (let i = 0; i < dataSource.length; i++) {
                        data.push(dataSource[i]);
                        imgUrl.push(dataSource[i].URL);
                    }
                } else {
                    for (let i = 0; i < num; i++) {
                        data.push(dataSource[i]);
                        imgUrl.push(dataSource[i].URL);
                    }
                }
                this.setState({
                    dataSource,
                    data,
                    imgUrl
                });
            })
        })
    }

    back = () => {
        const { goBack } = this.props.navigation;
        goBack()
    }

    //转换地址坐标
    positionApi = (address) => {
        let url = `output=json&address=${address}&ak=GuYLMTSrRt7KKnoFRVRpSEhwAwm2gGal`;
        fetch('http://api.map.baidu.com/geocoder/v2/?' + url).then((x) => {
            return x.json();
        }).then((x) => {
            if (x.status != 0) {
                ToastAndroid.showWithGravity('地址获取失败!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                return
            }
            let lat = x.result.location.lat;
            let lng = x.result.location.lng;
            let title = address, content = address;
            MapLinking.markLocation({ lat, lng }, title, content);
        }).catch(err => ToastAndroid.showWithGravity('地址获取失败!', ToastAndroid.SHORT, ToastAndroid.CENTER))
    }

    render() {
        const width = Dimensions.get('window').width;
        const { navigate } = this.props.navigation;
        return (
            <View style={styles.view}>
                {/* 轮播图片 */}
                <View style={{ height: 180, flexDirection: 'row', position: "relative", }}>
                    {/* 返回图标 */}
                    <TouchableOpacity
                        style={styles.Timage}
                        underlayColor="rgba(204, 204, 204, 0)"
                        onPress={this.back}
                    >
                        <Image
                            source={require('../images/fanhuis.png')}
                        />
                    </TouchableOpacity>
                    <Carousel
                        delay={47000}
                        style={{ width: width, height: 180 }}

                        bullets={true}
                    >
                        <Image
                            style={{ width: width, height: 180 }}
                            source={{ uri: this.state.url }}
                        />
                    </Carousel>
                </View>
                <View style={styles.select}>
                    <View style={{ flex: 2, height: 50, }}>
                        <Text style={styles.Stext}>
                            {this.state.code}
                        </Text>
                    </View>
                    <View style={styles.selectItemL}>
                        <TouchableOpacity
                            style={styles.selectP}
                            underlayColor="rgba(204, 204, 204, 0)"
                            onPress={this.positionApi.bind(this, this.state.Address)}
                        >
                            <View style={styles.selectTotal}>
                                <View style={styles.selectO}>
                                    <Image
                                        source={require('../images/position.png')}
                                    />
                                </View>
                                <View style={styles.selectTwo}>
                                    <Text style={styles.positionO}>{this.state.Address}</Text>
                                    <Text style={styles.positionT}>{this.state.Address.length > 40 ? "" : "点击查看具体位置"}</Text>
                                </View>
                            </View>

                        </TouchableOpacity>
                        <TouchableOpacity
                            style={styles.selectT}
                            underlayColor="rgba(204, 204, 204, 0)"
                            onPress={() => {
                                return Linking.openURL(`tel:${this.state.Telephone}`)
                            }}
                        >
                            <Image
                                source={require('../images/phone.png')}
                            />
                        </TouchableOpacity>
                    </View>
                    {/* 时间 */}
                    <DateTimePicker
                        isVisible={this.state.isDateTimePickerVisible}
                        onConfirm={(x) => {
                            let date = moment(x).format("MM月DD日");
                            let str = moment(x).toNow(true);

                            if (!this.state.next || this.state.next === "选择时间") {
                                this.setState({ bTime: x, isDateTimePickerVisible: false, today: date, nextTime: new Date(moment(x).add(1, 'days')) });
                            } else {
                                let a = moment(x);
                                let b = moment(this.state.tTime);
                                let total = `共 ${b.diff(a, 'days')} 晚`;
                                this.setState({ bTime: x, isDateTimePickerVisible: false, today: date, total, nextTime: new Date(moment(x).add(1, 'days')) });
                            }
                        }}
                        onCancel={() => {
                            this.setState({ isDateTimePickerVisible: false });
                        }}
                        minimumDate={this.state.date}
                    />
                    <DateTimePicker
                        isVisible={this.state.Visible}
                        onConfirm={(x) => {
                            let date = moment(x).format("MM月DD日");
                            let a = moment(this.state.nextTime || new Date());
                            let b = moment(x);
                            let tTime = x;
                            let total = `共 ${b.diff(a, 'days') + 1} 晚`;
                            this.setState({ Visible: false, next: date, total, tTime });
                        }}
                        onCancel={() => {
                            this.setState({ Visible: false });
                        }}
                        minimumDate={this.state.nextTime}
                    />
                    <View
                        style={styles.selectItem}
                    >
                        <View style={styles.date}>
                            <View style={{ flex: 4 }}>
                                <Text
                                    onPress={() => {
                                        this.setState({ isDateTimePickerVisible: true });
                                    }}
                                >
                                    入住  <Text style={{ color: "#008389" }}>{this.state.today}</Text>
                                </Text>
                            </View>
                            <View style={{ flex: 4 }}>
                                <Text onPress={() => {
                                    this.setState({ Visible: true });
                                }}>离店  <Text style={{ color: "#008389", textAlign: "left" }}>{this.state.next}</Text></Text>
                            </View>
                            <View style={{ flex: 2 }}>
                                <Text style={{ textAlign: "right" }}>{this.state.total}</Text>
                            </View>
                            <View style={{ flex: 1 }}>
                                <Text style={{ textAlign: "right", color: "#ccc", fontSize: 20 }}></Text>
                            </View>
                        </View>
                    </View>
                </View>
                <View style={{ height: 10, backgroundColor: "#fafafa" }}></View>
                <View style={styles.foot}>
                    <SectionList
                        sections={[
                            { data: this.state.data },
                        ]}
                        showsVerticalScrollIndicator={false}
                        onRefresh={this.getHotelRoom}
                        refreshing={this.state.refreshing}
                        onEndReachedThreshold={0.1}
                        keyExtractor={(item, i) => i}

                        onEndReached={() => {
                            this.setState({ refreshing: true });
                            let dataSource = this.state.dataSource;
                            let data = [];
                            let num = this.state.num, offer = false;

                            num += 5;
                            if (num >= dataSource.length) {
                                for (let i = 0; i < dataSource.length; i++) {
                                    data.push(dataSource[i])
                                }
                                offer = true;
                            } else {
                                for (let i = 0; i < num; i++) {
                                    data.push(dataSource[i])
                                }

                            }
                            this.setState({
                                data,
                                num,
                                refreshing: false,
                                offer
                            });
                        }}
                        ListFooterComponent={() => {
                            return this.state.offer ? <Text style={{ textAlign: "center" }}>{this.state.getData}</Text> : <Text></Text>
                        }}
                        renderItem={({ item, index }) => {
                            return (
                                <TouchableOpacity
                                    activeOpacity={1}
                                    underlayColor="#f0f0f0"
                                    style={{ marginTop: 5, marginLeft: 20, width: width - 40, paddingBottom: 10, borderBottomColor: "#f0f0f0", borderBottomWidth: 1 }}
                                >
                                    <View style={{ flex: 1, flexDirection: 'row', height: 80 }}>
                                        <View style={{ flex: 1, }}>
                                            <Image
                                                source={{ uri: item.URL }}
                                                style={{ height: 80, width: 100 }}
                                            />
                                        </View>
                                        <View style={{ flex: 2, flexDirection: 'column', }}>
                                            <View style={{ flex: 3, paddingTop: 0, paddingLeft: 5 }}>
                                                <Text style={{ fontSize: 14, color: "#333" }}>{item.Note}</Text>
                                                <Text style={{ fontSize: 10, color: "#999999" }}>{item.ServiceItem}</Text>
                                            </View>
                                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }}>
                                                <View style={{ flex: 2 }}></View>

                                                <View style={{ flex: 3 }}>
                                                    <Text style={{ color: "#008389", textAlign: "center" }}>￥ {item.Price}/晚</Text>
                                                </View>

                                                <View style={{ flex: 2, alignItems: 'flex-end', }}>
                                                    <Button
                                                        style={styles.Button}
                                                        styleDisabled={{ color: 'red' }}
                                                        onPress={() => {
                                                            if (this.state.today === "选择时间" || this.state.next === "选择时间") {
                                                                ToastAndroid.showWithGravity('请选择入住离店时间!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                                                return;
                                                            }
                                                            let a = moment(this.state.nextTime);
                                                            let b = moment(this.state.tTime);
                                                            if (b.diff(a) < 0 && this.state.tTime) {
                                                                ToastAndroid.showWithGravity('请重新选择离店日期!', ToastAndroid.SHORT, ToastAndroid.CENTER);
                                                                return
                                                            }
                                                            let dataProps = this.props.navigation.state.params.data;
                                                            let data = {
                                                                code: dataProps.code,
                                                                Address: dataProps.Address,
                                                                Telephone: dataProps.Telephone,
                                                                selectRoom: item,
                                                                today: this.state.today,
                                                                next: this.state.next,
                                                                total: this.state.total,
                                                                beginTime: this.state.nextTime,
                                                                endTime: this.state.tTime,
                                                                bTime: this.state.bTime,
                                                            }

                                                            navigate("Order", { data });
                                                        }}>
                                                        预订
                                                    </Button>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                            )
                        }}

                    />
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    view: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: "#fff"
    },
    Timage: {
        flex: 1,
        width: 30,
        height: 30,
        position: "absolute",
        top: 10,
        left: 20,
        zIndex: 10
    },
    image: {
        flex: 1,
        width: 30,
        height: 30,
        position: "absolute",
    },
    select: {
        flex: 3,
        flexDirection: 'column',

        padding: 20
    },
    selectItem: {
        flex: 2,
        height: 50,
        flexDirection: 'row',
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
        paddingTop: 10
    },
    selectItemL: {
        flex: 2,
        height: 50,
        flexDirection: 'row',
        borderTopColor: "#f0f0f0",
        borderTopWidth: 1,
        paddingTop: 10,
        paddingBottom: 15,
    },
    foot: {
        flex: 6,
        marginTop: 10
    },
    Stext: {
        color: "#333333",
        fontSize: 16,
    },
    selectP: {
        flex: 8,
        height: 50,
        flexDirection: 'row',
    },
    selectTotal: {
        flex: 1,
        height: 50,
        flexDirection: 'row',

    },
    selectT: {
        flex: 1,
        height: 40,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingRight: 5,
        marginTop: 10
    },
    selectO: {
        flex: 1,
        marginTop: 10
    },
    selectTwo: {
        flex: 10,
        paddingTop: 5,
        height: 40,
        flexDirection: 'column',
        justifyContent: 'center',
    },
    positionO: {
        width: 250,
        textAlign: "left",
        color: "#008389",
        fontSize: 12
    },
    positionT: {
        flex: 1,
        fontSize: 10,
        textAlign: "left"
    },
    date: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    Button: {
        fontSize: 14,
        color: 'white',
        backgroundColor: "#008389",
        borderRadius: 5,
        height: 25,
        paddingTop: 3,
        width: 45
    }
})