/*
 * @page:   Order 订单确认页面
 * @Author: Han 
 * @Date: 2017-09-12 18:19:39 
 * @Last Modified by: Han
 * @Last Modified time: 2017-09-18 10:03:56
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, Dimensions, StyleSheet, TouchableOpacity, Image, ToastAndroid, Modal, TextInput, Picker } from 'react-native';
import Button from 'react-native-button';
import ActionSheet from 'antd-mobile/lib/action-sheet';
import icon from '../images/img';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

class Pay extends Component {
    static navigationOptions = {
        title: '支付订单',
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            pay: 1
        }
    }

    _back() {
        const { navigate, goBack } = this.props.navigation;
        goBack();
    }
    submit = () => {

    }
    render() {
        const { navigate } = this.props.navigation;
        return (
            <View style={styles.order}>
                <View style={{ flexDirection: 'row', alignItems: 'center', height: 30, backgroundColor: "white" }}>
                    <TouchableOpacity onPress={this._back.bind(this)} style={{ flex: 1, marginLeft: 10 }}>
                        <Image
                            source={{ uri: icon.backX }}
                            style={{ height: 20, width: 20 }}
                        />
                    </TouchableOpacity>
                    <Text style={{ textAlign: 'center', fontSize: 16, flex: 1, marginLeft: -5 }}>支付订单</Text>
                    <View style={{ flex: 1 }}></View>
                </View>
                <View style={styles.header}>
                    <View style={styles.headerText}>
                        <Text style={{ fontSize: 16 }}>宁波南部商务店</Text>
                        <Text style={{ fontSize: 10 }}>高级套房</Text>
                        <Text style={{ fontSize: 14 }}>入住 8月29日  离店 8月30日   共1晚</Text>
                    </View>
                </View>
                <View style={styles.content}>
                    <Text style={{ color: "#999", paddingBottom: 10, borderBottomColor: "#ccc", borderBottomWidth: 1 }}>选择支付方式</Text>
                    <TouchableOpacity
                        style={{ height: 50, borderBottomColor: "#ccc", borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center', }}
                        onPress={() => {
                            this.setState({ pay: 1 });
                        }}
                    >
                        <Image
                            source={require("../images/wrChat.png")}
                        />
                        <Text style={{ flex: 7, marginLeft: 10 }}>微信支付</Text>
                        <View>
                            {this.state.pay === 1 ?
                                <Image
                                    source={{ uri: icon.ok }}
                                    style={{ width: 20, height: 20 }}
                                /> : null
                            }
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={{ height: 50, borderBottomColor: "#ccc", borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center', }}
                        onPress={() => {
                            this.setState({ pay: 2 });
                        }}
                    >
                        <Image
                            source={require("../images/Alipay.png")}
                        />
                        <Text style={{ flex: 7, marginLeft: 10 }}>支付宝支付</Text>
                        <View>
                            {this.state.pay === 2 ?
                                <Image
                                    source={{ uri: icon.ok }}
                                    style={{ width: 20, height: 20 }}
                                /> : null
                            }
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={styles.foot}>
                    <Text style={{ flex: 2 }}>支付总价： <Text style={{ color: "#008389" }}>￥610</Text></Text>
                    <Button
                        style={{ height: 30, width: 70, fontSize: 12, backgroundColor: "#008389", color: "white", paddingTop: 7, borderRadius: 5 }}
                        onPress={this.submit}
                    >
                        立即支付
                    </Button>
                </View>
            </View >
        );
    }
}

const styles = StyleSheet.create({
    order: {
        height: height,
        width: width,
        flex: 1,
        flexDirection: 'column',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        height: 100,
        width: width,
        backgroundColor: "#D8EBEC",
        padding: 5,
    },
    headerText: {
        flex: 1,
        width: width,
        height: 90,
        flexDirection: 'column',
        backgroundColor: "white",
        borderRadius: 5,
        justifyContent: 'space-around',
        padding: 10
    },
    content: {
        flexDirection: 'column',
        width: width,
        backgroundColor: "white",
        height: height - 210,
        padding: 10
    },
    foot: {
        flex: 1,
        width: width,
        height: 80,
        flexDirection: 'row',
        borderTopColor: "#CCC",
        borderTopWidth: 1,
        backgroundColor: "white",
        alignItems: 'center',
        padding: 10
    },
    contentItem: {
        height: 50,
        flexDirection: 'row',
        borderBottomColor: "#CCC",
        borderBottomWidth: 1,
        alignItems: 'center',
    }
});

export default Pay;