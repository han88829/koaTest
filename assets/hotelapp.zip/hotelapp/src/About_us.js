/*
 * @page:   关于我
 * @Author: Han 
 * @Date: 2017-09-12 18:19:39 
 * @Last Modified by: Han
 * @Last Modified time: 2017-10-17 15:36:55
 */
import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import icon from './images/img'

export default class About extends Component {
  static navigationOptions = {
    title: '关于我们！',
    header: null
  };
  render() {
    const { goBack } = this.props.navigation;
    return (
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center', padding: 5, backgroundColor: "#fafafa" }}>
        <View style={{ height: 44, flexDirection: 'row', backgroundColor: "#fff", paddingTop: 10 }}>
          <TouchableOpacity
            style={{ flex: 1, paddingLeft: 10, height: 44, paddingTop: 12 }}
            underlayColor="rgba(204, 204, 204, 0)"
            onPress={() => {
              goBack()
            }}
          >
            <Image
              source={{ uri: icon.backX }}
              style={{ height: 20, width: 20, }}
            />
          </TouchableOpacity>
          <View style={{ flex: 2 }}>
            <Text style={{ textAlign: "center", fontSize: 16, color: "#333", marginLeft: -10 }}>关于我们</Text>
          </View>
          <View style={{ flex: 1 }}>

          </View>
        </View>

        <View style={{ flex: 7, alignItems: 'center', marginTop: 30, padding: 20 }}>
          <Image
            source={require("./images/logo.png")}
            style={{ width: 130, height: 25 }}
          />
          <Text style={{ textAlign: "center", marginTop: 10, color: "#333", fontSize: 12 }}>版本号：0.0.2</Text>
          <Text style={{ marginTop: 10, color: "#333", fontSize: 14 }}>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 我们是专为酒店管理系统输出的互联网团队，专为酒店管理系统输出的互联网团队， 专为酒店管理系统输出的互联网团队！
          </Text>
        </View>
      </View >
    );
  }
}