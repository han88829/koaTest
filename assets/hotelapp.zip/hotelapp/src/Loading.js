import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, Dimensions } from 'react-native';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

class Loading extends Component {
    static navigationOptions = {
        title: "loading",
        header: null
    };
    componentDidMount() {
        const { navigate } = this.props.navigation;
        let timer = setTimeout(() => {
            navigate("App");
            clearTimeout(timer);
        }, 1000)
    }

    render() {
        return (
            <View style={styles.loading}>
                <Image
                    source={require("./images/loading.png")}
                />
                <Image
                    source={require("./images/logo.png")}
                    style={styles.image}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    loading: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        position: "relative"
    },
    image: {
        position: "absolute",
        bottom: 10
    }
})

export default Loading;